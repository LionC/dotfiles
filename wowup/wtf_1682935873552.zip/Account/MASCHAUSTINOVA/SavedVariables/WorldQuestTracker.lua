
WQTrackerDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Farfarella - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["quests_tracked"] = {
				["Player-580-0A021747"] = {
				},
				["Player-580-0A1B4033"] = {
				},
			},
			["player_names"] = {
				["Player-580-0A021747"] = {
					["class"] = "MAGE",
					["name"] = "Taifunari",
					["realm"] = "Blackmoore",
				},
				["Player-580-0A1B4033"] = {
					["class"] = "DRUID",
					["name"] = "Farfarella",
					["realm"] = "Blackmoore",
				},
			},
		},
	},
}
