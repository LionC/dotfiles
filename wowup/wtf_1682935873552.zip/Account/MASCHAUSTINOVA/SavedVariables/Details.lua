
_detalhes_global = {
	["encounter_spell_pool"] = {
		{
			2637, -- [1]
			"Granyth", -- [2]
		}, -- [1]
		[382267] = {
			2580, -- [1]
			"Balara", -- [2]
		},
		[196809] = {
			2606, -- [1]
			"Divine Image <Syreht-Nazjatar>", -- [2]
		},
		[374711] = {
			2580, -- [1]
			"Balara", -- [2]
		},
		[371981] = {
			2605, -- [1]
			"[*] Elemental Surge", -- [2]
		},
		[196810] = {
			2606, -- [1]
			"Divine Image <Syreht-Nazjatar>", -- [2]
		},
		[381602] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[375792] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[374554] = {
			2605, -- [1]
			"[*] Magma Pool", -- [2]
		},
		[372808] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[392398] = {
			2623, -- [1]
			"Primal Thundercloud", -- [2]
		},
		[374623] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[375825] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[384620] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[392399] = {
			2623, -- [1]
			"Primal Thundercloud", -- [2]
		},
		[376683] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[373004] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[396056] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[381605] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[374779] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[395893] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[32409] = {
			2605, -- [1]
			"[*] Shadow Word: Death", -- [2]
		},
		[374621] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[376685] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[375828] = {
			2605, -- [1]
			"Blazing Fiend", -- [2]
		},
		[381864] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[396212] = {
			2605, -- [1]
			"[*] Chilling Presence", -- [2]
		},
		[384687] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[374432] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[372963] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[381862] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[381513] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[372147] = {
			2580, -- [1]
			"Balara", -- [2]
		},
		[376725] = {
			2580, -- [1]
			"Nokhud Stormcaster", -- [2]
		},
		[321538] = {
			2605, -- [1]
			"Nomnom", -- [2]
		},
		[381514] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[375929] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[388817] = {
			2637, -- [1]
			"Granyth", -- [2]
		},
		[374625] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[382277] = {
			2580, -- [1]
			"Balara", -- [2]
		},
		[382563] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[385389] = {
			2637, -- [1]
			"[*] Shockwave", -- [2]
		},
		[384024] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[391711] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[382564] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[384628] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[384773] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[381517] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[376723] = {
			2580, -- [1]
			"Nokhud Stormcaster", -- [2]
		},
		[374215] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376660] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[374025] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[373803] = {
			2609, -- [1]
			"Infused Whelp", -- [2]
		},
		[386916] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[372851] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[384186] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[196816] = {
			2606, -- [1]
			"Divine Image <Syreht-Nazjatar>", -- [2]
		},
		[374217] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[381607] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[371489] = {
			2609, -- [1]
			"Flashfrost Chillweaver", -- [2]
		},
		[388283] = {
			2637, -- [1]
			"Granyth", -- [2]
		},
		[390920] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376644] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[384823] = {
			2606, -- [1]
			"Blazebound Firestorm <Kokia Blazehoof>", -- [2]
		},
		[376727] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[3110] = {
			2605, -- [1]
			"Zignik", -- [2]
		},
		[396222] = {
			2605, -- [1]
			"[*] Shattering Presence", -- [2]
		},
		[384316] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[397077] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[384761] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[373681] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[390921] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[373046] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[376634] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[395894] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[373087] = {
			2606, -- [1]
			"Blazebound Firestorm <Kokia Blazehoof>", -- [2]
		},
		[376730] = {
			2580, -- [1]
			"[*] Stormwinds", -- [2]
		},
		[374624] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[384185] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[381525] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[385558] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[376827] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[372858] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[373017] = {
			2606, -- [1]
			"Blazebound Firestorm <Kokia Blazehoof>", -- [2]
		},
		[376732] = {
			2580, -- [1]
			"[*] Stormwinds", -- [2]
		},
		[396068] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[372859] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[376864] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[372158] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376892] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[372860] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[376829] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[374022] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[374691] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[397338] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[375824] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[374427] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[397341] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[374430] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[374428] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[374622] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[396072] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[372863] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[390548] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376737] = {
			2580, -- [1]
			"[*] Lightning", -- [2]
		},
		[374705] = {
			2605, -- [1]
			"Earth Breaker", -- [2]
		},
		[381526] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[375937] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[376865] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[396201] = {
			2605, -- [1]
			"[*] Blistering Presence", -- [2]
		},
		[396233] = {
			2605, -- [1]
			"[*] Thundering Presence", -- [2]
		},
		[386921] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[376866] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[374485] = {
			2605, -- [1]
			"Blazing Fiend", -- [2]
		},
		[52042] = {
			2605, -- [1]
			"Healing Stream Totem <Fengala-DieArguswacht>", -- [2]
		},
		[381512] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[396044] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[385916] = {
			2637, -- [1]
			"Granyth", -- [2]
		},
		[396241] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[383925] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[373678] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[396077] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[396243] = {
			2605, -- [1]
			"[*] Primal Attunement", -- [2]
		},
		[381518] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[384686] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[372456] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[372107] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
	},
	["immersion_pets_on_solo_play"] = false,
	["npcid_ignored"] = {
	},
	["report_where"] = "SAY",
	["report_pos"] = {
		1, -- [1]
		1, -- [2]
	},
	["latest_report_table"] = {
	},
	["exp90temp"] = {
		["delete_damage_TCOB"] = true,
	},
	["always_use_profile"] = false,
	["deathlog_healingdone_min_arena"] = 400,
	["spell_school_cache"] = {
		["Stormslam"] = 8,
		["Hailbombs"] = 16,
		["Biting Chill"] = 16,
		["Sundering Strike"] = 28,
		["Searing Carnage"] = 4,
		["Rampage"] = 1,
		["Freezing Tempest"] = 16,
		["Main Gauche"] = 1,
		["Static Spear"] = 8,
		["Lava"] = 4,
		["Ravager"] = 1,
		["Thunder Strike"] = 8,
		["Infernocore"] = 4,
		["Ambush"] = 1,
		["Chillstorm"] = 16,
		["Sinister Strike"] = 1,
		["Lightning Strike"] = 8,
		["The Raging Tempest"] = 8,
		["Elemental Surge"] = 28,
		["Absolute Zero"] = 16,
		["Iron Stampede"] = 1,
		["Life Link"] = 1,
		["Crackling Detonation"] = 8,
		["Ground Shatter"] = 8,
		["Searing Wounds"] = 1,
		["Primal Attunement"] = 28,
		["Shockwave"] = 8,
		["Gale Arrow"] = 8,
		["Stormwinds"] = 8,
		["Frost Dominance"] = 16,
		["Chilling Presence"] = 16,
		["Roaring Firebreath"] = 4,
		["Execute"] = 1,
		["Flamespit"] = 4,
		["Iron Spear"] = 1,
		["Bloodbath"] = 1,
		["Instant Poison"] = 8,
		["Electrical Storm"] = 8,
		["Winds of Change"] = 8,
		["Flaming Embers"] = 4,
		["Corpo-a-Corpo"] = 1,
		["Ravaging Spear"] = 1,
		["Melee"] = 1,
		["Searing Blows"] = 1,
		["Lethal Current"] = 8,
		["Magma Burst"] = 4,
		["Blistering Presence"] = 4,
		["Flame Dominance"] = 4,
		["Shattering Presence"] = 8,
		["Earth Dominance"] = 8,
		["Lightning"] = 8,
		["Shadow Word: Death"] = 32,
		["Storm Dominance"] = 8,
		["Shocking Burst"] = 8,
		["Energy Surge"] = 8,
		["Thundering Presence"] = 8,
		["Erupting Bedrock"] = 8,
		["Magma Pool"] = 4,
		["Violent Upheaval"] = 8,
		["Corporeal Tear"] = 64,
	},
	["deathlog_healingdone_min"] = 1,
	["plater"] = {
		["realtime_dps_enabled"] = false,
		["damage_taken_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_shadow"] = true,
		["damage_taken_enabled"] = false,
		["realtime_dps_player_size"] = 12,
		["damage_taken_size"] = 12,
		["realtime_dps_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_size"] = 12,
		["damage_taken_shadow"] = true,
		["damage_taken_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_enabled"] = false,
		["realtime_dps_shadow"] = true,
	},
	["show_warning_id1_amount"] = 2,
	["current_exp_raid_encounters"] = {
		[2605] = true,
	},
	["keystone_frame"] = {
		["scale"] = 1,
		["position"] = {
		},
	},
	["show_totalhitdamage_on_overkill"] = false,
	["trinket_data"] = {
		[394453] = {
			["lastPlayerName"] = "Xaani",
			["maxTime"] = 143.4789998531342,
			["averageTime"] = 63,
			["activations"] = 16,
			["totalCooldownTime"] = 1009.141999721527,
			["lastCombatId"] = 1828,
			["minTime"] = 40.68400001525879,
			["lastActivation"] = 1675298698.996,
			["spellName"] = "Broodkeeper's Blaze",
		},
		[385903] = {
			["lastPlayerName"] = "Mothman",
			["maxTime"] = 72.57399988174438,
			["averageTime"] = 52,
			["activations"] = 3,
			["totalCooldownTime"] = 157.1579999923706,
			["lastCombatId"] = 1813,
			["minTime"] = 41.43400001525879,
			["lastActivation"] = 1675298524.019,
			["spellName"] = "Crystal Sickness",
		},
		[382426] = {
			["lastPlayerName"] = "Thiril",
			["maxTime"] = 49.76999998092651,
			["averageTime"] = 44,
			["activations"] = 4,
			["totalCooldownTime"] = 179.684999704361,
			["lastCombatId"] = 1830,
			["minTime"] = 40.30799984931946,
			["lastActivation"] = 1675298771.098,
			["spellName"] = "Spiteful Stormbolt",
		},
		[214052] = {
			["lastPlayerName"] = "Vygosa",
			["maxTime"] = 46.77000021934509,
			["averageTime"] = 43,
			["activations"] = 2,
			["totalCooldownTime"] = 87.79500031471252,
			["lastCombatId"] = 1859,
			["minTime"] = 41.02500009536743,
			["lastActivation"] = 1675437491.097,
			["spellName"] = "Fel Meteor",
		},
		[388755] = {
			["lastPlayerName"] = "Létizia-Baelgun",
			["maxTime"] = 143.0230000019074,
			["averageTime"] = 66,
			["activations"] = 21,
			["totalCooldownTime"] = 1396.574000358582,
			["lastCombatId"] = 1866,
			["minTime"] = 40.11199998855591,
			["lastActivation"] = 1675437920.281,
			["spellName"] = "Soulseeker Arrow",
		},
		[388739] = {
			["lastPlayerName"] = "Esme-Lordaeron",
			["maxTime"] = 40.3420000076294,
			["averageTime"] = 40,
			["activations"] = 1,
			["totalCooldownTime"] = 40.3420000076294,
			["lastCombatId"] = 1830,
			["minTime"] = 40.3420000076294,
			["lastActivation"] = 1675298771.389,
			["spellName"] = "Pure Decay",
		},
		[397376] = {
			["lastPlayerName"] = "Nêrdnuss",
			["maxTime"] = 158.8300001621246,
			["averageTime"] = 93,
			["activations"] = 7,
			["totalCooldownTime"] = 656.4219999313354,
			["lastCombatId"] = 1810,
			["minTime"] = 45.78399991989136,
			["lastActivation"] = 1675298458.97,
			["spellName"] = "Burning Embers",
		},
	},
	["global_plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["encounter_timers_bw"] = {
			},
			["encounter_timers_dbm"] = {
			},
		},
	},
	["update_warning_timeout"] = 10,
	["keystone_cache"] = {
	},
	["raid_data"] = {
	},
	["always_use_profile_name"] = "",
	["profile_by_spec"] = {
	},
	["combat_id_global"] = 1866,
	["displays_by_spec"] = {
	},
	["plugin_window_pos"] = {
		["y"] = 4.1961669921875e-05,
		["x"] = 0.00023651123046875,
		["point"] = "CENTER",
		["scale"] = 1,
	},
	["last_changelog_size"] = 8383,
	["immersion_unit_special_icons"] = true,
	["lastUpdateWarning"] = 1674136196,
	["npcid_pool"] = {
		[188230] = "Nokhud Raider",
		[34366] = "Warsong Vanguard",
		[193857] = "Elusive Proto Dragon",
		[189893] = "Infused Whelp",
		[97632] = "Crusher",
		[195264] = "Darktooth Battler",
		[188231] = "Nokhud Stormlasher",
		[97057] = "Overseer Brutarg",
		[195265] = "Stormcaller Arynga",
		[93221] = "Doom Commander Beliash",
		[186570] = "Lava Elemental",
		[189895] = "Primalist Infiltrator",
		[192325] = "Stone Shackles",
		[187338] = "Time-Charged Salamanther",
		[27829] = "Ebon Gargoyle <Zenarkos>",
		[97058] = "Count Nefarious",
		[27893] = "Rune Weapon <Cairnren>",
		[195267] = "Darktooth Spirit-Caller",
		[187211] = "Galestrike Proto-Dragon",
		[101406] = "Fel Spirit <[*] Fel Spirit>",
		[192582] = "Dragonbane Soldier",
		[61029] = "Primal Fire Elemental <Àsáy>",
		[194884] = "Shela the Windbinder",
		[186828] = "Hornswog",
		[100703] = "Leeching Spider",
		[191560] = "Oozing Decay",
		[186573] = "Restless Lava",
		[186701] = "Summoned Scalebiter",
		[97059] = "King Voras",
		[195269] = "Darktooth Skirmisher",
		[195397] = "Shiverweb Cloaker",
		[192456] = "Primalist Springfeeder",
		[77942] = "Primal Storm Elemental <Lucijá>",
		[192968] = "Oozing Decay",
		[195270] = "Darktooth Stalker",
		[185168] = "Nokhud Brute",
		[192457] = "Augmented Flood",
		[92776] = "Fel Shocktrooper",
		[187598] = "Rohzor Forgesmash",
		[191051] = "Nimblewing Slyvern",
		[186064] = "Shiverweb Queen",
		[187599] = "Qalashi Bonebreakers",
		[195272] = "Darktooth Renderer",
		[187600] = "Qalashi Stonemender",
		[96997] = "Kethrazor",
		[185810] = "Shiverweb Crawler",
		[196168] = "Springs Heater",
		[195273] = "Darktooth Howler",
		[95463] = "Living Flame",
		[192972] = "Blizzard",
		[198343] = "Malfunctioning Protector",
		[198471] = "Flame Boiler <Vadne Bleakheart>",
		[191438] = "Graviton Sphere <Ezrigeth>",
		[187474] = "Spotted Rockfang",
		[187602] = "Qalashi Scaleripper",
		[185812] = "Shiverweb Spiderling",
		[193229] = "Henlare",
		[196426] = "Grotto Creeper",
		[192462] = "Summoned Downpour",
		[192718] = "Maiden of Diligence",
		[195915] = "Firava the Rekindler",
		[196171] = "Flame Boiler",
		[196555] = "Gladehorn Armoredon",
		[95848] = "Felsoul Ritualist",
		[191696] = "Mature Basilisk",
		[185814] = "Shiverweb Crusher",
		[191057] = "Thunderspine Crasher",
		[194254] = "Ohuna Companion",
		[188244] = "Primal Juggernaut",
		[191697] = "Ancient Basilisk",
		[194894] = "Primalist Stormspeaker",
		[135816] = "Vilefiend <Lysarii>",
		[194255] = "Bakar Companion",
		[192337] = "Void Tendril <Sellio>",
		[187478] = "Broadhoof Bull",
		[97959] = "Jace Darkweaver",
		[194895] = "Unstable Squall",
		[190931] = "Tamed Vulture",
		[191187] = "Savage Wasp",
		[62982] = "Mindbender <Schâttenfêll>",
		[192466] = "Thornsided Basilisk",
		[189653] = "Snowhide Brute",
		[194896] = "Primal Stormshield",
		[191955] = "Blacktalon Assassin <Tinzigwinzig>",
		[96681] = "Ash'golm",
		[187352] = "Tarasek Warrior",
		[193618] = "Restless Rocks",
		[189654] = "Snowhide Shaman",
		[194897] = "Stormsurge Totem",
		[190294] = "Nokhud Stormcaster",
		[194898] = "Primalist Arcblade",
		[194003] = "Queasy Hornswog",
		[96682] = "Immolanth",
		[192341] = "Qalashi Drakeflayer",
		[191446] = "Qalashi Scoundrel",
		[92782] = "Savage Felstalker",
		[189656] = "Snowhide Mongrel",
		[180705] = "Magmammoth Calf",
		[191319] = "Ancient Splinter <Unbound Attendant>",
		[143622] = "Wild Imp <Sanyi>",
		[196051] = "Arcane Portal <Uncontrolled Guardian>",
		[97706] = "Fel Weaver",
		[194517] = "Crushing Elemental",
		[195668] = "Slavering Snapdragon",
		[187868] = "Molten Uprising",
		[186206] = "Cruel Bonecrusher",
		[188509] = "Tombcaller Ganzaya",
		[98986] = "Prolifica",
		[189149] = "Discordant Watcher",
		[190428] = "Snowhide Yeti Hunter",
		[188510] = "Risen Bakar",
		[195927] = "Soulharvester Galtmaa",
		[51987] = "Deadwind Widow",
		[188511] = "Nokhud Desecrator",
		[195928] = "Soulharvester Duuren",
		[97069] = "Wrath-Lord Lekos",
		[93105] = "Inquisitor Baleful",
		[195417] = "Tsokorg",
		[186338] = "Maruuk",
		[186594] = "Dragonbane Protector",
		[96494] = "Felguard Butcher",
		[190047] = "Tombcaller Arban",
		[193244] = "Titan Defense Matrix",
		[190303] = "Murloc You",
		[194523] = "Raging Elemental",
		[195674] = "Agitated Initiate <Yakuri-Onyxia>",
		[195930] = "Soulharvester Mandakh",
		[190943] = "Ravine Vulture",
		[185445] = "Nokhud Scavenger",
		[155906] = "Beast <Bebee>",
		[193885] = "Salkii",
		[192223] = "Zaphil the Defiant",
		[198489] = "Denizen of the Dream <Smásher>",
		[191712] = "Hissing Springsoul",
		[186725] = "Trrsha",
		[190945] = "Primalist Stormfury",
		[3527] = "Healing Stream Totem <Kanduk>",
		[192352] = "Shadepaw Trainer",
		[34917] = "Invading Tendril",
		[190690] = "Thundering Ravager",
		[189795] = "Unsettled Rubble",
		[196061] = "Arcane Detritus <Uncontrolled Guardian>",
		[192225] = "Dihar the Unyielding",
		[187366] = "Worldcarver Wurmling",
		[186599] = "Dragonbane Firebinder",
		[186727] = "Qalashi Rampager",
		[190947] = "Altered Wymling",
		[198236] = "Divine Image <Toute>",
		[192226] = "Ganmat the Wise",
		[100333] = "Skittering Broodling",
		[193505] = "Sickly Pilferer",
		[186600] = "Dragonbane Protector",
		[194912] = "Magmammoth Breaker",
		[197086] = "Berserk Proto-Drake",
		[193378] = "Leapmaize Ambusher",
		[195552] = "Bruffalon Bull",
		[192739] = "Feasting Wyrm",
		[197982] = "Storm Warrior",
		[100334] = "Tyranna's Spawn",
		[187625] = "Stonegrabber Fragment",
		[188009] = "Grand Flame",
		[99759] = "Fiendish Creeper",
		[186219] = "Weaponmaster Vordak",
		[94836] = "Varedis Felsoul",
		[15467] = "Omen",
		[189928] = "Ukhel Gravestirrer",
		[191335] = "Trembling Earth",
		[97330] = "Raxx",
		[58959] = "Zeple <Dryade-Arakarahm>",
		[196834] = "Relothina",
		[191847] = "Nokhud Plainstomper",
		[188011] = "Primal Terrasentry",
		[195300] = "Arkhuu",
		[187244] = "Time-Lost Destroyer",
		[192487] = "Lulu",
		[196835] = "Huntmaster Kroshk",
		[190953] = "Sunhide Stomphoof",
		[2630] = "Earthbind Totem <Lapuch-Tichondrius>",
		[190186] = "Primalist Magmashaper",
		[191337] = "Stone Vanguard",
		[95285] = "Fel Commander Igrius",
		[98482] = "Foul Felstalker",
		[181875] = "Olphis the Molten",
		[196581] = "White Tiger Statue <Chushk>",
		[186479] = "Timeling",
		[192745] = "Seismic Force",
		[193896] = "Borzgas",
		[187886] = "Turboris",
		[188014] = "Pitchstone Rumbler",
		[190188] = "Shadepaw Skulker",
		[195431] = "Diluu",
		[58960] = "Metaros",
		[98483] = "Hellish Imp",
		[17252] = "Skelshril",
		[183923] = "Gnoll Invader",
		[191212] = "Earthquake Totem",
		[198757] = "Void Lasher <Agnosie-Hyjal>",
		[186609] = "Dragonbane Shieldcracker",
		[195177] = "Proto Dragon",
		[192236] = "Alerted Stormsmith <Allegory>",
		[191341] = "Kindled Fury",
		[97333] = "Magolith",
		[98484] = "Mo'arg Brute",
		[187889] = "Shattered Fragment",
		[197224] = "Tamed Magmammoth Calf",
		[192237] = "Alerted Goliath <Yakuri-Onyxia>",
		[191342] = "Winged Ruin",
		[187506] = "Stonegrabber Shard",
		[186611] = "Restless Lava",
		[97014] = "Vile Soulmaster",
		[197225] = "Transformed Dreadsquall",
		[192238] = "Agitated Essence",
		[97334] = "Kurloth",
		[193645] = "Crystalus",
		[186612] = "Wyrmeater",
		[190960] = "Feasting Buzzard",
		[196459] = "Brackenhide Scrapper",
		[196971] = "Rendvith",
		[190961] = "Mudwalker Salamanther",
		[93115] = "Foul Felstalker",
		[193647] = "Karantun",
		[194798] = "Colossal Glacier",
		[189811] = "Agitated Keystone",
		[190962] = "Nokhud Warhound",
		[197356] = "High Shaman Rotknuckle",
		[186359] = "Brackenhide Scrapper",
		[186615] = "The Raging Tempest",
		[196973] = "Kerzanthi",
		[187894] = "Infused Whelp",
		[95226] = "Anguish Jailer",
		[194544] = "Konkhular",
		[185465] = "Nokhud Wardog",
		[185593] = "Worldbreaker Shapist",
		[195184] = "Defense Orb",
		[190325] = "Barkback Yeti",
		[186361] = "Rotting Treant",
		[195696] = "Primalist Thunderbeast",
		[185594] = "Worldbreaker Guard",
		[189814] = "Cliffdrip Wavemender",
		[190965] = "Nokhud Vulture",
		[191221] = "Nokhud Skirmisher",
		[186362] = "Brackenhide Rotflinger",
		[186490] = "Shadepaw Hunter",
		[188664] = "Rustpine Loamcrafter",
		[189815] = "Cliffdrip Fallstriker",
		[187897] = "Defier Draghar",
		[89] = "Infernal <Kitsume-C'Thun>",
		[194291] = "Primal Stonekin",
		[189304] = "Overcharged Mana Entity",
		[188665] = "Stonegrabber Fragment",
		[114409] = "Abyssal Riftbreaker",
		[92990] = "Sledge",
		[191479] = "Charred Hornspike",
		[190584] = "Time-Lost Murloc",
		[186620] = "Lava Crawler",
		[35159] = "Krom'gar Witch Doctor",
		[198385] = "Fragmented Energy",
		[194290] = "Feral Bakar",
		[195984] = "Auburntusk Bull",
		[99541] = "Risen Skulker",
		[192759] = "Gorger",
		[34969] = "Corrupted Sentinel",
		[187900] = "Nokhud Marauder",
		[193143] = "Razk'vex the Untamed",
		[26125] = "Felshäscher",
		[40229] = "Scalding Rock Elemental",
		[38896] = "Blazebound Elemental",
		[190586] = "Earth Breaker",
		[40123] = "Twilight Overseer",
		[38913] = "Twilight Vanquisher",
		[181763] = "Lava Phoenix",
		[38926] = "Twilight Flamecaller",
		[24207] = "Army of the Dead|T1392565:0|t <Donfrostis>",
		[191354] = "Ty'foon the Ascended",
		[188413] = "Water Fury",
		[8960] = "Felpaw Scavenger",
		[200945] = "Nokhud Warmonger",
		[114411] = "Infernal Siegebreaker",
		[187902] = "Nokhud Marauder",
		[191099] = "Overzealous Bloom",
		[191227] = "Nokhud Spearman",
		[193401] = "Snowscruff Bakar",
		[15466] = "Minion of Omen",
		[191611] = "Dragonhunter Igordan",
		[186624] = "Bound Spark",
		[185660] = "Cygenoth",
		[185596] = "Worldbreaker Bulwark",
		[186110] = "Djaradin Crustshaper",
		[186113] = "Nokhud Raider",
		[195448] = "Blazing Firesquall",
		[186369] = "Unleashed Floodwater",
		[185691] = "Vicious Hyena",
		[187079] = "Convoked Tremor",
		[189822] = "Shas'ith",
		[190932] = "Warmonger Kharad",
		[183940] = "Silithid Ravager",
		[191229] = "Primalist Stormfury",
		[187265] = "Time-Lost Geomancer",
		[187393] = "Displaced Earth",
		[192636] = "Wild Proto-Drake",
		[95423] = "Felsoul Berserker",
		[189823] = "Ravenous Nestling",
		[187262] = "Time-Lost Devilsaur",
		[101753] = "Soul Fragment <Vile Soulmaster>",
		[186115] = "Frostspike Guardian",
		[189312] = "Calving Elemental",
		[201562] = "Shardwing",
		[184453] = "Brutal Motivator",
		[19668] = "Shadowfiend <Laríía>",
		[186109] = "Qalashi Necksnapper",
		[189812] = "Cliffdrip Snapstrider",
		[195195] = "Highland Mammoth Bull",
		[193394] = "Mosshair Bull",
		[188542] = "Brackenhide Deadeye",
		[191487] = "Stone Pillar <Ezrigeth>",
		[58965] = "Arax-barash",
		[186628] = "Bound Pebbles",
		[186756] = "Shikaar Bakar",
		[187907] = "Qalashi Bonebreaker",
		[185591] = "Worldbreaker Smith",
		[191570] = "Nokhud Spearthrower",
		[187617] = "Acequian",
		[185350] = "Ravenous Bloodbeak",
		[193766] = "Starving Proto-Drake",
		[195836] = "Rimebound Controller",
		[188803] = "Rustpine Rager",
		[187908] = "Qalashi Scaleripper",
		[183944] = "Therazane",
		[191233] = "Invading Stormling",
		[193407] = "Horned Plainstomper",
		[192640] = "Mountain Herdstallion",
		[184456] = "Spellforged Brute",
		[186630] = "Bound Stones",
		[103673] = "Darkglare <Feldasel>",
		[191083] = "Spider Eggs",
		[196540] = "Furious Flame",
		[99773] = "Bloodworm <Defamed-Nazjatar>",
		[190339] = "Horned Armoredon",
		[187745] = "Disoriented Watcher",
		[194402] = "Spellforged Destroyer",
		[195838] = "Cragsworn Stoneshaper",
		[193791] = "Sundered Mercenary",
		[191940] = "Qalashi Necksnapper",
		[193153] = "Ripsaw the Stalker",
		[191235] = "Invading Storm Elemental",
		[191363] = "Manifested Inferno",
		[185353] = "Nokhud Huntmaster",
		[191619] = "Mature Hornswog",
		[186632] = "Scalepiercer",
		[195967] = "Starving Snail",
		[192003] = "Bloodhorn",
		[188039] = "Muckjaw Basilisk",
		[187256] = "Time-Lost Raptor",
		[193232] = "Rasnar the War Ender",
		[188360] = "Glacial Tunneler",
		[96441] = "Fel Lord Caza",
		[195968] = "Angerdrool",
		[191876] = "Goruk Steelwall",
		[193214] = "Forgotten Creation",
		[58964] = "Hrogrogg",
		[100286] = "Lesser Minion",
		[192371] = "Qalashi Dusttwister",
		[191493] = "Revitalizing Red Carving <Butzzjunge>",
		[198390] = "Shattered Fragment <Turboris>",
		[190726] = "Striped Bruffalon",
		[196992] = "Arcane Elemental",
		[181775] = "Uncontrolled Guardian",
		[193725] = "Karkidan",
		[185595] = "Worldbreaker Cultist",
		[196336] = "Qalashi Flameslinger",
		[191494] = "Teerai Battlemaster",
		[184461] = "Tarasek Marauder",
		[195842] = "Ukhel Corruptor",
		[195970] = "Munchbeak Turtle",
		[190983] = "Qalashi Pillager",
		[102269] = "Felstalker Ravener",
		[197377] = "Alpha Skulking Scythid",
		[193738] = "Forkriver Bull",
		[185357] = "Nokhud Sentry",
		[193223] = "Vakril",
		[98497] = "Imp Mother",
		[195971] = "Luumak the Insatiable",
		[185869] = "Protoforged Creation <Vitricus>",
		[190686] = "Frozen Destroyer",
		[188171] = "Arcane Manipulator Tharohn",
		[190688] = "Blazing Fiend",
		[191496] = "Pinehoof Doe",
		[195969] = "Hungry Hungry Riverbeast",
		[195844] = "Windfiend",
		[199041] = "Arcane Brutality",
		[190985] = "Death's Shadow",
		[102270] = "Eredar Invader",
		[188172] = "Arcane Manipulator",
		[191678] = "Magmammoth Crusher",
		[194794] = "Restless Icicle",
		[194375] = "Seething Seakelp",
		[95429] = "Fist of the Deceiver",
		[194950] = "Centaur Fighter",
		[101695] = "Felsoul Obliterator",
		[199298] = "Qalashi Skullhauler",
		[188173] = "Sundered Sentinel",
		[186339] = "Teera",
		[187239] = "Time-Lost Sunseeker",
		[100992] = "Fel Visage",
		[195846] = "Unleashed Storm",
		[195974] = "The Red Gulper",
		[95046] = "Eredar Summoner",
		[191339] = "Guardian Riptide",
		[188174] = "Destructive Flames",
		[197509] = "Primal Thundercloud",
		[7379] = "Deadwind Ogre Mage",
		[69791] = "Fire Spirit <Fikin>",
		[186859] = "Worldcarver A'tir",
		[195975] = "The Black Gulper",
		[187919] = "Caldera Stomper",
		[190484] = "Kyrakka",
		[193290] = "Magma Bubble",
		[197815] = "Hungry Muckjaw Basilisk",
		[114407] = "Spellstalker",
		[100993] = "Felblade Assassin",
		[187487] = "Spotted Prowler",
		[195976] = "The Blue Gulper",
		[186483] = "Qalashi Steelcrafter",
		[102272] = "Felguard Destroyer",
		[195337] = "Chief Dead Eye",
		[97285] = "Wind Rush Totem <Maplebaomn>",
		[108655] = "Spawn of Serpentrix <Demonea-Lordaeron>",
		[101505] = "Savage Felstalker",
		[192486] = "Lela",
		[189886] = "Blazebound Firestorm <Kokia Blazehoof>",
		[190214] = "Deathling Destroyer",
		[193722] = "Tomnu",
		[194315] = "Stormcaller Solongo",
		[191328] = "Ensnaring Current",
		[196617] = "Binding Ice <Scahra>",
		[186515] = "Hyenamaster Durgun",
		[187666] = "Ezrigeth",
		[186724] = "Qalashi Flamemaster",
		[190991] = "Char",
		[102273] = "Doomguard Infiltrator",
		[194316] = "Stormcaller Zarii",
		[194444] = "Wild Proto-Drake",
		[186616] = "Granyth",
		[193677] = "Maeleera",
		[195851] = "Ukhel Deathspeaker",
		[175519] = "Frothing Pustule",
		[187923] = "Lava Hatchling",
		[195314] = "Deathwingurlugull",
		[192776] = "Sunscale Snapper",
		[193674] = "Voraazka",
		[190780] = "Arcane Elemental",
		[193678] = "Fieraan",
		[190737] = "Earthenforged Invader",
		[163366] = "Magus of the Dead <Dívínus>",
		[110063] = "Beast <Aycicx>",
		[189373] = "Divebeak Ohuna",
		[188180] = "Koroleth",
		[190205] = "Scorchling",
		[186965] = "Smoldering Feather <Lava Phoenix>",
		[193679] = "Leerain",
		[190738] = "Primalsworn Furbolg",
		[193723] = "Mossy Armoredon",
		[186902] = "Reservoir Invader",
		[186516] = "Trap-Layer Kerwal",
		[197352] = "Alpha Thornsided Basilisk",
		[198919] = "Arcane Remnant <Spellforged Destroyer>",
		[186391] = "Vicious Ice Slitherer",
		[190611] = "Frenzied Pollenstag",
		[188693] = "Boneshaper Jardak",
		[186607] = "Dragonbane Soldier",
		[190995] = "Primal Watercaller",
		[191679] = "Magmammoth Bull",
		[189557] = "Qalashi Boltthrower",
		[187672] = "Rustfang Creeper",
		[191507] = "Gragza the Dragon-Breaker",
		[191318] = "Tidal Defender",
		[195855] = "Risen Warrior",
		[192914] = "Frostfoot Yeti",
		[196111] = "Pit Lord <Alhaz>",
		[184986] = "Kurog Grimtotem",
		[0] = "[*] Shadow Word: Death",
		[416] = "Rupuri",
		[190485] = "Erkhart Stormvein",
		[193682] = "Rouen Icewind",
		[197902] = "Lava Elemental",
		[417] = "Khuughon",
		[187928] = "Lava Phoenix <Qalashi Scaleripper>",
		[186736] = "Flame Sentry",
		[97225] = "Wrathguard Legate",
		[195092] = "Hydraulic Eroder",
		[189463] = "Riverback Rambler",
		[191637] = "Lava Phoenix",
		[193790] = "Sundered Supplyhand",
		[197814] = "Hungry Slyvern Matriarch",
		[102724] = "Vile Soulmaster",
		[191626] = "Ancient Gryphon",
		[192789] = "Nokhud Longbow",
		[186191] = "Decay Speaker",
		[195319] = "Ageless Rockfang",
		[191677] = "Magmammoth Calf",
		[181536] = "Destabilized Elemental",
		[97034] = "Fury Champion",
		[194068] = "Humid Drizzle",
		[185534] = "Bonebolt Hunter",
		[96680] = "Glazer",
		[69792] = "Earth Spirit <Fikin>",
		[189465] = "Riverback Stomper",
		[195839] = "Cragsworn Conqueror",
		[195221] = "Grasslands Bakar",
		[193941] = "Spiteful Snail",
		[182816] = "Summoned Lava Elemental",
		[187036] = "Unbound Attendant",
		[192792] = "Clearwater Frenzy",
		[193430] = "Prowling Vulture",
		[186397] = "Restless Wind",
		[136398] = "Illidari Satyr <Alhaz>",
		[192791] = "Nokhud Warspear",
		[193942] = "Spiteful Slug",
		[187932] = "Lava Phoenix",
		[191129] = "Awakened Revenant",
		[193545] = "Feral Bakar",
		[193431] = "Hungry Nibbler",
		[95452] = "Felsoul Crusher",
		[136399] = "Vicious Hellhound <Lysarii>",
		[198930] = "Deathling Destroyer",
		[193943] = "Spiteful Snail",
		[195094] = "Stormbound Proto-Drake",
		[189468] = "Riverback Savage",
		[97370] = "General Volroth",
		[188044] = "Cindershard Hulk",
		[186399] = "Ice Webber",
		[191898] = "Qalashi Ragetamer",
		[191259] = "Primalist Storm-Summoner",
		[189852] = "Shadepelt Prowler",
		[195095] = "Time-Lost Murhulk",
		[99160] = "Beaming Eye",
		[97228] = "Abyssal Shard",
		[186272] = "Risen Phoenix <Lava Phoenix>",
		[193534] = "Strunraan",
		[191899] = "Qalashi Marauder",
		[192794] = "Nokhud Beastmaster",
		[194968] = "Toluiqi",
		[188689] = "Oozing Decay",
		[186464] = "Timeless Causality",
		[190986] = "Battlehorn Pyrhus",
		[195929] = "Soulharvester Tumen",
		[188089] = "Swift Hornstrider",
		[136402] = "Ur'zul <Alhaz>",
		[198112] = "Garden Winghunter",
		[192224] = "Cathan the Determined",
		[190588] = "Tectonic Crusher",
		[189087] = "Risen Ohuna",
		[194937] = "Steam Scaulder",
		[187297] = "Nokhud Fighter",
		[97369] = "Liquid Magma Totem <Note>",
		[191645] = "Wind Serpent",
		[193819] = "Ruffian Hornswog",
		[191901] = "Blazing Dreadsquall",
		[187937] = "Plainswalker Bull",
		[192885] = "Snowhorn Bruffalon",
		[187232] = "Time-Lost Bladewing",
		[136404] = "Bilescourge <Alhaz>",
		[55659] = "Wild Imp",
		[185508] = "Claw Fighter",
		[193820] = "Ruffian Hornswog",
		[191902] = "Qalashi Magmatamer",
		[193385] = "Broadhoof Bull",
		[187043] = "Hardened Lava <Boneshaper Jardak>",
		[189217] = "Frigellus",
		[103432] = "Queen's Centurion",
		[190996] = "Primal Earthshaper",
		[191903] = "Magmammoth Bull",
		[186660] = "Kargpaw the Fetid",
		[193949] = "Expelled Earth Elemental",
		[185811] = "Shiverweb Creeper",
		[188067] = "Flashfrost Chillweaver",
		[196379] = "Khakad the Ancient",
		[96783] = "Bastillax",
		[198937] = "Deathling",
		[136406] = "Shivarra <Alhaz>",
		[192799] = "Unstable Rock <Invisible Stalker>",
		[193950] = "Expelled Rubble",
		[186917] = "Turbulent Gust",
		[192020] = "Eaglemaster Niraak",
		[190212] = "Magmasworn Lavablade",
		[185589] = "Worldbreaker Brute",
		[95313] = "Felsoul Chaosweaver",
		[136407] = "Wrathguard <Alhaz>",
		[192800] = "Nokhud Lancemaster",
		[187813] = "Qalashi Wallcrasher",
		[192386] = "Skulking Scythid",
		[61056] = "Primal Earth Elemental",
		[190243] = "Shifty Salamanther",
		[185529] = "Bracken Warscourge",
		[47649] = "Efflorescence <Thaladomus>",
		[195742] = "Primalist Instructor",
		[191778] = "Territorial Proto Drake",
		[98035] = "Dreadstalker",
		[189988] = "Thing From Beyond <Satori>",
		[195359] = "Thornsided Basilisk",
		[135002] = "Demonic Tyrant <Lysarii>",
		[194224] = "Crazed Alpha",
		[95314] = "Felsoul Stalker",
		[192796] = "Nokhud Hornsounder",
		[191653] = "Coastal Salamanther",
		[186792] = "Qalashi Skirmisher",
		[186679] = "Mudfin Shaman",
		[191524] = "Qalashi Ironskin",
		[185584] = "Blasphemy <Ayésha>",
		[193442] = "Stonewrecker Tokara",
		[183340] = "Scavenging Hyena",
		[186295] = "Nokhud Mystic-Hunter",
		[192803] = "War Ohuna",
		[192931] = "Seabreaker Skrog",
		[186921] = "Frostcaller Nai'jin",
		[194351] = "Parched Broadhoof",
		[101901] = "Explosive Inquisitor Eye",
		[193443] = "Molka The Grinder",
		[183341] = "Shadepaw Bandit",
		[96402] = "Hulking Forgefiend",
		[187817] = "Stormcaller Initiate",
		[78116] = "Wasserelementar",
		[186922] = "Frostcaller Sin'tia",
		[192038] = "Yetor",
		[195362] = "Garden Winghunter",
		[191398] = "Grotesque Bulwark",
		[35158] = "Krom'gar Berserker",
		[191654] = "Rimebound Controller",
		[186667] = "Sickly Shaman",
		[195363] = "Skulking Scythid",
		[186923] = "Frostcaller Julh'ek",
		[194212] = "Unleashed Rubble",
		[196386] = "Quilmo the Ancient",
		[191399] = "Winged Ruin",
		[183343] = "Shadepaw Bruiser",
		[196770] = "Hotenoth",
		[186668] = "Sickly Brute",
		[187819] = "Stormbound Essence",
		[193062] = "Prowling Frigidpelt",
		[194853] = "Mirror Image",
		[187916] = "Primalist Stormsmith",
		[191400] = "Aqir Harbinger",
		[61245] = "Capacitor Totem <Lapuch-Tichondrius>",
		[192351] = "Trained Hyena",
		[186669] = "Mudfin Salamancer",
		[193063] = "Frigidpelt Matriarch",
		[95061] = "Greater Fire Elemental <Fearchar>",
		[191145] = "Overseer Zambul",
		[195365] = "Mountain Stonefang",
		[190958] = "Nokhud Mystic-Hunter",
		[186606] = "Dragonbane Cauldron Keeper",
		[193320] = "Reformed Earth <Raging Elemental>",
		[29264] = "Spirit Wolf <Kanduk>",
		[196005] = "Nokhud Marauder",
		[185903] = "Ravenous Rockfang",
		[186392] = "Vicious Ice Borer",
		[195366] = "Swiftfoot Tallstrider",
		[191658] = "Rimebound Subjugator",
		[187438] = "Grotesque Bulwark",
		[193704] = "Honmor",
		[186735] = "Inferna the Bound",
		[97044] = "Inquisitor",
		[194088] = "Wild Proto-Drake",
		[94654] = "Doomguard Eradicator",
		[185592] = "Swooping Snitch",
		[96277] = "Queen's Centurion",
		[195837] = "Rimebound Subjugator",
		[186672] = "Colossal Causality",
		[165189] = "Sarah",
		[192938] = "Nimblewing Striker",
		[190980] = "Rowdy Hornswog",
		[103822] = "Treant",
		[189230] = "Earthshaker Theurgist",
		[6112] = "Windfury Totem <Bôrsalîno-Blackrock>",
		[187440] = "Aqir Harbinger",
		[195752] = "Rimetalon Brawler",
		[190765] = "Mysterious Apparition",
		[186626] = "Bound Flame",
		[190384] = "Snoll the Icebreaker",
		[1860] = "Mezzgrave",
		[189231] = "Earthshaker Marauder",
		[96278] = "Burning Soulstalker",
		[62005] = "Beast <Legosuck>",
		[191661] = "Cragsworn Stoneshaper",
		[190766] = "Qalashi Ragetamer",
		[193313] = "Watching Corpsewing",
		[185907] = "Sirena the Fangbreaker",
		[194219] = "Primal Waterspout",
		[189232] = "Kokia Blazehoof",
		[190998] = "Bossy Hornswog",
		[35160] = "Krom'gar Logger",
		[182439] = "Snappy Sidewalker",
		[186151] = "Balakar Khan",
		[192941] = "Thunderspine Rumbler",
		[199207] = "Crust Gorger",
		[195877] = "Risen Mystic",
		[187306] = "Morchok",
		[96279] = "Mardum Executioner",
		[197673] = "Ocean's Motion",
		[194084] = "Wild Proto-Drake",
		[186605] = "Dragonbane Firebinder",
		[189869] = "Primalist Infiltrator",
		[183863] = "Mogu Overlord",
		[94731] = "Taldath the Destroyer",
		[194349] = "Bound Spirit",
		[197535] = "High Channeler Ryvati",
		[186421] = "Primal Drift",
		[195756] = "Rimetalon Spellflinger",
		[190776] = "Arcane Commander",
		[190259] = "Echo of Loss",
		[187337] = "Time-Charged Ohuna",
		[187539] = "Rustpine Loamcrafter",
		[195876] = "Desecrated Ohuna",
		[96280] = "Volatile Minion",
		[182815] = "Summoned Lava Elemental",
		[191665] = "Rumbling Blackpaw",
		[186678] = "Chief Grrlgllmesh",
		[189875] = "Animated Cindershards",
		[194095] = "Raging Inferno",
		[186336] = "Blazing Manifestation",
		[100820] = "Spirit Wolf <Ishrax>",
		[188341] = "Nokhud Warmonger",
		[35161] = "Krom'gar Warrior",
		[185528] = "Trickclaw Mystic",
		[188725] = "Embertooth Spearhunter",
		[93716] = "Doom Slayer",
		[198047] = "Tempest Channeler",
		[191155] = "Rustpine Loamcrafter",
		[194352] = "Parched Broadhoof Bull",
		[193457] = "Balara",
		[186638] = "Qalashi Crustshaper",
		[192690] = "Smoldering Feather <Blazing Firesquall>",
		[73967] = "Niuzao <Lunombre-Suramar>",
		[136408] = "Darkhound <Alhaz>",
		[96473] = "Eredar Sorcerer",
		[96400] = "Mo'arg Brute",
		[195579] = "Primal Gust",
		[188343] = "Primalist Stormsurger",
		[184444] = "Oppressive Artificer",
		[198652] = "Risen Bakar <Tombcaller Ganzaya>",
		[189402] = "Sickly Ambusher",
		[187396] = "Rustpine Immolator",
		[187960] = "Sunhide Stomphoof",
		[187867] = "Qalashi Magmacrafter",
		[185147] = "Nokhud Stormcaller",
		[187321] = "Primal Lava Elemental",
		[191541] = "Craggy Stag",
		[194458] = "Rokzul",
		[196950] = "Haunting Gnoll <Darktooth Spirit-Caller>",
		[144961] = "Akaari's Soul",
		[186602] = "Dragonbane Mender",
		[98712] = "Kor'vas Bloodthorn",
		[191286] = "Molten Eruption <Qalashi Stonemender>",
		[186299] = "Nokhud Marauder",
		[186427] = "Restless Gale",
		[192693] = "Risen Phoenix <Qalashi Scaleripper>",
		[196913] = "Mara'nar the Thunderous",
		[192949] = "Skaara",
		[197169] = "Urglan",
		[192651] = "Clearwater Riverbeast",
		[186783] = "Cauldronbearer Blakor",
		[187540] = "Time-Lost Mudskipper",
		[195635] = "Time-Charged Bear",
		[192694] = "Custodial Protector",
		[186684] = "Lava Phoenix",
		[192950] = "Shenzai",
		[193533] = "Liskanoth",
		[187266] = "Time-Lost Chieftain",
		[187090] = "Enraged Cliff",
		[193462] = "Batak",
		[187507] = "Frenzied Grovetalon",
		[195764] = "Vadne Bleakheart",
		[186111] = "Primalist Tender",
		[192951] = "Bankai",
		[31216] = "Mirror Image <Linoe>",
		[186511] = "Piercer Gigra",
		[187342] = "Deathling",
		[198130] = "Rotting Totem <Kargpaw the Fetid>",
		[186768] = "Sickly Grunt",
		[192696] = "Tyrhold Watcher",
		[191240] = "Hillside Forager",
		[192952] = "Edai",
		[192057] = "Brackenhide Putrifier",
		[63508] = "Xuen",
		[195382] = "Mountain Stonefang",
		[182211] = "Primal Fire Elemental",
		[186604] = "Dragonbane Soldier",
		[186517] = "Bakra the Bully",
		[190779] = "Arcane Golem",
		[190946] = "Primalist Tempest",
		[196056] = "Gushgut the Beaksinker",
		[195255] = "Vicious Crystalspine",
		[97244] = "Kayn Sunfury",
		[197557] = "Bisquius",
		[194120] = "Vicious Rimefang",
		[189841] = "Russet Mudwalker",
		[193849] = "Rakkesh of the Flow",
		[169425] = "Felhound",
		[190034] = "Blazebound Destroyer",
		[193675] = "Kain Firebrand",
		[185883] = "Blazing Proto-Dragon",
		[197985] = "Flame Channeler",
		[190739] = "Primalbound Water Spirit",
		[192699] = "Forge-Keep Overseer",
		[195854] = "Unbound Windscourge",
		[190909] = "Swift Hornstrider",
		[186239] = "Qalashi Skullhauler",
		[201558] = "Malgain Rockknell",
		[114406] = "Spellfiend Devourer",
		[188252] = "Melidrussa Chillworn",
		[77936] = "Greater Storm Elemental <Syreth>",
		[192700] = "Forge-Keep Sentinel",
		[186690] = "Mudfin Mudrunner",
		[191476] = "Searing Flame Harchek",
		[187969] = "Flashfrost Earthshaper",
		[196495] = "Over-Pollinated Lasher",
		[198455] = "Conjured Icestorm",
		[186356] = "Nokhud Vulture",
		[93802] = "Brood Queen Tyranna",
		[193724] = "Uurtus",
		[98486] = "Wrath Warrior",
		[187842] = "Nokhud Goliath",
		[95072] = "Greater Earth Elemental <Fearchar>",
		[96159] = "Colossal Infernal",
		[186777] = "Meatgrinder Sotok",
		[195175] = "Djaradin Warrior",
		[190528] = "Ashen Spark",
		[192702] = "Menial Attendant",
		[93112] = "Felguard Sentry",
		[187843] = "Stormbound Colossus",
		[186728] = "Magmammoth Bull",
		[101786] = "Demon Spiderling",
		[198627] = "Darktooth Renderer",
		[199608] = "Siaszerathel",
		[196185] = "Tenacious Timbertooth",
		[192703] = "Forge-Keep Custodian",
		[106988] = "Beast <Dannyxhunter>",
		[191844] = "Primalist Infiltrator",
		[195815] = "Primal Stone",
		[195261] = "Plains Bull",
		[189825] = "Ravenous Nestling",
		[199609] = "Andantenormu",
		[95329] = "Felsoul Fleshcarver",
		[198382] = "Cindershard Igniter",
		[191084] = "Spiderling",
		[192626] = "Crust Lurker",
		[190207] = "Primalist Cinderweaver",
		[194284] = "Sedentary Sediment",
		[197436] = "Shadehide Forager",
		[191324] = "Encroaching Downpour",
		[194623] = "Tame Magmammoth",
		[191682] = "Sulfuric Rager",
		[187264] = "Time-Lost Briarback",
		[192961] = "Ayanga",
		[186112] = "Primalist Infuser",
		[188102] = "Khargall Fivefangs",
		[190206] = "Primalist Flamedancer",
	},
	["death_recap"] = {
		["enabled"] = true,
		["show_segments"] = false,
		["show_life_percent"] = false,
		["relevance_time"] = 7,
	},
	["spell_pool"] = {
		11, -- [1]
		3, -- [2]
		[53385] = 2,
		[382867] = 11,
		[376725] = "Nokhud Stormcaster",
		[386963] = 10,
		[376727] = "Balakar Khan",
		[394131] = 4,
		[47755] = 5,
		[199658] = 1,
		[376730] = "[*] Stormwinds",
		[264119] = 9,
		[376732] = "[*] Stormwinds",
		[190446] = 8,
		[351140] = 8,
		[222695] = 10,
		[389020] = 3,
		[94472] = 5,
		[115203] = 10,
		[59913] = 12,
		[304051] = 3,
		[200174] = 5,
		[385952] = 1,
		[374691] = "Kurog Grimtotem",
		[385953] = 1,
		[385954] = 1,
		[107270] = 10,
		[57994] = 7,
		[527] = 5,
		[264130] = 9,
		[396194] = 8,
		[381862] = "Kyrakka",
		[8680] = 4,
		[395172] = 11,
		[381864] = "Kyrakka",
		[30153] = "Haaroon <Saád-Malygos>",
		[262115] = 1,
		[382889] = 7,
		[324536] = 9,
		[388009] = 2,
		[383915] = 1,
		[585] = 5,
		[373678] = "Kurog Grimtotem",
		[589] = 5,
		[396201] = "[*] Blistering Presence",
		[388012] = 2,
		[327611] = 6,
		[324540] = 9,
		[224239] = 2,
		[373681] = "Kurog Grimtotem",
		[374705] = "Earth Breaker",
		[396204] = 8,
		[190456] = 1,
		[383921] = 2,
		[633] = 2,
		[345019] = 10,
		[229872] = 10,
		[178173] = 10,
		[5221] = 11,
		[267217] = 9,
		[374711] = "Balara",
		[383925] = "Melidrussa Chillworn",
		[386997] = 9,
		[383926] = 1,
		[197626] = 11,
		[392117] = 11,
		[388024] = 10,
		[373692] = "Blazebound Destroyer",
		[49039] = 6,
		[373693] = "Blazebound Destroyer",
		[197628] = 11,
		[218615] = 9,
		[373694] = "[*] Living Bomb",
		[322507] = 10,
		[315341] = 4,
		[122121] = 5,
		[218617] = 1,
		[47632] = 6,
		[394173] = 1,
		[382912] = 11,
		[755] = 9,
		[387008] = 11,
		[392127] = 9,
		[195072] = 12,
		[392128] = 2,
		[212988] = 12,
		[781] = 3,
		[375750] = 3,
		[193538] = 4,
		[383941] = 7,
		[265187] = 9,
		[225787] = "Allegory",
		[391109] = 5,
		[120588] = 7,
		[372683] = "Infused Whelp",
		[30283] = 9,
		[158221] = 10,
		[196100] = 9,
		[102417] = 11,
		[387018] = 9,
		[3355] = 3,
		[307166] = 12,
		[845] = 1,
		[396233] = "[*] Thundering Presence",
		[6789] = 9,
		[853] = 2,
		[198149] = 8,
		[381902] = 1,
		[871] = 1,
		[190984] = 11,
		[264173] = 9,
		[48018] = 9,
		[883] = 3,
		[386001] = 1,
		[195592] = 7,
		[376788] = "Rydrasil",
		[386002] = 1,
		[193545] = 12,
		[386003] = 1,
		[321507] = 8,
		[396241] = "Kurog Grimtotem",
		[221699] = 6,
		[387028] = 2,
		[392147] = 11,
		[372696] = "Primal Juggernaut",
		[394195] = 8,
		[228354] = 8,
		[396243] = "[*] Primal Attunement",
		[372697] = "Primal Juggernaut",
		[193547] = 12,
		[323558] = 4,
		[383960] = 3,
		[323559] = 4,
		[185358] = 3,
		[343011] = 12,
		[323560] = 4,
		[122128] = 5,
		[26573] = 2,
		[343013] = 12,
		[391130] = "High Channeler Ryvati",
		[386012] = "Stormcaller Solongo",
		[387036] = 2,
		[270329] = 3,
		[228358] = 8,
		[307185] = 9,
		[31884] = 2,
		[263165] = 5,
		[378849] = 6,
		[204301] = 2,
		[270332] = 3,
		[153626] = 8,
		[228360] = 5,
		[383971] = 1,
		[270335] = 3,
		[224266] = 2,
		[388068] = 9,
		[391140] = 11,
		[371689] = 6,
		[270338] = 3,
		[388070] = 9,
		[270339] = 3,
		[115989] = 6,
		[1122] = 9,
		[386024] = "Primalist Stormspeaker",
		[202770] = 11,
		[113942] = 9,
		[203794] = 12,
		[155166] = 6,
		[381931] = 7,
		[358385] = "Allegory",
		[53652] = 2,
		[270343] = 3,
		[203795] = 12,
		[400360] = 11,
		[290819] = 3,
		[381933] = 7,
		[382957] = 3,
		[117526] = 3,
		[118038] = 1,
		[203796] = 12,
		[375792] = "Thundering Ravager",
		[31821] = 2,
		[235021] = 12,
		[213011] = 12,
		[388081] = 11,
		[321538] = "Nomnom <Raffit-Ysera>",
		[210453] = 12,
		[262161] = 1,
		[215572] = 1,
		[388083] = 4,
		[188443] = 7,
		[5302] = 1,
		[1330] = 4,
		[346111] = 5,
		[383991] = 2,
		[372730] = "Primal Juggernaut",
		[361469] = "Askalaphos-Gilneas",
		[375802] = "Allegory",
		[391159] = 12,
		[376827] = "Balakar Khan",
		[390137] = 12,
		[375805] = 8,
		[376829] = "Balakar Khan",
		[115994] = 6,
		[372735] = "Flashfrost Earthshaper",
		[5782] = 9,
		[383997] = 8,
		[153640] = 8,
		[387069] = 7,
		[376832] = "Rydrasil",
		[1490] = 12,
		[391166] = 12,
		[376835] = 7,
		[381954] = "Syndarion-Gilneas",
		[73510] = 5,
		[390145] = 12,
		[387074] = 2,
		[375813] = 12,
		[186403] = "Allegory",
		[381956] = "Syndarion-Gilneas",
		[195617] = 6,
		[6262] = 9,
		[372743] = "Flashfrost Chillweaver",
		[381957] = "Syndarion-Gilneas",
		[391171] = 12,
		[194594] = 3,
		[42650] = 6,
		[391172] = 12,
		[59542] = 2,
		[387079] = 9,
		[205345] = 8,
		[387080] = 12,
		[363534] = "Rydrasil",
		[186406] = "Allegory",
		[387081] = 5,
		[172075] = 3,
		[390155] = 12,
		[1714] = 9,
		[381966] = 11,
		[375824] = "Tectonic Crusher",
		[225311] = 2,
		[381967] = 12,
		[119582] = 10,
		[394253] = 9,
		[395277] = 8,
		[376850] = "Askalaphos-Gilneas",
		[1766] = 4,
		[375827] = 6,
		[375828] = "Blazing Fiend",
		[385042] = 1,
		[193065] = 5,
		[214052] = 9,
		[1822] = 11,
		[184364] = 1,
		[16979] = 11,
		[372760] = 5,
		[85288] = 1,
		[1850] = 11,
		[369690] = 6,
		[342049] = 3,
		[386071] = 1,
		[195627] = 4,
		[384024] = "Melidrussa Chillworn",
		[391191] = 12,
		[392216] = 4,
		[184367] = 1,
		[83242] = 3,
		[203819] = 12,
		[265273] = 9,
		[132157] = 5,
		[1966] = 4,
		[335913] = 10,
		[195630] = 10,
		[376864] = "Balakar Khan",
		[132158] = 11,
		[376865] = "Balakar Khan",
		[361509] = "Allegory",
		[397341] = "Kurog Grimtotem",
		[383009] = 7,
		[386081] = 4,
		[2060] = 5,
		[385059] = 1,
		[390178] = 6,
		[375846] = 1,
		[385060] = 1,
		[381989] = 4,
		[385061] = 1,
		[207407] = 12,
		[17364] = 7,
		[385062] = 1,
		[390181] = 12,
		[385063] = "Primalist Cinderweaver",
		[260643] = 1,
		[373803] = "Infused Whelp",
		[383017] = 7,
		[387113] = 2,
		[243241] = 5,
		[115750] = 2,
		[49821] = 5,
		[33697] = 7,
		[386092] = 1,
		[381998] = 10,
		[344120] = 3,
		[59547] = 7,
		[111400] = 9,
		[344121] = 3,
		[2484] = 7,
		[372787] = 5,
		[10060] = 5,
		[24275] = 2,
		[380978] = 7,
		[390192] = 12,
		[383026] = 7,
		[384050] = 8,
		[5143] = 8,
		[2580] = 1,
		[210485] = 12,
		[191034] = 11,
		[10444] = 7,
		[192058] = 7,
		[50334] = 11,
		[132169] = 1,
		[105771] = 1,
		[387125] = "Primalist Thunderbeast",
		[390197] = 12,
		[397364] = 1,
		[398388] = 3,
		[387127] = "Primalist Thunderbeast",
		[389176] = 1,
		[191037] = 11,
		[392248] = 3,
		[376892] = "Balakar Khan",
		[389178] = 1,
		[120361] = 3,
		[88625] = 5,
		[2908] = 11,
		[331850] = 4,
		[192063] = 7,
		[2948] = 8,
		[326733] = 2,
		[398396] = 11,
		[387135] = "Primalist Arcblade",
		[56222] = 6,
		[387136] = 11,
		[228920] = 1,
		[49184] = 6,
		[397376] = 2,
		[391234] = 12,
		[50464] = 11,
		[6343] = 1,
		[191043] = 3,
		[387143] = 9,
		[373835] = "Rydrasil",
		[390216] = 7,
		[387145] = "Stormcaller Solongo",
		[334934] = 1,
		[387146] = "Stormsurge Totem",
		[394313] = 1,
		[400456] = 3,
		[381005] = 12,
		[6807] = 11,
		[391243] = 5,
		[391244] = 5,
		[210499] = 12,
		[370772] = 8,
		[375891] = 3,
		[390224] = 8,
		[370773] = 8,
		[387154] = 9,
		[375893] = 3,
		[107570] = 1,
		[33702] = 9,
		[124974] = 11,
		[217668] = 1,
		[387157] = 9,
		[394324] = 4,
		[387158] = 9,
		[315496] = 4,
		[394325] = 4,
		[205385] = 5,
		[390232] = 3,
		[387161] = 9,
		[384090] = 1,
		[372829] = 12,
		[382043] = 7,
		[396376] = "Ukhel Deathspeaker",
		[397400] = 1,
		[390234] = "Askalaphos-Gilneas",
		[387163] = 1,
		[343142] = 4,
		[397401] = 1,
		[378974] = 2,
		[400474] = "Stormsurge Totem",
		[198222] = 4,
		[397405] = 8,
		[108853] = 8,
		[246851] = 3,
		[388193] = 10,
		[397407] = 8,
		[316531] = 1,
		[246852] = 3,
		[315508] = 4,
		[188499] = 12,
		[221771] = 10,
		[246853] = 3,
		[223819] = 2,
		[17] = 5,
		[385126] = 2,
		[387174] = 2,
		[385127] = 2,
		[382056] = 6,
		[188501] = 12,
		[390247] = 11,
		[344179] = 7,
		[382058] = 12,
		[378987] = 11,
		[396391] = 11,
		[361584] = 11,
		[387178] = 2,
		[206930] = 6,
		[378989] = 11,
		[204883] = 5,
		[378990] = 11,
		[378991] = 11,
		[384110] = 1,
		[385134] = 12,
		[390253] = 11,
		[378992] = 11,
		[115767] = 1,
		[386159] = 3,
		[388207] = 10,
		[372851] = "Melidrussa Chillworn",
		[387184] = 10,
		[392303] = 11,
		[280715] = 1,
		[384114] = 5,
		[5176] = 11,
		[244813] = 8,
		[192090] = 11,
		[386164] = 1,
		[197721] = 11,
		[384117] = 12,
		[270481] = "Demonic Tyrant <Saád-Malygos>",
		[280719] = 4,
		[5384] = 3,
		[375929] = "Balakar Khan",
		[372858] = "Kokia Blazehoof",
		[372859] = "Kokia Blazehoof",
		[185438] = 4,
		[372860] = "Kokia Blazehoof",
		[5672] = "Healing Stream Totem <Fengala-DieArguswacht>",
		[371838] = "Allegory",
		[211545] = 11,
		[372863] = "Kokia Blazehoof",
		[370816] = 1,
		[324748] = 2,
		[55078] = 6,
		[197214] = 7,
		[370818] = "Allegory",
		[375937] = "Balakar Khan",
		[19801] = 3,
		[383104] = 1,
		[390271] = 6,
		[388224] = 6,
		[384130] = 3,
		[345228] = 1,
		[119611] = 10,
		[279709] = 11,
		[345230] = "Kisará-Alleria",
		[214621] = 5,
		[394371] = 3,
		[224347] = 11,
		[384134] = "Nokhud Warspear",
		[192611] = 12,
		[152173] = 10,
		[399491] = 10,
		[127802] = 9,
		[257620] = 3,
		[217694] = 8,
		[382090] = 7,
		[333974] = 7,
		[152175] = 10,
		[384139] = "Blazebound Destroyer",
		[257622] = 3,
		[124988] = 11,
		[382093] = 11,
		[333977] = 7,
		[382094] = 1,
		[34861] = 5,
		[382095] = 1,
		[200806] = 4,
		[390287] = 7,
		[115008] = 10,
		[194153] = 11,
		[379029] = 8,
		[192106] = 7,
		[386196] = 1,
		[7384] = 1,
		[385174] = 1,
		[399507] = "Primalist Thunderbeast",
		[124991] = 11,
		[117313] = 1,
		[382106] = 8,
		[322729] = 10,
		[202347] = 11,
		[195181] = 6,
		[104773] = 9,
		[195182] = 6,
		[317614] = 6,
		[196718] = 12,
		[378016] = 3,
		[47788] = 5,
		[32216] = 1,
		[386208] = 1,
		[44461] = 8,
		[2061] = 5,
		[24858] = 11,
		[121411] = 4,
		[384165] = "Allegory",
		[117828] = 9,
		[215661] = 2,
		[12975] = 1,
		[48045] = 5,
		[392359] = 1,
		[260708] = 1,
		[392360] = 11,
		[375981] = 5,
		[375982] = 7,
		[217200] = 3,
		[156287] = 1,
		[382126] = 8,
		[375984] = 7,
		[280776] = 1,
		[315584] = 4,
		[386223] = "Primal Stormshield",
		[375986] = 7,
		[315585] = 4,
		[201846] = 7,
		[384177] = 6,
		[212084] = 12,
		[2565] = 1,
		[382131] = 8,
		[202359] = 11,
		[5225] = 11,
		[386228] = "Primal Stormshield",
		[2645] = 7,
		[384182] = 4,
		[29722] = 9,
		[382135] = 12,
		[173184] = 7,
		[384183] = 5,
		[195707] = 11,
		[392375] = 7,
		[114250] = 2,
		[392376] = 1,
		[382139] = 1,
		[78675] = 11,
		[22812] = 11,
		[62124] = 2,
		[388283] = "Granyth",
		[196733] = 10,
		[210042] = 12,
		[391356] = 11,
		[55342] = 8,
		[64044] = 5,
		[387263] = 9,
		[382145] = 3,
		[383169] = 12,
		[326863] = 12,
		[382146] = 8,
		[384194] = "Primalist Cinderweaver",
		[106830] = 11,
		[33076] = 5,
		[6201] = 9,
		[382148] = 8,
		[108366] = 9,
		[390339] = 11,
		[392388] = 4,
		[391365] = 7,
		[382153] = 12,
		[382154] = 7,
		[188550] = 11,
		[368847] = "Allegory",
		[386251] = 9,
		[374990] = 3,
		[53] = 4,
		[385228] = 1,
		[382157] = 6,
		[391371] = 5,
		[270569] = 9,
		[342232] = 8,
		[81751] = 5,
		[389325] = 10,
		[225919] = 12,
		[370898] = "Askalaphos-Gilneas",
		[123725] = 10,
		[47666] = 5,
		[390350] = 12,
		[391374] = 12,
		[392398] = "Primal Thundercloud",
		[386256] = 9,
		[383185] = 2,
		[392399] = "Primal Thundercloud <High Channeler Ryvati>",
		[385233] = 1,
		[373972] = "Primalist Flamedancer",
		[370901] = "Allegory",
		[385234] = 1,
		[316643] = 1,
		[210053] = 11,
		[391378] = 12,
		[157331] = "Primal Storm Elemental <Blítzdìngs-Antonidas>",
		[198793] = 12,
		[342240] = 7,
		[376024] = 1,
		[377048] = 6,
		[390357] = 9,
		[394453] = 4,
		[392406] = "Storm Warrior",
		[275699] = 6,
		[383193] = 11,
		[113746] = 10,
		[386265] = 9,
		[394456] = 9,
		[342245] = 8,
		[132764] = 3,
		[219271] = 7,
		[394457] = 11,
		[212105] = 12,
		[342247] = 8,
		[260734] = 7,
		[212106] = 12,
		[335082] = 1,
		[47540] = 5,
		[378081] = 7,
		[393438] = 12,
		[221322] = 6,
		[213644] = 2,
		[123986] = 10,
		[353515] = 3,
		[191634] = 7,
		[66] = 8,
		[390371] = 7,
		[1079] = 11,
		[8690] = 11,
		[106839] = 11,
		[392421] = 3,
		[383208] = 2,
		[377066] = 5,
		[390375] = 11,
		[328951] = 12,
		[391400] = 10,
		[122708] = 1,
		[200851] = 11,
		[119381] = 10,
		[328953] = 12,
		[269576] = 3,
		[391403] = 5,
		[335097] = 1,
		[374000] = 12,
		[335098] = 1,
		[51637] = 4,
		[260231] = 3,
		[328957] = 12,
		[203925] = 12,
		[335100] = 1,
		[48438] = 11,
		[371956] = "Primal Terrasentry",
		[336126] = 3,
		[377077] = 6,
		[390386] = "Syndarion-Gilneas",
		[343294] = 6,
		[378102] = 7,
		[17057] = 11,
		[343295] = 6,
		[377079] = 11,
		[375033] = 3,
		[384247] = 9,
		[377081] = 1,
		[378105] = "Allegory",
		[124503] = 10,
		[327942] = 7,
		[386296] = 3,
		[386297] = 3,
		[383226] = 1,
		[384250] = 11,
		[115546] = 10,
		[368896] = "Syndarion-Gilneas",
		[197277] = 2,
		[384253] = 4,
		[389372] = 9,
		[386301] = 3,
		[368899] = "Allegory",
		[372995] = 3,
		[368901] = 12,
		[395519] = 10,
		[376068] = 3,
		[1543] = 3,
		[115804] = 1,
		[374022] = "Kurog Grimtotem",
		[395521] = 10,
		[341263] = 5,
		[99] = 11,
		[260242] = 3,
		[154796] = 12,
		[100] = 1,
		[196770] = 6,
		[205472] = 8,
		[260243] = 3,
		[79206] = 7,
		[124507] = 10,
		[392454] = "Flame Channeler",
		[196771] = 6,
		[205473] = 8,
		[387336] = 3,
		[373004] = "Kurog Grimtotem",
		[114014] = 4,
		[93795] = 7,
		[371981] = "[*] Elemental Surge",
		[45242] = 5,
		[272678] = 3,
		[384267] = 8,
		[272679] = 3,
		[389387] = 10,
		[376079] = 1,
		[1715] = 1,
		[1719] = 1,
		[376080] = 1,
		[272682] = 3,
		[260247] = 3,
		[219809] = 6,
		[32223] = 2,
		[389391] = 10,
		[20066] = 2,
		[81256] = 6,
		[370965] = 12,
		[363799] = 12,
		[378132] = 1,
		[370966] = 12,
		[163505] = 11,
		[88423] = 11,
		[370969] = 12,
		[116] = 8,
		[373017] = "Blazebound Firestorm <Kokia Blazehoof>",
		[382231] = 12,
		[370970] = 12,
		[247454] = 12,
		[274738] = 1,
		[382232] = 9,
		[370971] = 12,
		[253597] = 6,
		[247455] = 12,
		[130654] = 10,
		[120] = 8,
		[247456] = 12,
		[1943] = 4,
		[195757] = 6,
		[96103] = 1,
		[387356] = 9,
		[255647] = 5,
		[73325] = 5,
		[188592] = 7,
		[194223] = 11,
		[162487] = 3,
		[199854] = 1,
		[12051] = 8,
		[8122] = 5,
		[162488] = 3,
		[387361] = 7,
		[384290] = 7,
		[323889] = 3,
		[275773] = 2,
		[210093] = 12,
		[130] = 8,
		[119907] = 9,
		[212653] = 8,
		[133] = 8,
		[383269] = 6,
		[376103] = 8,
		[382246] = 9,
		[136] = 3,
		[234153] = 9,
		[377129] = 2,
		[139] = 5,
		[203953] = 11,
		[392486] = "Tempest Channeler",
		[382249] = "Trickclaw Mystic",
		[65081] = 5,
		[81262] = "Efflorescence <Helveti-DunMorogh>",
		[392488] = "Tempest Channeler",
		[387370] = 8,
		[61882] = 7,
		[375086] = 2,
		[196277] = 9,
		[393514] = 6,
		[375087] = "Allegory",
		[181945] = "Taldath the Destroyer",
		[393515] = 10,
		[196278] = 9,
		[189112] = 12,
		[226991] = 12,
		[80240] = 9,
		[396590] = 11,
		[203958] = 11,
		[383283] = 2,
		[373046] = "Melidrussa Chillworn",
		[5211] = 11,
		[120679] = 3,
		[381237] = 1,
		[50622] = 1,
		[167105] = 1,
		[286031] = 12,
		[315720] = 1,
		[203961] = 11,
		[172] = 9,
		[116841] = 10,
		[152262] = 2,
		[259756] = 9,
		[383290] = 1,
		[382267] = "Balara",
		[391481] = 6,
		[108396] = 9,
		[347462] = 12,
		[384318] = 1,
		[267611] = 2,
		[119914] = 9,
		[382272] = 8,
		[213691] = 3,
		[214203] = 7,
		[384321] = 11,
		[387393] = 9,
		[49088] = 6,
		[3110] = "Zignik <Tinca-Anetheron>",
		[228537] = 12,
		[16870] = 11,
		[116844] = 10,
		[382277] = "Balara",
		[383301] = 4,
		[384325] = 7,
		[81269] = 11,
		[383302] = 2,
		[385350] = 11,
		[358733] = "Allegory",
		[394565] = 11,
		[385352] = 2,
		[383305] = 2,
		[191685] = 6,
		[385354] = 2,
		[110959] = 8,
		[383307] = 2,
		[389450] = 3,
		[334168] = 7,
		[372047] = "Defier Draghar",
		[6795] = 11,
		[84342] = 3,
		[371024] = 12,
		[200389] = 11,
		[110960] = 8,
		[19750] = 2,
		[383312] = 6,
		[384336] = "Nokhud Lancemaster",
		[116847] = 10,
		[383313] = 6,
		[382290] = 8,
		[387409] = 9,
		[145109] = 11,
		[370007] = 9,
		[387411] = "Soulharvester Galtmaa",
		[196809] = "Divine Image <Syreht-Nazjatar>",
		[145110] = 11,
		[387413] = 9,
		[55233] = 6,
		[196810] = "Divine Image <Syreht-Nazjatar>",
		[86392] = 4,
		[115313] = 10,
		[87160] = 5,
		[388439] = 9,
		[196811] = "Divine Image <Syreht-Nazjatar>",
		[56641] = 3,
		[48707] = 6,
		[212680] = 3,
		[152279] = 6,
		[392537] = 1,
		[373087] = "Blazebound Firestorm <Kokia Blazehoof>",
		[260286] = 3,
		[386397] = 1,
		[264571] = 9,
		[390493] = 7,
		[385375] = 11,
		[203981] = 12,
		[384352] = 7,
		[393566] = 10,
		[148187] = 10,
		[113780] = 4,
		[355689] = "Allegory",
		[196816] = "Divine Image <Syreht-Nazjatar>",
		[213708] = 11,
		[124274] = 10,
		[213709] = 11,
		[210126] = 8,
		[384357] = 7,
		[68992] = 4,
		[124275] = 10,
		[334196] = 7,
		[384360] = 8,
		[196819] = 4,
		[44614] = 8,
		[391528] = 11,
		[384362] = 1,
		[201427] = 12,
		[205523] = 10,
		[384365] = "Nokhud Lancemaster",
		[385389] = "[*] Shockwave",
		[386413] = 4,
		[13877] = 4,
		[385391] = 1,
		[386415] = 5,
		[386416] = 1,
		[372084] = 7,
		[386417] = 1,
		[387441] = 2,
		[5116] = 3,
		[386418] = 2,
		[386419] = 3,
		[208086] = 1,
		[372087] = "Defier Draghar",
		[360826] = 4,
		[5308] = 1,
		[81281] = 11,
		[339] = 11,
		[362877] = "Rydrasil",
		[104316] = 9,
		[360830] = 4,
		[348] = 9,
		[36554] = 4,
		[22568] = 11,
		[355] = 1,
		[235219] = 8,
		[274838] = 11,
		[124280] = 10,
		[5740] = 9,
		[192222] = 7,
		[116858] = 9,
		[51271] = 6,
		[370] = 7,
		[389502] = 2,
		[104318] = "Wild Imp <Saád-Malygos>",
		[205021] = 8,
		[388480] = 10,
		[389504] = 2,
		[220890] = 6,
		[205022] = 8,
		[390529] = "Naldraxus-Malfurion",
		[86659] = 2,
		[328082] = 4,
		[387460] = "Syndarion-Gilneas",
		[227034] = 11,
		[387461] = "Syndarion-Gilneas",
		[384391] = 1,
		[372107] = "Kokia Blazehoof",
		[17962] = 9,
		[6572] = 1,
		[385417] = 2,
		[386441] = 12,
		[156910] = 2,
		[277925] = 4,
		[108416] = 9,
		[13750] = 4,
		[19434] = 3,
		[281000] = 1,
		[60103] = 7,
		[377234] = "Syndarion-Gilneas",
		[271788] = 3,
		[391568] = 6,
		[196840] = 7,
		[66188] = 6,
		[121471] = 4,
		[390548] = "Kurog Grimtotem",
		[465] = 2,
		[52042] = "Healing Stream Totem <Fengala-DieArguswacht>",
		[210152] = 12,
		[142073] = "Allegory",
		[210153] = 12,
		[269751] = 3,
		[377245] = 6,
		[378269] = 7,
		[217832] = 12,
		[383389] = 2,
		[359843] = 12,
		[114051] = 7,
		[63560] = 6,
		[498] = 2,
		[350631] = 12,
		[166646] = 10,
		[171253] = 5,
		[8092] = 5,
		[378275] = 7,
		[98440] = 4,
		[378277] = 7,
		[528] = 5,
		[389539] = 2,
		[321973] = 5,
		[384422] = 12,
		[397734] = 7,
		[400806] = 1,
		[115078] = 10,
		[586] = 5,
		[204019] = 2,
		[378286] = 2,
		[378287] = 3,
		[386478] = 1,
		[51533] = 7,
		[204021] = 12,
		[372147] = "Balara",
		[396718] = 1,
		[383410] = 11,
		[396719] = 1,
		[642] = 2,
		[281036] = 3,
		[49998] = 6,
		[5277] = 4,
		[345535] = 1,
		[383414] = 4,
		[390581] = 1,
		[25771] = 2,
		[394677] = 7,
		[387511] = 6,
		[52174] = 1,
		[64843] = 5,
		[394679] = 9,
		[702] = 9,
		[184575] = 2,
		[66198] = 6,
		[372158] = "Kurog Grimtotem",
		[228597] = 8,
		[388539] = 1,
		[213241] = 12,
		[27243] = 9,
		[228598] = 8,
		[118922] = 3,
		[740] = 11,
		[47568] = 6,
		[2983] = 4,
		[215802] = 7,
		[213243] = 12,
		[320976] = 3,
		[64844] = 5,
		[187650] = 3,
		[768] = 11,
		[102543] = 11,
		[772] = 1,
		[774] = 11,
		[384451] = 7,
		[12472] = 8,
		[391618] = 11,
		[374215] = "Kurog Grimtotem",
		[274912] = 10,
		[391620] = 11,
		[374217] = "Kurog Grimtotem",
		[384455] = 8,
		[8921] = 11,
		[131347] = 12,
		[236282] = 1,
		[82326] = 2,
		[388556] = 6,
		[384463] = 3,
		[345561] = "Teera",
		[212739] = 6,
		[373204] = 5,
		[382418] = 7,
		[61391] = 11,
		[102547] = 11,
		[106898] = 11,
		[396752] = 1,
		[362969] = "Allegory",
		[386516] = 8,
		[325092] = 10,
		[89751] = "Haaroon <Saád-Malygos>",
		[119952] = 2,
		[353759] = "Allegory",
		[212743] = 4,
		[386521] = 2,
		[139546] = 4,
		[390617] = 5,
		[45524] = 6,
		[386523] = 2,
		[974] = 7,
		[384476] = "Nokhud Longbow",
		[50259] = 11,
		[980] = 9,
		[982] = 3,
		[89753] = "Haaroon <Saád-Malygos>",
		[262652] = 7,
		[384479] = "Nokhud Longbow",
		[178963] = 12,
		[213771] = 11,
		[371172] = 11,
		[20271] = 2,
		[390625] = 8,
		[1044] = 2,
		[334320] = 9,
		[196881] = 7,
		[1064] = 7,
		[375273] = 12,
		[382440] = 8,
		[257284] = 3,
		[388583] = 9,
		[374251] = "Allegory",
		[279043] = 4,
		[271877] = 4,
		[375276] = 6,
		[196884] = 7,
		[1160] = 1,
		[22703] = 9,
		[157982] = 11,
		[236299] = 8,
		[384492] = "Nokhud Beastmaster",
		[382445] = 8,
		[383469] = 2,
		[388588] = "Allegory",
		[390636] = 5,
		[31661] = 8,
		[384494] = "Kyrakka",
		[110744] = 5,
		[52437] = 1,
		[390640] = 9,
		[384498] = 3,
		[110745] = 5,
		[384499] = 3,
		[308742] = 2,
		[29166] = 11,
		[360954] = 3,
		[5374] = 4,
		[383479] = 8,
		[388598] = 12,
		[207640] = 11,
		[91807] = 6,
		[388599] = 2,
		[388600] = 3,
		[194844] = 6,
		[386553] = 2,
		[115098] = 10,
		[384507] = 3,
		[111771] = 9,
		[271896] = 4,
		[383485] = 1,
		[210714] = 7,
		[385533] = 1,
		[1464] = 1,
		[102558] = 11,
		[23920] = 1,
		[384512] = "Nokhud Lancemaster",
		[389631] = 8,
		[264735] = 3,
		[185123] = 12,
		[115356] = 7,
		[260881] = 7,
		[108446] = 9,
		[385540] = 3,
		[21169] = 7,
		[292380] = 6,
		[77478] = 7,
		[188196] = 7,
		[373257] = 9,
		[390661] = 9,
		[115357] = 7,
		[394757] = 4,
		[393734] = 1,
		[117405] = 3,
		[157997] = 8,
		[382474] = "Decay Speaker",
		[391688] = 1,
		[132404] = 1,
		[1680] = 1,
		[373265] = 9,
		[390669] = 5,
		[391693] = 3,
		[263725] = 8,
		[146739] = 9,
		[373267] = "Rydrasil",
		[373268] = "Rydrasil",
		[1784] = 4,
		[372245] = "Allegory",
		[325153] = 10,
		[115360] = 7,
		[145205] = 11,
		[384532] = 3,
		[85416] = 2,
		[1856] = 4,
		[385558] = "Erkhart Stormvein",
		[390677] = 5,
		[396821] = 9,
		[287280] = 2,
		[387608] = "Ukhel Corruptor",
		[373276] = 5,
		[15290] = 5,
		[85673] = 2,
		[373277] = 5,
		[341541] = 4,
		[107428] = 10,
		[387611] = "Ukhel Corruptor",
		[373279] = "Thing From Beyond <Ahdri>",
		[345638] = 8,
		[202028] = 11,
		[360995] = "Allegory",
		[387613] = "Ukhel Corruptor",
		[396827] = 9,
		[381471] = 10,
		[387614] = "Ukhel Deathspeaker",
		[385567] = "Primalist Flamedancer",
		[23922] = 1,
		[391710] = 11,
		[196911] = 4,
		[391711] = "Thundering Ravager",
		[388640] = 8,
		[187698] = 3,
		[381475] = 10,
		[382499] = 11,
		[53595] = 2,
		[207150] = 6,
		[228649] = 10,
		[2120] = 8,
		[88747] = 11,
		[393763] = 11,
		[387621] = 10,
		[108199] = 6,
		[315961] = 1,
		[30449] = 8,
		[101545] = 10,
		[69041] = 8,
		[378412] = 2,
		[387626] = 9,
		[2336] = 11,
		[375342] = 7,
		[121253] = 10,
		[375343] = 11,
		[210738] = 6,
		[101546] = 10,
		[387629] = "Desecrated Ohuna",
		[204596] = 12,
		[375345] = 8,
		[396846] = 9,
		[122278] = 10,
		[77489] = 5,
		[204598] = 12,
		[5215] = 11,
		[187707] = 3,
		[100780] = 10,
		[88751] = 11,
		[373304] = 5,
		[114089] = 7,
		[34914] = 5,
		[386614] = 9,
		[235313] = 8,
		[325190] = 10,
		[5487] = 11,
		[258860] = 12,
		[235314] = 8,
		[199483] = 3,
		[204090] = 3,
		[57821] = 5,
		[33763] = 11,
		[33891] = 11,
		[117418] = 10,
		[122281] = 10,
		[196414] = 9,
		[375361] = 9,
		[194879] = 6,
		[199486] = 5,
		[212283] = 4,
		[225080] = 7,
		[281178] = 2,
		[388672] = "Allegory",
		[373316] = 5,
		[386625] = 1,
		[355913] = "Askalaphos-Gilneas",
		[49376] = 11,
		[336463] = 3,
		[100784] = 10,
		[355916] = "Allegory",
		[207167] = 6,
		[114093] = 7,
		[318038] = 7,
		[366155] = "Rydrasil",
		[47585] = 5,
		[381512] = "Erkhart Stormvein",
		[386631] = 1,
		[384584] = 5,
		[381513] = "Erkhart Stormvein",
		[125355] = 10,
		[30451] = 8,
		[381514] = "Erkhart Stormvein",
		[382538] = 2,
		[392776] = 1,
		[374349] = "Naldraxus-Malfurion",
		[53600] = 2,
		[207682] = 12,
		[392778] = 1,
		[381517] = "Erkhart Stormvein",
		[386636] = 1,
		[381518] = "Erkhart Stormvein",
		[205636] = 11,
		[388686] = 10,
		[389710] = 6,
		[207684] = 12,
		[360022] = "Askalaphos-Gilneas",
		[385616] = 4,
		[117679] = 11,
		[377427] = 5,
		[207685] = 12,
		[325217] = 10,
		[325218] = 10,
		[381525] = "Kyrakka",
		[269937] = 2,
		[381526] = "Kyrakka",
		[93622] = 11,
		[343648] = 11,
		[382551] = 1,
		[259387] = 3,
		[386647] = 9,
		[108211] = 4,
		[193356] = 4,
		[392791] = 1,
		[97462] = 1,
		[193357] = 4,
		[392793] = 1,
		[385627] = 4,
		[196941] = 2,
		[386652] = 2,
		[97463] = 1,
		[355941] = "Rydrasil",
		[222024] = 6,
		[387678] = 3,
		[335467] = 5,
		[124081] = 10,
		[263806] = 7,
		[281210] = 6,
		[8143] = 7,
		[207693] = 12,
		[396895] = "Thing From Beyond <Ahdri>",
		[382563] = "Kurog Grimtotem",
		[382564] = "Kurog Grimtotem",
		[384613] = 11,
		[77758] = 11,
		[385638] = 3,
		[258883] = 12,
		[384615] = 11,
		[377449] = 6,
		[184662] = 2,
		[393831] = 12,
		[73920] = 7,
		[182104] = 2,
		[377453] = 10,
		[391786] = 11,
		[384620] = "The Raging Tempest",
		[393834] = 12,
		[377455] = 8,
		[114871] = 2,
		[384624] = 11,
		[377458] = 12,
		[198487] = 10,
		[377459] = 12,
		[77505] = 7,
		[77761] = 11,
		[202583] = "Taldath the Destroyer",
		[377461] = 1,
		[384628] = "The Raging Tempest",
		[377462] = 11,
		[276111] = 2,
		[377463] = 12,
		[200025] = 2,
		[77762] = 7,
		[377464] = 8,
		[370298] = 6,
		[384631] = 4,
		[395893] = "Kurog Grimtotem",
		[395894] = "Kurog Grimtotem",
		[388728] = 1,
		[48743] = 6,
		[3411] = 1,
		[367230] = "Rydrasil",
		[147833] = 1,
		[205146] = 9,
		[368970] = "Allegory",
		[367231] = "Rydrasil",
		[1459] = 8,
		[382555] = "Bracken Warscourge",
		[388829] = 4,
		[383612] = 3,
		[5760] = 4,
		[356995] = "Askalaphos-Gilneas",
		[397399] = 9,
		[382865] = 11,
		[17038] = 1,
		[228477] = 12,
		[382133] = 12,
		[382864] = 11,
		[77764] = 11,
		[157348] = "Primal Storm Elemental <Blítzdìngs-Antonidas>",
		[19577] = 3,
		[369299] = "Rydrasil",
		[367726] = 3,
		[137619] = 4,
		[387547] = 9,
		[191840] = 10,
		[196447] = 9,
		[390195] = 12,
		[179057] = 12,
		[132463] = 10,
		[202590] = "Taldath the Destroyer",
		[109132] = 10,
		[114108] = 11,
		[363143] = 11,
		[196448] = 9,
		[53351] = 3,
		[390785] = 1,
		[363144] = 1,
		[390516] = 8,
		[194913] = 6,
		[375905] = 5,
		[394328] = 4,
		[388739] = 9,
		[382861] = 11,
		[386692] = 6,
		[376061] = 3,
		[43308] = 1,
		[201430] = 3,
		[391050] = "High Channeler Ryvati",
		[55090] = 6,
		[384646] = 1,
		[34026] = 3,
		[386694] = "Stormsurge Totem",
		[115129] = 10,
		[370817] = 1,
		[25912] = 2,
		[73921] = 7,
		[371339] = 9,
		[127797] = 11,
		[187878] = 7,
		[20707] = 9,
		[132467] = 10,
		[30455] = 8,
		[271971] = "Dreadstalker <Saád-Malygos>",
		[387096] = 9,
		[322098] = 5,
		[102351] = 11,
		[274009] = 6,
		[327574] = 6,
		[108287] = 7,
		[374002] = 12,
		[121147] = 6,
		[227291] = "Niuzao <Kenichi-DunMorogh>",
		[389774] = 1,
		[116670] = 10,
		[382245] = 4,
		[23161] = 9,
		[109248] = 3,
		[370794] = 6,
		[373392] = "Nokhud Longbow",
		[198817] = 1,
		[27576] = 4,
		[225119] = 8,
		[81340] = 6,
		[387260] = 9,
		[382097] = 2,
		[128594] = 3,
		[393869] = 11,
		[374271] = 6,
		[212800] = 12,
		[368276] = 5,
		[205644] = "Treant <Wegwienix-Ambossar>",
		[32375] = 5,
		[371348] = 9,
		[202598] = "Taldath the Destroyer",
		[114255] = 5,
		[198813] = 12,
		[388673] = 7,
		[371355] = 12,
		[392574] = "Tempest Channeler",
		[263856] = "Nomnom <Raffit-Ysera>",
		[371350] = 9,
		[394709] = 2,
		[381965] = 3,
		[335152] = 3,
		[16827] = "Björn <Lüddl>",
		[388755] = "Askalaphos-Gilneas",
		[88263] = 2,
		[118779] = 1,
		[400254] = 11,
		[289308] = 8,
		[324260] = 1,
		[386709] = 6,
		[371353] = 9,
		[231895] = 2,
		[21562] = 5,
		[230242] = 3,
		[371354] = 12,
		[165961] = 11,
		[383873] = 1,
		[370564] = "Rydrasil",
		[281265] = 5,
		[388759] = 1,
		[102560] = 11,
		[374427] = "Tectonic Crusher",
		[121536] = 5,
		[207203] = 6,
		[382156] = 3,
		[374428] = "Tectonic Crusher",
		[373977] = "Primalist Flamedancer",
		[384503] = 4,
		[97341] = "Naldraxus-Malfurion",
		[11327] = 4,
		[171850] = 2,
		[370562] = "Rydrasil",
		[22842] = 11,
		[382620] = "Bonebolt Hunter",
		[386540] = 8,
		[31224] = 4,
		[209258] = 12,
		[19483] = "Infernal <Donlock-Antonidas>",
		[118522] = 7,
		[190319] = 8,
		[35395] = 2,
		[374432] = "Tectonic Crusher",
		[205448] = 5,
		[102342] = 11,
		[184689] = 2,
		[59752] = 9,
		[359077] = "Askalaphos-Gilneas",
		[343721] = 2,
		[381955] = "Syndarion-Gilneas",
		[386026] = "Unstable Squall",
		[223306] = 2,
		[383978] = 1,
		[117952] = 10,
		[2643] = 3,
		[148859] = 5,
		[386632] = 1,
		[381602] = "Kyrakka",
		[122470] = 10,
		[228128] = 12,
		[343724] = 2,
		[209261] = 12,
		[94719] = 6,
		[382426] = 11,
		[384186] = "The Raging Tempest",
		[374430] = "Tectonic Crusher",
		[386723] = 2,
		[390618] = 9,
		[382419] = 5,
		[381605] = "Kyrakka",
		[8512] = 7,
		[20153] = "Infernal <Donlock-Antonidas>",
		[322101] = 10,
		[389148] = 2,
		[386725] = 2,
		[113862] = 8,
		[262232] = 1,
		[381607] = "Kyrakka",
		[106951] = 11,
		[378213] = "Rydrasil",
		[334275] = 9,
		[25914] = 2,
		[32409] = "[*] Shadow Word: Death",
		[107574] = 1,
		[386025] = "Primalist Stormspeaker",
		[8042] = 7,
		[386728] = 2,
		[395942] = 11,
		[209426] = 12,
		[215407] = 12,
		[386729] = 12,
		[195125] = 6,
		[265931] = 9,
		[370553] = "Allegory",
		[257045] = 3,
		[395944] = 11,
		[44457] = 8,
		[210803] = 10,
		[2139] = 8,
		[384316] = "The Raging Tempest",
		[388025] = 10,
		[271048] = 3,
		[42223] = 9,
		[285381] = 11,
		[384685] = 8,
		[271049] = 3,
		[66196] = 6,
		[49576] = 6,
		[384686] = "The Raging Tempest",
		[384029] = 2,
		[192109] = 7,
		[115399] = 10,
		[384687] = "The Raging Tempest",
		[118699] = 9,
		[387763] = "Naldraxus-Malfurion",
		[270323] = 3,
		[273104] = 2,
		[389807] = 12,
		[258920] = 12,
		[396212] = "[*] Chilling Presence",
		[394215] = 9,
		[207317] = 6,
		[386486] = 1,
		[198103] = 7,
		[228645] = 6,
		[316099] = 9,
		[258921] = 12,
		[374250] = 12,
		[319175] = 4,
		[389810] = 12,
		[5217] = 11,
		[163201] = 1,
		[33778] = 11,
		[267999] = "Vilefiend <Saád-Malygos>",
		[258922] = 12,
		[210294] = 2,
		[392883] = 10,
		[370602] = 11,
		[120644] = 5,
		[45297] = 7,
		[373973] = "Primalist Flamedancer",
		[381623] = 4,
		[8936] = 11,
		[148022] = 8,
		[388790] = 7,
		[385724] = 2,
		[394933] = 12,
		[374779] = "Kurog Grimtotem",
		[390835] = 2,
		[389815] = 12,
		[394934] = 12,
		[20473] = 2,
		[157981] = 8,
		[389816] = 1,
		[199547] = 12,
		[334713] = "Dreadstalker <Saád-Malygos>",
		[351338] = "Allegory",
		[2825] = 7,
		[275335] = 1,
		[222026] = 6,
		[15487] = 5,
		[385723] = 2,
		[157736] = 9,
		[267997] = "Vilefiend <Saád-Malygos>",
		[5761] = 4,
		[205179] = 9,
		[373614] = "Blazebound Destroyer",
		[198013] = 12,
		[105421] = 2,
		[389820] = "Allegory",
		[51490] = 7,
		[126664] = 1,
		[386959] = 10,
		[205180] = 9,
		[390845] = 5,
		[388801] = "Risen Warrior",
		[203651] = 11,
		[373442] = "Mindbender <Ahdri>",
		[152108] = 9,
		[204157] = 12,
		[57755] = 1,
		[343312] = 12,
		[209788] = 12,
		[375491] = 12,
		[381802] = 4,
		[50401] = 6,
		[385424] = 4,
		[783] = 11,
		[188290] = 6,
		[377540] = 6,
		[217979] = 9,
		[221562] = 6,
		[194310] = 6,
		[392038] = 3,
		[199552] = 12,
		[108238] = 11,
		[388007] = 2,
		[381637] = 4,
		[373213] = 5,
		[214397] = 10,
		[53563] = 2,
		[6353] = 9,
		[29893] = 9,
		[376866] = "Balakar Khan",
		[319190] = 4,
		[131474] = 8,
		[242551] = 2,
		[388808] = 1,
		[116011] = 8,
		[371984] = "Flashfrost Chillweaver",
		[370537] = "Rydrasil",
		[114214] = 5,
		[207386] = 11,
		[391891] = 11,
		[386760] = 9,
		[391215] = 12,
		[392903] = 2,
		[386276] = 10,
		[138130] = 10,
		[191877] = 7,
		[200656] = 2,
		[131476] = 8,
		[213888] = 12,
		[388376] = 3,
		[31850] = 2,
		[256374] = 1,
		[224126] = 7,
		[220543] = 5,
		[155722] = 11,
		[383696] = 10,
		[395978] = 9,
		[383693] = "Nokhud Beastmaster",
		[198533] = 10,
		[393931] = 1,
		[224127] = 7,
		[131894] = 3,
		[392908] = 1,
		[370652] = 8,
		[115151] = 10,
		[188370] = 2,
		[183811] = 2,
		[373458] = "Primal Terrasentry",
		[344548] = 7,
		[195975] = 6,
		[272790] = 3,
		[389839] = "Askalaphos-Gilneas",
		[394958] = 12,
		[36213] = "Greater Earth Elemental <Fengala-DieArguswacht>",
		[255937] = 2,
		[393935] = 3,
		[387796] = "Bracken Warscourge",
		[61295] = 7,
		[388817] = "Granyth",
		[191837] = 10,
		[374485] = "Blazing Fiend",
		[391889] = 11,
		[215785] = 7,
		[373462] = 5,
		[394961] = 5,
		[200654] = 2,
		[391058] = 12,
		[197625] = 11,
		[269571] = 2,
		[383701] = 10,
		[333957] = 7,
		[373464] = 5,
		[383328] = 2,
		[374625] = "Frozen Destroyer",
		[279303] = 6,
		[389845] = 9,
		[390869] = "Naldraxus-Malfurion",
		[135286] = 11,
		[49206] = 6,
		[116014] = 8,
		[686] = 9,
		[148135] = 10,
		[2641] = 3,
		[389847] = 12,
		[321388] = 8,
		[53365] = 6,
		[210824] = 8,
		[393943] = 1,
		[256893] = 5,
		[383706] = 1,
		[388367] = 3,
		[369374] = "Allegory",
		[83243] = 3,
		[264057] = 9,
		[396918] = 7,
		[15407] = 5,
		[156423] = 12,
		[381683] = "Nokhud Warspear",
		[344572] = "Nomnom <Raffit-Ysera>",
		[203413] = 3,
		[45470] = 6,
		[393955] = 11,
		[232698] = 5,
		[389860] = 12,
		[137639] = 10,
		[78674] = 11,
		[392924] = "High Channeler Ryvati",
		[703] = 4,
		[382089] = 7,
		[395996] = 4,
		[186257] = 3,
		[93337] = 2,
		[61336] = 11,
		[196608] = 10,
		[330131] = 5,
		[378994] = 11,
		[392451] = "Flame Channeler",
		[105174] = 9,
		[186258] = 3,
		[393951] = 1,
		[219788] = 6,
		[371070] = 12,
		[102359] = 11,
		[394366] = 3,
		[232613] = 4,
		[139068] = 7,
		[596] = 5,
		[389858] = 12,
		[378597] = 7,
		[361195] = "Allegory",
		[219432] = 11,
		[203782] = 12,
		[259760] = 5,
		[387812] = 2,
		[372456] = "Kurog Grimtotem",
		[93402] = 11,
		[205025] = 8,
		[209388] = 2,
		[357210] = "Syndarion-Gilneas",
		[373481] = 5,
		[214980] = 1,
		[386028] = "Primalist Thunderbeast",
		[190356] = 8,
		[393957] = 11,
		[201671] = 11,
		[257044] = 3,
		[52212] = 6,
		[171982] = 9,
		[372963] = "Melidrussa Chillworn",
		[396006] = 7,
		[190357] = 8,
		[393959] = 11,
		[384636] = 1,
		[77535] = 6,
		[260402] = 3,
		[246152] = 3,
		[1161] = 1,
		[58867] = "Spirit Wolf <Snacksyheal>",
		[210833] = 8,
		[393961] = 11,
		[385787] = 11,
		[191894] = 10,
		[356084] = 5,
		[279302] = 6,
		[387402] = 9,
		[121557] = 5,
		[202644] = 12,
		[389868] = 9,
		[393038] = 2,
		[371441] = "Rydrasil",
		[147362] = 3,
		[394504] = 11,
		[395289] = 8,
		[224125] = 7,
		[397036] = 5,
		[183435] = 2,
		[393939] = 8,
		[193359] = 4,
		[93985] = 11,
		[274281] = 11,
		[348162] = 12,
		[214743] = 12,
		[319233] = 6,
		[359618] = "Allegory",
		[390896] = "Allegory",
		[325984] = 2,
		[397039] = 1,
		[377588] = 6,
		[386891] = 1,
		[319238] = 6,
		[372470] = "Askalaphos-Gilneas",
		[381684] = 7,
		[215956] = 9,
		[285452] = 7,
		[347901] = 9,
		[383351] = 2,
		[390899] = 1,
		[319836] = 8,
		[1329] = 4,
		[377591] = 6,
		[385536] = "Primalist Flamedancer",
		[370511] = "Allegory",
		[331523] = 12,
		[5394] = 7,
		[185245] = 12,
		[202137] = 12,
		[341374] = 5,
		[200200] = 5,
		[394550] = 2,
		[386890] = 12,
		[298765] = 7,
		[186270] = 3,
		[271045] = 3,
		[394727] = 2,
		[384761] = "The Raging Tempest",
		[325464] = 6,
		[381692] = "Nokhud Warspear",
		[114282] = 11,
		[49143] = 6,
		[123904] = 10,
		[61684] = "Björn <Lüddl>",
		[47541] = 6,
		[319243] = 6,
		[11426] = 8,
		[384644] = 12,
		[383800] = 10,
		[360194] = 4,
		[371807] = "Allegory",
		[1449] = 8,
		[202140] = 12,
		[319245] = 6,
		[319236] = 6,
		[207771] = 12,
		[46968] = 1,
		[392956] = 3,
		[208628] = 12,
		[333889] = 9,
		[5938] = 4,
		[391493] = 2,
		[386886] = 11,
		[341770] = 9,
		[367364] = "Rydrasil",
		[137211] = 11,
		[201428] = 12,
		[272156] = "Void Terror <Saád-Malygos>",
		[86040] = 9,
		[392959] = 10,
		[198337] = 1,
		[81141] = 6,
		[285466] = 7,
		[401150] = 1,
		[385794] = 4,
		[313108] = 6,
		[185763] = 4,
		[312411] = 6,
		[381700] = 7,
		[383813] = "Askalaphos-Gilneas",
		[384294] = 7,
		[331537] = "Shadowgrasp Totem <Lulax-Malfurion>",
		[213405] = 12,
		[325983] = 2,
		[347765] = 12,
		[46585] = 6,
		[34428] = 1,
		[15286] = 5,
		[124506] = 10,
		[386344] = 9,
		[135601] = 11,
		[59638] = "Mirror Image <Ayuvinayeth-Antonidas>",
		[387846] = 9,
		[392418] = 9,
		[392511] = 5,
		[116189] = 10,
		[387847] = 9,
		[391430] = 12,
		[320338] = 12,
		[376644] = "Balakar Khan",
		[45334] = 11,
		[383346] = 2,
		[391602] = 12,
		[390920] = "Kurog Grimtotem",
		[375825] = "Frozen Destroyer",
		[382522] = 2,
		[385802] = 4,
		[18562] = 11,
		[202147] = 1,
		[114074] = 7,
		[195292] = 6,
		[388380] = 3,
		[383756] = 3,
		[278310] = 8,
		[33917] = 11,
		[85222] = 2,
		[388379] = 4,
		[408] = 4,
		[207267] = 6,
		[227255] = 12,
		[1725] = 4,
		[396092] = 1,
		[114911] = 7,
		[205766] = 8,
		[31935] = 2,
		[114923] = 8,
		[70890] = 6,
		[196728] = "Niuzao <Kenichi-DunMorogh>",
		[204197] = 5,
		[384784] = 3,
		[325461] = 6,
		[272172] = "Shivarra <Saád-Malygos>",
		[396046] = 12,
		[266030] = 9,
		[344859] = 12,
		[386833] = 9,
		[383762] = 1,
		[35546] = 4,
		[374622] = "Thundering Ravager",
		[370454] = "Kisará-Alleria",
		[191587] = 6,
		[344862] = 12,
		[22482] = 4,
		[389533] = 1,
		[394006] = 1,
		[257946] = 3,
		[164273] = 3,
		[1833] = 4,
		[394994] = 8,
		[387855] = 5,
		[385806] = 4,
		[116705] = 10,
		[375576] = 2,
		[372505] = 11,
		[112866] = 9,
		[14914] = 5,
		[342817] = 12,
		[275779] = 2,
		[344865] = 12,
		[374554] = "[*] Magma Pool",
		[370452] = "Midnightstar-Antonidas",
		[397077] = "Melidrussa Chillworn",
		[385816] = 2,
		[367931] = 4,
		[322109] = 10,
		[392983] = 10,
		[231843] = 2,
		[390936] = 1,
		[96231] = 2,
		[215479] = 10,
		[18499] = 1,
		[374557] = 6,
		[396056] = "Kurog Grimtotem",
		[372794] = "Defier Draghar",
		[394009] = 12,
		[211881] = 12,
		[371982] = 11,
		[278326] = 12,
		[381725] = 7,
		[390941] = 2,
		[84714] = 8,
		[155158] = 8,
		[394011] = "Allegory",
		[31616] = 7,
		[371489] = "Flashfrost Chillweaver",
		[376634] = "Balakar Khan",
		[30146] = 9,
		[193455] = 3,
		[395035] = "Soulharvester Galtmaa",
		[162243] = 12,
		[377633] = 6,
		[183218] = 2,
		[6673] = 1,
		[392990] = 5,
		[394015] = 4,
		[382753] = 3,
		[374025] = "Kurog Grimtotem",
		[377656] = 6,
		[365350] = 8,
		[196528] = 6,
		[49020] = 6,
		[2050] = 5,
		[157128] = 2,
		[57330] = 6,
		[259489] = 3,
		[384193] = 3,
		[390981] = 5,
		[199600] = 4,
		[187827] = 12,
		[81297] = 2,
		[205231] = "Darkglare <Tinca-Anetheron>",
		[228532] = 12,
		[383781] = 3,
		[353084] = 8,
		[333120] = 12,
		[388867] = 10,
		[8676] = 4,
		[397091] = 8,
		[48181] = 9,
		[383783] = 8,
		[396068] = "Kurog Grimtotem",
		[231338] = 4,
		[394021] = 4,
		[194249] = 5,
		[285515] = 7,
		[377642] = 6,
		[129250] = 5,
		[353082] = 8,
		[198067] = 7,
		[20484] = 11,
		[398118] = 12,
		[199603] = 4,
		[85739] = 1,
		[384810] = 2,
		[45438] = 8,
		[57723] = 7,
		[396072] = "Kurog Grimtotem",
		[203975] = 11,
		[357170] = "Rydrasil",
		[6552] = 1,
		[385292] = "[*] Molten Steel",
		[368432] = "Allegory",
		[394026] = 4,
		[34433] = 5,
		[202164] = 1,
		[58875] = 7,
		[365362] = 8,
		[390921] = "Kurog Grimtotem",
		[396077] = "Kurog Grimtotem",
		[388909] = 3,
		[114919] = 2,
		[115175] = 10,
		[120954] = 10,
		[389407] = "Askalaphos-Gilneas",
		[390917] = "Naldraxus-Malfurion",
		[129253] = 5,
		[204213] = 5,
		[389890] = 12,
		[19236] = 5,
		[125050] = 3,
		[202166] = 1,
		[364342] = "Allegory",
		[394031] = 4,
		[391973] = 9,
		[285514] = 7,
		[364343] = "Rydrasil",
		[385842] = 1,
		[115176] = 10,
		[157122] = 2,
		[393009] = 12,
		[381748] = "Askalaphos-Gilneas",
		[47528] = 6,
		[384773] = "Kyrakka",
		[278350] = 9,
		[394034] = 1,
		[386868] = 4,
		[202168] = 1,
		[2098] = 4,
		[280375] = 2,
		[390964] = 5,
		[108920] = 5,
		[210105] = 12,
		[394036] = 4,
		[374585] = 6,
		[375901] = 5,
		[384823] = "Blazebound Firestorm <Kokia Blazehoof>",
		[215478] = 12,
		[197835] = 4,
		[387895] = 2,
		[282449] = 4,
		[312106] = 10,
		[395006] = 8,
		[84721] = 8,
		[44544] = 8,
		[207289] = 6,
		[173183] = 7,
		[85256] = 2,
		[2818] = 4,
		[381755] = 7,
		[382079] = 9,
		[205246] = 9,
		[385568] = "Primalist Flamedancer",
		[374037] = 12,
		[386875] = 3,
		[1953] = 8,
		[227847] = 1,
		[221883] = 2,
		[390971] = 5,
		[400185] = 9,
		[198589] = 12,
		[95750] = 9,
		[386877] = 3,
		[228260] = 5,
		[390933] = 5,
		[320334] = 12,
		[43265] = 6,
		[342857] = 12,
		[198590] = 9,
		[381760] = 10,
		[383761] = 1,
		[396044] = "Melidrussa Chillworn",
		[212396] = 3,
		[204490] = 12,
		[273977] = 6,
		[361237] = 11,
		[394354] = 1,
		[394047] = 11,
		[390435] = "Askalaphos-Gilneas",
		[393995] = 9,
		[102383] = 11,
		[20549] = 11,
		[197568] = 7,
		[372014] = "Allegory",
		[165832] = 11,
		[394049] = 11,
		[390978] = 5,
		[192081] = 11,
		[114050] = 7,
		[394050] = 11,
		[374599] = 9,
		[157131] = 2,
		[392490] = 6,
		[8613] = 11,
		[114113] = 11,
		[391459] = 6,
		[245686] = 1,
		[41425] = 8,
		[115181] = 10,
		[225921] = 12,
		[101643] = 10,
		[342076] = 3,
		[392452] = "Flame Channeler",
		[108271] = 7,
		[327510] = 2,
		[274837] = 11,
		[386888] = 1,
		[102793] = 11,
		[235450] = 8,
		[185313] = 4,
		[114158] = 2,
		[383818] = 1,
		[114738] = 7,
		[131900] = 3,
		[164812] = 11,
		[386998] = 9,
		[65116] = 3,
		[124682] = 10,
		[374606] = 6,
		[183752] = 12,
		[321390] = 8,
		[260798] = 1,
		[374087] = 6,
		[48792] = 6,
		[393035] = 12,
		[256522] = 4,
		[288613] = 3,
		[232893] = 12,
		[356181] = 3,
		[72221] = "Askalaphos-Gilneas",
		[390989] = 5,
		[383823] = "Nokhud Hornsounder",
		[274282] = 11,
		[394061] = 11,
		[12654] = 8,
		[400204] = 11,
		[274283] = 11,
		[394062] = 1,
		[164815] = 11,
		[114954] = 8,
		[363916] = "Allegory",
		[371028] = 3,
		[204513] = 12,
		[80353] = 8,
		[376660] = "Balakar Khan",
		[357209] = "Askalaphos-Gilneas",
		[390993] = 5,
		[397041] = 8,
		[307046] = 12,
		[57984] = "Greater Fire Elemental <Fengala-DieArguswacht>",
		[381654] = 3,
		[255654] = 1,
		[191466] = 12,
		[357211] = "Askalaphos-Gilneas",
		[20572] = 1,
		[396222] = "[*] Shattering Presence",
		[190411] = 1,
		[357212] = "Askalaphos-Gilneas",
		[203720] = 12,
		[50842] = 6,
		[3714] = 6,
		[252216] = 11,
		[383168] = "Naldraxus-Malfurion",
		[197834] = 4,
		[251837] = 2,
		[393971] = 4,
		[374348] = "Naldraxus-Malfurion",
		[163073] = 12,
		[391888] = 11,
		[7268] = 8,
		[345466] = 12,
		[234946] = 5,
		[264178] = 9,
		[394259] = 12,
		[27285] = 9,
		[373966] = 12,
		[8004] = 7,
		[388035] = 3,
		[374621] = "Thundering Ravager",
		[226757] = 8,
		[197209] = 7,
		[386414] = 4,
		[386907] = 4,
		[390838] = 9,
		[200652] = 2,
		[385884] = 8,
		[374623] = "Frozen Destroyer",
		[392937] = 1,
		[214985] = 1,
		[198030] = 12,
		[374624] = "Frozen Destroyer",
		[216521] = 10,
		[311193] = 1,
		[90361] = 3,
		[35079] = 1,
		[257542] = 8,
		[153561] = 8,
		[263140] = 3,
		[386911] = 2,
		[32182] = 7,
		[393054] = 12,
		[344006] = 10,
		[386912] = "[*] Stormsurge Cloud",
		[384379] = 8,
		[393055] = 12,
		[162264] = 12,
		[391008] = 2,
		[49028] = 6,
		[393056] = 10,
		[385890] = 1,
		[200758] = 4,
		[381657] = 3,
		[192249] = 7,
		[335096] = 1,
		[382849] = 8,
		[117014] = 7,
		[384868] = "Nokhud Longbow",
		[345020] = 10,
		[386916] = "The Raging Tempest",
		[372032] = 1,
		[376679] = 1,
		[207311] = 6,
		[114165] = 2,
		[111898] = 9,
		[200657] = 2,
		[386124] = 9,
		[51460] = 6,
		[132578] = 10,
		[345464] = 12,
		[202497] = 11,
		[132168] = 1,
		[212431] = 3,
		[30213] = "Haaroon <Saád-Malygos>",
		[199581] = 9,
		[194311] = 6,
		[48517] = 11,
		[376683] = "Balakar Khan",
		[385897] = 4,
		[386921] = "Dragonkiller Lance",
		[204242] = 2,
		[106785] = 11,
		[377708] = 1,
		[397338] = "Tectonic Crusher",
		[85948] = 6,
		[376685] = "Balakar Khan",
		[385899] = 9,
		[377763] = 3,
		[186387] = 3,
		[26297] = 3,
		[229837] = 10,
		[337819] = 12,
		[109304] = 3,
		[225788] = "Allegory",
		[63106] = 9,
		[378735] = 12,
		[263648] = 12,
		[391748] = 3,
		[394714] = 2,
		[115191] = 4,
		[132403] = 2,
		[195457] = 4,
		[385903] = 9,
		[122783] = 10,
		[108281] = 7,
		[34477] = 3,
		[203415] = 3,
		[143924] = 5,
		[48518] = 11,
		[113656] = 10,
		[344955] = 6,
		[32645] = 4,
		[212436] = 3,
		[83381] = "Nomnom <Raffit-Ysera>",
		[385906] = 9,
		[186401] = "Allegory",
		[201754] = "Nomnom <Raffit-Ysera>",
		[376737] = "[*] Lightning",
		[69070] = 4,
		[386931] = 9,
		[54149] = 2,
		[346665] = 12,
		[385408] = 4,
		[358267] = "Allegory",
		[257541] = 8,
		[185099] = 10,
		[375902] = 5,
		[386933] = 4,
		[102352] = 11,
		[184362] = 1,
		[63619] = "Mindbender <Ahdri>",
		[19574] = 3,
		[229976] = 2,
		[1126] = 11,
		[394101] = 2,
		[271881] = 4,
		[291843] = 1,
		[116680] = 10,
		[75] = 3,
		[391031] = "Primal Thundercloud",
		[321530] = 3,
		[280735] = 1,
		[205648] = 7,
		[378747] = 3,
		[297871] = 12,
		[58984] = 12,
		[263642] = 12,
		[185311] = 4,
		[11366] = 8,
		[122] = 8,
		[389277] = 9,
		[382844] = 8,
		[392058] = 3,
		[270232] = 8,
		[385916] = "Granyth",
		[382845] = 8,
		[392329] = 11,
		[372608] = 3,
		[386029] = 1,
		[160029] = 11,
		[392060] = 3,
		[393786] = 10,
		[32379] = 5,
		[382847] = 8,
		[392061] = 3,
		[372610] = 3,
		[381824] = 11,
		[382848] = 8,
		[108285] = 7,
		[155625] = 11,
		[190784] = 2,
		[32390] = 9,
		[44425] = 8,
		[255546] = 4,
		[394111] = 11,
		[382850] = 8,
		[187874] = 7,
		[12294] = 1,
		[193315] = 4,
		[382851] = 8,
		[209693] = 12,
		[202719] = 12,
		[120360] = 3,
		[118905] = 7,
		[204255] = 12,
		[390163] = 12,
		[381522] = 8,
		[378015] = 3,
		[25504] = 7,
		[372616] = 5,
		[361500] = "Askalaphos-Gilneas",
		[162794] = 12,
		[51505] = 7,
		[162480] = 3,
		[267171] = 9,
		[378760] = 8,
		[55095] = 6,
		[388998] = 3,
		[47753] = 5,
		[193358] = 4,
		[30151] = "Haaroon <Saád-Malygos>",
		[188389] = 7,
		[48265] = 6,
		[155777] = 11,
		[274062] = 10,
		[345231] = 3,
		[72968] = 3,
		[296863] = 2,
		[77575] = 6,
		[384906] = 2,
		[326731] = 2,
		[205386] = 5,
		[248622] = 1,
		[375335] = 7,
		[385700] = 4,
		[382860] = 11,
		[228478] = 12,
		[389328] = 10,
		[392576] = "Tempest Channeler",
		[370576] = 11,
		[372808] = "Melidrussa Chillworn",
		[351316] = 6,
		[186265] = 3,
		[382862] = 11,
		[31687] = 8,
		[375904] = 5,
		[377451] = 5,
		[382863] = 11,
		[333964] = 7,
		[231390] = 3,
		[23881] = 1,
		[391054] = 2,
		[200166] = 12,
		[227723] = 1,
		[384185] = "The Raging Tempest",
		[378770] = 3,
		[51399] = 6,
		[376723] = "Nokhud Stormcaster",
		[51723] = 4,
		[382866] = 11,
		[381699] = 4,
	},
	["auto_open_news_window"] = true,
	["got_first_run"] = true,
	["all_switch_config"] = {
		["scale"] = 1,
		["font_size"] = 10,
	},
	["__profiles"] = {
		["Allegory-Blackmoore"] = {
			["overall_clear_newtorghast"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["disable_mythic_dungeon"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["default_bg_color"] = 0.0941,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_no_libwindow"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
			["animation_speed"] = 33,
			["deadlog_limit"] = 16,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["font_face"] = "Friz Quadrata TT",
				["text_offset"] = 2,
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["memory_ram"] = 64,
			["instances_segments_locked"] = true,
			["ps_abbreviation"] = 3,
			["disable_window_groups"] = false,
			["data_broker_text"] = "",
			["pvp_as_group"] = true,
			["instances_suppress_trash"] = 0,
			["use_battleground_server_parser"] = false,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["numerical_system_symbols"] = "auto",
			["report_schema"] = 1,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["death_tooltip_width"] = 350,
			["numerical_system"] = 1,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -140.5829467773438,
							["x"] = 454.6597900390625,
							["w"] = 230.1668701171875,
							["h"] = 18.85465431213379,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["clickthrough_window"] = false,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["bars_sort_direction"] = 1,
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
							["enabled"] = false,
							["size"] = 12,
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["height"] = 21,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["use_spec_icons"] = true,
						["percent_type"] = 1,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["show_faction_icon"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["arena_role_icon_size_offset"] = -10,
						["textR_bracket"] = "(",
						["texture_custom"] = "",
						["show_arena_role_icon"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_background"] = "Details D'ictum (reverse)",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["textR_enable_custom_text"] = false,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["start_after_icon"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["font_size"] = 16,
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["skin"] = "Minimalistic",
					["__was_opened"] = true,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["fullborder_shown"] = false,
					["grab_on_top"] = false,
					["use_multi_fontstrings"] = true,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["show_sidebars"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["fontstrings_text_limit_offset"] = -10,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["menu_icons_size"] = 0.82,
					["micro_displays_locked"] = true,
					["backdrop_texture"] = "Details Ground",
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["hide_in_combat_alpha"] = 0,
					["clickthrough_rows"] = false,
					["rowareaborder_shown"] = false,
					["libwindow"] = {
						["y"] = -140.5829315185547,
						["x"] = -90.3104248046875,
						["point"] = "RIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["show_statusbar"] = false,
					["bars_grow_direction"] = 1,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["strata"] = "LOW",
					["switch_damager_in_combat"] = false,
					["switch_damager"] = false,
					["switch_all_roles_after_wipe"] = false,
					["auto_current"] = true,
					["skin_custom"] = "",
					["bg_alpha"] = 0.6,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["show_timer"] = true,
						["enable_custom_text"] = false,
						["show_timer_bg"] = true,
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -140.5829467773438,
							["x"] = 454.6597900390625,
							["w"] = 230.1668701171875,
							["h"] = 18.85465431213379,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["fontstrings_text3_anchor"] = 38,
					["ignore_mass_showhide"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["bars_inverted"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["segments_amount"] = 40,
			["report_lines"] = 5,
			["auto_swap_to_dynamic_overall"] = false,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["time_type_original"] = 2,
			["overall_clear_newboss"] = true,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["overall_clear_logout"] = false,
			["minimum_combat_time"] = 5,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["use_scroll"] = false,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["disable_alldisplays_window"] = false,
			["total_abbreviation"] = 2,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["animation_speed_triggertravel"] = 5,
			["segments_amount_to_save"] = 40,
			["clear_graphic"] = true,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["version"] = 1,
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
			},
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = false,
				["minimapPos"] = 61.7118018250174,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["trash_auto_remove"] = false,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["deny_score_messages"] = false,
			["segments_panic_mode"] = false,
			["overall_flag"] = 16,
			["show_arena_role_icon"] = false,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["overall_clear_pvp"] = true,
			["time_type"] = 2,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["force_activity_time_pvp"] = true,
			["clear_ungrouped"] = true,
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["standard_skin"] = false,
			["instances_disable_bar_highlight"] = false,
			["default_bg_alpha"] = 0.5,
			["disable_lock_ungroup_buttons"] = false,
		},
		["Taifunari-Blackmoore"] = {
			["show_arena_role_icon"] = false,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["disable_mythic_dungeon"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["ocd_tracker"] = {
				["enabled"] = false,
				["cooldowns"] = {
				},
				["show_conditions"] = {
					["only_inside_instance"] = true,
					["only_in_group"] = true,
				},
				["pos"] = {
				},
				["show_options"] = false,
			},
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["tooltip"] = {
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 2,
				["anchored_to"] = 1,
				["show_amount"] = false,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["background"] = {
					0.196, -- [1]
					0.196, -- [2]
					0.196, -- [3]
					0.8697, -- [4]
				},
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 6,
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["maximize_method"] = 1,
				["fontshadow"] = false,
				["border_size"] = 14,
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = true,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["current_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = true,
				["sample_size"] = 5,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = false,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 65,
					["width"] = 220,
				},
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["animation_speed"] = 33,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["instances_segments_locked"] = true,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["deadlog_limit"] = 16,
			["instances_no_libwindow"] = false,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["clear_ungrouped"] = true,
			["data_broker_text"] = "",
			["segments_amount"] = 18,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 6.103515625e-05,
							["x"] = -0.0001220703125,
							["w"] = 310,
							["h"] = 157.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.850000023841858,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.0941176470588235,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["micro_displays_locked"] = true,
					["fontstrings_width"] = 35,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.0941176470588235,
					["menu_icons_alpha"] = 0.5,
					["bg_b"] = 0.0941176470588235,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.0705882352941177, -- [1]
						0.0705882352941177, -- [2]
						0.0705882352941177, -- [3]
						0.639196664094925, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 70,
					["StatusBarSaved"] = {
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
					},
					["__was_opened"] = true,
					["bg_alpha"] = 0.183960914611816,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["clickthrough_window"] = false,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["stretch_button_side"] = 1,
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["ignore_mass_showhide"] = false,
					["hide_in_combat_alpha"] = 0,
					["hide_in_combat_type"] = 1,
					["fontstrings_text3_anchor"] = 35,
					["libwindow"] = {
						["y"] = 6.103515625e-05,
						["x"] = -0.0001220703125,
						["point"] = "CENTER",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["bars_grow_direction"] = 1,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_sort_direction"] = 1,
					["switch_damager_in_combat"] = false,
					["grab_on_top"] = false,
					["bars_inverted"] = false,
					["micro_displays_side"] = 2,
					["auto_current"] = true,
					["skin_custom"] = "",
					["desaturated_menu"] = false,
					["switch_all_roles_after_wipe"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 6.103515625e-05,
							["x"] = -0.0001220703125,
							["w"] = 310,
							["h"] = 157.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["font_size"] = 16,
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\BantoBar",
						["backdrop"] = {
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
						},
						["percent_type"] = 1,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textR_bracket"] = "(",
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "BantoBar",
						["start_after_icon"] = true,
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_background"] = "Details D'ictum (reverse)",
						["alpha"] = 1,
						["textR_class_colors"] = false,
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_outline_small"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["attribute_text"] = {
						["show_timer"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["custom_text"] = "{name}",
						["text_face"] = "Accidental Presidency",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["enabled"] = true,
						["enable_custom_text"] = false,
						["text_size"] = 12,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_tank_in_combat"] = false,
					["show_sidebars"] = false,
					["use_multi_fontstrings"] = false,
					["switch_healer_in_combat"] = false,
				}, -- [1]
			},
			["report_lines"] = 5,
			["use_battleground_server_parser"] = false,
			["use_scroll"] = false,
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["report_schema"] = 1,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["overall_clear_newboss"] = true,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["memory_threshold"] = 3,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MONK"] = {
					0.5, -- [1]
					0.73828125, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.73828126, -- [1]
					1, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
			},
			["time_type_original"] = 2,
			["disable_alldisplays_window"] = false,
			["numerical_system_symbols"] = "auto",
			["trash_auto_remove"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["clear_graphic"] = true,
			["total_abbreviation"] = 2,
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 18,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = false,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["deny_score_messages"] = false,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["broadcaster_enabled"] = false,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["ARENA_GREEN"] = {
					0.4, -- [1]
					1, -- [2]
					0.4, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
			},
			["default_bg_color"] = 0.0941,
			["segments_panic_mode"] = false,
			["report_heal_links"] = false,
			["overall_flag"] = 16,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["minimum_combat_time"] = 5,
			["numerical_system"] = 1,
			["force_activity_time_pvp"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["pvp_as_group"] = true,
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["death_tooltip_width"] = 350,
			["time_type"] = 2,
			["default_bg_alpha"] = 0.5,
			["standard_skin"] = false,
		},
		["Farfarella-Blackmoore"] = {
			["show_arena_role_icon"] = false,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["tooltip"] = {
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 2,
				["anchored_to"] = 1,
				["show_amount"] = false,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["background"] = {
					0.196, -- [1]
					0.196, -- [2]
					0.196, -- [3]
					0.8697, -- [4]
				},
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 6,
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["maximize_method"] = 1,
				["border_size"] = 14,
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = true,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["current_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = true,
				["sample_size"] = 5,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = false,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 65,
					["width"] = 220,
				},
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["animation_speed"] = 33,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["time_type_original"] = 2,
			["default_bg_alpha"] = 0.5,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["time_type"] = 2,
			["death_tooltip_width"] = 350,
			["animate_scroll"] = false,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 6.103515625e-05,
							["x"] = -0.0001220703125,
							["w"] = 310,
							["h"] = 157.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.850000023841858,
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.0941176470588235,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["micro_displays_locked"] = true,
					["fontstrings_width"] = 35,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["clickthrough_rows"] = false,
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.0941176470588235,
					["menu_icons_alpha"] = 0.5,
					["bg_b"] = 0.0941176470588235,
					["backdrop_texture"] = "Details Ground",
					["color"] = {
						0.0705882352941177, -- [1]
						0.0705882352941177, -- [2]
						0.0705882352941177, -- [3]
						0.639196664094925, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["skin"] = "Minimalistic",
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 70,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textYMod"] = 1,
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textYMod"] = 1,
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textYMod"] = 1,
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["switch_healer_in_combat"] = false,
					["version"] = 3,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["bg_alpha"] = 0.183960914611816,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["show_sidebars"] = false,
					["switch_tank_in_combat"] = false,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["strata"] = "LOW",
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["ignore_mass_showhide"] = false,
					["hide_in_combat_alpha"] = 0,
					["attribute_text"] = {
						["show_timer"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["custom_text"] = "{name}",
						["text_face"] = "Accidental Presidency",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_size"] = 12,
						["enable_custom_text"] = false,
						["enabled"] = true,
					},
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["font_size"] = 16,
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\BantoBar",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["percent_type"] = 1,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["use_spec_icons"] = true,
						["textR_bracket"] = "(",
						["textR_enable_custom_text"] = false,
						["textL_outline_small"] = true,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture_custom"] = "",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "BantoBar",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["start_after_icon"] = true,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["texture_custom_file"] = "Interface\\",
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
						},
					},
					["libwindow"] = {
						["y"] = 6.103515625e-05,
						["x"] = -0.0001220703125,
						["point"] = "CENTER",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["bars_grow_direction"] = 1,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["switch_all_roles_after_wipe"] = false,
					["desaturated_menu"] = false,
					["grab_on_top"] = false,
					["skin_custom"] = "",
					["micro_displays_side"] = 2,
					["auto_current"] = true,
					["bars_inverted"] = false,
					["switch_damager_in_combat"] = false,
					["bars_sort_direction"] = 1,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 6.103515625e-05,
							["x"] = -0.0001220703125,
							["w"] = 310,
							["h"] = 157.9999847412109,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["fontstrings_text3_anchor"] = 35,
					["hide_in_combat_type"] = 1,
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["clickthrough_window"] = false,
					["use_multi_fontstrings"] = false,
					["__was_opened"] = true,
				}, -- [1]
			},
			["report_lines"] = 5,
			["clear_ungrouped"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["pvp_as_group"] = true,
			["force_activity_time_pvp"] = true,
			["numerical_system"] = 1,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["overall_clear_logout"] = false,
			["memory_threshold"] = 3,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MONK"] = {
					0.5, -- [1]
					0.73828125, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.73828126, -- [1]
					1, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
			},
			["overall_flag"] = 16,
			["disable_alldisplays_window"] = false,
			["numerical_system_symbols"] = "auto",
			["trash_auto_remove"] = true,
			["total_abbreviation"] = 2,
			["segments_amount_to_save"] = 18,
			["clear_graphic"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["default_bg_color"] = 0.0941,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["deny_score_messages"] = false,
			["segments_auto_erase"] = 1,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["ARENA_GREEN"] = {
					0.4, -- [1]
					1, -- [2]
					0.4, -- [3]
				},
			},
			["segments_panic_mode"] = false,
			["standard_skin"] = false,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["minimum_combat_time"] = 5,
			["overall_clear_newboss"] = true,
			["report_schema"] = 1,
			["use_scroll"] = false,
			["use_battleground_server_parser"] = false,
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["segments_amount"] = 18,
			["instances_no_libwindow"] = false,
			["deadlog_limit"] = 16,
			["instances_segments_locked"] = true,
		},
		["Natinne-Blackmoore"] = {
			["overall_clear_newtorghast"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["default_bg_color"] = 0.0941,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["disable_lock_ungroup_buttons"] = false,
			["animation_speed"] = 33,
			["default_bg_alpha"] = 0.5,
			["disable_stretch_from_toolbar"] = false,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["memory_ram"] = 64,
			["instances_no_libwindow"] = false,
			["standard_skin"] = false,
			["disable_window_groups"] = false,
			["animate_scroll"] = false,
			["use_battleground_server_parser"] = false,
			["instances_suppress_trash"] = 0,
			["clear_ungrouped"] = true,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["force_activity_time_pvp"] = true,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["pvp_as_group"] = true,
			["numerical_system"] = 1,
			["overall_clear_pvp"] = true,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = 395.8890075683594,
							["x"] = 25.18524169921875,
							["w"] = 257.8519287109375,
							["h"] = 21.55556106567383,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["clickthrough_window"] = false,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["bars_sort_direction"] = 1,
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["start_after_icon"] = true,
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["font_size"] = 16,
						["texture_custom_file"] = "Interface\\",
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["percent_type"] = 1,
						["show_faction_icon"] = true,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["arena_role_icon_size_offset"] = -10,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["textR_enable_custom_text"] = false,
						["use_spec_icons"] = true,
						["texture_custom"] = "",
						["show_arena_role_icon"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["textL_class_colors"] = false,
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["textR_bracket"] = "(",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["skin"] = "Minimalistic",
					["bars_inverted"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["fullborder_shown"] = false,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["stretch_button_side"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["ignore_mass_showhide"] = false,
					["fontstrings_text3_anchor"] = 38,
					["menu_icons_size"] = 0.82,
					["StatusBarSaved"] = {
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textAlign"] = 3,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textAlign"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["bg_alpha"] = 0.6,
					["skin_custom"] = "",
					["rowareaborder_shown"] = false,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["switch_all_roles_after_wipe"] = false,
					["hide_in_combat_alpha"] = 0,
					["switch_damager"] = false,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = -20,
						["x"] = 25.18521118164063,
						["point"] = "TOP",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["strata"] = "LOW",
					["bars_grow_direction"] = 1,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["grab_on_top"] = false,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["show_statusbar"] = false,
					["auto_current"] = true,
					["clickthrough_rows"] = false,
					["backdrop_texture"] = "Details Ground",
					["micro_displays_locked"] = true,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = 395.8890075683594,
							["x"] = 25.18524169921875,
							["w"] = 257.8519287109375,
							["h"] = 21.55556106567383,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["fontstrings_text_limit_offset"] = -10,
					["show_sidebars"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["__was_opened"] = true,
					["use_multi_fontstrings"] = true,
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["report_lines"] = 5,
			["auto_swap_to_dynamic_overall"] = false,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["overall_clear_newboss"] = true,
			["overall_flag"] = 16,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["memory_threshold"] = 3,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["use_scroll"] = false,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["disable_alldisplays_window"] = false,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
			},
			["segments_auto_erase"] = 1,
			["broadcaster_enabled"] = false,
			["clear_graphic"] = true,
			["trash_auto_remove"] = false,
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["total_abbreviation"] = 2,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["minimum_combat_time"] = 5,
			["deny_score_messages"] = false,
			["segments_panic_mode"] = false,
			["show_arena_role_icon"] = false,
			["time_type_original"] = 2,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["segments_amount"] = 40,
			["time_type"] = 2,
			["death_tooltip_width"] = 350,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["ps_abbreviation"] = 3,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
	},
	["immersion_special_units"] = true,
	["boss_mods_timers"] = {
		["encounter_timers_bw"] = {
		},
		["encounter_timers_dbm"] = {
			["376634"] = {
				"376634", -- [1]
				"Timer376634cd", -- [2]
				"~Iron Spear", -- [3]
				18, -- [4]
				135130, -- [5]
				"cd", -- [6]
				376634, -- [7]
				3, -- [8]
				"2477", -- [9]
				["id"] = 2580,
			},
			["382670"] = {
				"382670", -- [1]
				"Timer382670cdcount	1", -- [2]
				"~Gale Arrow (1)", -- [3]
				21.5, -- [4]
				1029585, -- [5]
				"cdcount", -- [6]
				382670, -- [7]
				3, -- [8]
				"2478", -- [9]
				["id"] = 2581,
			},
			["376864"] = {
				"376864", -- [1]
				"Timer376864cd", -- [2]
				"~Static Spear", -- [3]
				18, -- [4]
				135127, -- [5]
				"cd", -- [6]
				376864, -- [7]
				3, -- [8]
				"2477", -- [9]
				["id"] = 2580,
			},
			["374430"] = {
				"374430", -- [1]
				"Timer374430cd", -- [2]
				"~Violent Upheaval", -- [3]
				20.6, -- [4]
				136025, -- [5]
				"cd", -- [6]
				374430, -- [7]
				3, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["374427"] = {
				"374427", -- [1]
				"Timer374427cd", -- [2]
				"~Ground Shatter", -- [3]
				5.9, -- [4]
				451165, -- [5]
				"cd", -- [6]
				374427, -- [7]
				3, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["374622"] = {
				"374622", -- [1]
				"Timer374622cd", -- [2]
				"~Storm Break", -- [3]
				7.2, -- [4]
				132331, -- [5]
				"cd", -- [6]
				374622, -- [7]
				2, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["nil"] = {
				"nil", -- [1]
				"DBMLFGTimer", -- [2]
				"LFG Invite", -- [3]
				40, -- [4]
				"237538", -- [5]
				"extratimer", -- [6]
				nil, -- [7]
				0, -- [8]
				["id"] = 2605,
			},
			["388817"] = {
				"388817", -- [1]
				"Timer388817cd", -- [2]
				"~Shards of Stone", -- [3]
				10.6, -- [4]
				4554447, -- [5]
				"cd", -- [6]
				388817, -- [7]
				2, -- [8]
				"2498", -- [9]
				["id"] = 2637,
			},
			["375943"] = {
				"375943", -- [1]
				"Timer375943cd", -- [2]
				"~Upheaval", -- [3]
				37, -- [4]
				1016245, -- [5]
				"cd", -- [6]
				375943, -- [7]
				3, -- [8]
				"2477", -- [9]
				["id"] = 2580,
			},
			["384620"] = {
				"384620", -- [1]
				"Timer384620cd", -- [2]
				"~Electrical Storm", -- [3]
				30.1, -- [4]
				237589, -- [5]
				"cd", -- [6]
				384620, -- [7]
				2, -- [8]
				"2497", -- [9]
				["id"] = 2636,
			},
			["376827"] = {
				"376827", -- [1]
				"Timer376827cdcount	1", -- [2]
				"~Conductive Strike (1)", -- [3]
				8, -- [4]
				839977, -- [5]
				"cdcount", -- [6]
				376827, -- [7]
				5, -- [8]
				"2477", -- [9]
				["id"] = 2580,
			},
			["388283"] = {
				"388283", -- [1]
				"Timer388283cd", -- [2]
				"~Eruption", -- [3]
				28.8, -- [4]
				136025, -- [5]
				"cd", -- [6]
				388283, -- [7]
				2, -- [8]
				"2498", -- [9]
				["id"] = 2637,
			},
			["386320"] = {
				"386320", -- [1]
				"Timer386320cast", -- [2]
				"Summon Saboteur", -- [3]
				25, -- [4]
				3012071, -- [5]
				"cast", -- [6]
				386320, -- [7]
				5, -- [8]
				"2498", -- [9]
				["id"] = 2637,
			},
			["385434"] = {
				"385434", -- [1]
				"Timer385434cdcount	1", -- [2]
				"~Spirit Leap (1)", -- [3]
				6, -- [4]
				135736, -- [5]
				"cdcount", -- [6]
				385434, -- [7]
				3, -- [8]
				"2478", -- [9]
				["id"] = 2581,
			},
			["374624"] = {
				"374624", -- [1]
				"Timer374624cd", -- [2]
				"~Freezing Tempest", -- [3]
				30.4, -- [4]
				135833, -- [5]
				"cd", -- [6]
				374624, -- [7]
				2, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["385916"] = {
				"385916", -- [1]
				"Timer385916cd", -- [2]
				"~Tectonic Stomp", -- [3]
				15.5, -- [4]
				1016245, -- [5]
				"cd", -- [6]
				385916, -- [7]
				3, -- [8]
				"2498", -- [9]
				["id"] = 2637,
			},
			["384316"] = {
				"384316", -- [1]
				"Timer384316cd", -- [2]
				"~Lightning Strike", -- [3]
				10.6, -- [4]
				252174, -- [5]
				"cd", -- [6]
				384316, -- [7]
				3, -- [8]
				"2497", -- [9]
				["id"] = 2636,
			},
			["375937"] = {
				"375937", -- [1]
				"Timer375937cdcount	1", -- [2]
				"~Rending Strike (1)", -- [3]
				8, -- [4]
				132155, -- [5]
				"cdcount", -- [6]
				375937, -- [7]
				5, -- [8]
				"2477", -- [9]
				["id"] = 2580,
			},
			["386063"] = {
				"386063", -- [1]
				"Timer386063cdcount	1", -- [2]
				"~Frightful Roar (1)", -- [3]
				5.5, -- [4]
				136147, -- [5]
				"cdcount", -- [6]
				386063, -- [7]
				2, -- [8]
				"2478", -- [9]
				["id"] = 2581,
			},
			["376892"] = {
				"376892", -- [1]
				"Timer376892cd", -- [2]
				"~Crackling Upheaval", -- [3]
				37, -- [4]
				136111, -- [5]
				"cd", -- [6]
				376892, -- [7]
				3, -- [8]
				"2477", -- [9]
				["id"] = 2580,
			},
			["386547"] = {
				"386547", -- [1]
				"Timer386547cdcount	1", -- [2]
				"~Repel (1)", -- [3]
				50, -- [4]
				1029595, -- [5]
				"cdcount", -- [6]
				386547, -- [7]
				4, -- [8]
				"2478", -- [9]
				["id"] = 2581,
			},
		},
	},
	["spell_category_latest_query"] = 0,
	["check_stuttering"] = true,
	["played_class_time"] = true,
	["dungeon_data"] = {
	},
	["class_time_played"] = {
		[9] = {
			["DRUID"] = 11496.41300000003,
			["EVOKER"] = 187173.0020000004,
			["DEMONHUNTER"] = 13103.59299999999,
		},
	},
	["slash_me_used"] = false,
	["aura_tracker_frame"] = {
		["scaletable"] = {
			["scale"] = 1,
		},
		["position"] = {
		},
	},
	["spell_category_latest_save"] = 0,
	["realm_sync"] = true,
	["show_warning_id1"] = true,
	["run_code"] = {
		["on_specchanged"] = "\n-- run when the player changes its spec",
		["on_zonechanged"] = "\n-- when the player changes zone, this code will run",
		["on_init"] = "\n-- code to run when Details! initializes, put here code which only will run once\n-- this also will run then the profile is changed\n\n--size of the death log tooltip in the Deaths display (default 350)\nDetails.death_tooltip_width = 350;\n\n--when in arena or battleground, details! silently switch to activity time (goes back to the old setting on leaving, default true)\nDetails.force_activity_time_pvp = true;\n\n--speed of the bar animations (default 33)\nDetails.animation_speed = 33;\n\n--threshold to trigger slow or fast speed (default 0.45)\nDetails.animation_speed_mintravel = 0.45;\n\n--call to update animations\nDetails:RefreshAnimationFunctions();\n\n--max window size, does require a /reload to work (default 480 x 450)\nDetails.max_window_size.width = 480;\nDetails.max_window_size.height = 450;\n\n--use the arena team color as the class color (default true)\nDetails.color_by_arena_team = true;\n\n--use the role icon in the player bar when inside an arena (default false)\nDetails.show_arena_role_icon = false;\n\n--how much time the update warning is shown (default 10)\nDetails.update_warning_timeout = 10;",
		["on_groupchange"] = "\n-- this code runs when the player enter or leave a group",
		["on_leavecombat"] = "\n-- this code runs when the player leave combat",
		["on_entercombat"] = "\n-- this code runs when the player enters in combat",
	},
	["custom"] = {
		{
			["source"] = false,
			["tooltip"] = "				\n			",
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format (\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing damage.",
			["attribute"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor (value/60), math.floor (value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["name"] = "Damage Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, amount = 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				\n				--do the loop:\n				for _, player in ipairs ( damage_container ) do \n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player \n						instance_container:AddValue (player, activity)\n					end\n				end\n				\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Red",
			["script_version"] = 3,
		}, -- [1]
		{
			["source"] = false,
			["tooltip"] = "				\n			",
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format (\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing healing.",
			["attribute"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor (value/60), math.floor (value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["name"] = "Healing Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_HEAL )\n				\n				--do the loop:\n				for _, player in ipairs ( damage_container ) do \n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player \n						instance_container:AddValue (player, activity)\n					end\n				end\n				\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Green",
			["script_version"] = 2,
		}, -- [2]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor (value)\n			",
			["desc"] = "Show the crowd control amount for each player.",
			["attribute"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs (misc_actors) do\n					if (character.cc_done and character:IsPlayer()) then\n						local cc_done = floor (character.cc_done)\n						instance_container:AddValue (character, cc_done)\n						total = total + cc_done\n						if (cc_done > top) then\n							top = cc_done\n						end\n						amount = amount + 1\n					end\n				end\n\n				return total, top, amount\n			",
			["name"] = "Crowd Control Done",
			["tooltip"] = "				local actor, combat, instance = ...\n				local spells = {}\n				for spellid, spell in pairs (actor.cc_done_spells._ActorTable) do\n				    tinsert (spells, {spellid, spell.counter})\n				end\n\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs (spells) do\n				    local name, _, icon = GetSpellInfo (spell [1])\n				    GameCooltip:AddLine (name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n				local targets = {}\n				for playername, amount in pairs (actor.cc_done_targets) do\n				    tinsert (targets, {playername, amount})\n				end\n\n				table.sort (targets, _detalhes.Sort2)\n\n				_detalhes:AddTooltipSpellHeaderText (\"Targets\", \"yellow\", #targets)\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass (actor.nome)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, target in ipairs (targets) do\n				    GameCooltip:AddLine (target[1], target [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    \n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass (target [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon (class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    end\n				    --\n				end\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_FreezingBreath",
			["script_version"] = 11,
		}, -- [3]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor (value)\n			",
			["desc"] = "Show the amount of crowd control received for each player.",
			["attribute"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amt = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n				DETAILS_CUSTOM_CC_RECEIVED_CACHE = DETAILS_CUSTOM_CC_RECEIVED_CACHE or {}\n				wipe (DETAILS_CUSTOM_CC_RECEIVED_CACHE)\n\n				for index, character in ipairs (misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n					\n					for player_name, amount in pairs (character.cc_done_targets) do\n					    local target = combat (1, player_name) or combat (2, player_name)\n					    if (target and target:IsPlayer()) then\n						instance_container:AddValue (target, amount)\n						total = total + amount\n						if (amount > top) then\n						    top = amount\n						end\n						if (not DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name]) then\n						    DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name] = true\n						    amt = amt + 1\n						end\n					    end\n					end\n					\n				    end\n				end\n\n				return total, top, amt\n			",
			["name"] = "Crowd Control Received",
			["tooltip"] = "				local actor, combat, instance = ...\n				local name = actor:name()\n				local spells, from = {}, {}\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs (misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n					local on_actor = character.cc_done_targets [name]\n					if (on_actor) then\n					    tinsert (from, {character:name(), on_actor})\n					    \n					    for spellid, spell in pairs (character.cc_done_spells._ActorTable) do\n						\n						local spell_on_actor = spell.targets [name]\n						if (spell_on_actor) then\n						    local has_spell\n						    for index, spell_table in ipairs (spells) do\n							if (spell_table [1] == spellid) then\n							    spell_table [2] = spell_table [2] + spell_on_actor\n							    has_spell = true\n							end\n						    end\n						    if (not has_spell) then\n							tinsert (spells, {spellid, spell_on_actor}) \n						    end\n						end\n						\n					    end            \n					end\n				    end\n				end\n\n				table.sort (from, _detalhes.Sort2)\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs (spells) do\n				    local name, _, icon = GetSpellInfo (spell [1])\n				    GameCooltip:AddLine (name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)    \n				end\n\n				_detalhes:AddTooltipSpellHeaderText (\"From\", \"yellow\", #from)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, t in ipairs (from) do\n				    GameCooltip:AddLine (t[1], t[2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    \n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass (t [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon (class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    end     \n				    \n				end\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_ChainsOfIce",
			["script_version"] = 3,
		}, -- [4]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				local dps = _detalhes:ToK (floor (value) / combat:GetCombatTime())\n				local percent = string.format (\"%.1f\", value/total*100)\n				return dps .. \", \" .. percent\n			",
			["desc"] = "Show your spells in the window.",
			["tooltip"] = "			--config:\n			--Background RBG and Alpha:\n			local R, G, B, A = 0, 0, 0, 0.75\n			local R, G, B, A = 0.1960, 0.1960, 0.1960, 0.8697\n\n			--get the parameters passed\n			local spell, combat, instance = ...\n\n			--get the cooltip object (we dont use the convencional GameTooltip here)\n			local GC = GameCooltip\n			GC:SetOption (\"YSpacingMod\", 0)\n\n			local role = DetailsFramework.UnitGroupRolesAssigned (\"player\")\n\n			if (spell.n_dmg) then\n			    \n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n			    \n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n			    \n			    local debuff_uptime_total, cast_string = \"\", \"\"\n			    local misc_actor = instance.showing (4, _detalhes.playername)\n			    if (misc_actor) then\n				local debuff_uptime = misc_actor.debuff_uptime_spells and misc_actor.debuff_uptime_spells._ActorTable [spell.id] and misc_actor.debuff_uptime_spells._ActorTable [spell.id].uptime\n				if (debuff_uptime) then\n				    debuff_uptime_total = floor (debuff_uptime / instance.showing:GetCombatTime() * 100)\n				end\n				\n				local spell_cast = misc_actor.spell_cast and misc_actor.spell_cast [spell.id]\n				\n				if (not spell_cast and misc_actor.spell_cast) then\n				    local spellname = GetSpellInfo (spell.id)\n				    for casted_spellid, amount in pairs (misc_actor.spell_cast) do\n					local casted_spellname = GetSpellInfo (casted_spellid)\n					if (casted_spellname == spellname) then\n					    spell_cast = amount .. \" (|cFFFFFF00?|r)\"\n					end\n				    end\n				end\n				if (not spell_cast) then\n				    spell_cast = \"(|cFFFFFF00?|r)\"\n				end\n				cast_string = cast_string .. spell_cast\n			    end\n			    \n			    --Cooltip code\n			    GC:AddLine (\"Casts:\", cast_string or \"?\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    if (debuff_uptime_total ~= \"\") then\n				GC:AddLine (\"Uptime:\", (debuff_uptime_total or \"?\") .. \"%\")\n				GC:AddStatusBar (100, 1, R, G, B, A)\n			    end\n			    \n			    GC:AddLine (\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local average = spell.total / total_hits\n			    GC:AddLine (\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"E-Dps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Normal Hits: \", spell.n_amt .. \" (\" ..floor ( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local n_average = spell.n_dmg / spell.n_amt\n			    local T = (combat_time*spell.n_dmg)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n			    \n			    GC:AddLine (\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format (\"%.1f\",spell.n_dmg / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Critical Hits: \", spell.c_amt .. \" (\" ..floor ( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_dmg/spell.c_amt\n				local T = (combat_time*spell.c_dmg)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_dmg / T\n				\n				GC:AddLine (\"Average / E-Dps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine (\"Average / E-Dps: \",  \"0 / 0\")    \n			    end\n			    \n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    \n			elseif (spell.n_curado) then\n			    \n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n			    \n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n			    \n			    --Cooltip code\n			    GC:AddLine (\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local average = spell.total / total_hits\n			    GC:AddLine (\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"E-Hps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Normal Hits: \", spell.n_amt .. \" (\" ..floor ( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local n_average = spell.n_curado / spell.n_amt\n			    local T = (combat_time*spell.n_curado)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n			    \n			    GC:AddLine (\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format (\"%.1f\",spell.n_curado / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Critical Hits: \", spell.c_amt .. \" (\" ..floor ( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_curado/spell.c_amt\n				local T = (combat_time*spell.c_curado)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_curado / T\n				\n				GC:AddLine (\"Average / E-Hps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine (\"Average / E-Hps: \",  \"0 / 0\")    \n			    end\n			    \n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			end\n			",
			["attribute"] = false,
			["name"] = "My Spells",
			["script"] = "				--get the parameters passed\n				local combat, instance_container, instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				local player\n				local pet_attribute\n				\n				local role = DetailsFramework.UnitGroupRolesAssigned (\"player\")\n				local spec = DetailsFramework.GetSpecialization()\n				role = spec and DetailsFramework.GetSpecializationRole (spec) or role\n\n				if (role == \"DAMAGER\") then\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				elseif (role == \"HEALER\") then    \n					player = combat (DETAILS_ATTRIBUTE_HEAL, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_HEAL\n				else\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				end\n\n				--do the loop\n\n				if (player) then\n					local spells = player:GetSpellList()\n					for spellid, spell in pairs (spells) do\n						instance_container:AddValue (spell, spell.total)\n						total = total + spell.total\n						if (top < spell.total) then\n							top = spell.total\n						end\n						amount = amount + 1\n					end\n				    \n					for _, PetName in ipairs (player.pets) do\n						local pet = combat (pet_attribute, PetName)\n						if (pet) then\n							for spellid, spell in pairs (pet:GetSpellList()) do\n								instance_container:AddValue (spell, spell.total, nil, \" (\" .. PetName:gsub ((\" <.*\"), \"\") .. \")\")\n								total = total + spell.total\n								if (top < spell.total) then\n									top = spell.total\n								end\n								amount = amount + 1\n							end\n						end\n					end\n				end\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\CHATFRAME\\UI-ChatIcon-Battlenet",
			["script_version"] = 8,
		}, -- [5]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with skull.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [128]\n				if (DamageOnStar) then\n				    --RAID_TARGET_8 is the built-in localized word for 'Skull'.\n				    GameCooltip:AddLine (RAID_TARGET_8 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_8\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["attribute"] = false,
			["name"] = "Damage On Skull Marked Targets",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n				\n				--raid target flags: \n				-- 128: skull \n				-- 64: cross\n				-- 32: square\n				-- 16: moon\n				-- 8: triangle\n				-- 4: diamond\n				-- 2: circle\n				-- 1: star\n				\n				--do the loop\n				for _, actor in ipairs (Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					if (actor.raid_targets [128]) then\n					    CustomContainer:AddValue (actor, actor.raid_targets [128])\n					end        \n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_8",
			["script_version"] = 3,
		}, -- [6]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with any other mark.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object\n				local GameCooltip = GameCooltip\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [1]\n				if (DamageOnStar) then\n				    GameCooltip:AddLine (RAID_TARGET_1 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_1\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCircle = RaidTargets [2]\n				if (DamageOnCircle) then\n				    GameCooltip:AddLine (RAID_TARGET_2 .. \":\", format_func (_, DamageOnCircle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_2\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnDiamond = RaidTargets [4]\n				if (DamageOnDiamond) then\n				    GameCooltip:AddLine (RAID_TARGET_3 .. \":\", format_func (_, DamageOnDiamond))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_3\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnTriangle = RaidTargets [8]\n				if (DamageOnTriangle) then\n				    GameCooltip:AddLine (RAID_TARGET_4 .. \":\", format_func (_, DamageOnTriangle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_4\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnMoon = RaidTargets [16]\n				if (DamageOnMoon) then\n				    GameCooltip:AddLine (RAID_TARGET_5 .. \":\", format_func (_, DamageOnMoon))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_5\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnSquare = RaidTargets [32]\n				if (DamageOnSquare) then\n				    GameCooltip:AddLine (RAID_TARGET_6 .. \":\", format_func (_, DamageOnSquare))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_6\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCross = RaidTargets [64]\n				if (DamageOnCross) then\n				    GameCooltip:AddLine (RAID_TARGET_7 .. \":\", format_func (_, DamageOnCross))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_7\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["attribute"] = false,
			["name"] = "Damage On Other Marked Targets",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for _, actor in ipairs (Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					local total = (actor.raid_targets [1] or 0) --star\n					total = total + (actor.raid_targets [2] or 0) --circle\n					total = total + (actor.raid_targets [4] or 0) --diamond\n					total = total + (actor.raid_targets [8] or 0) --tiangle\n					total = total + (actor.raid_targets [16] or 0) --moon\n					total = total + (actor.raid_targets [32] or 0) --square\n					total = total + (actor.raid_targets [64] or 0) --cross\n					\n					if (total > 0) then\n					    CustomContainer:AddValue (actor, total)\n					end\n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_5",
			["script_version"] = 3,
		}, -- [7]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Damage done to shields",
			["tooltip"] = "				--get the parameters passed\n				local actor, Combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				--get the actor total damage absorbed\n				local totalAbsorb = actor.totalabsorbed\n				local format_func = Details:GetCurrentToKFunction()\n\n				--get the damage absorbed by all the actor pets\n				for petIndex, petName in ipairs (actor.pets) do\n				    local pet = Combat :GetActor (1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n				    end\n				end\n\n				GameCooltip:AddLine (actor:Name(), format_func (_, actor.totalabsorbed))\n				Details:AddTooltipBackgroundStatusbar()\n\n				for petIndex, petName in ipairs (actor.pets) do\n				    local pet = Combat :GetActor (1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n					\n					GameCooltip:AddLine (petName, format_func (_, pet.totalabsorbed))\n					Details:AddTooltipBackgroundStatusbar()        \n					\n				    end\n				end\n			",
			["attribute"] = false,
			["name"] = "Damage on Shields",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for index, actor in ipairs (Combat:GetActorList(1)) do\n				    if (actor:IsPlayer()) then\n					\n					--get the actor total damage absorbed\n					local totalAbsorb = actor.totalabsorbed\n					\n					--get the damage absorbed by all the actor pets\n					for petIndex, petName in ipairs (actor.pets) do\n					    local pet = Combat :GetActor (1, petName)\n					    if (pet) then\n						totalAbsorb = totalAbsorb + pet.totalabsorbed\n					    end\n					end\n					\n					--add the value to the actor on the custom container\n					CustomContainer:AddValue (actor, totalAbsorb)        \n					\n				    end\n				end\n				--loop end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Holy_PowerWordShield",
			["script_version"] = 1,
		}, -- [8]
		{
			["source"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return value\n			",
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n\n				--get the time of overall combat\n				local OverallCombatTime = Details:GetCombat(-1):GetCombatTime()\n\n				--get the time of current combat if the player is in combat\n				if (Details.in_combat) then\n					local CurrentCombatTime = Details:GetCombat(0):GetCombatTime()\n					OverallCombatTime = OverallCombatTime + CurrentCombatTime\n				end\n\n				--calculate the DPS and return it as percent\n				local totalValue = value\n\n				--build the string\n				local ToK = Details:GetCurrentToKFunction()\n				local s = ToK (_, value / OverallCombatTime)\n\n				return s\n			",
			["desc"] = "Show overall damage done on the fly.",
			["attribute"] = false,
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the overall combat\n				local OverallCombat = Details:GetCombat(-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat(0)\n\n				if (not OverallCombat.GetActorList or not CurrentCombat.GetActorList) then\n					return 0, 0, 0\n				end\n\n				--get the damage actor container for overall\n				local damage_container_overall = OverallCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				--get the damage actor container for current\n				local damage_container_current = CurrentCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n\n				--do the loop:\n				for _, player in ipairs( damage_container_overall ) do\n					--only player in group\n					if (player:IsGroupPlayer()) then\n						instance_container:AddValue (player, player.total)\n					end\n				end\n\n				if (Details.in_combat) then\n					for _, player in ipairs( damage_container_current ) do\n						--only player in group\n						if (player:IsGroupPlayer()) then\n							instance_container:AddValue (player, player.total)\n						end\n					end\n				end\n\n				total, top =  instance_container:GetTotalAndHighestValue()\n				amount =  instance_container:GetNumActors()\n\n				--return:\n				return total, top, amount\n			",
			["name"] = "Dynamic Overall Damage",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip2\n\n				--Cooltip code\n				--get the overall combat\n				local OverallCombat = Details:GetCombat(-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat(0)\n\n				local AllSpells = {}\n\n				local playerTotal = 0\n\n				--overall\n				local player = OverallCombat [1]:GetActor(actor.nome)\n				if (player) then\n					playerTotal = playerTotal + player.total\n					local playerSpells = player:GetSpellList()\n					for spellID, spellTable in pairs(playerSpells) do\n						AllSpells [spellID] = spellTable.total\n					end\n				end\n				--current\n				if (Details.in_combat) then\n					local player = CurrentCombat [1]:GetActor(actor.nome)\n					if (player) then\n						playerTotal = playerTotal + player.total\n						local playerSpells = player:GetSpellList()\n						for spellID, spellTable in pairs(playerSpells) do\n							AllSpells [spellID] = (AllSpells [spellID] or 0) + (spellTable.total or 0)\n						end\n					end\n				end\n\n				local sortedList = {}\n				for spellID, total in pairs(AllSpells) do\n					tinsert(sortedList, {spellID, total})\n				end\n				table.sort (sortedList, Details.Sort2)\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--build the tooltip\n\n				local topSpellTotal = sortedList and sortedList[1] and sortedList[1][2] or 0\n\n				for i, t in ipairs(sortedList) do\n					local spellID, total = unpack(t)\n					if (total > 1) then\n						local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n\n						local spellPercent = total / playerTotal * 100\n						local formatedSpellPercent = format(\"%.1f\", spellPercent)\n\n						if (string.len(formatedSpellPercent) < 4) then\n							formatedSpellPercent = formatedSpellPercent  .. \"0\"\n						end\n\n						GameCooltip:AddLine(spellName, format_func (_, total) .. \"    \" .. formatedSpellPercent  .. \"%\")\n\n						Details:AddTooltipBackgroundStatusbar(false, total / topSpellTotal * 100)\n						GameCooltip:AddIcon (spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, 0.078125, 0.921875, 0.078125, 0.921875)\n\n					end\n				end\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\Spell-Reset",
			["script_version"] = 8,
		}, -- [9]
		{
			["source"] = false,
			["author"] = "Rhythm",
			["total_script"] = "        local value, top, total, Combat, Instance, Actor = ...\n\n        if _G.Details_ExplosiveOrbs then\n            return _G.Details_ExplosiveOrbs:GetDisplayText(Combat:GetCombatNumber(), Actor.my_actor:guid())\n        end\n        return \"\"\n    ",
			["desc"] = "Show how many explosive orbs players target and hit.",
			["attribute"] = false,
			["script"] = "        local Combat, CustomContainer, Instance = ...\n        local total, top, amount = 0, 0, 0\n\n        if _G.Details_ExplosiveOrbs then\n            local CombatNumber = Combat:GetCombatNumber()\n            local Container = Combat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n            for _, Actor in Container:ListActors() do\n                if Actor:IsGroupPlayer() then\n                    -- we only record the players in party\n                    local target, hit = _G.Details_ExplosiveOrbs:GetRecord(CombatNumber, Actor:guid())\n                    if target > 0 or hit > 0 then\n                        CustomContainer:AddValue(Actor, hit)\n                    end\n                end\n            end\n\n            total, top = CustomContainer:GetTotalAndHighestValue()\n            amount = CustomContainer:GetNumActors()\n        end\n\n        return total, top, amount\n    ",
			["name"] = "Explosive Orbs",
			["tooltip"] = "        local Actor, Combat, Instance = ...\n        local GameCooltip = GameCooltip\n\n        if _G.Details_ExplosiveOrbs then\n            local actorName = Actor:name()\n            local Actor = Combat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE):GetActor(actorName)\n            if not Actor then return end\n\n            local sortedList = {}\n            local orbName = _G.Details_ExplosiveOrbs:RequireOrbName()\n            local Container = Combat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n\n            for spellID, spellTable in pairs(Actor:GetSpellList()) do\n                local amount = spellTable.targets[orbName]\n                if amount then\n                    tinsert(sortedList, {spellID, amount})\n                end\n            end\n\n            -- handle pet\n            for _, petName in ipairs(Actor.pets) do\n                local petActor = Container:GetActor(petName)\n                for spellID, spellTable in pairs(petActor:GetSpellList()) do\n                    local amount = spellTable.targets[orbName]\n                    if amount then\n                        tinsert(sortedList, {spellID, amount, petName})\n                    end\n                end\n            end\n\n            sort(sortedList, Details.Sort2)\n\n            local format_func = Details:GetCurrentToKFunction()\n            for _, tbl in ipairs(sortedList) do\n                local spellID, amount, petName = unpack(tbl)\n                local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n                if petName then\n                    spellName = spellName .. ' (' .. petName .. ')'\n                end\n\n                GameCooltip:AddLine(spellName, format_func(_, amount))\n                Details:AddTooltipBackgroundStatusbar()\n                GameCooltip:AddIcon(spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n            end\n        end\n    ",
			["target"] = false,
			["spellid"] = false,
			["icon"] = 2175503,
			["script_version"] = 11,
		}, -- [10]
		{
			["source"] = false,
			["author"] = "Rhythm",
			["total_script"] = "        local value, top, total, Combat, Instance, Actor = ...\n\n        if _G.Details_ExplosiveOrbs then\n            return _G.Details_ExplosiveOrbs:GetDisplayText(Details:GetCombat(-1):GetCombatNumber(), Actor.my_actor:guid())\n        end\n        return \"\"\n    ",
			["desc"] = "Show how many explosive orbs players target and hit.",
			["attribute"] = false,
			["script"] = "        local Combat, CustomContainer, Instance = ...\n        local total, top, amount = 0, 0, 0\n\n        if _G.Details_ExplosiveOrbs then\n            local OverallCombat = Details:GetCombat(-1)\n            local CombatNumber = OverallCombat:GetCombatNumber()\n            local Container = OverallCombat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n            for _, Actor in Container:ListActors() do\n                if Actor:IsGroupPlayer() then\n                    -- we only record the players in party\n                    local target, hit = _G.Details_ExplosiveOrbs:GetRecord(CombatNumber, Actor:guid())\n                    if target > 0 or hit > 0 then\n                        CustomContainer:AddValue(Actor, hit)\n                    end\n                end\n            end\n\n            total, top = CustomContainer:GetTotalAndHighestValue()\n            amount = CustomContainer:GetNumActors()\n        end\n\n        return total, top, amount\n    ",
			["name"] = "Dynamic Overall Explosive Orbs",
			["tooltip"] = "        local Actor, Combat, Instance = ...\n        local GameCooltip = GameCooltip\n\n        if _G.Details_ExplosiveOrbs then\n            local actorName = Actor:name()\n            local orbName = _G.Details_ExplosiveOrbs:RequireOrbName()\n\n            local OverallCombat = Details:GetCombat(-1)\n            local CurrentCombat = Details:GetCombat(0)\n\n            local OverallContainer = OverallCombat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n            local CurrentContainer = CurrentCombat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n\n            local AllSpells = {}\n\n            -- handle overall\n            local Actor = OverallContainer:GetActor(actorName)\n            local ActorSpells = Actor:GetSpellList()\n\n            -- handle player\n            AllSpells[actorName] = {}\n            for spellID, spellTable in pairs(ActorSpells) do\n                AllSpells[actorName][spellID] = spellTable.targets[orbName]\n            end\n\n            -- handle pet\n            for _, petName in ipairs(Actor.pets) do\n                local petActor = OverallContainer:GetActor(petName)\n                local petActorSpells = petActor:GetSpellList()\n\n                AllSpells[petName] = {}\n                for spellID, spellTable in pairs(petActorSpells) do\n                    AllSpells[petName][spellID] = spellTable.targets[orbName]\n                end\n            end\n\n            if Details.in_combat then\n                -- handle current\n                local Actor = CurrentContainer:GetActor(actorName)\n                local ActorSpells = Actor:GetSpellList()\n\n                -- handle player\n                for spellID, spellTable in pairs(ActorSpells) do\n                    AllSpells[actorName][spellID] = (AllSpells[actorName][spellID] or 0) + (spellTable.targets[orbName] or 0)\n                end\n\n                -- handle pet\n                for _, petName in ipairs(Actor.pets) do\n                    local petActor = CurrentContainer:GetActor(petName)\n                    local petActorSpells = petActor:GetSpellList()\n\n                    if not AllSpells[petName] then\n                        AllSpells[petName] = {}\n                    end\n\n                    for spellID, spellTable in pairs(petActorSpells) do\n                        AllSpells[petName][spellID] = (AllSpells[petName][spellID] or 0) + (spellTable.targets[orbName] or 0)\n                    end\n                end\n            end\n\n            local sortedList = {}\n            for name, spellTable in pairs(AllSpells) do\n                for spellID, amount in pairs(spellTable) do\n                    tinsert(sortedList, {spellID, amount, name ~= actorName and name})\n                end\n            end\n\n            sort(sortedList, Details.Sort2)\n\n            local format_func = Details:GetCurrentToKFunction()\n            for _, tbl in ipairs(sortedList) do\n                local spellID, amount, petName = unpack(tbl)\n                local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n                if petName then\n                    spellName = spellName .. ' (' .. petName .. ')'\n                end\n\n                GameCooltip:AddLine(spellName, format_func(_, amount))\n                Details:AddTooltipBackgroundStatusbar()\n                GameCooltip:AddIcon(spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n            end\n        end\n    ",
			["target"] = false,
			["spellid"] = false,
			["icon"] = 2175503,
			["script_version"] = 11,
		}, -- [11]
		{
			["source"] = false,
			["tooltip"] = "				local actorObject, combatObject, instanceObject = ...\n\n				local iconSize = 20\n				\n				local buffUptimeContainer = actorObject:GetSpellContainer(\"buff\")\n				if (buffUptimeContainer) then\n					for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n						local spellTable = buffUptimeContainer:GetSpell(spellId)\n						if (spellTable) then\n							local used = spellTable.activedamt\n							if (used and used > 0) then\n								local spellName, _, spellIcon = GetSpellInfo(spellId)\n								GameCooltip:AddLine(spellName, used)\n								GameCooltip:AddIcon(spellIcon, 1, 1, iconSize, iconSize)\n								Details:AddTooltipBackgroundStatusbar()\n							end\n						end\n					end\n				end\n			",
			["import_string"] = "1EvBVnkoq4FlxKwDWDjCn6Q0kfD7kL(YwruUMOLK7JaoGPX3rSrgZwLV4F73yJ5LMxjPDfBBzHXZZZmEMhg7p0FHVxoRGhH9x57HkeRzCFVhWcejn)x89YWWROIG8iojt47LYIqPYWFGslW9LHcwM(3cuk83i2MvibCdHMlq0iSm8lYqhhh5e5e9s0pydsS2jjLX4w6hAREnhlk4uzyVEYWbdYfCc9fNeghm2Q3NCgM0RVb2)qd3Vn8MBSvohwYN6P8GCIVxmopY3ZBn7vz4RRzkMid3cXNmKJiXYWICm8BKmmJjim4LXfkKGyynqomnIvqfyUJVNgLpG4UkW2pQljV6Fg2tIyu)Nh(N3(5H367rrBW(EZn8CjqCyRkdNMsIv7vce)fSqD3oCSKnZw9V4ifNIkYfSn3ZOWwkfZBXYstA4Qz9vrvzmI2OYiAJUPV5hfBhmaq3K22qYJalJemUcEds1omLKlMLSuqsjITJvwLR9xBIo6jSq)QPGXwp84IXUt9cgVyX3DVB5Ihd(BxV7TlXnMzGfYLzJKtsuOg03qGQGsTXtYqeEU1bWhs(GBMidlVgmGrt3cffPOTaX1l(foRiRXesIm0QfcJCZFszXC9sSST1KI2SGQltsy13G8yC1Uje9jO0C8(MV)tANP17)a3XRksacvKjiBWVjNFe4lxXsT911cAE0oMGnbpfc1wy1RCH9S33Z6mYb97rZfnHuv7hdCscdQrbFfHO)Qq3IcScEqghBSd2CZzQkxrEtfjrDF6ROTWFhECSmjaniTs)hK41jG6kWVn7(LEbZNTWD2ZbUpyFCC0PJwOC2Kq1LUFtZjZD)(jJNQR9kOe8c85xMMMqRTm8Vay6mjBiBMgSoqqmn(8gnyakoUzpvu1BB6ep763rDB0444)rPU2UvTVoqNCr88WKVl9MxAN5v2xEYUYRPNulJQJb34(vFFCo71k9WsT0PU3fmB(Jph89XUpemE6utVH3okQNPBuJZc0Q0YpvEYwrdNS7yTDJRV4IBd5kNr4lTzPdSBq(bogTr0D3PPJzGdA9ShFf(a6fZStPvOD7f7PRu(4eX4x1QdxDOTRcZ1fwDs05891)SLTUszmvoXU7EVtjJtA07rBSujQvz2zlnAnRz1Th(BHVHb6)t5tGPdlh3EuZC3hCCw942ibCkJvfc9rFemwQGKvpf9Bt87mt9XMGUEK33POENfX)5iA)HksFPIYVtr4par32H)ZWHW6xE8IYqmYixwf5U0e2f8jQNqQ0NUut1KpfYIwTbQJD474gfRSQ5NAEhZpMdY7yQUDsb8cwJjVSwC632boywTc)fLo4ou0)Po2engoDQOiFfcoy07rCPQ12x47))d",
			["author"] = "Terciob",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				value = math.floor(value)\n				return \"\"\n			",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return math.floor(value) .. \" \"\n			",
			["script"] = "				local combatObject, customContainer, instanceObject = ...\n				local total, top, amount = 0, 0, 0\n				\n				--get the misc actor container\n				local listOfUtilityActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_MISC)\n				\n				--do the loop:\n				for _, actorObject in ipairs(listOfUtilityActors) do\n					--only player in group\n					if (actorObject:IsGroupPlayer()) then\n						local bFoundPotion = false\n						\n						--get the spell debuff uptime container\n						local debuffUptimeContainer = actorObject:GetSpellContainer(\"debuff\")\n						if (debuffUptimeContainer) then\n							--potion of focus (can't use as pre-potion, so, its amount is always 1\n							local focusPotion = debuffUptimeContainer:GetSpell(DETAILS_FOCUS_POTION_ID)\n							if (focusPotion) then\n								total = total + 1\n								bFoundPotion = true\n								if (top < 1) then\n									top = 1\n								end\n								--add amount to the player\n								customContainer:AddValue(actorObject, 1)\n							end\n						end\n						\n						--get the spell buff uptime container\n						local buffUptimeContainer = actorObject:GetSpellContainer(\"buff\")\n						if (buffUptimeContainer) then\n							for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n								local spellTable = buffUptimeContainer:GetSpell(spellId)\n								if (spellTable) then\n									local used = spellTable.activedamt\n									if (used and used > 0) then\n										total = total + used\n										bFoundPotion = true\n										if (used > top) then\n											top = used\n										end\n										\n										--add amount to the player\n										customContainer:AddValue(actorObject, used)\n									end\n								end\n							end\n						end\n						\n						if (bFoundPotion) then\n							amount = amount + 1\n						end\n					end\n				end\n				\n				--return:\n				return total, top, amount\n				",
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["name"] = "Potion Used",
			["attribute"] = false,
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\INV_Potion_03",
			["script_version"] = 8,
		}, -- [12]
		{
			["source"] = false,
			["desc"] = "Show who in your raid group used the healthstone or a heal potion.",
			["author"] = "Terciob",
			["percent_script"] = false,
			["total_script"] = false,
			["attribute"] = false,
			["tooltip"] = "				local actorObject, combatObject, instanceObject = ...\n				local spellContainer = actorObject:GetSpellContainer(\"spell\")\n				\n				local iconSize = 20\n				\n				local allHealingPotions = {6262}\n				for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n					allHealingPotions[#allHealingPotions+1] = spellId\n				end\n				\n				for i = 1, #allHealingPotions do\n					local spellId = allHealingPotions[i]\n					local spellTable = spellContainer:GetSpell(spellId)\n					if (spellTable) then\n						local spellName, _, spellIcon = GetSpellInfo(spellId)\n						GameCooltip:AddLine(spellName, Details:ToK(spellTable.total))\n						GameCooltip:AddIcon(spellIcon, 1, 1, iconSize, iconSize)\n						GameCooltip:AddStatusBar (100, 1, 0, 0, 0, 0.75)\n					end\n				end\n			",
			["name"] = "Health Potion & Stone",
			["script"] = "				local combatObject, instanceContainer, instanceObject = ...\n				local total, top, amount = 0, 0, 0\n				\n				local listOfHealingActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_HEAL)\n				for _, actorObject in ipairs(listOfHealingActors) do\n					local listOfSpells = actorObject:GetSpellList()\n					local found = false\n					\n					for spellId, spellTable in pairs(listOfSpells) do\n						if (LIB_OPEN_RAID_HEALING_POTIONS[spellId]) then\n							instanceContainer:AddValue(actorObject, spellTable.total)\n							total = total + spellTable.total\n							if (top < spellTable.total) then\n								top = spellTable.total\n							end\n							found = true\n						end\n					end\n					\n					if (found) then\n						amount = amount + 1\n					end\n				end\n				\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\INV_Stone_04",
			["script_version"] = 18,
		}, -- [13]
	},
	["exit_errors"] = {
	},
	["spell_category_savedtable"] = {
	},
	["spellid_ignored"] = {
	},
	["createauraframe"] = {
	},
	["data_wipes_exp"] = {
		["9"] = true,
		["14"] = false,
		["13"] = false,
		["12"] = false,
		["11"] = false,
		["10"] = true,
	},
	["item_level_pool"] = {
	},
	["damage_scroll_auto_open"] = true,
	["merge_player_abilities"] = false,
	["switchSaved"] = {
		["slots"] = 4,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
		},
	},
	["spell_category_latest_sent"] = 0,
	["mythic_plus"] = {
		["make_overall_boss_only"] = false,
		["mythicrun_chart_frame"] = {
		},
		["merge_boss_trash"] = true,
		["delay_to_show_graphic"] = 5,
		["always_in_combat"] = false,
		["make_overall_when_done"] = true,
		["delete_trash_after_merge"] = true,
		["show_damage_graphic"] = true,
		["mythicrun_chart_frame_ready"] = {
		},
		["boss_dedicated_segment"] = true,
		["mythicrun_chart_frame_minimized"] = {
		},
		["last_mythicrun_chart"] = {
		},
	},
	["installed_skins_cache"] = {
	},
	["savedStyles"] = {
	},
	["always_use_profile_exception"] = {
	},
	["details_auras"] = {
	},
	["tutorial"] = {
		["bookmark_tutorial"] = false,
		["main_help_button"] = 47,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["logons"] = 47,
		["version_announce"] = 0,
		["MIN_COMBAT_TIME"] = true,
		["ctrl_click_close_tutorial"] = false,
		["unlock_button"] = 0,
		["STREAMER_PLUGIN_FIRSTRUN"] = true,
	},
	["savedTimeCaptures"] = {
	},
	["latest_news_saw"] = "10.0.2 10402",
	["damage_scroll_position"] = {
		["scale"] = 1,
	},
	["performance_profiles"] = {
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["RaidFinder"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Mythic"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid30"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["exit_log"] = {
		"1 - Closing Janela Info.", -- [1]
		"2 - Clearing user place from instances.", -- [2]
		"  - 1 has baseFrame: yes.", -- [3]
		"4 - Reversing switches.", -- [4]
		"6 - Saving Config.", -- [5]
		"7 - Saving Profiles.", -- [6]
		"8 - Saving nicktag cache.", -- [7]
	},
	["merge_pet_abilities"] = false,
	["savedCustomSpells"] = {
		{
			339538, -- [1]
			"Templar's Verdict (Templar's Vindication)", -- [2]
			461860, -- [3]
		}, -- [1]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\ICONS\\INV_Weapon_Bow_07", -- [3]
		}, -- [2]
		{
			3, -- [1]
			"Environment (Falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [3]
		{
			55090, -- [1]
			"Scourge Strike (Physical)", -- [2]
			237530, -- [3]
		}, -- [4]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [5]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [6]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [7]
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [8]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [9]
		{
			59638, -- [1]
			"Frostbolt (Mirror Image)", -- [2]
			135846, -- [3]
		}, -- [10]
		{
			49184, -- [1]
			"Howling Blast (Main Target)", -- [2]
			135833, -- [3]
		}, -- [11]
		{
			44461, -- [1]
			"Living Bomb (explosion)", -- [2]
			236220, -- [3]
		}, -- [12]
		{
			278227, -- [1]
			"Barkspines (Trinket)", -- [2]
			134439, -- [3]
		}, -- [13]
		{
			268998, -- [1]
			"Kindled Soul (Trinket)", -- [2]
			651093, -- [3]
		}, -- [14]
		{
			196917, -- [1]
			"Light of the Martyr (Damage)", -- [2]
			1360762, -- [3]
		}, -- [15]
		{
			120761, -- [1]
			"Glaive Toss (Glaive #2)", -- [2]
			132330, -- [3]
		}, -- [16]
		{
			278812, -- [1]
			"Lion's Grace (Trinket)", -- [2]
			464140, -- [3]
		}, -- [17]
		{
			270827, -- [1]
			"Webweaver's Soul Gem (Trinket)", -- [2]
			237431, -- [3]
		}, -- [18]
		{
			212739, -- [1]
			"Epidemic (Main Target)", -- [2]
			136066, -- [3]
		}, -- [19]
		{
			279664, -- [1]
			"Bloody Bile (Trinket)", -- [2]
			136007, -- [3]
		}, -- [20]
		{
			237680, -- [1]
			"Howling Blast (AoE)", -- [2]
			135833, -- [3]
		}, -- [21]
		{
			215969, -- [1]
			"Epidemic (AoE)", -- [2]
			136066, -- [3]
		}, -- [22]
		{
			278359, -- [1]
			"Blood Hatred (Trinket)", -- [2]
			132175, -- [3]
		}, -- [23]
		{
			278057, -- [1]
			"Volatile Blood Explosion (Trinket)", -- [2]
			538040, -- [3]
		}, -- [24]
		{
			278155, -- [1]
			"Lingering Power of Xalzaix (Trinket)", -- [2]
			254105, -- [3]
		}, -- [25]
		{
			271115, -- [1]
			"Ignition Mage's Fuse (Trinket)", -- [2]
			1119937, -- [3]
		}, -- [26]
		{
			277179, -- [1]
			"Gladiator's Medallion (Trinket)", -- [2]
			252267, -- [3]
		}, -- [27]
		{
			70890, -- [1]
			"Scourge Strike (Shadow)", -- [2]
			237530, -- [3]
		}, -- [28]
		{
			277185, -- [1]
			"Gladiator's Badge (Trinket)", -- [2]
			135884, -- [3]
		}, -- [29]
		{
			278383, -- [1]
			"Ruffling Tempest (Trinket)", -- [2]
			2103829, -- [3]
		}, -- [30]
		{
			228649, -- [1]
			"Blackout Kick (Passive)", -- [2]
			574575, -- [3]
		}, -- [31]
		{
			277187, -- [1]
			"Gladiator's Emblem (Trinket)", -- [2]
			132344, -- [3]
		}, -- [32]
		{
			94472, -- [1]
			"Atonement (critical)", -- [2]
			135887, -- [3]
		}, -- [33]
		{
			121414, -- [1]
			"Glaive Toss (Glaive #1)", -- [2]
			132330, -- [3]
		}, -- [34]
		{
			277181, -- [1]
			"Gladiator's Insignia (Trinket)", -- [2]
			134501, -- [3]
		}, -- [35]
		{
			271462, -- [1]
			"Rotcrusted Voodoo Doll (Trinket)", -- [2]
			1716867, -- [3]
		}, -- [36]
		{
			270925, -- [1]
			"Waterspout (Trinket)", -- [2]
			1698701, -- [3]
		}, -- [37]
		{
			278862, -- [1]
			"Chill of the Runes (Trinket)", -- [2]
			252270, -- [3]
		}, -- [38]
		{
			271071, -- [1]
			"Conch of Dark Whispers (Trinket)", -- [2]
			1498840, -- [3]
		}, -- [39]
		{
			271465, -- [1]
			"Rotcrusted Voodoo Doll (Trinket)", -- [2]
			1716867, -- [3]
		}, -- [40]
		{
			33778, -- [1]
			"Lifebloom (Bloom)", -- [2]
			134206, -- [3]
		}, -- [41]
		{
			88082, -- [1]
			"Fireball (Mirror Image)", -- [2]
			135812, -- [3]
		}, -- [42]
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\ICONS\\INV_Sword_04", -- [3]
		}, -- [43]
		{
			345020, -- [1]
			"Skulking Predator (Trinket)", -- [2]
			2103921, -- [3]
		}, -- [44]
		{
			271671, -- [1]
			"Cacaphonous Chord (Trinket)", -- [2]
			454048, -- [3]
		}, -- [45]
		{
			98021, -- [1]
			"Health Exchange", -- [2]
			237586, -- [3]
		}, -- [46]
		{
			108271, -- [1]
			"Astral Shift", -- [2]
			"Interface\\Addons\\Details\\images\\icon_astral_shift", -- [3]
		}, -- [47]
		{
			77535, -- [1]
			"Blood Shield", -- [2]
			"Interface\\Addons\\Details\\images\\icon_blood_shield", -- [3]
		}, -- [48]
		{
			382056, -- [1]
			"Decoration of Flame", -- [2]
			1387353, -- [3]
		}, -- [49]
		{
			381475, -- [1]
			"Erupting Spear Fragment", -- [2]
			4638721, -- [3]
		}, -- [50]
		{
			385903, -- [1]
			"Crystal Sickness", -- [2]
			237007, -- [3]
		}, -- [51]
		{
			388739, -- [1]
			"Pure Decay", -- [2]
			4635246, -- [3]
		}, -- [52]
		{
			382058, -- [1]
			"Decoration of Flame", -- [2]
			1387353, -- [3]
		}, -- [53]
		{
			382097, -- [1]
			"Rumbling Ruby", -- [2]
			1016245, -- [3]
		}, -- [54]
		{
			377455, -- [1]
			"Iceblood Deathsnare", -- [2]
			237430, -- [3]
		}, -- [55]
		{
			384004, -- [1]
			"Dwarven Barrage", -- [2]
			252172, -- [3]
		}, -- [56]
		{
			382090, -- [1]
			"Storm-Eater's Boon", -- [2]
			4554454, -- [3]
		}, -- [57]
		{
			214985, -- [1]
			"Slicing Maelstrom", -- [2]
			1029585, -- [3]
		}, -- [58]
		{
			382135, -- [1]
			"Manic Grieftorch", -- [2]
			650636, -- [3]
		}, -- [59]
		{
			381967, -- [1]
			"Way of Controlled Currents", -- [2]
			1020391, -- [3]
		}, -- [60]
		{
			388855, -- [1]
			"Miniature Singing Stone", -- [2]
			4638394, -- [3]
		}, -- [61]
		{
			387036, -- [1]
			"Burning Embers", -- [2]
			460952, -- [3]
		}, -- [62]
		{
			394453, -- [1]
			"Broodkeeper's Blaze", -- [2]
			514016, -- [3]
		}, -- [63]
		{
			214052, -- [1]
			"Fel Meteor", -- [2]
			135799, -- [3]
		}, -- [64]
		{
			383934, -- [1]
			"Water's Beating Heart", -- [2]
			839910, -- [3]
		}, -- [65]
		{
			382426, -- [1]
			"Spiteful Stormbolt", -- [2]
			572029, -- [3]
		}, -- [66]
		{
			397376, -- [1]
			"Burning Embers", -- [2]
			460952, -- [3]
		}, -- [67]
		{
			377451, -- [1]
			"Conjured Chillglobe", -- [2]
			4643989, -- [3]
		}, -- [68]
		{
			214200, -- [1]
			"Expel Light", -- [2]
			237541, -- [3]
		}, -- [69]
		{
			388755, -- [1]
			"Soulseeker Arrow", -- [2]
			2103807, -- [3]
		}, -- [70]
	},
	["deathlog_line_height"] = 16,
}
__details_backup = {
	["_exit_error"] = {
	},
	["_instance_backup"] = {
	},
}
