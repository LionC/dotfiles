
MythicDungeonToolsDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Taifunari - Blackmoore",
		["Farfarella - Blackmoore"] = "Farfarella - Blackmoore",
		["Allegory - Blackmoore"] = "Allegory - Blackmoore",
	},
	["global"] = {
		["minimap"] = {
			["minimapPos"] = 159.9103826165047,
		},
	},
}
