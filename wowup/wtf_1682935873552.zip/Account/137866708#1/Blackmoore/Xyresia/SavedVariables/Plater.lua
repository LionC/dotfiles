
PlaterDBChr = {
	["first_run2"] = {
		["Player-580-08203F26"] = true,
	},
	["buffsBanned"] = {
	},
	["debuffsBanned"] = {
	},
	["spellRangeCheck"] = {
		[64] = "Frostbolt",
		[63] = "Fireball",
		[62] = "Arcane Blast",
	},
}
