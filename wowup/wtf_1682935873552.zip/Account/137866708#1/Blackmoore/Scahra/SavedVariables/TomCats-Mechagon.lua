
TomCats_Mechagon_Character = {
	["preferences"] = {
		["TomCats-MechagonMinimapButton"] = {
			["position"] = 3.003863563808611,
		},
	},
}
