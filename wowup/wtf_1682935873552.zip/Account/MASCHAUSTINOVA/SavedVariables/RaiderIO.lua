
RaiderIO_Config = {
}
RaiderIO_LastCharacter = "eu-Farfarella-blackmoore"
RaiderIO_MissingCharacters = {
}
RaiderIO_CachedRuns = nil
