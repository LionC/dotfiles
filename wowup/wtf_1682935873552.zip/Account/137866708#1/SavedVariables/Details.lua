
_detalhes_global = {
	["encounter_spell_pool"] = {
		{
			2587, -- [1]
			"Eranog", -- [2]
		}, -- [1]
		[193473] = {
			2607, -- [1]
			"Void Tendril", -- [2]
		},
		[377995] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[198077] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[375439] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[396411] = {
			2580, -- [1]
			"Raszageth", -- [2]
		},
		[118540] = {
			1416, -- [1]
			"[*] Jade Serpent Wave", -- [2]
		},
		[388996] = {
			2565, -- [1]
			"[*] Energy Eruption", -- [2]
		},
		[153067] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[193092] = {
			1805, -- [1]
			"Hymdall", -- [2]
		},
		[386440] = {
			2590, -- [1]
			"Kadros Icewrath", -- [2]
		},
		[376723] = {
			2580, -- [1]
			"Nokhud Stormcaster", -- [2]
		},
		[396672] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[106841] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[395907] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[121483] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[153070] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[376727] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[375449] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[374427] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[373405] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[376730] = {
			2580, -- [1]
			"[*] Stormwinds", -- [2]
		},
		[153072] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[389007] = {
			2565, -- [1]
			"[*] Wild Energy", -- [2]
		},
		[396424] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[374430] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[376732] = {
			2580, -- [1]
			"[*] Stormwinds", -- [2]
		},
		[387474] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[391055] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[391056] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[154353] = {
			1682, -- [1]
			"Omen of Death <Ner'zhul>", -- [2]
		},
		[381595] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[375458] = {
			2614, -- [1]
			"Juvenile Frost Proto-Dragon", -- [2]
		},
		[378783] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[390548] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[207806] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[378784] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[386201] = {
			2562, -- [1]
			"[*] Corrupted Mana", -- [2]
		},
		[375204] = {
			2610, -- [1]
			"[*] Liquid Hot Magma", -- [2]
		},
		[375716] = {
			2614, -- [1]
			"Primalist Mage", -- [2]
		},
		[386202] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[375717] = {
			2614, -- [1]
			"Primalist Mage", -- [2]
		},
		[197961] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[378787] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[376997] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[372394] = {
			2590, -- [1]
			"Dathea Stormlash", -- [2]
		},
		[381602] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[395669] = {
			2581, -- [1]
			"Maruuk", -- [2]
		},
		[197963] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[373932] = {
			2585, -- [1]
			"Draconic Image", -- [2]
		},
		[381349] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[381605] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[197964] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[381862] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[381607] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[377004] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[197965] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[395930] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[381864] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[209602] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[164974] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[197966] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[390817] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[385958] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[193235] = {
			1805, -- [1]
			"Hymdall", -- [2]
		},
		[377008] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[197967] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[388773] = {
			2584, -- [1]
			"Umbrelskul", -- [2]
		},
		[370615] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[377009] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[389541] = {
			2581, -- [1]
			"White Tiger Statue <Dyrell>", -- [2]
		},
		[381613] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[377522] = {
			2611, -- [1]
			"Raging Ember <Warlord Sargha>", -- [2]
		},
		[388008] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[181089] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[207815] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[388777] = {
			2584, -- [1]
			"Umbrelskul", -- [2]
		},
		[389033] = {
			2563, -- [1]
			"Hungry Lasher", -- [2]
		},
		[384686] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[384687] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[374969] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[395686] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[350163] = {
			2637, -- [1]
			"Spiteful Shade", -- [2]
		},
		[377017] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[372158] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[377018] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[387504] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[393898] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[375485] = {
			2614, -- [1]
			"Dragonspawn Flamebender", -- [2]
		},
		[396201] = {
			2605, -- [1]
			"[*] Blistering Presence", -- [2]
		},
		[153089] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[375487] = {
			2614, -- [1]
			"Dragonspawn Flamebender", -- [2]
		},
		[374720] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[152962] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[373442] = {
			2607, -- [1]
			"Mindbender", -- [2]
		},
		[396716] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[374466] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[376257] = {
			2614, -- [1]
			"Tarasek Earthreaver", -- [2]
		},
		[384186] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[376260] = {
			2614, -- [1]
			"Tarasek Earthreaver", -- [2]
		},
		[240559] = {
			1677, -- [1]
			"[*] Grievous Wound", -- [2]
		},
		[396721] = {
			2563, -- [1]
			"Ancient Branch", -- [2]
		},
		[153093] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[209742] = {
			1870, -- [1]
			"Image of Advisor Melandrus", -- [2]
		},
		[386748] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[385981] = {
			2562, -- [1]
			"[*] Arcane Orb", -- [2]
		},
		[374217] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[153094] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[396212] = {
			2605, -- [1]
			"[*] Chilling Presence", -- [2]
		},
		[387261] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[375241] = {
			2612, -- [1]
			"The Scorching Forge", -- [2]
		},
		[388796] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[374731] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[376266] = {
			2614, -- [1]
			"Tarasek Earthreaver", -- [2]
		},
		[107110] = {
			1416, -- [1]
			"Yu'lon", -- [2]
		},
		[377034] = {
			2564, -- [1]
			"Crawth", -- [2]
		},
		[388799] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[153224] = {
			1677, -- [1]
			"Daggerfall", -- [2]
		},
		[388544] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[376780] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[376781] = {
			2564, -- [1]
			"Goal of the Searing Blaze", -- [2]
		},
		[388290] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[388546] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[389059] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[376272] = {
			2614, -- [1]
			"Tarasek Earthreaver", -- [2]
		},
		[388804] = {
			2584, -- [1]
			"Umbrelskul", -- [2]
		},
		[106856] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[375251] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[370648] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[374485] = {
			2605, -- [1]
			"Blazing Fiend", -- [2]
		},
		[382670] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[224327] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[188395] = {
			1805, -- [1]
			"[*] Ball Lightning", -- [2]
		},
		[376279] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[388302] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[384978] = {
			2584, -- [1]
			"Umbrelskul", -- [2]
		},
		[388815] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[153232] = {
			1677, -- [1]
			"[*] Daggerfall", -- [2]
		},
		[207707] = {
			1807, -- [1]
			"Ebonclaw Packmate", -- [2]
		},
		[396233] = {
			2605, -- [1]
			"[*] Thundering Presence", -- [2]
		},
		[196838] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[344572] = {
			2607, -- [1]
			"Arwen", -- [2]
		},
		[388817] = {
			2637, -- [1]
			"Granyth", -- [2]
		},
		[392398] = {
			2623, -- [1]
			"Primal Thundercloud", -- [2]
		},
		[388562] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[117665] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[224333] = {
			1870, -- [1]
			"[*] Enveloping Winds", -- [2]
		},
		[388309] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[152979] = {
			1688, -- [1]
			"Possessed Soul", -- [2]
		},
		[209628] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[240446] = {
			2606, -- [1]
			"[*] Explosion", -- [2]
		},
		[388822] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[373733] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[399053] = {
			2607, -- [1]
			"Surging Ruiner", -- [2]
		},
		[181113] = {
			2614, -- [1]
			"Primalist Mage", -- [2]
		},
		[372456] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[373735] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[391382] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[106797] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[209630] = {
			1870, -- [1]
			"[*] Piercing Gale", -- [2]
		},
		[107053] = {
			1416, -- [1]
			"Dragon Wave", -- [2]
		},
		[392151] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[384223] = {
			2585, -- [1]
			"Azureblade", -- [2]
		},
		[386781] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[382434] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[188404] = {
			1805, -- [1]
			"Storm Drake", -- [2]
		},
		[386016] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[392666] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[153623] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[373742] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[397783] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[389855] = {
			2585, -- [1]
			"Draconic Image", -- [2]
		},
		[17253] = {
			2607, -- [1]
			"Éowyn", -- [2]
		},
		[397785] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[375535] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[386277] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[378861] = {
			2639, -- [1]
			"[*] Fractured Rubble", -- [2]
		},
		[106736] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[106864] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[387559] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[374517] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[282449] = {
			2607, -- [1]
			"Akaari's Soul", -- [2]
		},
		[392166] = {
			2611, -- [1]
			"[*] Azure Stone of Might", -- [2]
		},
		[153501] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[91776] = {
			2607, -- [1]
			"Risen Ghoul", -- [2]
		},
		[391402] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[374523] = {
			2582, -- [1]
			"Ley-Line Sprout", -- [2]
		},
		[374779] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[375291] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[386289] = {
			2590, -- [1]
			"Embar Firepath", -- [2]
		},
		[397798] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[389870] = {
			2607, -- [1]
			"Colossal Stormfiend", -- [2]
		},
		[376827] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[385267] = {
			2584, -- [1]
			"Crackling Vortex", -- [2]
		},
		[397799] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[386547] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[381688] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[376829] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[387571] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[389873] = {
			2607, -- [1]
			"Colossal Stormfiend", -- [2]
		},
		[386037] = {
			2581, -- [1]
			"[*] Gale Arrow", -- [2]
		},
		[376063] = {
			2605, -- [1]
			"Smoldering Hellion", -- [2]
		},
		[106228] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[373762] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[395501] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[382458] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[193659] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[384761] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[198263] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[193660] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[374533] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[374789] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[371976] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[374534] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[375046] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[374535] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[381442] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[373004] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[375306] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[396022] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[372238] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[396023] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[371983] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[381958] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[198396] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[396025] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[390911] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[375055] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[375056] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[396028] = {
			2587, -- [1]
			"Molten Spike", -- [2]
		},
		[375824] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[375057] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[398331] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[219498] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[380174] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[396031] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[193668] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[380175] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[113394] = {
			1417, -- [1]
			"Strife", -- [2]
		},
		[392196] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[380176] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[384524] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[387849] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[375829] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[391686] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[384014] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[373017] = {
			2606, -- [1]
			"Blazebound Firestorm <Kokia Blazehoof>", -- [2]
		},
		[396035] = {
			2607, -- [1]
			"Surging Ruiner", -- [2]
		},
		[384015] = {
			2615, -- [1]
			"Watcher Irideus", -- [2]
		},
		[390921] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[395781] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[374554] = {
			2605, -- [1]
			"[*] Magma Pool", -- [2]
		},
		[386063] = {
			2581, -- [1]
			"Maruuk", -- [2]
		},
		[374043] = {
			2590, -- [1]
			"Embar Firepath", -- [2]
		},
		[375578] = {
			2614, -- [1]
			"Dragonspawn Flamebender", -- [2]
		},
		[375834] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[386320] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[385553] = {
			2607, -- [1]
			"Stormseeker Acolyte", -- [2]
		},
		[377881] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[375068] = {
			2610, -- [1]
			"Lava Tentacles", -- [2]
		},
		[388623] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[375580] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[373535] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[388625] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[385812] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[379419] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[388115] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[396044] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[384024] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[373027] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[376864] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[375842] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[375331] = {
			2590, -- [1]
			"Dathea Stormlash", -- [2]
		},
		[376866] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[153908] = {
			1679, -- [1]
			"[*] Inhale", -- [2]
		},
		[374567] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[317791] = {
			2607, -- [1]
			"Magus of the Dead", -- [2]
		},
		[375591] = {
			2582, -- [1]
			"Volatile Sapling", -- [2]
		},
		[317792] = {
			2607, -- [1]
			"Magus of the Dead", -- [2]
		},
		[388635] = {
			2607, -- [1]
			"Volatile Spark", -- [2]
		},
		[374570] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[373803] = {
			2609, -- [1]
			"Infused Whelp", -- [2]
		},
		[375082] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[397077] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[387359] = {
			2618, -- [1]
			"[*] Waterlogged", -- [2]
		},
		[385569] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[396056] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[384292] = {
			2635, -- [1]
			"Thunder Caller <Dathea, Ascended>", -- [2]
		},
		[391711] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[391967] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[397338] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[385574] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[211457] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[209667] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[196496] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[388645] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[397341] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[375091] = {
			2590, -- [1]
			"Embar Firepath", -- [2]
		},
		[196497] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[224374] = {
			1869, -- [1]
			"Infernal Imp <Talixae Flamewreath>", -- [2]
		},
		[373046] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[385578] = {
			2585, -- [1]
			"Azureblade", -- [2]
		},
		[373559] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[224375] = {
			1869, -- [1]
			"Infernal Imp <Talixae Flamewreath>", -- [2]
		},
		[373048] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[374327] = {
			2592, -- [1]
			"Caustic Spiderling", -- [2]
		},
		[371514] = {
			2590, -- [1]
			"Embar Firepath", -- [2]
		},
		[374839] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[387627] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[373817] = {
			2592, -- [1]
			"Frostbreath Arachnid", -- [2]
		},
		[372027] = {
			2590, -- [1]
			"Embar Firepath", -- [2]
		},
		[388651] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[396068] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[388396] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[207881] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[224377] = {
			1869, -- [1]
			"Infernal Imp <Talixae Flamewreath>", -- [2]
		},
		[385073] = {
			2607, -- [1]
			"Colossal Stormfiend", -- [2]
		},
		[372030] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[376634] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[154175] = {
			1679, -- [1]
			"Bonemaw", -- [2]
		},
		[396328] = {
			2590, -- [1]
			"Earthen Pillar", -- [2]
		},
		[386354] = {
			2590, -- [1]
			"Opalfang", -- [2]
		},
		[376892] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[153153] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[375870] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[375871] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[390449] = {
			2635, -- [1]
			"Thunderstorm", -- [2]
		},
		[388659] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[377662] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[373059] = {
			2590, -- [1]
			"Kadros Icewrath", -- [2]
		},
		[396077] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376896] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[394875] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[160537] = {
			1682, -- [1]
			"[*] Ritual of Bones", -- [2]
		},
		[154469] = {
			1682, -- [1]
			"[*] Ritual of Bones", -- [2]
		},
		[209676] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[209862] = {
			1677, -- [1]
			"[*] Volcanic Plume", -- [2]
		},
		[388918] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[397358] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[388407] = {
			2635, -- [1]
			"Raging Tempest <Dathea, Ascended>", -- [2]
		},
		[391732] = {
			2607, -- [1]
			"Colossal Stormfiend", -- [2]
		},
		[152688] = {
			1677, -- [1]
			"[*] Shadow Rune", -- [2]
		},
		[376899] = {
			2580, -- [1]
			"[*] Crackling Cloud", -- [2]
		},
		[384316] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[390710] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[388920] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[372808] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[152690] = {
			1677, -- [1]
			"[*] Shadow Rune", -- [2]
		},
		[374343] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[392922] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[387131] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[209678] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[384132] = {
			2585, -- [1]
			"Azureblade", -- [2]
		},
		[396222] = {
			2605, -- [1]
			"[*] Shattering Presence", -- [2]
		},
		[387132] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[381250] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[394873] = {
			1682, -- [1]
			"[*] Lightning Strike", -- [2]
		},
		[388923] = {
			2563, -- [1]
			"Overgrown Ancient", -- [2]
		},
		[372811] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[381251] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[382530] = {
			2607, -- [1]
			"Surging Ruiner", -- [2]
		},
		[83381] = {
			2607, -- [1]
			"Arwen", -- [2]
		},
		[399054] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[372045] = {
			2592, -- [1]
			"Caustic Spiderling", -- [2]
		},
		[390715] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[375475] = {
			2614, -- [1]
			"Juvenile Frost Proto-Dragon", -- [2]
		},
		[396037] = {
			2607, -- [1]
			"Surging Ruiner", -- [2]
		},
		[396038] = {
			2607, -- [1]
			"Surging Ruiner", -- [2]
		},
		[396734] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[373688] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[375883] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[118459] = {
			2607, -- [1]
			"Arwen", -- [2]
		},
		[390717] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[374364] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[374861] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[386370] = {
			2590, -- [1]
			"Opalfang", -- [2]
		},
		[373327] = {
			2587, -- [1]
			"Primal Flame", -- [2]
		},
		[106938] = {
			1416, -- [1]
			"[*] Serpent Wave", -- [2]
		},
		[397801] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[390463] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[381512] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[106823] = {
			1416, -- [1]
			"Liu Flameheart", -- [2]
		},
		[193260] = {
			1805, -- [1]
			"[*] Static Field", -- [2]
		},
		[395893] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[373329] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[201754] = {
			2607, -- [1]
			"Arwen", -- [2]
		},
		[381315] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[372051] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[381514] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[397115] = {
			2587, -- [1]
			"[*] Incinerate", -- [2]
		},
		[397113] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[198412] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[373331] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[193826] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[372820] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[386747] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[381516] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[375634] = {
			2614, -- [1]
			"Drakonid Stormbringer", -- [2]
		},
		[375890] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[154442] = {
			1682, -- [1]
			"Ner'zhul", -- [2]
		},
		[381517] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[386173] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[371981] = {
			2605, -- [1]
			"[*] Elemental Surge", -- [2]
		},
		[372055] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[382541] = {
			2607, -- [1]
			"Surging Ruiner", -- [2]
		},
		[396072] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[385078] = {
			2584, -- [1]
			"Crackling Vortex", -- [2]
		},
		[388424] = {
			2618, -- [1]
			"Primal Tsunami", -- [2]
		},
		[382628] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[381775] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[153804] = {
			1679, -- [1]
			"Bonemaw", -- [2]
		},
		[389448] = {
			2607, -- [1]
			"Arwen", -- [2]
		},
		[374355] = {
			2612, -- [1]
			"The Scorching Forge", -- [2]
		},
		[372315] = {
			2590, -- [1]
			"Kadros Icewrath", -- [2]
		},
		[388084] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[374352] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[343520] = {
			2606, -- [1]
			"[*] Storming", -- [2]
		},
		[196512] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[193702] = {
			1808, -- [1]
			"[*] Infernal Flames", -- [2]
		},
		[390462] = {
			2585, -- [1]
			"Azureblade", -- [2]
		},
		[374361] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[374218] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[345561] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[91800] = {
			2607, -- [1]
			"Risen Ghoul", -- [2]
		},
		[387133] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[374482] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[387150] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[385065] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[219488] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[375825] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[387151] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[374365] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[381525] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[381781] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[387152] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[388431] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[381526] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[374621] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[375792] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[373087] = {
			2606, -- [1]
			"Blazebound Firestorm <Kokia Blazehoof>", -- [2]
		},
		[376449] = {
			2564, -- [1]
			"Goal of the Searing Blaze", -- [2]
		},
		[374622] = {
			2605, -- [1]
			"Thundering Ravager", -- [2]
		},
		[391600] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[391282] = {
			2607, -- [1]
			"Colossal Stormfiend", -- [2]
		},
		[388644] = {
			2614, -- [1]
			"Tarasek Legionnaire", -- [2]
		},
		[375873] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[387155] = {
			2637, -- [1]
			"Granyth", -- [2]
		},
		[374112] = {
			2592, -- [1]
			"Frostbreath Arachnid", -- [2]
		},
		[372322] = {
			2590, -- [1]
			"Opalfang", -- [2]
		},
		[374624] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[380487] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[372963] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[207261] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[374625] = {
			2605, -- [1]
			"Frozen Destroyer", -- [2]
		},
		[385075] = {
			2584, -- [1]
			"Umbrelskul", -- [2]
		},
		[396907] = {
			1416, -- [1]
			"Yu'lon", -- [2]
		},
		[153680] = {
			1679, -- [1]
			"Bonemaw", -- [2]
		},
		[373652] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[374038] = {
			2590, -- [1]
			"Embar Firepath", -- [2]
		},
		[374705] = {
			2605, -- [1]
			"Earth Breaker", -- [2]
		},
		[385434] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[388949] = {
			2614, -- [1]
			"Frozen Shroud", -- [2]
		},
		[374586] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[373681] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[371489] = {
			2609, -- [1]
			"Flashfrost Chillweaver", -- [2]
		},
		[397134] = {
			2590, -- [1]
			"Opalfang", -- [2]
		},
		[386181] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[215204] = {
			1868, -- [1]
			"Vigilant Duskwatch", -- [2]
		},
		[372275] = {
			2590, -- [1]
			"Dathea Stormlash", -- [2]
		},
		[117570] = {
			1439, -- [1]
			"Figment of Doubt", -- [2]
		},
		[375209] = {
			2612, -- [1]
			"The Scorching Forge", -- [2]
		},
		[383925] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[391765] = {
			2611, -- [1]
			"Raging Ember <Warlord Sargha>", -- [2]
		},
		[375653] = {
			2614, -- [1]
			"Drakonid Stormbringer", -- [2]
		},
		[372863] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[373424] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[165578] = {
			1679, -- [1]
			"Bonemaw", -- [2]
		},
		[372648] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[375457] = {
			2614, -- [1]
			"Juvenile Frost Proto-Dragon", -- [2]
		},
		[153686] = {
			1679, -- [1]
			"Bonemaw", -- [2]
		},
		[373680] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[381518] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[377505] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[374428] = {
			2605, -- [1]
			"Tectonic Crusher", -- [2]
		},
		[198058] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[384625] = {
			2585, -- [1]
			"Azureblade", -- [2]
		},
		[383073] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[374471] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[391769] = {
			2611, -- [1]
			"Dragon's Eruption", -- [2]
		},
		[386910] = {
			2583, -- [1]
			"Telash Greywing", -- [2]
		},
		[372860] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[384273] = {
			2635, -- [1]
			"Thunder Caller <Dathea, Ascended>", -- [2]
		},
		[382563] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[374635] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[165579] = {
			1679, -- [1]
			"Bonemaw", -- [2]
		},
		[386400] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[382564] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[207906] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[152792] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[372765] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[391772] = {
			2611, -- [1]
			"Dragon's Eruption", -- [2]
		},
		[376683] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[154327] = {
			1688, -- [1]
			"Shadowmoon Dominator", -- [2]
		},
		[153496] = {
			1679, -- [1]
			"Carrion Worm", -- [2]
		},
		[391773] = {
			2611, -- [1]
			"Dragon's Eruption", -- [2]
		},
		[207907] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[372859] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[371624] = {
			2590, -- [1]
			"Dathea Stormlash", -- [2]
		},
		[390920] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376685] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[374704] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[372082] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[386660] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[386916] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[376943] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[397793] = {
			1418, -- [1]
			"Wise Mari", -- [2]
		},
		[386661] = {
			2590, -- [1]
			"Kadros Icewrath", -- [2]
		},
		[374641] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[372851] = {
			2609, -- [1]
			"Melidrussa Chillworn", -- [2]
		},
		[375843] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[153240] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[395899] = {
			2605, -- [1]
			"Primalist Chillblaster", -- [2]
		},
		[372129] = {
			2592, -- [1]
			"Sennarth", -- [2]
		},
		[208165] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[206574] = {
			1868, -- [1]
			"[*] Resonant Slash", -- [2]
		},
		[377204] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[389221] = {
			2635, -- [1]
			"Raging Tempest <Dathea, Ascended>", -- [2]
		},
		[377612] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[374812] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[374582] = {
			2582, -- [1]
			"Leymor", -- [2]
		},
		[91807] = {
			2607, -- [1]
			"Glaciermonger <Astranith>", -- [2]
		},
		[396640] = {
			2563, -- [1]
			"Ancient Branch", -- [2]
		},
		[381482] = {
			2612, -- [1]
			"[*] Forgefire", -- [2]
		},
		[386921] = {
			2637, -- [1]
			"Dragonkiller Lance", -- [2]
		},
		[387333] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[386410] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[384620] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[153692] = {
			1679, -- [1]
			"[*] Necrotic Pitch", -- [2]
		},
		[384019] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[386411] = {
			2581, -- [1]
			"Teera", -- [2]
		},
		[384773] = {
			2623, -- [1]
			"Kyrakka", -- [2]
		},
		[375828] = {
			2605, -- [1]
			"Blazing Fiend", -- [2]
		},
		[191284] = {
			1805, -- [1]
			"Hymdall", -- [2]
		},
		[376851] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[387691] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[52042] = {
			2635, -- [1]
			"Healing Stream Totem <Capten-Frostwolf>", -- [2]
		},
		[372858] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[381298] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[381576] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[375061] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[371836] = {
			2590, -- [1]
			"Kadros Icewrath", -- [2]
		},
		[376725] = {
			2580, -- [1]
			"Nokhud Stormcaster", -- [2]
		},
		[388716] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[321538] = {
			2635, -- [1]
			"Lobo", -- [2]
		},
		[375929] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[387822] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[388717] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[391019] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[370991] = {
			2590, -- [1]
			"Opalfang", -- [2]
		},
		[374691] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[196543] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[382836] = {
			2581, -- [1]
			"Maruuk", -- [2]
		},
		[152800] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[379256] = {
			2585, -- [1]
			"Draconic Illusion", -- [2]
		},
		[374397] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[376737] = {
			2580, -- [1]
			"[*] Lightning", -- [2]
		},
		[114571] = {
			1417, -- [1]
			"Strife", -- [2]
		},
		[375575] = {
			2614, -- [1]
			"Dragonspawn Flamebender", -- [2]
		},
		[384628] = {
			2636, -- [1]
			"The Raging Tempest", -- [2]
		},
		[391022] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[152801] = {
			1688, -- [1]
			"Nhallish", -- [2]
		},
		[32409] = {
			2587, -- [1]
			"[*] Shadow Word: Death", -- [2]
		},
		[370307] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[373678] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[385068] = {
			2607, -- [1]
			"Colossal Stormfiend", -- [2]
		},
		[388643] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[197558] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[375630] = {
			2614, -- [1]
			"Drakonid Stormbringer", -- [2]
		},
		[376644] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[372279] = {
			2590, -- [1]
			"Dathea Stormlash", -- [2]
		},
		[375424] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[209741] = {
			1870, -- [1]
			"Image of Advisor Melandrus", -- [2]
		},
		[372056] = {
			2590, -- [1]
			"Opalfang", -- [2]
		},
		[374854] = {
			2613, -- [1]
			"Grounding Spear <Chargath, Bane of Scales>", -- [2]
		},
		[375397] = {
			2613, -- [1]
			"Chargath, Bane of Scales", -- [2]
		},
		[384823] = {
			2606, -- [1]
			"Blazebound Firestorm <Kokia Blazehoof>", -- [2]
		},
		[375937] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[193234] = {
			1805, -- [1]
			"[*] Dancing Blade", -- [2]
		},
		[207278] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[374842] = {
			2612, -- [1]
			"Forgemaster Gorek", -- [2]
		},
		[374022] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[381615] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[377473] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[371591] = {
			2590, -- [1]
			"Kadros Icewrath", -- [2]
		},
		[386088] = {
			2562, -- [1]
			"[*] Arcane Orb", -- [2]
		},
		[164686] = {
			1677, -- [1]
			"Sadana Bloodfury", -- [2]
		},
		[385339] = {
			2581, -- [1]
			"Maruuk", -- [2]
		},
		[374215] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[376865] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[393425] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[154671] = {
			1682, -- [1]
			"Ner'zhul", -- [2]
		},
		[376783] = {
			2611, -- [1]
			"Warlord Sargha", -- [2]
		},
		[373326] = {
			2565, -- [1]
			"Echo of Doragosa", -- [2]
		},
		[384696] = {
			2584, -- [1]
			"Umbrelskul", -- [2]
		},
		[384637] = {
			2635, -- [1]
			"Raging Tempest <Dathea, Ascended>", -- [2]
		},
		[385916] = {
			2637, -- [1]
			"Granyth", -- [2]
		},
		[377658] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[377542] = {
			2611, -- [1]
			"[*] Burning Ground", -- [2]
		},
		[389313] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[372222] = {
			2585, -- [1]
			"Azureblade", -- [2]
		},
		[375943] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[372107] = {
			2606, -- [1]
			"Kokia Blazehoof", -- [2]
		},
		[377166] = {
			2639, -- [1]
			"Terros", -- [2]
		},
		[378829] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[381249] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[377223] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[374410] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[381513] = {
			2623, -- [1]
			"Erkhart Stormvein", -- [2]
		},
		[376660] = {
			2580, -- [1]
			"Balakar Khan", -- [2]
		},
		[388537] = {
			2562, -- [1]
			"Vexamus <Magic Book>", -- [2]
		},
		[395894] = {
			2605, -- [1]
			"Kurog Grimtotem", -- [2]
		},
		[390711] = {
			2614, -- [1]
			"Broodkeeper Diurna", -- [2]
		},
		[370410] = {
			2587, -- [1]
			"Eranog", -- [2]
		},
		[388410] = {
			2635, -- [1]
			"Dathea, Ascended", -- [2]
		},
		[106113] = {
			1439, -- [1]
			"Sha of Doubt", -- [2]
		},
		[396151] = {
			1417, -- [1]
			"Strife", -- [2]
		},
		[377597] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
		[199373] = {
			2607, -- [1]
			"Army of the Dead|T1392565:0|t", -- [2]
		},
		[375436] = {
			2610, -- [1]
			"Magmatusk", -- [2]
		},
		[194112] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[397431] = {
			2635, -- [1]
			"Volatile Infuser <Dathea, Ascended>", -- [2]
		},
		[377594] = {
			2607, -- [1]
			"Raszageth", -- [2]
		},
	},
	["immersion_pets_on_solo_play"] = false,
	["npcid_ignored"] = {
	},
	["dungeon_data"] = {
	},
	["report_pos"] = {
		1, -- [1]
		1, -- [2]
	},
	["latest_report_table"] = {
	},
	["merge_pet_abilities"] = false,
	["always_use_profile"] = false,
	["deathlog_healingdone_min_arena"] = 400,
	["spell_school_cache"] = {
		["Dark Eclipse"] = 32,
		["Hailbombs"] = 16,
		["Chillstorm"] = 16,
		["Shadow Word: Pain"] = 32,
		["Icicle"] = 16,
		["Rotting from Within"] = 8,
		["Corrupted Vortex"] = 16,
		["Feeling of Superiority"] = 32,
		["Barbed Shot"] = 1,
		["Lasher Toxin"] = 8,
		["Liquid Hot Magma"] = 4,
		["Life Link"] = 1,
		["Firebolt"] = 4,
		["Wound Poison"] = 8,
		["Wither Will"] = 32,
		["Corrupted Mana"] = 64,
		["Cyclone"] = 8,
		["Trail of Ruin"] = 124,
		["Grounding Spear"] = 1,
		["Frost Strike Off-Hand"] = 16,
		["Sidearm"] = 1,
		["Quaking Pulse"] = 8,
		["Frost Tomb"] = 16,
		["Electrical Storm"] = 8,
		["Primal Overload"] = 8,
		["Static Charge"] = 8,
		["Dreadnaught"] = 1,
		["Searing Blows"] = 1,
		["Jade Fire"] = 4,
		["Melee"] = 1,
		["Shiv"] = 1,
		["Overpowering Croak"] = 1,
		["Localized Storm"] = 8,
		["Thunderous Energy"] = 8,
		["Arcane Fissure"] = 64,
		["Serpent Wave"] = 4,
		["Deathspike"] = 32,
		["Frost Bomb"] = 16,
		["Death and Decay"] = 32,
		["Burning Wound"] = 4,
		["Versatile Storm Lure"] = 8,
		["Serpent Sting"] = 8,
		["Ritual of Bones"] = 32,
		["Grievous Wound"] = 1,
		["Wildfire"] = 4,
		["Arcane Assault"] = 64,
		["Resonant Aftermath"] = 8,
		["Germinate"] = 1,
		["Avalanche"] = 16,
		["Energy Eruption"] = 64,
		["Glacial Surge"] = 16,
		["Frost Shock"] = 16,
		["Obliterate"] = 1,
		["Unstable Gusts"] = 8,
		["Frost Strike"] = 16,
		["Infernal Eruption"] = 4,
		["Resonant Slash"] = 64,
		["Earthen Pillar"] = 8,
		["Fissuring Slam"] = 8,
		["Frozen Shroud"] = 16,
		["Quake"] = 8,
		["Arcane Shot"] = 64,
		["Volcanic Plume"] = 4,
		["Feral Spirit"] = 8,
		["Raging Tempest"] = 8,
		["Blistering Presence"] = 4,
		["Felblade"] = 4,
		["Remorseless Winter"] = 16,
		["Ancient Orb Fragment"] = 64,
		["Nether Tempest"] = 64,
		["Erupting Bedrock"] = 8,
		["Scattered Charge"] = 8,
		["Envenom"] = 8,
		["Crackling Energy"] = 8,
		["Rock Blast"] = 8,
		["Overpower"] = 1,
		["Explosive Brand"] = 64,
		["Infernocore"] = 4,
		["Storm's Spite"] = 8,
		["Mind Flay"] = 32,
		["Crystalline Roar"] = 64,
		["Massive Boulders"] = 8,
		["Revenge"] = 1,
		["Deep Wounds"] = 1,
		["Ice Barrage"] = 16,
		["Soulrend"] = 127,
		["Splinterbark"] = 1,
		["Omen of Death"] = 32,
		["Spear of Bastion"] = 1,
		["Thunder Clap"] = 1,
		["Runic Brand"] = 2,
		["Lethal Current"] = 8,
		["Branch Out"] = 1,
		["Infernal Awakening"] = 4,
		["Feedback"] = 2,
		["Volatile Current"] = 8,
		["Shadow Burn"] = 32,
		["Absolute Zero"] = 16,
		["Burning Rush"] = 4,
		["Magma Eruption"] = 4,
		["Deafening Screech"] = 8,
		["Garrote"] = 1,
		["Raging Winds"] = 8,
		["Icy Ground"] = 16,
		["Lava Wave"] = 4,
		["Devastator"] = 1,
		["Demon Blades"] = 32,
		["Eruption"] = 4,
		["Burning Intensity"] = 4,
		["Fel Meteor"] = 4,
		["Glacial Convocation"] = 16,
		["Primal Shift"] = 28,
		["Enveloping Earth"] = 8,
		["Void Devastation"] = 32,
		["Raging Burst"] = 8,
		["Frozen Devotion"] = 16,
		["Master Marksman"] = 1,
		["Cobra Shot"] = 1,
		["Surge of Power"] = 8,
		["Corrupted Geyser"] = 16,
		["Body Slam"] = 32,
		["Winds of Change"] = 8,
		["Resonant Fists"] = 8,
		["Howling Blast"] = 16,
		["Greatstaff of the Broodkeeper"] = 8,
		["Lava Splash"] = 4,
		["Throw Glaive"] = 1,
		["Inhale"] = 32,
		["The Hunt"] = 8,
		["Spear of Light"] = 2,
		["Sigil of Flame"] = 4,
		["Flame Eruption"] = 4,
		["Eye of the Storm"] = 8,
		["Rushing Jade Wind"] = 1,
		["Arcane Orb"] = 64,
		["Fel Barrage"] = 36,
		["Gulp"] = 8,
		["Immolate"] = 4,
		["Secret Technique"] = 1,
		["Conductive Mark"] = 8,
		["Sunfire"] = 8,
		["Shadow Blades"] = 32,
		["Fractured Rubble"] = 8,
		["Aimed Shot"] = 1,
		["Electric Scales"] = 8,
		["Suffocating Webs"] = 1,
		["Seismic Assault"] = 8,
		["Shuriken Storm"] = 1,
		["Black Powder"] = 1,
		["Jade Serpent Strike"] = 4,
		["Storm Frenzy"] = 8,
		["Lightning Strike"] = 8,
		["Fulminating Charge"] = 8,
		["Ground Shatter"] = 8,
		["Blazing Eruption"] = 4,
		["Empowered Greatstaff's Wrath"] = 8,
		["Molten Boulder"] = 4,
		["Shadowburn"] = 36,
		["Surging Blast"] = 8,
		["Stormblast"] = 8,
		["Storming"] = 8,
		["Icy Shroud"] = 16,
		["Gale Arrow"] = 8,
		["Unstable Magic"] = 64,
		["Freezing Tempest"] = 16,
		["Tip of the Spear"] = 1,
		["Searing Wounds"] = 1,
		["Slicing Maelstrom"] = 1,
		["Ionizing Charge"] = 8,
		["Oppressive Miasma"] = 64,
		["Mutilated Flesh"] = 1,
		["Lightning Devastation"] = 8,
		["Void Blast"] = 32,
		["Erupted Ground"] = 4,
		["Flaming Embers"] = 4,
		["Flaring Cowl"] = 4,
		["Raging Blow"] = 1,
		["Overwhelming Rage"] = 16,
		["Polar Winds"] = 16,
		["Mana Bomb"] = 64,
		["Primal Devastation"] = 1,
		["Shocking Burst"] = 8,
		["Glacial Fury"] = 16,
		["Starfall"] = 72,
		["Thunderous Blast"] = 8,
		["Jade Serpent Wave"] = 4,
		["Empowered Greatstaff of the Broodkeeper"] = 8,
		["Primal Flames"] = 4,
		["Typhoon Strike"] = 1,
		["Flamerift"] = 4,
		["Beast Cleave"] = 1,
		["Frigid Torrent"] = 16,
		["Magma Pool"] = 4,
		["Scorched Ground"] = 4,
		["Unstable Power"] = 64,
		["Mortal Stoneclaws"] = 8,
		["Fel Armor"] = 32,
		["Flame Dominance"] = 4,
		["Blessed Hammer"] = 2,
		["Forgestorm"] = 4,
		["Eye Storm"] = 4,
		["Cauterizing Flashflames"] = 4,
		["Rampage"] = 1,
		["Conflagrate"] = 4,
		["Nothingness"] = 32,
		["Rupture"] = 1,
		["Master of the Glaive"] = 1,
		["Dancing Blade"] = 1,
		["Sanctify"] = 2,
		["Arcane Barrage"] = 64,
		["Tyr's Enforcer"] = 2,
		["Molten Rupture"] = 4,
		["Stomp"] = 1,
		["Intensity"] = 32,
		["Death Sweep"] = 1,
		["Soulseeker Arrow"] = 32,
		["The Raging Tempest"] = 8,
		["Elemental Surge"] = 28,
		["Molten Spike"] = 1,
		["Iron Stampede"] = 1,
		["Abundance"] = 8,
		["Ragefire"] = 4,
		["Lingering Charge"] = 8,
		["Bladestorm"] = 1,
		["Ravenous Leap"] = 1,
		["Azure Stone of Might"] = 64,
		["Burning"] = 4,
		["Overwhelming Energy"] = 64,
		["Shadow Rune"] = 32,
		["Lightning Crash"] = 8,
		["Thundering Presence"] = 8,
		["Quaking Convocation"] = 8,
		["Frostbolt"] = 16,
		["Storm Break"] = 8,
		["Stormwinds"] = 8,
		["Eviscerate"] = 32,
		["Electric Lash"] = 8,
		["Thunderbolt"] = 8,
		["Daggerfall"] = 32,
		["Maul"] = 1,
		["Deathmark"] = 1,
		["Primal Blizzard"] = 16,
		["Crackling Cloud"] = 8,
		["Shattering Presence"] = 8,
		["Magma Burst"] = 4,
		["Tough as Nails"] = 1,
		["Frost Overload"] = 16,
		["Incinerate"] = 4,
		["Kill Shot"] = 1,
		["Moonfire"] = 64,
		["Shadow Word: Death"] = 32,
		["Odyn's Fury"] = 1,
		["Lava Flow"] = 4,
		["Corpo-a-Corpo"] = 1,
		["Streetsweeper"] = 64,
		["Gulp Swog Toxin"] = 8,
		["Avenger's Shield"] = 2,
		["Static Surge"] = 64,
		["Immolation Aura"] = 4,
		["Catastrophe"] = 4,
		["Mortal Strike"] = 1,
		["Electrical Overload"] = 8,
		["Touch of the Grave"] = 32,
		["Crackling Vortex"] = 64,
		["Stormsurge"] = 8,
		["Serrated Bone Spike"] = 1,
		["Flame Sentry"] = 4,
		["Crackling Upheaval"] = 8,
		["Tremors"] = 8,
		["Toxic Effluvia"] = 8,
		["Thunderstruck"] = 8,
		["Flurry"] = 16,
		["Ice Strike"] = 16,
		["Blazing Hammer"] = 4,
		["Energy Bomb"] = 64,
		["Sticky Webbing"] = 8,
		["Shadowy Apparition"] = 32,
		["Heated Swings"] = 1,
		["Amice of the Blue"] = 64,
		["Chaos Barrage"] = 126,
		["Stormslam"] = 8,
		["Wash Away"] = 16,
		["Shooting Stars"] = 72,
		["Static Spear"] = 8,
		["Flame Shock"] = 4,
		["Frost Fever"] = 16,
		["Sanguine Ichor"] = 32,
		["Corpse Breath"] = 32,
		["Claw"] = 1,
		["Burning Ground"] = 4,
		["Obliterate Off-Hand"] = 1,
		["Biting Chill"] = 16,
		["Frost Dominance"] = 16,
		["Scorched Earth"] = 4,
		["Backstab"] = 1,
		["Wild Energy"] = 64,
		["Deadly Poison"] = 8,
		["Razorice"] = 16,
		["Auto Shot"] = 1,
		["Lightning Breath"] = 8,
		["Lightning"] = 8,
		["Ice Lance"] = 16,
		["The Dragon's Eruption"] = 4,
		["Concussive Slam"] = 1,
		["Bloodbath"] = 1,
		["Energy Surge"] = 8,
		["Shield Slam"] = 1,
		["Slag Eruption"] = 4,
		["Cave In"] = 1,
		["Overload"] = 8,
		["Greatstaff's Wrath"] = 8,
		["Clutchwatcher's Rage"] = 28,
		["Drifting Embers"] = 4,
		["Glacial Plume"] = 16,
		["Ball Lightning"] = 8,
		["Storm Dominance"] = 8,
		["Resonating Annihilation"] = 8,
		["Iron Spear"] = 1,
		["Flametongue Attack"] = 4,
		["Necrotic Pitch"] = 32,
		["Vampiric Touch"] = 32,
		["Heroic Throw"] = 1,
		["Pyre"] = 4,
		["Felblaze Puddle"] = 4,
		["Aftershock"] = 1,
		["Tempest Wing"] = 8,
		["Corporeal Tear"] = 64,
		["Sundering Strike"] = 28,
		["Blazing Charge"] = 4,
		["Electrified Jaws"] = 8,
		["Crushing Stoneclaws"] = 8,
		["Rapid Fire"] = 1,
		["Fiery Focus"] = 1,
		["Frozen Ground"] = 16,
		["Blazing Aegis"] = 4,
		["Infused Globule"] = 16,
		["Essence Break"] = 124,
		["Thunder Strike"] = 8,
		["Lingering Shadow"] = 32,
		["Windfury Attack"] = 1,
		["Waterlogged"] = 16,
		["Smack"] = 1,
		["Chilling Tantrum"] = 16,
		["Chaos Bolt"] = 124,
		["Kill Command"] = 1,
		["Surge"] = 8,
		["Molten Fissure"] = 4,
		["Meteor Axe"] = 4,
		["Blade Dance"] = 127,
		["Azure Strike"] = 80,
		["Molten Gold"] = 4,
		["Whirlwind"] = 1,
		["Annihilator"] = 1,
		["Infernal Flames"] = 4,
		["Mutilate"] = 1,
		["Fel Blast"] = 36,
		["Expel Light"] = 2,
		["Chilling Presence"] = 16,
		["Roaring Firebreath"] = 4,
		["Execute"] = 1,
		["Rend"] = 1,
		["Arcane Explosion"] = 64,
		["Awakened Earth"] = 8,
		["Mind Blast"] = 32,
		["Flamespit"] = 4,
		["Lightning Bolt"] = 8,
		["Void Vortex"] = 32,
		["Elemental Blast"] = 28,
		["Inexorable Assault"] = 16,
		["Icy Devastator"] = 16,
		["Stormstrike"] = 1,
		["Chaos Strike"] = 127,
		["Fel Bolt"] = 36,
		["Earth Dominance"] = 8,
		["Tectonic Barrage"] = 8,
		["Gushing Wound"] = 1,
		["Arcane Missiles"] = 64,
		["Static Field"] = 8,
		["Enveloping Winds"] = 8,
		["Whispers of the Dark Star"] = 32,
		["Blowback"] = 8,
		["Forgefire"] = 4,
		["Crushing Blow"] = 1,
		["Pulsing Flames"] = 4,
		["Divine Resonance"] = 64,
		["Disintegrate"] = 80,
		["Searing Glare"] = 4,
	},
	["spell_category_latest_sent"] = 0,
	["plater"] = {
		["realtime_dps_enabled"] = false,
		["damage_taken_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_shadow"] = true,
		["damage_taken_enabled"] = false,
		["realtime_dps_player_size"] = 12,
		["damage_taken_size"] = 12,
		["realtime_dps_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_size"] = 12,
		["damage_taken_shadow"] = true,
		["damage_taken_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_enabled"] = false,
		["realtime_dps_shadow"] = true,
	},
	["deathlog_line_height"] = 16,
	["latest_shield_spellid_cache_access"] = 1676570530,
	["current_exp_raid_encounters"] = {
		[2639] = true,
		[2635] = true,
		[2590] = true,
		[2605] = true,
		[2592] = true,
		[2607] = true,
		[2587] = true,
		[2614] = true,
	},
	["keystone_frame"] = {
		["scale"] = 1,
		["position"] = {
			["y"] = 33.61370468139648,
			["x"] = -29.79400634765625,
			["point"] = "CENTER",
			["scale"] = 1,
		},
	},
	["show_totalhitdamage_on_overkill"] = false,
	["trinket_data"] = {
		[394453] = {
			["lastPlayerName"] = "Caxivora",
			["maxTime"] = 97.73799991607666,
			["averageTime"] = 54,
			["activations"] = 42,
			["totalCooldownTime"] = 2292.146999597549,
			["lastCombatId"] = 1509,
			["minTime"] = 40.14300012588501,
			["lastActivation"] = 1676587438.389,
			["spellName"] = "Broodkeeper's Blaze",
		},
		[385903] = {
			["lastPlayerName"] = "Hakizu",
			["maxTime"] = 195.9880001544952,
			["averageTime"] = 75,
			["activations"] = 47,
			["totalCooldownTime"] = 3557.954999685288,
			["lastCombatId"] = 1124,
			["minTime"] = 40.05699992179871,
			["lastActivation"] = 1674768071.223,
			["spellName"] = "Crystal Sickness",
		},
		[382426] = {
			["lastPlayerName"] = "Caxivora",
			["maxTime"] = 98.23600006103516,
			["averageTime"] = 48,
			["activations"] = 177,
			["totalCooldownTime"] = 8539.407000303268,
			["lastCombatId"] = 1509,
			["minTime"] = 40.01200008392334,
			["lastActivation"] = 1676587440.541,
			["spellName"] = "Spiteful Stormbolt",
		},
		[214052] = {
			["lastPlayerName"] = "Feny-Gilneas",
			["maxTime"] = 721.7459998130798,
			["averageTime"] = 52,
			["activations"] = 294,
			["totalCooldownTime"] = 15406.09899997711,
			["lastCombatId"] = 1229,
			["minTime"] = 40.18499994277954,
			["lastActivation"] = 1675002976.017,
			["spellName"] = "Fel Meteor",
		},
		[388755] = {
			["lastPlayerName"] = "Nilandra",
			["maxTime"] = 154.5190000534058,
			["averageTime"] = 56,
			["activations"] = 296,
			["totalCooldownTime"] = 16780.4710006714,
			["lastCombatId"] = 1509,
			["minTime"] = 40.00200009346008,
			["lastActivation"] = 1676587541.088,
			["spellName"] = "Soulseeker Arrow",
		},
		[388739] = {
			["lastPlayerName"] = "Фармацет-Гордунни",
			["maxTime"] = 64.6029999256134,
			["averageTime"] = 61,
			["activations"] = 2,
			["totalCooldownTime"] = 123.4079999923706,
			["lastCombatId"] = 1061,
			["minTime"] = 58.8050000667572,
			["lastActivation"] = 1674754348.121,
			["spellName"] = "Pure Decay",
		},
		[397376] = {
			["lastPlayerName"] = "Danori-Tichondrius",
			["maxTime"] = 0,
			["averageTime"] = 0,
			["activations"] = 0,
			["totalCooldownTime"] = 0,
			["lastCombatId"] = 620,
			["minTime"] = 9999999,
			["lastActivation"] = 1674215250.121,
			["spellName"] = "Burning Embers",
		},
	},
	["global_plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["encounter_timers_bw"] = {
			},
			["encounter_timers_dbm"] = {
			},
		},
	},
	["savedCustomSpells"] = {
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\ICONS\\INV_Sword_04", -- [3]
		}, -- [1]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\ICONS\\INV_Weapon_Bow_07", -- [3]
		}, -- [2]
		{
			3, -- [1]
			"Environment (Falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [3]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [4]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [5]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [6]
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [7]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [8]
		{
			382056, -- [1]
			"Decoration of Flame (|T1387353:14:14:0:0:14:14:1:12:1:12|t Decoration of Flame)", -- [2]
			1387353, -- [3]
		}, -- [9]
		{
			381475, -- [1]
			"Erupting Spear Fragment (|T4638721:14:14:0:0:14:14:1:12:1:12|t Erupting Spear Fragment)", -- [2]
			4638721, -- [3]
		}, -- [10]
		{
			385903, -- [1]
			"Crystal Sickness (|T237007:14:14:0:0:14:14:1:12:1:12|t Umbrelskul's Fractured Heart)", -- [2]
			237007, -- [3]
		}, -- [11]
		{
			108271, -- [1]
			"Astral Shift", -- [2]
			"Interface\\Addons\\Details\\images\\icon_astral_shift", -- [3]
		}, -- [12]
		{
			388739, -- [1]
			"Pure Decay (|T4635246:14:14:0:0:14:14:1:12:1:12|t Idol of Pure Decay)", -- [2]
			4635246, -- [3]
		}, -- [13]
		{
			382058, -- [1]
			"Decoration of Flame (|T1387353:14:14:0:0:14:14:1:12:1:12|t Decoration of Flame)", -- [2]
			1387353, -- [3]
		}, -- [14]
		{
			382097, -- [1]
			"Rumbling Ruby (|T4638708:14:14:0:0:14:14:1:12:1:12|t Rumbling Ruby)", -- [2]
			1016245, -- [3]
		}, -- [15]
		{
			377455, -- [1]
			"Iceblood Deathsnare (|T237430:14:14:0:0:14:14:1:12:1:12|t Iceblood Deathsnare)", -- [2]
			237430, -- [3]
		}, -- [16]
		{
			384004, -- [1]
			"Dwarven Barrage (|T1029000:14:14:0:0:14:14:1:12:1:12|t Homeland Raid Horn)", -- [2]
			252172, -- [3]
		}, -- [17]
		{
			382090, -- [1]
			"Storm-Eater's Boon (|T4554454:14:14:0:0:14:14:1:12:1:12|t Storm-Eater's Boon)", -- [2]
			4554454, -- [3]
		}, -- [18]
		{
			214985, -- [1]
			"Slicing Maelstrom (|T519378:14:14:0:0:14:14:1:12:1:12|t Windscar Whetstone)", -- [2]
			1029585, -- [3]
		}, -- [19]
		{
			77535, -- [1]
			"Blood Shield", -- [2]
			"Interface\\Addons\\Details\\images\\icon_blood_shield", -- [3]
		}, -- [20]
		{
			382135, -- [1]
			"Manic Grieftorch (|T650636:14:14:0:0:14:14:1:12:1:12|t Manic Grieftorch)", -- [2]
			650636, -- [3]
		}, -- [21]
		{
			381967, -- [1]
			"Way of Controlled Currents (|T1020391:14:14:0:0:14:14:1:12:1:12|t Controlled Current Technique)", -- [2]
			1020391, -- [3]
		}, -- [22]
		{
			388855, -- [1]
			"Miniature Singing Stone (|T4638394:14:14:0:0:14:14:1:12:1:12|t Miniature Singing Stone)", -- [2]
			4638394, -- [3]
		}, -- [23]
		{
			387036, -- [1]
			"Burning Embers (|T4638716:14:14:0:0:14:14:1:12:1:12|t Kyrakka's Searing Embers)", -- [2]
			460952, -- [3]
		}, -- [24]
		{
			394453, -- [1]
			"Broodkeeper's Blaze (|T4638576:14:14:0:0:14:14:1:12:1:12|t Seal of Diurna's Chosen)", -- [2]
			514016, -- [3]
		}, -- [25]
		{
			214052, -- [1]
			"Fel Meteor (|T136030:14:14:0:0:14:14:1:12:1:12|t Eye of Skovald)", -- [2]
			135799, -- [3]
		}, -- [26]
		{
			383934, -- [1]
			"Water's Beating Heart (|T839910:14:14:0:0:14:14:1:12:1:12|t Water's Beating Heart)", -- [2]
			839910, -- [3]
		}, -- [27]
		{
			196917, -- [1]
			"Light of the Martyr (Damage)", -- [2]
			1360762, -- [3]
		}, -- [28]
		{
			382426, -- [1]
			"Spiteful Stormbolt (|T4638591:14:14:0:0:14:14:1:12:1:12|t Spiteful Storm)", -- [2]
			572029, -- [3]
		}, -- [29]
		{
			397376, -- [1]
			"Burning Embers (|T4638716:14:14:0:0:14:14:1:12:1:12|t Kyrakka's Searing Embers)", -- [2]
			460952, -- [3]
		}, -- [30]
		{
			377451, -- [1]
			"Conjured Chillglobe (|T4643989:14:14:0:0:14:14:1:12:1:12|t Conjured Chillglobe)", -- [2]
			4643989, -- [3]
		}, -- [31]
		{
			214200, -- [1]
			"Expel Light (|T535593:14:14:0:0:14:14:1:12:1:12|t Mote of Sanctification)", -- [2]
			237541, -- [3]
		}, -- [32]
		{
			98021, -- [1]
			"Health Exchange", -- [2]
			237586, -- [3]
		}, -- [33]
		{
			388755, -- [1]
			"Soulseeker Arrow (|T2103807:14:14:0:0:14:14:1:12:1:12|t Furious Ragefeather)", -- [2]
			2103807, -- [3]
		}, -- [34]
	},
	["keystone_cache"] = {
		["Scahra"] = {
			"Scahra", -- [1]
			20, -- [2]
			1176, -- [3]
			165, -- [4]
			12, -- [5]
			2535, -- [6]
			165, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.7421875, -- [1]
				0.98828125, -- [2]
				0.5, -- [3]
				0.75, -- [4]
			}, -- [9]
			"Shadowmoon Burial Grounds", -- [10]
			182, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Lüddl"] = {
			"Lüddl", -- [1]
			5, -- [2]
			960, -- [3]
			2, -- [4]
			3, -- [5]
			68, -- [6]
			2, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0, -- [1]
				0.25, -- [2]
				0.25, -- [3]
				0.5, -- [4]
			}, -- [9]
			"Temple of the Jade Serpent", -- [10]
			271, -- [11]
			false, -- [12]
			true, -- [13]
			["date"] = 1674422052,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Gorlirn"] = {
			"Gorlirn", -- [1]
			20, -- [2]
			2515, -- [3]
			401, -- [4]
			5, -- [5]
			2267, -- [6]
			401, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.49609375, -- [1]
				0.7421875, -- [2]
				0.25, -- [3]
				0.5, -- [4]
			}, -- [9]
			"The Azure Vault", -- [10]
			182, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Selenerah"] = {
			"Selenerah", -- [1]
			15, -- [2]
			2526, -- [3]
			402, -- [4]
			6, -- [5]
			1645, -- [6]
			402, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.25, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.75, -- [4]
			}, -- [9]
			"Algeth'ar Academy", -- [10]
			184, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Aubry"] = {
			"Aubry", -- [1]
			20, -- [2]
			1571, -- [3]
			210, -- [4]
			2, -- [5]
			2458, -- [6]
			210, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0, -- [1]
				0.25, -- [2]
				0.5, -- [3]
				0.75, -- [4]
			}, -- [9]
			"Court of Stars", -- [10]
			182, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Kalzifer"] = {
			"Kalzifer", -- [1]
			13, -- [2]
			2515, -- [3]
			401, -- [4]
			8, -- [5]
			586, -- [6]
			401, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.25, -- [1]
				0.49609375, -- [2]
				0, -- [3]
				0.25, -- [4]
			}, -- [9]
			"The Azure Vault", -- [10]
			172, -- [11]
			false, -- [12]
			true, -- [13]
			["date"] = 1674515818,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Morrizane"] = {
			"Morrizane", -- [1]
			18, -- [2]
			960, -- [3]
			2, -- [4]
			13, -- [5]
			2145, -- [6]
			2, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0, -- [1]
				0.25, -- [2]
				0.75, -- [3]
				1, -- [4]
			}, -- [9]
			"Temple of the Jade Serpent", -- [10]
			0, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Astrona"] = {
			"Astrona", -- [1]
			3, -- [2]
			1477, -- [3]
			200, -- [4]
			7, -- [5]
			271, -- [6]
			200, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.25, -- [1]
				0.49609375, -- [2]
				0.25, -- [3]
				0.5, -- [4]
			}, -- [9]
			"Halls of Valor", -- [10]
			0, -- [11]
			false, -- [12]
			true, -- [13]
			["date"] = 1674515576,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Nascha"] = {
			"Nascha", -- [1]
			16, -- [2]
			1477, -- [3]
			200, -- [4]
			3, -- [5]
			1771, -- [6]
			200, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0, -- [1]
				0.25, -- [2]
				0.25, -- [3]
				0.5, -- [4]
			}, -- [9]
			"Halls of Valor", -- [10]
			175, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1674581984,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Soosai"] = {
			"Soosai", -- [1]
			18, -- [2]
			1477, -- [3]
			200, -- [4]
			3, -- [5]
			2101, -- [6]
			200, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0, -- [1]
				0.25, -- [2]
				0.25, -- [3]
				0.5, -- [4]
			}, -- [9]
			"Halls of Valor", -- [10]
			0, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Miotas"] = {
			"Miotas", -- [1]
			2, -- [2]
			2516, -- [3]
			400, -- [4]
			7, -- [5]
			269, -- [6]
			400, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.25, -- [1]
				0.49609375, -- [2]
				0.25, -- [3]
				0.5, -- [4]
			}, -- [9]
			"The Nokhud Offensive", -- [10]
			0, -- [11]
			false, -- [12]
			true, -- [13]
			["date"] = 1674422052,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Astranith"] = {
			"Astranith", -- [1]
			20, -- [2]
			1571, -- [3]
			210, -- [4]
			6, -- [5]
			2452, -- [6]
			210, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.25, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.75, -- [4]
			}, -- [9]
			"Court of Stars", -- [10]
			180, -- [11]
			false, -- [12]
			true, -- [13]
			["date"] = 1674515818,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Dyrell"] = {
			"Dyrell", -- [1]
			12, -- [2]
			2516, -- [3]
			400, -- [4]
			10, -- [5]
			975, -- [6]
			400, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.5, -- [1]
				0.73828125, -- [2]
				0.5, -- [3]
				0.75, -- [4]
			}, -- [9]
			"The Nokhud Offensive", -- [10]
			189, -- [11]
			false, -- [12]
			true, -- [13]
			["date"] = 1673800040,
			["guild_name"] = "Gönnung Deluxe",
		},
		["Happenslol"] = {
			"Happenslol", -- [1]
			20, -- [2]
			1176, -- [3]
			165, -- [4]
			4, -- [5]
			2655, -- [6]
			165, -- [7]
			"Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes", -- [8]
			{
				0.49609375, -- [1]
				0.7421875, -- [2]
				0, -- [3]
				0.25, -- [4]
			}, -- [9]
			"Shadowmoon Burial Grounds", -- [10]
			0, -- [11]
			true, -- [12]
			true, -- [13]
			["date"] = 1676581823,
			["guild_name"] = "Gönnung Deluxe",
		},
	},
	["raid_data"] = {
	},
	["always_use_profile_name"] = "",
	["profile_by_spec"] = {
	},
	["combat_id_global"] = 1511,
	["displays_by_spec"] = {
	},
	["plugin_window_pos"] = {
		["y"] = -1.1444091796875e-05,
		["x"] = 1.52587890625e-05,
		["point"] = "CENTER",
		["scale"] = 1,
	},
	["last_changelog_size"] = 9341,
	["immersion_unit_special_icons"] = true,
	["lastUpdateWarning"] = 1674414118,
	["npcid_pool"] = {
		[0] = "[*] Shadow Word: Death",
		[75829] = "Nhallish",
		[198716] = "Unstable Storm",
		[194752] = "Agitated Horned Filcher",
		[192834] = "Greenbelt Riverbeast",
		[189893] = "Infused Whelp",
		[190405] = "Infuser Sariya",
		[95842] = "Valarjar Thundercaller",
		[186825] = "Molten Primalist",
		[195265] = "Stormcaller Arynga",
		[187209] = "Klozicc the Ascended",
		[106584] = "Watchful Oculus",
		[187593] = "Primal Flame",
		[195905] = "Hornstrider Runner",
		[189895] = "Primalist Infiltrator",
		[190023] = "Lava Tentacles",
		[187082] = "Primal Avalanche",
		[190407] = "Aqua Rager",
		[27829] = "Ebon Gargoyle <Noggerchoc>",
		[195906] = "Amberpelt Hunter",
		[201149] = "Cragsworn Stonemender",
		[120651] = "Explosives",
		[187083] = "Primal Avalanche",
		[191303] = "Apex Proto-Dragon",
		[106585] = "Watchful Oculus",
		[61029] = "Primal Fire Elemental <Fâméx>",
		[198081] = "Quarry Earthshaper",
		[199232] = "Molten Spike",
		[187212] = "Rumbling Proto-Dragon",
		[76407] = "Ner'zhul",
		[186701] = "Summoned Scalebiter",
		[196420] = "Cavern Hunter",
		[196548] = "Ancient Branch",
		[77942] = "Primal Storm Elemental <Æsberg>",
		[195398] = "Destructive Proto-Drake",
		[186319] = "Tarasek Laborer",
		[55659] = "Wild Imp <Seone>",
		[190923] = "Zephyrling",
		[194120] = "Vicious Rimefang",
		[195399] = "Curious Swoglet",
		[197829] = "Seismic Stomps",
		[189901] = "Warlord Sargha",
		[200387] = "Shambling Infester",
		[196679] = "Frozen Shroud",
		[187600] = "Qalashi Stonemender",
		[201155] = "Nascent Proto-Dragon",
		[198214] = "Broodguardian Ziruss",
		[187089] = "Flashfrost Tarasek",
		[197831] = "Quarry Stonebreaker",
		[185811] = "Shiverweb Creeper",
		[186962] = "Cascade",
		[198343] = "Malfunctioning Protector",
		[192333] = "Alpha Eagle",
		[168932] = "Doomguard <Scahra>",
		[194763] = "Tenmod",
		[185812] = "Shiverweb Spiderling",
		[196426] = "Grotto Creeper",
		[195915] = "Firava the Rekindler",
		[199368] = "Hardened Crystal",
		[189266] = "Qalashi Trainee",
		[196555] = "Gladehorn Armoredon",
		[75452] = "Bonemaw",
		[196044] = "Unruly Textbook",
		[190034] = "Blazebound Destroyer",
		[190162] = "Animated Vault Protector",
		[188244] = "Primal Juggernaut",
		[192464] = "Raging Ember <Warlord Sargha>",
		[197835] = "Kaurdyth",
		[195917] = "Primal Revenant",
		[196045] = "Corrupted Manafiend",
		[135816] = "Vilefiend <Necroso-TarrenMill>",
		[194255] = "Bakar Companion",
		[192337] = "Void Tendril <Ríbz>",
		[191570] = "Nokhud Spearthrower",
		[194895] = "Unstable Squall <Primalist Stormspeaker>",
		[190931] = "Tamed Vulture",
		[197197] = "Hectic Wildwater Ottuk",
		[191315] = "Herald of Frost",
		[194896] = "Primal Stormshield",
		[197198] = "Scythid Stalker",
		[187352] = "Tarasek Warrior",
		[193618] = "Restless Rocks",
		[189654] = "Snowhide Shaman",
		[194897] = "Stormsurge Totem",
		[198547] = "Shadowy Tear <Shapehex>",
		[198555] = "Chaos Tear <Ghenos>",
		[190294] = "Nokhud Stormcaster",
		[200035] = "Carrion Worm",
		[75451] = "Defiled Spirit",
		[75966] = "Defiled Spirit",
		[194898] = "Primalist Arcblade",
		[104218] = "Advisor Melandrus",
		[197200] = "Rapid Wooly Ewe",
		[196671] = "Arcane Ravager",
		[104217] = "Talixae Flamewreath",
		[97081] = "King Bjorn",
		[191541] = "Craggy Stag",
		[96934] = "Valarjar Trapper",
		[194495] = "Churning Wildwater",
		[192873] = "Proto-Drake",
		[193109] = "Empowered Greatstaff's Wrath",
		[195283] = "Yamakh",
		[191319] = "Ancient Splinter <Arcane Golem>",
		[195286] = "Mantai",
		[195431] = "Diluu",
		[143622] = "Wild Imp <Lúriell>",
		[195814] = "Monstrous Monolith",
		[196051] = "Arcane Portal <Arcane Commander>",
		[186483] = "Qalashi Steelcrafter",
		[193238] = "Spellwrought Snowman",
		[194389] = "Lava Spawn <Qalashi Lavamancer>",
		[65317] = "Xiang",
		[195668] = "Slavering Snapdragon",
		[193750] = "Primalist Stormsage",
		[201550] = "Overloading Defense Matrix",
		[187868] = "Molten Uprising",
		[186438] = "Primal Lava Elemental",
		[190174] = "Hypnosis Bat",
		[188252] = "Melidrussa Chillworn",
		[112668] = "Infernal Imp <Talixae Flamewreath>",
		[195930] = "Soulharvester Mandakh",
		[188274] = "Sutaan",
		[105699] = "Mana Saber",
		[188251] = "Earthen Pillar",
		[189040] = "Provoked Geode",
		[190171] = "Ruby Egg Guardian",
		[201552] = "Overseer Stonetongue",
		[189555] = "Astral Attendant",
		[194647] = "Thunder Caller <Dathea, Ascended>",
		[185591] = "Worldbreaker Smith",
		[193880] = "Shortcoat Bear Cub",
		[97068] = "Storm Drake",
		[193497] = "Shortcoat Bear",
		[75713] = "Shadowmoon Bone-Mender",
		[99868] = "Fenryr",
		[186336] = "Blazing Manifestation",
		[196694] = "Arcane Forager",
		[198868] = "Primalist Voltweaver",
		[195927] = "Soulharvester Galtmaa",
		[199124] = "Primalist Chillblaster",
		[195160] = "Igneous Wanderer",
		[190173] = "Earth Elemental",
		[187232] = "Time-Lost Bladewing",
		[186600] = "Dragonbane Protector",
		[186739] = "Azureblade",
		[185592] = "Swooping Snitch",
		[195928] = "Soulharvester Duuren",
		[169429] = "Shivarra",
		[189886] = "Blazebound Firestorm <Kokia Blazehoof>",
		[97197] = "Valarjar Purifier",
		[195417] = "Tsokorg",
		[186338] = "Maruuk",
		[188014] = "Pitchstone Rumbler",
		[190686] = "Frozen Destroyer",
		[195929] = "Soulharvester Tumen",
		[190688] = "Blazing Fiend",
		[186602] = "Dragonbane Mender",
		[193244] = "Titan Defense Matrix",
		[187203] = "Frozen Revenant",
		[186339] = "Teera",
		[195674] = "Agitated Initiate",
		[75459] = "Plagued Bat",
		[193884] = "Elusive Hornstrider",
		[190943] = "Ravine Vulture",
		[104295] = "Blazing Imp",
		[75715] = "Reanimated Ritual Bones",
		[60561] = "Earthgrab Totem <Xarozz>",
		[197177] = "Fuming Ice Burrower",
		[185445] = "Nokhud Scavenger",
		[155906] = "Beast",
		[169428] = "Wrathguard",
		[106586] = "Watchful Oculus",
		[200414] = "Landslide",
		[191847] = "Nokhud Plainstomper",
		[198489] = "Denizen of the Dream <Trullala>",
		[190433] = "Earthquake Totem",
		[193760] = "Surging Ruiner",
		[191712] = "Hissing Springsoul",
		[186725] = "Trrsha",
		[27893] = "Rune Weapon",
		[75652] = "Void Spawn",
		[3527] = "Healing Stream Totem <Blurkhlust>",
		[191329] = "Sleepless Fickleshell",
		[194526] = "Magma Droplet <Magmaticus>",
		[188011] = "Primal Terrasentry",
		[186598] = "Dragonbane Soldier",
		[105703] = "Mana Wyrm",
		[196061] = "Arcane Detritus",
		[187969] = "Flashfrost Earthshaper",
		[196203] = "Ethereal Restorer",
		[201560] = "Primalist Flamecaller",
		[187366] = "Worldcarver Wurmling",
		[189798] = "Ancient Proto-Dragon",
		[191714] = "Seeking Stormling",
		[75981] = "Daggerfall",
		[190947] = "Altered Wymling",
		[187256] = "Time-Lost Raptor",
		[196559] = "Volatile Sapling",
		[187239] = "Time-Lost Sunseeker",
		[190690] = "Thundering Ravager",
		[188009] = "Grand Flame",
		[189669] = "Binding Spear",
		[105704] = "Arcane Manifestation",
		[190434] = "Rainstorm Totem",
		[190909] = "Swift Hornstrider",
		[199388] = "Mark of Wind",
		[187240] = "Drakonid Breaker",
		[195552] = "Bruffalon Bull",
		[185814] = "Shiverweb Crusher",
		[191736] = "Crawth",
		[197982] = "Storm Warrior",
		[193243] = "Acrosoth",
		[58319] = "Lesser Sha",
		[17252] = "AkinVazul",
		[192356] = "Enraged Embers",
		[196576] = "Spellbound Scepter",
		[192329] = "Territorial Eagle",
		[190694] = "Angered Steam",
		[105705] = "Bound Energy",
		[186599] = "Dragonbane Firebinder",
		[194147] = "Volcanius",
		[191206] = "Primalist Mage",
		[187242] = "Tarasek Looter",
		[196577] = "Spellbound Battleaxe",
		[59726] = "Peril",
		[188649] = "Blazing Manifestation",
		[193892] = "Elusive Bull",
		[186859] = "Worldcarver A'tir",
		[197174] = "Furious Horned Filcher",
		[97202] = "Olmyr the Enlightened",
		[187262] = "Time-Lost Devilsaur",
		[193849] = "Rakkesh of the Flow",
		[58959] = "Unknown",
		[186604] = "Dragonbane Soldier",
		[197985] = "Flame Channeler",
		[193644] = "Bouldron",
		[197218] = "Enraged Drip",
		[195300] = "Arkhuu",
		[193134] = "Enkine the Voracious",
		[190278] = "Malifron",
		[191227] = "Nokhud Spearman",
		[186605] = "Dragonbane Firebinder",
		[186741] = "Arcane Elemental",
		[190953] = "Sunhide Stomphoof",
		[104300] = "Shadow Mistress",
		[190186] = "Primalist Magmashaper",
		[200137] = "Depraved Mistweaver",
		[189822] = "Shas'ith",
		[190206] = "Primalist Flamedancer",
		[186606] = "Dragonbane Cauldron Keeper",
		[194798] = "Colossal Glacier",
		[76104] = "Monstrous Corpse Spider",
		[197220] = "Furious Deluge",
		[190187] = "Draconic Image",
		[187246] = "Nullmagic Hornswog",
		[196581] = "White Tiger Statue <Shoulao>",
		[191448] = "Greatstaff's Wrath",
		[185584] = "Blasphemy <Lúriell>",
		[98035] = "Dreadstalker <Lúriell>",
		[187886] = "Turboris",
		[197221] = "Raging Torrent",
		[186965] = "Smoldering Feather <Lava Phoenix>",
		[198500] = "Council Earthcaller",
		[187638] = "Flamescale Tarasek",
		[58960] = "Unknown",
		[195815] = "Primal Stone",
		[186736] = "Flame Sentry",
		[190404] = "Subterranean Proto-Dragon",
		[191084] = "Spiderling",
		[191212] = "Earthquake Totem",
		[198501] = "Council Icecaller",
		[193514] = "Snowy Mammoth Bull",
		[192626] = "Crust Lurker",
		[186609] = "Dragonbane Shieldcracker",
		[186737] = "Telash Greywing",
		[104215] = "Patrol Captain Gerdo",
		[196200] = "Algeth'ar Echoknight",
		[107435] = "Gerenth the Vile",
		[198502] = "Council Stormcaller",
		[186354] = "Sundered Runebinder",
		[194894] = "Primalist Stormspeaker",
		[187396] = "Rustpine Immolator",
		[186738] = "Umbrelskul",
		[187889] = "Shattered Fragment",
		[197224] = "Tamed Magmammoth Calf",
		[197352] = "Alpha Thornsided Basilisk",
		[196457] = "Orian Darkwater",
		[99891] = "Storm Drake",
		[187506] = "Stonegrabber Shard",
		[186611] = "Restless Lava",
		[184693] = "Living Flame",
		[196336] = "Qalashi Flameslinger",
		[196202] = "Spectral Invoker",
		[191215] = "Tarasek Legionnaire",
		[193389] = "Towering Fickleshells",
		[189042] = "Disquieted Frost",
		[195403] = "Rampaging Wooly Ewe",
		[186612] = "Wyrmeater",
		[186740] = "Arcane Construct",
		[191983] = "Erupting Droplet",
		[190065] = "Unruly Whelp",
		[187897] = "Defier Draghar",
		[78219] = "Desecrated Ancestor",
		[192745] = "Seismic Force",
		[192630] = "Muck Brawler",
		[194797] = "Hoary Icicle",
		[191856] = "Raging Tempest <Dathea, Ascended>",
		[190961] = "Mudwalker Salamanther",
		[190066] = "Water Primalist",
		[191057] = "Thunderspine Crasher",
		[190322] = "Highhorn Bull",
		[187264] = "Time-Lost Briarback",
		[193647] = "Karantun",
		[200936] = "Living Flame",
		[194926] = "Swift Hornstrider",
		[190962] = "Nokhud Warhound",
		[198577] = "Unstable Flame",
		[198385] = "Fragmented Energy <Malfunctioning Protector>",
		[194761] = "Khuumog",
		[186359] = "Brackenhide Scrapper",
		[26125] = "Madenbrecher <Hallowaslos>",
		[186615] = "The Raging Tempest",
		[196973] = "Kerzanthi",
		[187894] = "Infused Whelp",
		[193973] = "Mistyvale Splashcaster",
		[186684] = "Lava Phoenix",
		[194760] = "Uurhilt",
		[24207] = "Army of the Dead|T1392565:0|t",
		[189557] = "Qalashi Boltthrower",
		[185593] = "Worldbreaker Shapist",
		[189813] = "Dathea, Ascended",
		[191313] = "Bubbling Sapling",
		[195184] = "Defense Orb",
		[95674] = "Fenryr",
		[193394] = "Mosshair Bull",
		[191476] = "Searing Flame Harchek",
		[195696] = "Primalist Thunderbeast",
		[185594] = "Worldbreaker Guard",
		[187768] = "Dathea Stormlash",
		[198126] = "Cloying Gale",
		[192764] = "Flame Guardian",
		[194290] = "Feral Bakar",
		[200945] = "Nokhud Warmonger",
		[198390] = "Shattered Fragment <Turboris>",
		[184444] = "Oppressive Artificer",
		[185595] = "Worldbreaker Cultist",
		[189815] = "Cliffdrip Fallstriker",
		[194035] = "Tundra Bear",
		[89] = "Infernal <Lúriell>",
		[95675] = "God-King Skovald",
		[58964] = "Hrogrogg",
		[196913] = "Mara'nar the Thunderous",
		[192693] = "Risen Phoenix <Blazing Firesquall>",
		[185596] = "Worldbreaker Bulwark",
		[192885] = "Snowhorn Bruffalon",
		[186624] = "Bound Spark",
		[56789] = "Dragon Wave",
		[97788] = "Storm Drake",
		[191351] = "Sleepless Fickleshell",
		[186323] = "Sundered Enforcer",
		[190584] = "Time-Lost Murloc",
		[188666] = "Unleashed Lavaburst",
		[187771] = "Kadros Icewrath",
		[197376] = "Alpha Mountain Stonefang",
		[188672] = "Consuming Upswell",
		[200431] = "Furious Earth",
		[57109] = "Minion of Doubt",
		[199664] = "Seismodor, Earth's Wrath",
		[189823] = "Ravenous Nestling",
		[192759] = "Gorger",
		[187772] = "Opalfang",
		[97083] = "King Ranulf",
		[104822] = "Flame of Woe",
		[191225] = "Tarasek Earthreaver",
		[191230] = "Dragonspawn Flamebender",
		[191481] = "Stomphoof Calf",
		[190586] = "Earth Breaker",
		[194806] = "Crackling Vortex",
		[105715] = "Watchful Inquisitor",
		[181763] = "Lava Phoenix",
		[195190] = "Highlands Bull",
		[186111] = "Primalist Tender",
		[186239] = "Qalashi Skullhauler",
		[97369] = "Liquid Magma Totem <Sonuf>",
		[188673] = "Smoldering Colossus",
		[192761] = "Iskakx",
		[199027] = "Magmas",
		[97084] = "King Tor",
		[193145] = "Ravenous Proto-Drake",
		[186112] = "Primalist Infuser",
		[193401] = "Snowscruff Bakar",
		[59051] = "Strife",
		[190588] = "Tectonic Crusher",
		[191739] = "Scalebane Lieutenant",
		[191867] = "Summoned Icestorm",
		[195968] = "Angerdrool",
		[195003] = "Rowdy Goat",
		[190205] = "Scorchling",
		[195448] = "Blazing Firesquall",
		[196599] = "Magmaticus",
		[200439] = "Modor",
		[196855] = "Braekkas",
		[191868] = "Security Construct",
		[104246] = "Duskwatch Guard",
		[75979] = "Exhumed Spirit",
		[191229] = "Primalist Stormfury",
		[187265] = "Time-Lost Geomancer",
		[196600] = "Blazing Ember",
		[192636] = "Wild Proto-Drake",
		[56439] = "Sha of Doubt",
		[199030] = "Loamas",
		[96574] = "Stormforged Sentinel",
		[198263] = "Stalwart Broodwarden",
		[186115] = "Frostspike Guardian",
		[189312] = "Calving Elemental",
		[193532] = "Bazual",
		[184453] = "Brutal Motivator",
		[19668] = "Shadowfiend <Shadowmagoo>",
		[194939] = "Cascade Proto-Drake",
		[104247] = "Duskwatch Arcanist",
		[190080] = "Tarasek Elementalist",
		[187139] = "Crystal Thrasher",
		[186630] = "Bound Stones",
		[195579] = "Primal Gust",
		[58965] = "Zig-garath",
		[186628] = "Bound Pebbles",
		[193859] = "Elusive Thunder Lizard",
		[187907] = "Qalashi Bonebreaker",
		[191104] = "Primal Scythid",
		[191232] = "Drakonid Stormbringer",
		[200438] = "Seis",
		[185350] = "Ravenous Bloodbeak",
		[95843] = "King Haldor",
		[192767] = "Primal Icebulk",
		[191324] = "Encroaching Downpour",
		[187908] = "Qalashi Scaleripper",
		[195197] = "Shortcoat Bear",
		[191233] = "Invading Stormling",
		[193407] = "Horned Plainstomper",
		[193535] = "Basrikron",
		[195198] = "Shortcoat Mauler",
		[195837] = "Rimebound Subjugator",
		[103673] = "Darkglare <Cursekek>",
		[193969] = "Mistyvale Firestarter",
		[96640] = "Valarjar Marksman",
		[99773] = "Bloodworm",
		[190339] = "Horned Armoredon",
		[185810] = "Shiverweb Crawler",
		[193664] = "Ancient Protector",
		[192769] = "Thondrozus",
		[192690] = "Smoldering Feather <Blazing Firesquall>",
		[191469] = "Streamside Scythid",
		[56792] = "Figment of Doubt",
		[191235] = "Invading Storm Elemental",
		[187271] = "Brinetooth Gnasher",
		[185353] = "Nokhud Huntmaster",
		[187273] = "Brinetooth Jabber",
		[186632] = "Scalepiercer",
		[6112] = "Windfury Totem <Dareschine>",
		[190980] = "Rowdy Hornswog",
		[190085] = "Grounding Spear <Chargath, Bane of Scales>",
		[57080] = "Corrupted Scroll",
		[199029] = "Cyclas",
		[59873] = "Corrupt Living Water",
		[195119] = "Primalist Shockcaster",
		[187211] = "Galestrike Proto-Dragon",
		[199037] = "Primalist Shocktrooper",
		[198142] = "Quarry Earthshaper",
		[186679] = "Mudfin Shaman",
		[195758] = "Nokhud Harrier",
		[190342] = "Containment Apparatus",
		[95833] = "Hyrja",
		[192644] = "Mountain Stonefang",
		[190726] = "Striped Bruffalon",
		[198136] = "Eminent Earthshaper",
		[195836] = "Rimebound Controller",
		[184972] = "Eranog",
		[198399] = "Taresh <Taresh>",
		[190343] = "Vigilant Watcher",
		[191494] = "Teerai Battlemaster",
		[184461] = "Tarasek Marauder",
		[192773] = "Primalist Gateway",
		[198503] = "Council Flamecaller",
		[104251] = "Duskwatch Sentry",
		[59553] = "The Songbird Queen",
		[193967] = "Dragonbane Wingshredder",
		[196482] = "Overgrown Ancient",
		[188426] = "Toluijin",
		[194692] = "Horned Armoredon",
		[193839] = "Nokhud Dominator",
		[195971] = "Luumak the Insatiable",
		[195195] = "Highland Mammoth Bull",
		[194181] = "Vexamus <Magic Book>",
		[191240] = "Hillside Forager",
		[190345] = "Primalist Geomancer",
		[106988] = "Beast",
		[193417] = "Young Horned Armoredon",
		[189235] = "Overseer Lahar",
		[195972] = "Slobberclaw",
		[194694] = "Horned Armoredon",
		[188044] = "Cindershard Hulk",
		[97219] = "Solsten",
		[163366] = "Magus of the Dead",
		[185357] = "Nokhud Sentry",
		[190602] = "Hailstorm Warmonger",
		[186638] = "Qalashi Crustshaper",
		[195973] = "Piskato",
		[190986] = "Battlehorn Pyrhus",
		[199298] = "Qalashi Skullhauler",
		[188173] = "Sundered Sentinel",
		[196102] = "Conjured Lasher",
		[193673] = "Shortcoat Mauler",
		[190603] = "Hailstorm Iceshot",
		[186421] = "Primal Drift",
		[195974] = "The Red Gulper",
		[56762] = "Yu'lon",
		[69791] = "Fire Spirit <Shoulao>",
		[188174] = "Destructive Flames",
		[190348] = "Primalist Ravager",
		[193545] = "Feral Bakar",
		[185489] = "King Drippy",
		[195975] = "The Black Gulper",
		[76057] = "Carrion Worm",
		[187919] = "Caldera Stomper",
		[189515] = "Infused Proto-Drake",
		[193290] = "Magma Bubble",
		[193384] = "Plains Rockfang",
		[185691] = "Vicious Hyena",
		[185490] = "Entranced Water Elemental",
		[188687] = "Zhurtan the Riverboiler",
		[195976] = "The Blue Gulper",
		[62005] = "Beast <Ribenji>",
		[188048] = "Crystalized Steelshard",
		[193291] = "Apex Blazewing",
		[97285] = "Wind Rush Totem <Sonuf>",
		[166949] = "Chi-Ji <Twinfists>",
		[69792] = "Earth Spirit <Shoulao>",
		[197801] = "Awakened Terrasentry",
		[59544] = "The Nodding Tiger",
		[193534] = "Strunraan",
		[194315] = "Stormcaller Solongo",
		[187154] = "Unstable Curator",
		[189233] = "Caustic Spiderling",
		[187867] = "Qalashi Magmacrafter",
		[190207] = "Primalist Cinderweaver",
		[192781] = "Ore Elemental",
		[191886] = "Primalist Lava Conduit",
		[200131] = "Sha-Touched Guardian",
		[194316] = "Stormcaller Zarii",
		[193293] = "Qalashi Warden",
		[194444] = "Wild Proto-Drake",
		[186644] = "Leymor",
		[187539] = "Rustpine Loamcrafter",
		[195851] = "Ukhel Deathspeaker",
		[189841] = "Russet Mudwalker",
		[187602] = "Qalashi Scaleripper",
		[175519] = "Frothing Pustule",
		[194317] = "Stormcaller Boroo",
		[195580] = "Nokhud Saboteur <Dragonkiller Lance>",
		[59598] = "Lesser Sha",
		[190609] = "Echo of Doragosa",
		[193806] = "Primal Proto-Drake",
		[62358] = "Corrupt Droplet",
		[192045] = "Windseeker Avash",
		[190611] = "Frenzied Pollenstag",
		[189843] = "Fire Elemental",
		[191661] = "Cragsworn Stoneshaper",
		[195597] = "Primal Proto-Whelp",
		[190510] = "Vault Guard",
		[184600] = "Argzeal",
		[59545] = "The Golden Beetle",
		[195241] = "Primal Proto-Drake",
		[76444] = "Subjugated Soul",
		[198310] = "Flame Tarasek",
		[101637] = "Valarjar Aspirant",
		[195855] = "Risen Warrior",
		[102019] = "Stormforged Obliterator",
		[188693] = "Boneshaper Jardak",
		[56732] = "Liu Flameheart",
		[144961] = "Akaari's Soul",
		[192787] = "Qalashi Spinecrusher",
		[187159] = "Shrieking Whelp",
		[99922] = "Ebonclaw Packmate",
		[190484] = "Kyrakka",
		[196624] = "Mistyvale Stonecarver",
		[192786] = "Qalashi Plunderer",
		[59546] = "The Talking Fish",
		[196111] = "Pit Lord <Lúriell>",
		[184986] = "Kurog Grimtotem",
		[187160] = "Crystal Fury",
		[196495] = "Over-Pollinated Lasher",
		[190485] = "Erkhart Stormvein",
		[199182] = "Jumping Spiderling",
		[187672] = "Rustfang Creeper",
		[417] = "Jhuuzun",
		[191510] = "Smoldering Hellion",
		[192938] = "Nimblewing Striker",
		[76446] = "Shadowmoon Dominator",
		[188697] = "Provoking Flame",
		[189463] = "Riverback Rambler",
		[192660] = "Gronn Servant",
		[192788] = "Qalashi Thaumaturge",
		[194962] = "Highhorn Bull",
		[190998] = "Bossy Hornswog",
		[187802] = "Mudfin Frenzy",
		[198415] = "Tyrhold Dapple",
		[190359] = "Skulking Zealot",
		[189464] = "Qalashi Irontorch",
		[193684] = "Pipspark Thundersnap",
		[192789] = "Nokhud Longbow",
		[198032] = "Dragon's Eruption",
		[182815] = "Summoned Lava Elemental <Qalashi Flameslinger>",
		[192534] = "Stormshroud Matriarch",
		[193301] = "Aggressive Hornstrider",
		[182816] = "Summoned Lava Elemental",
		[189465] = "Riverback Stomper",
		[193685] = "Chargum",
		[196115] = "Arcane Tender",
		[195348] = "Earthen Spire <Basrikron>",
		[195092] = "Hydraulic Eroder",
		[197906] = "Flickering Ember",
		[198417] = "Tyrhold Gryphon",
		[188717] = "Hihveer",
		[189466] = "Irontorch Commander",
		[136398] = "Illidari Satyr <Lúriell>",
		[192791] = "Nokhud Warspear",
		[190362] = "Dazzling Dragonfly",
		[196116] = "Crystal Fury",
		[195221] = "Grasslands Bakar",
		[184862] = "Primal Proto-Whelp",
		[193431] = "Hungry Nibbler",
		[189467] = "Qalashi Bonesplitter",
		[189595] = "Infused Egg",
		[101639] = "Valarjar Shieldmaiden",
		[189851] = "Ritual Scout",
		[196117] = "Crystal Thrasher",
		[189228] = "Hailbringer Marauder",
		[193388] = "Towering Fickleshells",
		[189340] = "Chargath, Bane of Scales",
		[189468] = "Riverback Savage",
		[193688] = "Phenran",
		[188026] = "Frost Tomb",
		[193944] = "Qalashi Lavamancer",
		[195095] = "Time-Lost Murhulk",
		[193320] = "Reformed Earth <Pitchstone Rumbler>",
		[29264] = "Spirit Wolf <Windfurybot>",
		[191451] = "Hungering Tyranha",
		[197142] = "Decayed Elder",
		[136401] = "Eye of Gul'dan <Lúriell>",
		[192794] = "Nokhud Beastmaster",
		[194968] = "Toluiqi",
		[196119] = "Dragonspawn Spell Weaver",
		[193306] = "Stream Hunter",
		[197398] = "Hungry Lasher",
		[195876] = "Desecrated Ohuna",
		[189470] = "Lava Flare",
		[136402] = "Ur'zul <Burschì>",
		[189875] = "Animated Cindershards",
		[190366] = "Curious Swoglet",
		[188704] = "Maneet",
		[186669] = "Mudfin Salamancer",
		[189472] = "Qalashi Lavabearer",
		[187297] = "Nokhud Fighter",
		[189471] = "Qalashi Blacksmith",
		[136403] = "Void Terror <Lúriell>",
		[192796] = "Nokhud Hornsounder",
		[100943] = "Earthen Wall Totem <Néxèz>",
		[189217] = "Frigellus",
		[184869] = "Primal Proto-Drake",
		[197400] = "Alpha Cascade Swog",
		[196634] = "Mistyvale Insurgent",
		[187426] = "Embertooth Scavenger",
		[136404] = "Bilescourge <Lúriell>",
		[192799] = "Unstable Rock <Invisible Stalker>",
		[193948] = "Mistyvale Mauler",
		[197145] = "Colossal Stormfiend",
		[187043] = "Hardened Lava <Boneshaper Jardak>",
		[198424] = "Primalist Frostsculptor",
		[190368] = "Flamecaller Aymi",
		[190496] = "Terros",
		[187819] = "Stormbound Essence",
		[189729] = "Primal Tsunami",
		[197147] = "Qalashi Honor Guard",
		[197146] = "Qalashi Emissary",
		[188067] = "Flashfrost Chillweaver",
		[196379] = "Khakad the Ancient",
		[196386] = "Quilmo the Ancient",
		[189474] = "The Scorching Forge",
		[136406] = "Shivarra <Lúriell>",
		[188707] = "Nightrot",
		[188708] = "Ceeqa the Peacetaker",
		[195101] = "Yaankhi",
		[189859] = "Cavern Lurker",
		[187173] = "Earthshatter Primalist",
		[190370] = "Squallbringer Cyraz",
		[101326] = "Honored Ancestor",
		[136407] = "Wrathguard <Lúriell>",
		[56448] = "Wise Mari",
		[186790] = "Animated Mountain",
		[197148] = "Qalashi Lavabearer",
		[186151] = "Balakar Khan",
		[187174] = "Galestrike Primalist",
		[190371] = "Primalist Earthshaker",
		[196381] = "Mellg the Ancient",
		[136408] = "Darkhound <Eliola-Azshara>",
		[197403] = "Alpha Sleepless Fickleshell",
		[135002] = "Demonic Tyrant <Lúriell>",
		[197149] = "Qalashi Lavamancer",
		[187175] = "Galestrike Primalist",
		[196382] = "Thornmu the Ancient",
		[199028] = "Glacias",
		[193882] = "Elusive Feral Bakar",
		[197535] = "High Channeler Ryvati",
		[188710] = "Sherath",
		[196123] = "Tarasek Warrior",
		[191524] = "Qalashi Ironskin",
		[197278] = "Thunderstorm",
		[190245] = "Broodkeeper Diurna",
		[190373] = "Primalist Galesinger",
		[189478] = "Forgemaster Gorek",
		[187817] = "Stormcaller Initiate",
		[192803] = "War Ohuna",
		[193442] = "Stonewrecker Tokara",
		[194082] = "Elusive Storm Lizard",
		[174773] = "Spiteful Shade",
		[190630] = "Lava Tentacles <Magmatusk>",
		[193443] = "Molka The Grinder",
		[188711] = "Taresh",
		[191653] = "Coastal Salamanther",
		[105481] = "Oll'ison",
		[198047] = "Tempest Channeler",
		[193311] = "Melkhop",
		[197406] = "Aggravated Skitterfly",
		[196385] = "Grod the Ancient",
		[187687] = "Agitated Seedling",
		[193558] = "Primalist Flamecaller",
		[191654] = "Rimebound Controller",
		[76518] = "Ritual of Bones",
		[189988] = "Thing From Beyond",
		[63508] = "Xuen <Shoulao>",
		[194212] = "Unleashed Rubble",
		[195363] = "Skulking Scythid",
		[187813] = "Qalashi Wallcrasher",
		[196642] = "Hungry Lasher",
		[197793] = "Awakened Juggernaut",
		[195875] = "Desecrated Bakar",
		[192934] = "Volatile Infuser <Dathea, Ascended>",
		[192800] = "Nokhud Lancemaster",
		[187172] = "Rumbling Primalist",
		[186917] = "Turbulent Gust",
		[190377] = "Primalist Icecaller",
		[61245] = "Capacitor Totem <Natzh>",
		[185508] = "Claw Fighter",
		[194853] = "Mirror Image",
		[193958] = "Nokhud Galebringer",
		[95061] = "Greater Fire Elemental <Shjaman>",
		[188715] = "Huntmaster Amaa",
		[189227] = "Qalashi Hunter",
		[189727] = "Khajin the Unyielding",
		[197671] = "Volatile Infuser <Dathea, Ascended>",
		[192680] = "Guardian Sentry",
		[195877] = "Risen Mystic",
		[197799] = "Quarry Infuser",
		[185903] = "Ravenous Rockfang",
		[195984] = "Auburntusk Bull",
		[195366] = "Swiftfoot Tallstrider",
		[59547] = "Jiang",
		[196645] = "Desecrated Bakar",
		[136399] = "Vicious Hellhound <Lúriell>",
		[195878] = "Ukhel Beastcaller",
		[97087] = "Valarjar Champion",
		[189722] = "Gulping Goliath",
		[107073] = "Duskwatch Reinforcement <Duskwatch Sentry>",
		[189229] = "Hailbringer Theurgist",
		[111622] = "Arcane Chronomaton",
		[195175] = "Djaradin Warrior",
		[194068] = "Humid Drizzle",
		[165189] = "Direhorn",
		[189869] = "Primalist Infiltrator",
		[194089] = "Wild Proto-Dragon",
		[103822] = "Treant",
		[189230] = "Earthshaker Theurgist",
		[188696] = "Tormented Steam",
		[190509] = "Ley-Line Sprout",
		[195752] = "Rimetalon Brawler",
		[416] = "Volkol",
		[189719] = "Watcher Irideus",
		[104270] = "Guardian Construct",
		[199333] = "Frostbreath Arachnid",
		[189231] = "Earthshaker Marauder",
		[186626] = "Bound Flame",
		[1863] = "Angxia",
		[195753] = "Bloodcrazed Warhound",
		[1860] = "Makthak",
		[59552] = "The Crybaby Hozen",
		[185907] = "Sirena the Fangbreaker",
		[185589] = "Worldbreaker Brute",
		[189232] = "Kokia Blazehoof",
		[193413] = "Thunderstorm",
		[47649] = "Efflorescence <Asuril>",
		[94960] = "Hymdall",
		[187155] = "Rune Seal Keeper",
		[192941] = "Thunderspine Rumbler",
		[199207] = "Crust Gorger",
		[195243] = "Awakened Crag <Basrikron>",
		[187187] = "Blacktalon Avenger",
		[77006] = "Corpse Skitterling",
		[197673] = "Ocean's Motion",
		[193709] = "Primalist Earthwarden",
		[190340] = "Refti Defender",
		[198266] = "Pouncing Broodswarmer",
		[195842] = "Ukhel Corruptor",
		[191328] = "Ensnaring Current",
		[189234] = "Frostbreath Arachnid",
		[197509] = "Primal Thundercloud",
		[95832] = "Valarjar Shieldmaiden",
		[190604] = "Rockguard Warmonger",
		[187279] = "Brinetooth Spawnwatcher",
		[198058] = "Localized Storm",
		[77700] = "Shadowmoon Exhumer",
		[83385] = "Voidseer Kalurg",
		[187189] = "Blacktalon Assassin",
		[187767] = "Embar Firepath",
		[187445] = "Embertooth Pooltender",
		[192386] = "Skulking Scythid",
		[186678] = "Chief Grrlgllmesh",
		[194990] = "Stormseeker Acolyte",
		[192961] = "Ayanga",
		[96664] = "Valarjar Runecarver",
		[100820] = "Spirit Wolf",
		[188341] = "Nokhud Warmonger",
		[189492] = "Raszageth",
		[185528] = "Trickclaw Mystic",
		[193840] = "Nokhud Raider",
		[194991] = "Oathsworn Vanguard",
		[104273] = "Jazshariu",
		[195247] = "Parched Shortcoat Bear",
		[199031] = "Raszageth",
		[193457] = "Balara",
		[194816] = "Forgewrought Monstrosity",
		[185529] = "Bracken Warscourge",
		[61056] = "Primal Earth Elemental",
		[192946] = "Thicket Scalebiter",
		[196856] = "Primal Stormsentry",
		[195248] = "Parched Shortcoat Mauler",
		[187599] = "Qalashi Bonebreakers",
		[188343] = "Primalist Stormsurger",
		[95834] = "Valarjar Mystic",
		[188172] = "Arcane Manipulator",
		[192582] = "Dragonbane Soldier",
		[193970] = "Mistyvale Mauler",
		[104274] = "Baalgar the Watchful",
		[196272] = "Lost Armoredon",
		[195138] = "Detonating Crystal",
		[191051] = "Nimblewing Slyvern",
		[198702] = "Unstable Frost",
		[199802] = "Cragsworn Striker",
		[191222] = "Juvenile Frost Proto-Dragon",
		[195012] = "Raging Ice Burrower",
		[190983] = "Qalashi Pillager",
		[188089] = "Swift Hornstrider",
		[196601] = "Incendiary Goo",
		[197185] = "Primalist Recruiter",
		[189265] = "Qalashi Bonetender",
		[76462] = "Omen of Death <Ner'zhul>",
		[185660] = "Cygenoth",
		[193376] = "Scythid Hunter",
		[104275] = "Imacu'tya",
		[197697] = "Flamegullet",
		[62982] = "Mindbender <Phunk>",
		[101398] = "Psyfiend <Phunk>",
		[197698] = "Thunderhead",
		[192694] = "Custodial Protector",
		[190776] = "Arcane Commander",
		[169421] = "Felguard",
		[201148] = "Cragsworn Reaver",
		[197298] = "Nascent Proto-Dragon",
		[188372] = "Primal Tarasek",
		[193462] = "Batak",
		[2630] = "Earthbind Totem <Sonuf>",
		[185534] = "Bonebolt Hunter",
		[105754] = "Image of Advisor Melandrus",
		[189780] = "Giant Ottuk Agitator",
		[31216] = "Mirror Image <Irugá>",
		[181861] = "Magmatusk",
		[189243] = "Alora Mistbreeze",
		[193232] = "Rasnar the War Ender",
		[193896] = "Borzgas",
		[192696] = "Tyrhold Watcher",
		[193847] = "Chalsec of the Earth",
		[59555] = "Haunting Sha",
		[200388] = "Malformed Sha <[*] Summon Sha>",
		[110063] = "Beast <Sinha>",
		[200126] = "Fallen Waterspeaker",
		[187487] = "Spotted Prowler",
		[195638] = "Polymorphed",
		[186594] = "Dragonbane Protector",
		[190779] = "Arcane Golem",
		[194999] = "Volatile Spark",
		[104277] = "Legion Hound",
		[186735] = "Inferna the Bound",
		[195383] = "Swiftfoot Tallstrider",
		[197557] = "Bisquius",
		[187623] = "Surging Torrent",
		[194254] = "Ohuna Companion",
		[190780] = "Arcane Elemental",
		[169425] = "Felhound",
		[187967] = "Sennarth",
		[191164] = "Arcane Tender",
		[189246] = "Karthis Sleetsong",
		[186110] = "Djaradin Crustshaper",
		[198709] = "Unstable Earth",
		[192699] = "Forge-Keep Overseer",
		[75506] = "Shadowmoon Loyalist",
		[192955] = "Draconic Illusion",
		[104278] = "Felbound Enforcer",
		[196280] = "Unstable Tear <Ghenos>",
		[189247] = "Tamed Phoenix",
		[186620] = "Lava Crawler",
		[193595] = "Pinehoof Bull",
		[192700] = "Forge-Keep Sentinel",
		[186690] = "Mudfin Mudrunner",
		[194291] = "Primal Stonekin",
		[197176] = "Unruly Goat",
		[195258] = "Frantic Wildwater Ottuk",
		[104918] = "Vigilant Duskwatch",
		[197976] = "Runestone Detonation",
		[194912] = "Magmammoth Breaker",
		[186607] = "Dragonbane Soldier",
		[190325] = "Barkback Yeti",
		[187842] = "Nokhud Goliath",
		[95072] = "Greater Earth Elemental",
		[187075] = "Enraged Shards",
		[188226] = "Melter Igneous",
		[186616] = "Granyth",
		[169426] = "Infernal",
		[192702] = "Menial Attendant",
		[78135] = "Shadowmoon Channeller",
		[187843] = "Stormbound Colossus",
		[195132] = "Tevgai",
		[193214] = "Forgotten Creation",
		[191083] = "Spider Eggs",
		[190401] = "Gusting Proto-Dragon",
		[189811] = "Agitated Keystone",
		[192703] = "Forge-Keep Custodian",
		[193854] = "Elusive Salamanther",
		[169430] = "Ur'zul",
		[193391] = "Towering Fickleshells",
		[199353] = "Frost Tomb",
		[193385] = "Broadhoof Bull",
		[198878] = "Primalist Tempestmaker",
		[194622] = "Scorchling",
		[186206] = "Cruel Bonecrusher",
		[197219] = "Vile Lasher",
		[186822] = "Infused Ruby Whelpling",
		[96608] = "Ebonclaw Worg",
		[191841] = "Primalist Infiltrator",
		[197436] = "Shadehide Forager",
		[190403] = "Glacial Proto-Dragon",
		[186109] = "Qalashi Necksnapper",
		[191682] = "Sulfuric Rager",
		[75509] = "Sadana Bloodfury",
		[186823] = "Lavacaller Primalist",
		[194673] = "Sprightly Hornstrider",
		[187079] = "Convoked Tremor",
		[95676] = "Odyn",
	},
	["death_recap"] = {
		["enabled"] = true,
		["show_segments"] = false,
		["show_life_percent"] = false,
		["relevance_time"] = 7,
	},
	["spell_pool"] = {
		12, -- [1]
		3, -- [2]
		"Environment (Falling)", -- [3]
		[61447] = 10,
		[53385] = 2,
		[321442] = 12,
		[376725] = "Nokhud Stormcaster",
		[7268] = 8,
		[188395] = "[*] Ball Lightning",
		[321444] = 12,
		[376727] = "Balakar Khan",
		[394131] = 4,
		[199658] = 1,
		[376730] = "[*] Stormwinds",
		[125439] = 1,
		[389016] = 12,
		[264119] = 9,
		[376732] = "[*] Stormwinds",
		[265144] = 5,
		[190446] = 8,
		[351140] = 8,
		[385948] = 4,
		[389020] = 3,
		[385949] = 4,
		[378783] = "Broodkeeper Diurna",
		[200685] = 12,
		[94472] = 5,
		[378784] = "Broodkeeper Diurna",
		[51723] = 4,
		[304051] = 3,
		[200174] = 5,
		[209388] = 2,
		[374691] = "Kurog Grimtotem",
		[24394] = "Jochen <Lightør-Blackhand>",
		[378787] = "Broodkeeper Diurna",
		[375716] = "Primalist Mage",
		[385954] = 1,
		[107270] = 10,
		[153595] = 8,
		[57994] = 7,
		[527] = 5,
		[264130] = 9,
		[2139] = 8,
		[153596] = 8,
		[381862] = "Kyrakka",
		[8680] = 4,
		[188404] = "Storm Drake",
		[385958] = "Vexamus <Magic Book>",
		[395172] = 11,
		[381864] = "Kyrakka",
		[30153] = "Dag'arad <Kêrberøs-Arygos>",
		[262115] = 1,
		[385960] = 4,
		[382889] = 7,
		[388008] = "Telash Greywing",
		[324536] = 9,
		[199667] = 1,
		[388009] = 2,
		[389033] = "Hungry Lasher",
		[388010] = 2,
		[585] = 5,
		[373678] = "Kurog Grimtotem",
		[589] = 5,
		[396201] = "[*] Blistering Presence",
		[9512] = 4,
		[388012] = 2,
		[373680] = "Melidrussa Chillworn",
		[224239] = 2,
		[388013] = 2,
		[373681] = "Kurog Grimtotem",
		[374705] = "Earth Breaker",
		[153089] = "Sadana Bloodfury",
		[190456] = 1,
		[374706] = "Flamecaller Aymi",
		[287688] = 3,
		[383921] = 2,
		[389040] = "Thondrozus",
		[207349] = 6,
		[200183] = 5,
		[178173] = 10,
		[5221] = 11,
		[388019] = 2,
		[267217] = 9,
		[197625] = 11,
		[383925] = "Melidrussa Chillworn",
		[267218] = 9,
		[391092] = 5,
		[383926] = 6,
		[385974] = "Professor Maxdormu",
		[197626] = 11,
		[396212] = "[*] Chilling Presence",
		[199674] = "King Bjorn",
		[383928] = "Overseer Lahar",
		[691] = 9,
		[153094] = "Sadana Bloodfury",
		[697] = 9,
		[373692] = "Blazebound Destroyer",
		[49039] = 6,
		[114954] = 8,
		[197628] = 11,
		[218615] = 9,
		[373694] = "[*] Living Bomb",
		[322507] = 10,
		[344006] = 10,
		[193534] = 3,
		[384957] = "Verdant Dreambreaker <Muffinform-TarrenMill>",
		[385981] = "[*] Arcane Orb",
		[374720] = "Leymor",
		[218617] = 1,
		[47632] = 6,
		[394173] = 1,
		[395197] = 7,
		[155145] = 2,
		[389055] = "Arcane Forager",
		[378818] = "Qalashi Thaumaturge",
		[396222] = "[*] Shattering Presence",
		[373700] = "Deaadevo-Ragnaros",
		[374724] = "Flamecaller Aymi",
		[392128] = 3,
		[196608] = 10,
		[383939] = 8,
		[781] = 3,
		[388035] = "ЛокеНахак <Шадовхант-Ясеневыйлес>",
		[389059] = "Chargath, Bane of Scales",
		[193538] = 4,
		[383941] = 2,
		[384965] = 2,
		[265187] = 9,
		[263140] = 3,
		[391109] = 5,
		[47633] = 6,
		[196099] = 9,
		[372683] = "Infused Whelp",
		[30283] = 9,
		[374731] = "Leymor",
		[307164] = 6,
		[158221] = 10,
		[378827] = "Qalashi Plunderer",
		[196100] = 9,
		[102417] = 11,
		[350163] = "Spiteful Shade",
		[3355] = 3,
		[376781] = "Goal of the Searing Blaze",
		[211457] = "Talixae Flamewreath",
		[378829] = "Raszageth",
		[200196] = 5,
		[6789] = 9,
		[209410] = "Duskwatch Arcanist",
		[374735] = "Flamecaller Aymi",
		[376783] = "Warlord Sargha",
		[378831] = "Qalashi Plunderer",
		[388045] = 3,
		[319454] = 11,
		[871] = 1,
		[190984] = 11,
		[391118] = "Scalebane Lieutenant",
		[48018] = 9,
		[883] = 3,
		[391120] = "Scalebane Lieutenant",
		[384978] = "Umbrelskul",
		[209413] = "Guardian Construct",
		[374741] = "Flamecaller Aymi",
		[16591] = 8,
		[321507] = 8,
		[200200] = 5,
		[221699] = 6,
		[370648] = "Eranog",
		[265202] = 5,
		[372696] = "Primal Juggernaut",
		[394195] = 8,
		[228354] = 8,
		[388053] = 12,
		[372697] = "Primal Juggernaut",
		[270323] = 3,
		[383960] = 12,
		[323559] = 4,
		[370652] = 2,
		[392151] = "Teera",
		[323560] = 4,
		[211464] = "Felbound Enforcer",
		[207881] = "Talixae Flamewreath",
		[26573] = 2,
		[343013] = 12,
		[153623] = "Nhallish",
		[398296] = "Shambling Infester",
		[391130] = "High Channeler Ryvati",
		[386012] = "Primalist Stormspeaker",
		[72221] = 5,
		[270329] = 3,
		[228358] = 8,
		[307185] = 5,
		[31884] = 2,
		[199182] = "Ebonclaw Worg",
		[378849] = 6,
		[204301] = 2,
		[270332] = 3,
		[386016] = "Teera",
		[153626] = 8,
		[391136] = "Drakonid Breaker",
		[392160] = 11,
		[373733] = "Chargath, Bane of Scales",
		[270335] = 3,
		[224266] = 2,
		[192018] = "Hyrja",
		[373735] = "Chargath, Bane of Scales",
		[388068] = 9,
		[307192] = 11,
		[211470] = "Shadow Mistress",
		[391140] = 11,
		[392164] = 12,
		[270338] = 3,
		[386022] = "Primalist Stormspeaker",
		[370666] = "Morrizane",
		[392165] = 12,
		[270339] = 3,
		[353263] = 1,
		[191508] = "Valarjar Aspirant",
		[392166] = "[*] Azure Stone of Might",
		[1122] = 9,
		[386024] = "Primalist Stormspeaker",
		[391143] = "Drakonid Breaker",
		[363502] = "Morrizane",
		[231435] = 2,
		[394215] = 9,
		[203794] = 12,
		[383978] = 1,
		[401382] = "Past Self <Drakares-GrimBatol>",
		[381931] = 7,
		[321530] = 3,
		[392169] = 11,
		[270343] = 3,
		[373742] = "Chargath, Bane of Scales",
		[395241] = "Primalist Voltweaver",
		[400360] = 11,
		[290819] = 3,
		[386028] = "Primalist Thunderbeast",
		[382957] = 2,
		[117526] = 3,
		[118038] = 1,
		[395243] = "Ruby Skyscorcher <Acumena>",
		[375792] = "Thundering Ravager",
		[31821] = 2,
		[395244] = "Verdant Dreambreaker <Muffinform-TarrenMill>",
		[235021] = 4,
		[395245] = "Verdant Dreambreaker <Muffinform-TarrenMill>",
		[213011] = 12,
		[388081] = 4,
		[254474] = 2,
		[382963] = 2,
		[16593] = 8,
		[262161] = 1,
		[256522] = 4,
		[388083] = 4,
		[188443] = 7,
		[388084] = "Telash Greywing",
		[386037] = "[*] Gale Arrow",
		[391156] = 5,
		[383991] = 2,
		[372730] = "Primal Juggernaut",
		[361469] = "Morrizane",
		[374778] = "Vault Guard",
		[350209] = "[*] Spiteful Fixation",
		[376827] = "Balakar Khan",
		[390137] = 12,
		[376829] = "Balakar Khan",
		[207386] = 11,
		[387067] = "Arcane Construct",
		[375806] = 8,
		[372735] = "Flashfrost Earthshaper",
		[383997] = 8,
		[356356] = 1,
		[1462] = 3,
		[395259] = "Primalist Tempestmaker",
		[376832] = "Akisu",
		[398331] = "Volatile Infuser <Dathea, Ascended>",
		[351239] = "Hyraie-Hyjal",
		[1490] = 12,
		[373762] = "Chargath, Bane of Scales",
		[257040] = 4,
		[319504] = 4,
		[381954] = 8,
		[73510] = 5,
		[390145] = 12,
		[387074] = 4,
		[381956] = 8,
		[195617] = 6,
		[6262] = 9,
		[372743] = "Flashfrost Chillweaver",
		[152108] = 9,
		[391171] = 12,
		[194594] = 3,
		[381958] = "Raszageth",
		[391172] = 12,
		[392196] = "Raszageth",
		[157228] = 11,
		[257044] = 3,
		[48153] = 5,
		[164907] = "Reanimated Ritual Bones",
		[363534] = "Morrizane",
		[186406] = 12,
		[387081] = 4,
		[386088] = "[*] Arcane Orb",
		[287712] = 11,
		[156718] = "Monstrous Corpse Spider",
		[394875] = "The Raging Tempest",
		[390192] = 12,
		[160537] = "[*] Ritual of Bones",
		[395273] = "Primal Stormsentry",
		[152688] = "[*] Shadow Rune",
		[385036] = "Primalist Galesinger",
		[381965] = 4,
		[1706] = 5,
		[351338] = "Morrizane",
		[1714] = 9,
		[381966] = 4,
		[207907] = "Talixae Flamewreath",
		[375824] = "Tectonic Crusher",
		[225311] = 2,
		[106785] = 11,
		[152690] = "[*] Shadow Rune",
		[384015] = "Watcher Irideus",
		[108920] = 5,
		[386063] = "Maruuk",
		[395277] = 8,
		[41252] = 4,
		[184362] = 1,
		[1766] = 4,
		[307194] = 5,
		[375827] = 6,
		[376851] = "Dathea, Ascended",
		[102352] = 11,
		[291635] = 8,
		[375828] = "Blazing Fiend",
		[385042] = 1,
		[193065] = 5,
		[214052] = 9,
		[384019] = "Chargath, Bane of Scales",
		[291057] = 12,
		[370615] = "Eranog",
		[291009] = 3,
		[1822] = 11,
		[184364] = 1,
		[16979] = 11,
		[272432] = "Wrathguard <Kêrberøs-Arygos>",
		[399053] = "Surging Ruiner",
		[372760] = 5,
		[394259] = 3,
		[1850] = 11,
		[375829] = "Broodkeeper Diurna",
		[1459] = 8,
		[390165] = 4,
		[342049] = 3,
		[373652] = "Grounding Spear <Chargath, Bane of Scales>",
		[375033] = 4,
		[377881] = "Raszageth",
		[272435] = "Darkhound <Kêrberøs-Arygos>",
		[375834] = "Broodkeeper Diurna",
		[375825] = "Frozen Destroyer",
		[391055] = "Kurog Grimtotem",
		[387096] = 9,
		[388065] = "Vault Rune",
		[381955] = 8,
		[191976] = "Solsten",
		[374812] = "Forgemaster Gorek",
		[61336] = 11,
		[184367] = 1,
		[386959] = 10,
		[384209] = 11,
		[228360] = 5,
		[382155] = 4,
		[390170] = 11,
		[272439] = "Ur'zul <Kêrberøs-Arygos>",
		[265273] = 9,
		[376791] = "Treasure Pile",
		[373688] = "Melidrussa Chillworn",
		[132157] = 5,
		[1966] = 4,
		[397338] = "Tectonic Crusher",
		[153093] = "Sadana Bloodfury",
		[195630] = 10,
		[2580] = 2,
		[376864] = "Balakar Khan",
		[59545] = 6,
		[132158] = 11,
		[7] = "Environment (Lava)",
		[376865] = "Balakar Khan",
		[361509] = "Morrizane",
		[199726] = "King Tor",
		[396317] = "Loamas",
		[397341] = "Kurog Grimtotem",
		[50334] = 11,
		[185394] = 4,
		[375843] = "Broodkeeper Diurna",
		[384186] = "The Raging Tempest",
		[386081] = 4,
		[57755] = 1,
		[373817] = "Frostbreath Arachnid",
		[192044] = "Hyrja",
		[2060] = 5,
		[376788] = "Morrizane",
		[373693] = "Blazebound Destroyer",
		[385059] = 1,
		[83244] = 3,
		[199652] = "King Haldor",
		[375846] = 4,
		[385060] = 1,
		[35395] = 2,
		[374823] = "Squallbringer Cyraz",
		[396322] = 2,
		[352301] = 12,
		[207407] = 12,
		[385953] = 1,
		[17364] = 7,
		[385062] = 1,
		[390181] = 12,
		[383883] = 8,
		[257541] = 8,
		[385063] = "Primalist Cinderweaver",
		[83245] = 3,
		[387079] = 9,
		[102401] = 11,
		[383882] = 8,
		[373803] = "Infused Whelp",
		[382858] = 2,
		[396326] = "Glacias",
		[385065] = "Raszageth",
		[382106] = 8,
		[114214] = 5,
		[396327] = "Glacias",
		[192565] = "Valarjar Purifier",
		[383026] = 6,
		[153070] = "Nhallish",
		[243241] = 5,
		[115750] = 2,
		[195125] = 11,
		[6343] = 1,
		[396329] = "Glacias",
		[385068] = "Colossal Stormfiend",
		[62618] = 5,
		[382097] = 1,
		[269576] = 3,
		[397354] = "Professor Ichistrasz",
		[108287] = 7,
		[387143] = 9,
		[224375] = "Infernal Imp <Talixae Flamewreath>",
		[344120] = 3,
		[311193] = 1,
		[51485] = 7,
		[111400] = 9,
		[397356] = "Professor Mystakria",
		[124974] = 11,
		[2484] = 7,
		[376974] = 6,
		[372787] = 5,
		[376737] = "[*] Lightning",
		[10060] = 5,
		[24275] = 2,
		[397358] = "Kurog Grimtotem",
		[382002] = "Apex Blazewing",
		[342076] = 3,
		[396335] = "Glacias",
		[374779] = "Kurog Grimtotem",
		[5143] = 8,
		[132168] = 1,
		[210042] = 12,
		[385075] = "Umbrelskul",
		[191034] = 11,
		[10444] = 7,
		[192058] = 7,
		[372791] = 5,
		[382005] = "Apex Blazewing",
		[218164] = 10,
		[375863] = 6,
		[384139] = "Blazebound Destroyer",
		[105771] = 1,
		[387125] = "Primalist Thunderbeast",
		[387975] = "Spectral Invoker",
		[397363] = "[*] Revitalization",
		[390197] = 12,
		[372616] = 5,
		[212552] = 6,
		[397364] = 1,
		[398388] = 3,
		[374842] = "Forgemaster Gorek",
		[375842] = "Broodkeeper Diurna",
		[203796] = 12,
		[20572] = 1,
		[371591] = "Kadros Icewrath",
		[108853] = 8,
		[372796] = "Defier Draghar",
		[394295] = "Primalist Gateway",
		[263165] = 5,
		[372794] = "Defier Draghar",
		[262232] = 1,
		[135299] = 3,
		[246852] = 3,
		[395382] = "Thondrozus",
		[153232] = "[*] Daggerfall",
		[2908] = 11,
		[120361] = 3,
		[375870] = "Broodkeeper Diurna",
		[8936] = 11,
		[394298] = 3,
		[387132] = "Dragonkiller Lance",
		[326731] = 2,
		[331850] = 4,
		[231895] = 2,
		[387133] = "Dragonkiller Lance",
		[384062] = 12,
		[2948] = 8,
		[106797] = "Liu Flameheart",
		[107053] = "Dragon Wave",
		[326733] = 2,
		[375891] = 3,
		[116011] = 8,
		[387135] = "Primalist Arcblade",
		[56222] = 6,
		[383873] = 1,
		[32390] = 9,
		[393306] = "Primalist Earthwarden",
		[194112] = "God-King Skovald",
		[376899] = "[*] Crackling Cloud",
		[387263] = 9,
		[110125] = "Minion of Doubt",
		[228920] = 1,
		[155722] = 11,
		[396157] = 6,
		[387069] = 1,
		[367687] = 2,
		[397376] = 11,
		[386251] = 9,
		[391234] = 12,
		[396489] = "Loamas",
		[194679] = 6,
		[185313] = 4,
		[172] = 9,
		[153164] = "Defiled Spirit",
		[290908] = 11,
		[191043] = 3,
		[118522] = 7,
		[192067] = "Hyrja",
		[225788] = 12,
		[160331] = 6,
		[384029] = 2,
		[213634] = 5,
		[395367] = "Thondrozus",
		[198745] = "Stormforged Sentinel",
		[212031] = "Bound Energy",
		[85288] = 1,
		[372811] = "Kokia Blazehoof",
		[373835] = "Morrizane",
		[370764] = "Crystal Fury",
		[375883] = "Broodkeeper Diurna",
		[376907] = 6,
		[312411] = 3,
		[387145] = "Stormcaller Boroo",
		[334934] = 1,
		[378987] = 11,
		[119085] = 10,
		[387146] = "Stormsurge Totem",
		[316643] = 1,
		[219199] = 3,
		[382028] = 7,
		[211477] = "Legion Hound",
		[400456] = 3,
		[80353] = 8,
		[6807] = 11,
		[391243] = 5,
		[374863] = "Squallbringer Cyraz",
		[153680] = "Bonemaw",
		[211522] = 5,
		[391244] = 5,
		[370794] = 2,
		[155166] = 6,
		[382043] = 7,
		[387150] = "Telash Greywing",
		[374789] = "Leymor",
		[396151] = "Strife",
		[122708] = 8,
		[387151] = "Telash Greywing",
		[392270] = 3,
		[153686] = "Bonemaw",
		[209033] = "Duskwatch Guard",
		[387152] = "Telash Greywing",
		[392271] = 3,
		[372820] = "Kokia Blazehoof",
		[291944] = 3,
		[370773] = 2,
		[270481] = "Demonic Tyrant <Kêrberøs-Arygos>",
		[387158] = 9,
		[209477] = "Mana Wyrm",
		[387154] = 9,
		[255546] = 4,
		[107570] = 1,
		[373846] = 12,
		[387155] = "Granyth",
		[384084] = 12,
		[393298] = "Smoldering Colossus",
		[229976] = 2,
		[345230] = 8,
		[392275] = 3,
		[377995] = "Forgemaster Gorek",
		[48792] = 6,
		[387157] = 9,
		[55095] = 6,
		[375890] = "Magmatusk",
		[394324] = 4,
		[51490] = 7,
		[386124] = 9,
		[315496] = 4,
		[394325] = 4,
		[392147] = 11,
		[384088] = 7,
		[393302] = "Smoldering Colossus",
		[205385] = 5,
		[185422] = 4,
		[388323] = 12,
		[340068] = "Drakares-GrimBatol",
		[390232] = 3,
		[387161] = 9,
		[384090] = 1,
		[397399] = 11,
		[394328] = 4,
		[383067] = "Balara",
		[396376] = "Ukhel Deathspeaker",
		[397400] = 6,
		[390234] = 12,
		[198715] = "Val'kyr Battlemaiden <Alamo-Doomhammer>",
		[375902] = 5,
		[397401] = 6,
		[386933] = 12,
		[378974] = 2,
		[113942] = 9,
		[393307] = "Primalist Flamecaller",
		[199248] = "Valarjar Marksman",
		[224327] = "Advisor Melandrus",
		[375904] = 5,
		[393308] = "Primalist Flamecaller",
		[394258] = 12,
		[374861] = "Kurog Grimtotem",
		[375905] = 5,
		[372834] = 6,
		[48181] = 9,
		[390178] = 6,
		[156722] = "Shadowmoon Exhumer",
		[397405] = 11,
		[390239] = 10,
		[246851] = 3,
		[362361] = "Morrizane",
		[394301] = "Primalist Gateway",
		[199247] = "Valarjar Marksman",
		[114738] = 7,
		[388193] = 10,
		[376932] = 4,
		[373861] = "Morrizane",
		[374885] = "Astral Attendant",
		[384099] = 12,
		[315508] = 4,
		[373862] = "Morrizane",
		[385061] = 1,
		[192082] = 7,
		[188499] = 12,
		[221771] = 10,
		[246853] = 3,
		[115192] = 4,
		[153692] = "[*] Necrotic Pitch",
		[223819] = 2,
		[120644] = 5,
		[17] = 5,
		[385126] = 2,
		[8004] = 7,
		[387174] = 2,
		[396388] = "Glacias",
		[385127] = 2,
		[382056] = 11,
		[395303] = "Thunderhead",
		[199851] = 1,
		[207317] = 6,
		[390247] = 12,
		[113656] = 10,
		[198103] = 7,
		[344179] = 7,
		[382058] = 11,
		[224333] = "[*] Enveloping Winds",
		[396391] = 2,
		[290945] = 4,
		[361584] = 1,
		[387178] = 2,
		[378003] = "Guardian Sentry",
		[206930] = 6,
		[399502] = 10,
		[378989] = 11,
		[388203] = 10,
		[204883] = 5,
		[378847] = "Qalashi Spinecrusher",
		[378990] = 11,
		[396394] = "Glacias",
		[376943] = "Dathea, Ascended",
		[387127] = "Primalist Thunderbeast",
		[378991] = 11,
		[384110] = 1,
		[138213] = 4,
		[47750] = 5,
		[378992] = 11,
		[199210] = "Valarjar Marksman",
		[115767] = 1,
		[386159] = 3,
		[396233] = "[*] Thundering Presence",
		[388207] = 10,
		[372851] = "Melidrussa Chillworn",
		[374641] = "Forgemaster Gorek",
		[387184] = 10,
		[392303] = 11,
		[378011] = "Guardian Sentry",
		[373876] = 12,
		[280715] = 1,
		[396399] = "Glacias",
		[185438] = 4,
		[192109] = 7,
		[350219] = 3,
		[5176] = 11,
		[111673] = 6,
		[152696] = "[*] Shadow Rune",
		[395377] = "Thondrozus",
		[192090] = 11,
		[334713] = "Darkhound <Kêrberøs-Arygos>",
		[197209] = 7,
		[197721] = 11,
		[384117] = 12,
		[385141] = "Primalist Galesinger",
		[384050] = 8,
		[280719] = 4,
		[378015] = 3,
		[5384] = 3,
		[209495] = "Guardian Construct",
		[280720] = 4,
		[375929] = "Balakar Khan",
		[372858] = "Kokia Blazehoof",
		[173184] = 7,
		[389277] = 9,
		[375893] = 3,
		[372859] = "Kokia Blazehoof",
		[373614] = "Blazebound Destroyer",
		[333957] = 7,
		[371836] = "Kadros Icewrath",
		[372860] = "Kokia Blazehoof",
		[376061] = 2,
		[212056] = 2,
		[236645] = 8,
		[397431] = "Volatile Infuser <Dathea, Ascended>",
		[371875] = "Qalashi Trainee",
		[5672] = "Healing Stream Totem <Capten-Frostwolf>",
		[343173] = 4,
		[387113] = 2,
		[211545] = 11,
		[199772] = "Valarjar Champion",
		[392314] = "Kaurdyth",
		[372863] = "Kokia Blazehoof",
		[2643] = 3,
		[370816] = 4,
		[321538] = "Lobo <Wolfankiller-Sanguino>",
		[344121] = 3,
		[324748] = 10,
		[55078] = 6,
		[396411] = "Raszageth",
		[376896] = "Balakar Khan",
		[197214] = 7,
		[156776] = "Shadowmoon Dominator",
		[375937] = "Balakar Khan",
		[381185] = 12,
		[382080] = 5,
		[383104] = 1,
		[393303] = "Smoldering Colossus",
		[374635] = "Forgemaster Gorek",
		[394366] = 3,
		[246867] = 2,
		[44457] = 8,
		[398301] = "Shambling Infester",
		[382082] = 5,
		[30213] = "Dag'arad <Kêrberøs-Arygos>",
		[384130] = 1,
		[376866] = "Balakar Khan",
		[382083] = 1,
		[370766] = "Crystal Thrasher",
		[49576] = 6,
		[41514] = 5,
		[279709] = 11,
		[56488] = 1,
		[384132] = "Azureblade",
		[386015] = "Primalist Stormspeaker",
		[121147] = 6,
		[29893] = 9,
		[392323] = "Kaurdyth",
		[391191] = 12,
		[394371] = 3,
		[191587] = 6,
		[384134] = "Nokhud Warspear",
		[393348] = "Stalwart Broodwarden",
		[152173] = 10,
		[193635] = "Void Tendril <Gorlirn>",
		[127802] = 3,
		[390224] = 4,
		[153153] = "Sadana Bloodfury",
		[127797] = 11,
		[257620] = 3,
		[361500] = "Morrizane",
		[390279] = 6,
		[211406] = "Blazing Imp",
		[101185] = 7,
		[389293] = 11,
		[382090] = 12,
		[333974] = 7,
		[377009] = "Crawth",
		[25504] = 7,
		[152175] = 10,
		[315585] = 4,
		[392329] = 11,
		[372583] = "Qalashi Hunter",
		[384177] = 6,
		[386225] = "Primal Stormshield",
		[257622] = 3,
		[290979] = 3,
		[373977] = "Primalist Flamedancer",
		[333977] = 7,
		[342242] = 8,
		[375653] = "Drakonid Stormbringer",
		[382094] = 1,
		[382133] = 1,
		[391166] = 12,
		[34861] = 5,
		[382095] = 1,
		[164974] = "Sadana Bloodfury",
		[188370] = 2,
		[375652] = "Arcane Tender",
		[192063] = 7,
		[369509] = 12,
		[395254] = "Primalist Tempestmaker",
		[385168] = "[*] Thunderstorm",
		[390287] = 7,
		[366741] = 12,
		[15407] = 5,
		[269571] = 2,
		[373908] = 12,
		[391312] = 5,
		[372829] = 6,
		[165961] = 11,
		[115008] = 10,
		[193641] = 4,
		[194153] = 11,
		[374699] = "Flamecaller Aymi",
		[392127] = 6,
		[379029] = 8,
		[192106] = 7,
		[391359] = 5,
		[386196] = 1,
		[153561] = 8,
		[192077] = 7,
		[386910] = "Telash Greywing",
		[7384] = 1,
		[203958] = 11,
		[384150] = "Claw Fighter",
		[386026] = "Unstable Squall <Primalist Stormspeaker>",
		[394388] = 3,
		[399507] = "Primalist Thunderbeast",
		[400218] = 3,
		[257045] = 3,
		[47528] = 6,
		[395413] = 10,
		[388070] = 9,
		[124991] = 11,
		[209512] = "Guardian Construct",
		[395414] = 10,
		[116768] = 10,
		[192563] = "Valarjar Purifier",
		[386201] = "[*] Corrupted Mana",
		[370667] = 3,
		[322729] = 10,
		[344228] = 12,
		[386202] = "Vexamus <Magic Book>",
		[391321] = 5,
		[202347] = 11,
		[398300] = "Shambling Infester",
		[195181] = 6,
		[383132] = 3,
		[34477] = 3,
		[386907] = 2,
		[121153] = 4,
		[268473] = 8,
		[117570] = "Figment of Doubt",
		[384321] = "Morrizane",
		[390300] = 6,
		[207979] = "Jazshariu",
		[104773] = 9,
		[196718] = 12,
		[390301] = 9,
		[228478] = 12,
		[215572] = 1,
		[388302] = "Dathea, Ascended",
		[47788] = 5,
		[207980] = "Baalgar the Watchful",
		[32216] = 1,
		[374002] = 12,
		[209516] = "Mana Saber",
		[75] = 3,
		[384161] = "Qalashi Irontorch",
		[386257] = 12,
		[101643] = 10,
		[207981] = "Baalgar the Watchful",
		[371877] = "Morrizane",
		[132169] = 1,
		[2061] = 5,
		[86603] = "Dusk Lily Agent",
		[259516] = "Tallstriker <Huntz-Ravencrest>",
		[376997] = "Crawth",
		[33206] = 5,
		[396167] = 10,
		[371879] = "Morrizane",
		[376666] = 3,
		[207906] = "Talixae Flamewreath",
		[372808] = "Melidrussa Chillworn",
		[384165] = 8,
		[117828] = 9,
		[215661] = 2,
		[201764] = 7,
		[372570] = "Qalashi Hunter",
		[195707] = 1,
		[106823] = "Liu Flameheart",
		[390357] = 5,
		[391382] = "Volatile Infuser <Dathea, Ascended>",
		[388949] = "Frozen Shroud",
		[12975] = 1,
		[394454] = 2,
		[48045] = 5,
		[203720] = 12,
		[113746] = 10,
		[388948] = 10,
		[392359] = 5,
		[397478] = 3,
		[373932] = "Draconic Image",
		[374604] = 12,
		[392360] = 11,
		[377004] = "Crawth",
		[188046] = "Denizen of the Dream <Muffinform-TarrenMill>",
		[376780] = "Warlord Sargha",
		[375981] = 5,
		[342246] = 8,
		[783] = 11,
		[342247] = 8,
		[375982] = 7,
		[217200] = 3,
		[156287] = 1,
		[57984] = "Greater Fire Elemental <Capten-Frostwolf>",
		[372566] = "Qalashi Hunter",
		[389292] = 11,
		[382126] = 8,
		[391282] = "Colossal Stormfiend",
		[375984] = 7,
		[377008] = "Crawth",
		[394412] = 11,
		[280776] = 1,
		[247402] = "Hyraie-Hyjal",
		[315584] = 4,
		[386223] = "Primal Stormshield",
		[201671] = 11,
		[392366] = "Awakened Juggernaut",
		[155777] = 11,
		[394414] = 11,
		[32409] = "[*] Shadow Word: Death",
		[198263] = "Odyn",
		[201754] = "Jochen <Lightør-Blackhand>",
		[382130] = 11,
		[212084] = 12,
		[396463] = "Magmas",
		[2565] = 1,
		[382131] = 11,
		[395440] = 11,
		[202359] = 11,
		[206966] = 12,
		[171982] = 9,
		[47540] = 5,
		[396072] = "Kurog Grimtotem",
		[371624] = "Dathea Stormlash",
		[386228] = "Primal Stormshield",
		[2645] = 7,
		[397134] = "Opalfang",
		[206967] = 6,
		[59052] = 6,
		[374968] = "Morrizane",
		[396467] = "Loamas",
		[29722] = 9,
		[382135] = 4,
		[374969] = "Forgemaster Gorek",
		[78674] = 11,
		[377017] = "Warlord Sargha",
		[307160] = 3,
		[395445] = 11,
		[264178] = 9,
		[377018] = "Warlord Sargha",
		[381777] = 7,
		[193660] = "God-King Skovald",
		[392375] = 7,
		[393038] = 2,
		[400204] = 11,
		[376778] = 12,
		[392376] = 5,
		[264173] = 9,
		[382139] = 10,
		[274282] = 11,
		[78675] = 11,
		[22812] = 11,
		[62124] = 2,
		[224374] = "Infernal Imp <Talixae Flamewreath>",
		[400568] = 12,
		[396204] = 1,
		[394426] = "Council Flamecaller",
		[387260] = 9,
		[153224] = "Daggerfall",
		[203795] = 12,
		[386237] = 4,
		[391356] = 11,
		[320976] = 3,
		[55342] = 8,
		[274281] = 11,
		[400202] = 11,
		[47536] = 5,
		[207887] = "Talixae Flamewreath",
		[387122] = "Arcane Construct",
		[383168] = 2,
		[393035] = 12,
		[225787] = 2,
		[382145] = 1,
		[383169] = 12,
		[326863] = 12,
		[395495] = 12,
		[382146] = "Morrizane",
		[224377] = "Infernal Imp <Talixae Flamewreath>",
		[384194] = "Primalist Cinderweaver",
		[389313] = "Raszageth",
		[106830] = 11,
		[33076] = 5,
		[388290] = "Dathea, Ascended",
		[335097] = 1,
		[382148] = 8,
		[195592] = 7,
		[371911] = 6,
		[375630] = "Drakonid Stormbringer",
		[382149] = 11,
		[374606] = 6,
		[384197] = "Primalist Cinderweaver",
		[203413] = 3,
		[382150] = 1,
		[370889] = "Morrizane",
		[392388] = 4,
		[377077] = 6,
		[377234] = 12,
		[391365] = 5,
		[386890] = 1,
		[211071] = 12,
		[382152] = 3,
		[106736] = "Sha of Doubt",
		[393456] = 3,
		[377034] = "Crawth",
		[382153] = 12,
		[193668] = "God-King Skovald",
		[69369] = 11,
		[386889] = 3,
		[382154] = 5,
		[372648] = "Sennarth",
		[198595] = "Valarjar Thundercaller",
		[188550] = 11,
		[390345] = 11,
		[391369] = 12,
		[385267] = "Crackling Vortex",
		[375717] = "Primalist Mage",
		[382156] = 3,
		[374990] = 9,
		[392394] = "Flamegullet",
		[196741] = 10,
		[394054] = 2,
		[389533] = 6,
		[392395] = "Thunderhead",
		[270569] = 9,
		[54049] = "Kreethun <Nyashia-Silvermoon>",
		[342232] = 8,
		[81751] = 5,
		[209027] = "Duskwatch Guard",
		[225919] = 12,
		[51505] = 7,
		[123725] = 10,
		[47666] = 5,
		[390350] = 1,
		[391374] = 12,
		[392398] = "Primal Thundercloud",
		[200806] = 4,
		[386256] = 9,
		[383185] = 2,
		[392399] = "Primal Thundercloud",
		[385233] = 1,
		[373972] = "Primalist Flamedancer",
		[183435] = 2,
		[381768] = 2,
		[385234] = 1,
		[373973] = "Primalist Flamedancer",
		[210053] = 11,
		[392401] = 4,
		[393425] = "Balakar Khan",
		[346111] = 5,
		[321469] = 3,
		[325461] = 6,
		[6552] = 1,
		[199179] = "Ebonclaw Worg",
		[385310] = "Primalist Shockcaster",
		[392403] = 4,
		[198793] = 12,
		[383224] = "Ruby Skyscorcher <Acumena>",
		[342240] = 7,
		[388309] = "Dathea, Ascended",
		[377048] = 6,
		[205448] = 5,
		[81141] = 6,
		[384215] = 12,
		[603] = 9,
		[394453] = 12,
		[199818] = "[*] Crackle",
		[392406] = "Storm Warrior",
		[383813] = 12,
		[275699] = 6,
		[383193] = 11,
		[384253] = 7,
		[211080] = 5,
		[386265] = 9,
		[384289] = "Radiant Drake <Hyraie-Hyjal>",
		[396503] = "Loamas",
		[393432] = "Refti Defender",
		[394456] = 9,
		[342245] = 8,
		[132764] = 3,
		[219271] = 7,
		[394457] = 2,
		[212105] = 12,
		[845] = 1,
		[383073] = "Terros",
		[207806] = "Patrol Captain Gerdo",
		[305392] = 6,
		[153240] = "Sadana Bloodfury",
		[377669] = "Azure Vorquin",
		[260734] = 7,
		[212106] = 12,
		[335082] = 1,
		[27285] = 9,
		[386270] = 4,
		[83243] = 3,
		[384223] = "Azureblade",
		[193473] = "Void Tendril <Gorlirn>",
		[378081] = 7,
		[20549] = 4,
		[376644] = "Balakar Khan",
		[393438] = 12,
		[383009] = 7,
		[72286] = 3,
		[115989] = 6,
		[390163] = 12,
		[376643] = 3,
		[371976] = "Sennarth",
		[198817] = 1,
		[221322] = 6,
		[213644] = 2,
		[382235] = 11,
		[265157] = 3,
		[123986] = 10,
		[228477] = 12,
		[383204] = "[*] Crashing Tsunami",
		[392418] = 5,
		[205473] = 8,
		[386276] = 10,
		[259202] = "Drakares-GrimBatol",
		[375871] = "Broodkeeper Diurna",
		[210875] = "Stormforged Sentinel",
		[1079] = 11,
		[153033] = "Possessed Soul",
		[51124] = 6,
		[393444] = "Refti Defender",
		[106839] = 11,
		[395492] = 5,
		[47541] = 6,
		[186387] = 3,
		[114923] = 8,
		[383208] = 2,
		[111898] = 9,
		[377066] = 5,
		[45470] = 6,
		[377991] = "Guardian Sentry",
		[124506] = 10,
		[393019] = 2,
		[328951] = 12,
		[391400] = 10,
		[384234] = 3,
		[200851] = 11,
		[201363] = 1,
		[391401] = 5,
		[198077] = "Odyn",
		[337819] = 12,
		[328953] = 12,
		[391402] = "Raszageth",
		[335096] = 1,
		[394111] = 11,
		[201364] = 1,
		[395498] = 12,
		[50613] = 6,
		[372543] = "Irontorch Commander",
		[374000] = 12,
		[122128] = 5,
		[335098] = 1,
		[382795] = "Qalashi Lavamancer",
		[106841] = "Liu Flameheart",
		[387310] = 9,
		[51637] = 4,
		[260231] = 3,
		[328957] = 12,
		[395501] = "Volatile Infuser <Dathea, Ascended>",
		[335100] = 1,
		[382079] = 6,
		[384316] = "The Raging Tempest",
		[48438] = 11,
		[371956] = "Primal Terrasentry",
		[120588] = 7,
		[386289] = "Embar Firepath",
		[274742] = 1,
		[394040] = 12,
		[49206] = 6,
		[396400] = "Glacias",
		[395504] = "Thondrozus",
		[1715] = 1,
		[211093] = 2,
		[390386] = "Morrizane",
		[219809] = 6,
		[343294] = 6,
		[211384] = "Legion Hound",
		[378102] = 7,
		[395506] = "Bronze Timewarden <Soosai>",
		[343295] = 6,
		[377079] = 4,
		[308488] = 5,
		[395507] = "Bronze Timewarden <Soosai>",
		[392436] = "Quarry Infuser",
		[44544] = 8,
		[387896] = 2,
		[383223] = 7,
		[53563] = 2,
		[395532] = 4,
		[378105] = "Morrizane",
		[280849] = 1,
		[326918] = 6,
		[327942] = 7,
		[386296] = 3,
		[380729] = 4,
		[387895] = 2,
		[85256] = 2,
		[386297] = 3,
		[383226] = 1,
		[384250] = 2,
		[291662] = 6,
		[372538] = "Lava Flare",
		[383799] = 2,
		[115546] = 10,
		[393465] = "Stalwart Broodwarden",
		[201657] = 7,
		[377656] = 6,
		[192158] = "Olmyr the Enlightened",
		[368896] = 12,
		[197277] = 2,
		[395514] = "Thondrozus",
		[376063] = "Smoldering Hellion",
		[389372] = 9,
		[386301] = 3,
		[375079] = "Squallbringer Cyraz",
		[396318] = "Loamas",
		[240559] = "[*] Grievous Wound",
		[199854] = 1,
		[383231] = "Qalashi Lavamancer",
		[375873] = "Broodkeeper Diurna",
		[368899] = 10,
		[173183] = 7,
		[396142] = 5,
		[384256] = 12,
		[393470] = "Pouncing Broodswarmer",
		[129253] = 5,
		[388923] = "Overgrown Ancient",
		[61882] = 7,
		[368901] = 5,
		[374020] = "Containment Apparatus",
		[395519] = 10,
		[377101] = 6,
		[408] = 4,
		[1543] = 3,
		[633] = 2,
		[396544] = "Magmas",
		[115804] = 10,
		[374022] = "Kurog Grimtotem",
		[375046] = "Forgemaster Gorek",
		[57724] = 11,
		[135700] = 11,
		[341263] = 5,
		[45438] = 8,
		[99] = 11,
		[260242] = 3,
		[20484] = 11,
		[154796] = 12,
		[100] = 1,
		[196770] = 6,
		[205472] = 8,
		[19801] = 3,
		[152262] = 2,
		[260243] = 3,
		[79206] = 7,
		[154797] = 6,
		[392454] = "Flame Channeler",
		[196771] = 6,
		[382217] = 7,
		[387336] = 5,
		[396328] = "Earthen Pillar",
		[373004] = "Kurog Grimtotem",
		[114014] = 4,
		[364342] = "Morrizane",
		[371981] = "[*] Elemental Surge",
		[393480] = 3,
		[45242] = 5,
		[272678] = 3,
		[384267] = 8,
		[123996] = "Xuen <Dyrell>",
		[315720] = 1,
		[272679] = 3,
		[371983] = "Sennarth",
		[385292] = "[*] Molten Steel",
		[356181] = 11,
		[193702] = "[*] Infernal Flames",
		[376079] = 1,
		[377103] = 6,
		[1719] = 1,
		[375056] = "Chargath, Bane of Scales",
		[380175] = "Broodkeeper Diurna",
		[386997] = 9,
		[215785] = 7,
		[375057] = "Chargath, Bane of Scales",
		[380176] = "Broodkeeper Diurna",
		[260247] = 3,
		[390414] = 11,
		[396077] = "Kurog Grimtotem",
		[388367] = 3,
		[389391] = 10,
		[386320] = "Dragonkiller Lance",
		[374711] = "Balara",
		[384273] = "Thunder Caller <Dathea, Ascended>",
		[25046] = 4,
		[81256] = 6,
		[395535] = 4,
		[396559] = "Raszageth",
		[210155] = 12,
		[394512] = "Void Spawn",
		[375061] = "Forgemaster Gorek",
		[214692] = "Gerenth the Vile",
		[260249] = 3,
		[16739] = 2,
		[374038] = "Embar Firepath",
		[163505] = 11,
		[197558] = "Fenryr",
		[88423] = 11,
		[376171] = "Primalist Icecaller",
		[153268] = "Shadowmoon Exhumer",
		[329737] = 3,
		[199337] = "[*] Bear Trap",
		[370969] = 12,
		[116] = 8,
		[373017] = "Blazebound Firestorm <Kokia Blazehoof>",
		[376080] = 1,
		[370970] = 12,
		[247454] = 12,
		[274738] = 1,
		[124255] = 10,
		[370971] = 12,
		[253597] = 6,
		[274739] = 1,
		[382233] = "Batak",
		[382912] = 11,
		[247455] = 12,
		[274740] = 1,
		[114018] = 4,
		[130654] = 10,
		[120] = 8,
		[274741] = 1,
		[374045] = "Containment Apparatus",
		[373552] = "Gerenth the Vile",
		[247456] = 12,
		[119905] = 9,
		[1943] = 4,
		[195757] = 6,
		[96103] = 1,
		[397726] = "Shrieking Whelp",
		[198069] = 5,
		[395546] = "Azure Spellweaver <Selenerah>",
		[255647] = 2,
		[389404] = 12,
		[199341] = "Valarjar Trapper",
		[73325] = 5,
		[106864] = "Liu Flameheart",
		[188592] = 7,
		[394524] = "Void Spawn",
		[383307] = 2,
		[194223] = 11,
		[385311] = "Primalist Shockcaster",
		[162487] = 3,
		[8042] = 7,
		[335148] = 3,
		[12051] = 8,
		[386400] = "Terros",
		[192249] = 7,
		[8122] = 5,
		[84342] = 2,
		[162488] = 3,
		[387361] = 12,
		[384290] = 11,
		[357170] = "Morrizane",
		[275773] = 2,
		[107110] = "Yu'lon",
		[20707] = 9,
		[119907] = 9,
		[2094] = 4,
		[264057] = 9,
		[212653] = 8,
		[391977] = 5,
		[133] = 8,
		[391459] = 6,
		[376103] = 8,
		[384336] = "Nokhud Plainstomper",
		[259277] = "Tallstriker <Huntz-Ravencrest>",
		[395555] = "Bronze Timewarden <Soosai>",
		[136] = 3,
		[114805] = "Xiang",
		[234153] = 9,
		[375596] = "Arcane Tender",
		[200682] = "Solsten",
		[377129] = 2,
		[139] = 5,
		[203953] = 11,
		[392486] = "Tempest Channeler",
		[118540] = "[*] Jade Serpent Wave",
		[275779] = 2,
		[330038] = 3,
		[387411] = "Soulharvester Galtmaa",
		[65081] = 5,
		[81262] = "Efflorescence <Trooell-Hyjal>",
		[50842] = 6,
		[392488] = "Tempest Channeler",
		[211473] = "Shadow Mistress",
		[106856] = "Liu Flameheart",
		[387370] = 12,
		[372014] = "Drakares-GrimBatol",
		[252071] = 11,
		[129250] = 5,
		[370991] = "Opalfang",
		[196277] = 9,
		[145110] = 11,
		[387440] = "Ukhel Beastcaller",
		[596] = 5,
		[388396] = "Terros",
		[198837] = "Risen Skulker <Astranith>",
		[214621] = 5,
		[88625] = 5,
		[196278] = 9,
		[391973] = 2,
		[189112] = 12,
		[96231] = 2,
		[48707] = 6,
		[119910] = 9,
		[374066] = "Primalist Geomancer",
		[387413] = 9,
		[4987] = 2,
		[291843] = 11,
		[80240] = 9,
		[375091] = "Embar Firepath",
		[396590] = 6,
		[393519] = "Pouncing Broodswarmer",
		[386419] = 3,
		[93805] = 2,
		[388444] = 12,
		[260798] = 1,
		[390449] = "Thunderstorm",
		[383283] = 2,
		[202160] = 1,
		[385331] = "Detonating Crystal",
		[5211] = 11,
		[200166] = 12,
		[120679] = 3,
		[291147] = 6,
		[378773] = 7,
		[393565] = 10,
		[50622] = 1,
		[256171] = 4,
		[17253] = "Patrick <Aknimo-Destromath>",
		[167105] = 1,
		[143924] = 12,
		[199600] = 4,
		[374073] = "Primalist Geomancer",
		[33697] = 7,
		[202425] = 11,
		[124007] = "Xuen <Dyrell>",
		[157153] = 7,
		[203961] = 11,
		[183998] = 2,
		[116841] = 10,
		[394550] = 2,
		[205025] = 8,
		[259756] = 4,
		[307046] = 12,
		[204513] = 12,
		[387385] = 9,
		[196528] = 6,
		[49020] = 6,
		[382267] = "Balara",
		[391481] = 6,
		[388410] = "Dathea, Ascended",
		[385339] = "Maruuk",
		[108839] = 8,
		[373540] = "Binding Spear",
		[108396] = 9,
		[44614] = 8,
		[372051] = "Sennarth",
		[86040] = 9,
		[347462] = 12,
		[378172] = "Ore Elemental",
		[374080] = "Primalist Ravager",
		[109132] = 10,
		[384318] = 1,
		[61999] = 6,
		[51963] = "Ebon Gargoyle <Astranith>",
		[214202] = 2,
		[362877] = "Morrizane",
		[124009] = "Xuen <Dyrell>",
		[390462] = "Azureblade",
		[383405] = 4,
		[384320] = 11,
		[381249] = "Raszageth",
		[213691] = 3,
		[214203] = 2,
		[259760] = 6,
		[381250] = "Raszageth",
		[382274] = "Balara",
		[387393] = 9,
		[49088] = 6,
		[381251] = "Raszageth",
		[386370] = "Opalfang",
		[335913] = 10,
		[390941] = 12,
		[385347] = 2,
		[370984] = "Morrizane",
		[228537] = 12,
		[16870] = 11,
		[116844] = 10,
		[394562] = "Unstable Flame",
		[383301] = 12,
		[384325] = 6,
		[153804] = "Bonemaw",
		[81269] = 11,
		[383302] = 2,
		[395630] = "Morrizane",
		[368970] = "Morrizane",
		[385350] = 2,
		[358733] = "Morrizane",
		[165578] = "Bonemaw",
		[280375] = 2,
		[394565] = 11,
		[382791] = "Qalashi Lavamancer",
		[383346] = 2,
		[385352] = 2,
		[373579] = 5,
		[383305] = 2,
		[165579] = "Bonemaw",
		[389448] = "Jochen <Lightør-Blackhand>",
		[394609] = 5,
		[191685] = 6,
		[372045] = "Caustic Spiderling",
		[385354] = 2,
		[110959] = 8,
		[387402] = 9,
		[373535] = "Kurog Grimtotem",
		[389450] = 3,
		[1953] = 8,
		[334168] = 7,
		[372047] = "Defier Draghar",
		[6795] = 11,
		[209602] = "Advisor Melandrus",
		[371024] = 1,
		[208086] = 1,
		[227518] = 12,
		[394571] = 6,
		[211881] = 12,
		[200389] = 11,
		[200901] = "Solsten",
		[110960] = 8,
		[317791] = "Magus of the Dead <Astranith>",
		[225921] = 12,
		[19750] = 2,
		[395521] = 10,
		[317792] = "Magus of the Dead <Astranith>",
		[388431] = "Raszageth",
		[116847] = 10,
		[378861] = "[*] Fractured Rubble",
		[383313] = 6,
		[325984] = 2,
		[32592] = 5,
		[382290] = 8,
		[387409] = 9,
		[325983] = 2,
		[193783] = 12,
		[394576] = "Morrizane",
		[228260] = 5,
		[145109] = 11,
		[396092] = 6,
		[193659] = "God-King Skovald",
		[383316] = 1,
		[392530] = "Quarry Infuser",
		[118905] = 7,
		[272790] = 3,
		[312106] = 10,
		[372056] = "Opalfang",
		[397077] = "Melidrussa Chillworn",
		[394579] = "Morrizane",
		[395603] = 1,
		[55233] = 6,
		[385434] = "Teera",
		[86392] = 4,
		[197834] = 4,
		[386365] = 3,
		[87160] = 5,
		[391058] = 12,
		[388886] = "Spellbound Scepter",
		[388439] = 12,
		[385368] = 12,
		[378202] = "Ore Elemental",
		[56641] = 3,
		[198058] = "Odyn",
		[373084] = "Irontorch Commander",
		[394583] = "Morrizane",
		[390933] = 5,
		[212680] = 3,
		[373059] = "Kadros Icewrath",
		[152279] = 6,
		[390242] = 4,
		[392537] = 1,
		[154353] = "Omen of Death <Ner'zhul>",
		[154327] = "Shadowmoon Dominator",
		[68992] = 9,
		[192206] = "Olmyr the Enlightened",
		[373087] = "Blazebound Firestorm <Kokia Blazehoof>",
		[152280] = 6,
		[152792] = "Nhallish",
		[392539] = "Awakened Terrasentry",
		[260286] = 3,
		[374112] = "Frostbreath Arachnid",
		[264571] = 9,
		[385813] = 12,
		[114803] = "Xiang",
		[153524] = "Plagued Bat",
		[115315] = 10,
		[367971] = 9,
		[385375] = 2,
		[124273] = 10,
		[203981] = 12,
		[384352] = 7,
		[393566] = 10,
		[148187] = 10,
		[396050] = 3,
		[211412] = "Blazing Imp",
		[113780] = 4,
		[32612] = 8,
		[164273] = 3,
		[333889] = 9,
		[394552] = "Morrizane",
		[213708] = 11,
		[193765] = 12,
		[396640] = "Ancient Branch",
		[393569] = "Broodguardian Ziruss",
		[378213] = "Morrizane",
		[383410] = 11,
		[387333] = "Raszageth",
		[104318] = "Wild Imp <Kêrberøs-Arygos>",
		[193234] = "[*] Dancing Blade",
		[210126] = 8,
		[384357] = 7,
		[400745] = 2,
		[378215] = 3,
		[80483] = 3,
		[367978] = 10,
		[377192] = 6,
		[193235] = "Hymdall",
		[214222] = 2,
		[123904] = 10,
		[383762] = 1,
		[124275] = 10,
		[334196] = 7,
		[384360] = 8,
		[385384] = 12,
		[191401] = "Valarjar Marksman",
		[392576] = "Tempest Channeler",
		[396646] = "Loamas",
		[377195] = 6,
		[388880] = 5,
		[391528] = 11,
		[384362] = 1,
		[66196] = 6,
		[386410] = "Raszageth",
		[372027] = "Embar Firepath",
		[227034] = 11,
		[202770] = 11,
		[386411] = "Teera",
		[391950] = 6,
		[388459] = 12,
		[49998] = 6,
		[205523] = 10,
		[317821] = 10,
		[384365] = "Nokhud Plainstomper",
		[324382] = 10,
		[386413] = 3,
		[208628] = 12,
		[396044] = "Melidrussa Chillworn",
		[11426] = 8,
		[13877] = 4,
		[152801] = "Nhallish",
		[372082] = "Sennarth",
		[385391] = 1,
		[114911] = 7,
		[389407] = 5,
		[395292] = "Flamegullet",
		[363916] = "Morrizane",
		[201430] = 3,
		[226512] = "[*] Sanguine Ichor",
		[85222] = 2,
		[381298] = "Terros",
		[374868] = "Astral Attendant",
		[387441] = 2,
		[5116] = 3,
		[377204] = "Warlord Sargha",
		[386418] = 4,
		[119415] = 8,
		[392561] = "Quarry Stonebreaker",
		[376892] = "Balakar Khan",
		[341374] = 5,
		[58180] = 11,
		[372087] = "Defier Draghar",
		[381301] = 12,
		[372107] = "Kokia Blazehoof",
		[317829] = 3,
		[5308] = 1,
		[205022] = 8,
		[390516] = 6,
		[213709] = 11,
		[6770] = 4,
		[393588] = "Broodguardian Ziruss",
		[342428] = 2,
		[339] = 11,
		[22482] = 4,
		[259285] = 3,
		[388380] = 11,
		[5484] = 9,
		[376186] = "Overseer Lahar",
		[360830] = 4,
		[390921] = "Kurog Grimtotem",
		[377612] = "Raszageth",
		[348] = 9,
		[384292] = "Thunder Caller <Dathea, Ascended>",
		[195292] = 6,
		[114050] = 7,
		[390463] = "Raszageth",
		[274837] = 11,
		[394570] = 6,
		[371070] = 12,
		[235219] = 8,
		[385403] = 3,
		[124280] = 10,
		[91776] = "Wormflayer <Astranith>",
		[392570] = "Flamegullet",
		[116858] = 9,
		[394618] = 11,
		[393612] = "Broodguardian Ziruss",
		[396038] = "Surging Ruiner",
		[115994] = 6,
		[116095] = 10,
		[381329] = "Qalashi Lavabearer",
		[163558] = 1,
		[51271] = 6,
		[370] = 7,
		[396037] = "Surging Ruiner",
		[116189] = 10,
		[395547] = "Azure Spellweaver <Selenerah>",
		[282449] = 4,
		[52174] = 1,
		[392574] = "Tempest Channeler",
		[120954] = 10,
		[209628] = "Advisor Melandrus",
		[379] = 7,
		[59638] = "Mirror Image <Hakizu>",
		[385409] = 3,
		[394528] = "Unstable Flame",
		[124274] = 10,
		[359816] = "Morrizane",
		[381315] = "Terros",
		[394624] = 5,
		[86659] = 2,
		[396672] = "Chargath, Bane of Scales",
		[383269] = 6,
		[383783] = 8,
		[91778] = "Wormflayer <Astranith>",
		[396047] = 6,
		[328082] = 4,
		[209630] = "[*] Piercing Gale",
		[387460] = 2,
		[392579] = "Quarry Stonebreaker",
		[377223] = "Dathea, Ascended",
		[384773] = "Kyrakka",
		[374704] = "Chargath, Bane of Scales",
		[374535] = "Forgemaster Gorek",
		[378149] = "Ore Elemental",
		[157736] = 9,
		[228563] = 10,
		[384391] = 1,
		[373130] = 5,
		[199373] = "Army of the Dead|T237511:0|t <Astranith>",
		[381700] = 7,
		[392582] = "Quarry Stonebreaker",
		[393606] = 12,
		[386440] = "Kadros Icewrath",
		[6572] = 1,
		[129914] = 10,
		[385417] = 2,
		[386441] = 12,
		[398446] = 4,
		[371462] = 1,
		[374533] = "Forgemaster Gorek",
		[143625] = 9,
		[156910] = 2,
		[277925] = 4,
		[196512] = "Fenryr",
		[285466] = 7,
		[394504] = 11,
		[108416] = 9,
		[204490] = 12,
		[48020] = 9,
		[372129] = "Sennarth",
		[272156] = "Void Terror <Kêrberøs-Arygos>",
		[42650] = 6,
		[13750] = 4,
		[106113] = "Sha of Doubt",
		[19434] = 3,
		[196838] = "Fenryr",
		[6940] = 2,
		[281000] = 1,
		[197835] = 4,
		[367364] = "Morrizane",
		[60103] = 7,
		[373027] = "Sennarth",
		[389537] = 12,
		[385424] = 4,
		[271788] = 3,
		[152818] = "Shadowmoon Bone-Mender",
		[392957] = "Azure Vorquin",
		[396028] = "Molten Spike",
		[385787] = 11,
		[391568] = 6,
		[372134] = 10,
		[196840] = 7,
		[397051] = "Cyclas",
		[66188] = 6,
		[155158] = 8,
		[198888] = "Storm Drake",
		[207771] = 12,
		[167152] = 8,
		[120696] = 5,
		[388860] = 5,
		[210330] = 2,
		[121471] = 4,
		[192225] = 3,
		[385429] = 12,
		[390548] = "Kurog Grimtotem",
		[389221] = "Raging Tempest <Dathea, Ascended>",
		[360194] = 4,
		[465] = 2,
		[196555] = 12,
		[386267] = 10,
		[269747] = 3,
		[381692] = "Nokhud Warspear",
		[397048] = "Frostbreath Arachnid",
		[52042] = "Healing Stream Totem <Capten-Frostwolf>",
		[119611] = 10,
		[152800] = "Nhallish",
		[193260] = "[*] Static Field",
		[210152] = 12,
		[392452] = "Flame Channeler",
		[383328] = 2,
		[15286] = 5,
		[77451] = 7,
		[385816] = 2,
		[22570] = 11,
		[383915] = 1,
		[210153] = 12,
		[269751] = 3,
		[377245] = 6,
		[378269] = 7,
		[227255] = 12,
		[269752] = 3,
		[384761] = "The Raging Tempest",
		[217832] = 12,
		[383389] = 2,
		[375068] = "Lava Tentacles",
		[374523] = "Ley-Line Sprout",
		[394651] = 7,
		[395675] = "Embar Firepath",
		[359844] = 3,
		[63560] = 6,
		[498] = 2,
		[350631] = 12,
		[95750] = 9,
		[388855] = 5,
		[166646] = 10,
		[394667] = 2,
		[227847] = 1,
		[264667] = 3,
		[8092] = 5,
		[396717] = "Cyclas",
		[374087] = 12,
		[385441] = 12,
		[378275] = 7,
		[375204] = "[*] Liquid Hot Magma",
		[370898] = "Morrizane",
		[98440] = 4,
		[195645] = 3,
		[383395] = 8,
		[206574] = "[*] Resonant Slash",
		[377253] = 6,
		[378277] = 7,
		[319238] = 6,
		[528] = 5,
		[389539] = 2,
		[374075] = "[*] Seismic Slam",
		[391602] = 2,
		[384421] = 3,
		["DEBUFF"] = "Mindbender <Gorlirn>",
		[377591] = 6,
		[321973] = 5,
		[395336] = 11,
		[389541] = "White Tiger Statue <Dyrell>",
		[374037] = 12,
		[375209] = "The Scorching Forge",
		[394994] = 8,
		[394676] = "Council Icecaller",
		[378281] = "Qalashi Thaumaturge",
		[236777] = 3,
		[52172] = 8,
		[347901] = 5,
		[378282] = "Qalashi Thaumaturge",
		[395686] = "Terros",
		[145152] = 11,
		[397734] = 6,
		[384182] = 12,
		[390898] = 6,
		[400806] = 1,
		[393969] = 4,
		[115078] = 10,
		[392945] = "Broodguardian Ziruss",
		[41425] = 8,
		[586] = 5,
		[370965] = 12,
		[204019] = 2,
		[377588] = 6,
		[389547] = 12,
		[2383] = 4,
		[395690] = "Primalist Shocktrooper",
		[290133] = 10,
		[385228] = 1,
		[378287] = 10,
		[395691] = "Primalist Shocktrooper",
		[373048] = "Sennarth",
		[389549] = 12,
		[389416] = 12,
		[51533] = 7,
		[396716] = "Overgrown Ancient",
		[389550] = 4,
		[2479] = 5,
		[204021] = 12,
		[372147] = "Balara",
		[389551] = 12,
		[394670] = 7,
		[395694] = "Primalist Shocktrooper",
		[396718] = 1,
		[198903] = "[*] Crackling Storm",
		[333964] = 7,
		[391600] = "Dathea, Ascended",
		[396719] = 1,
		[642] = 2,
		[377102] = "Morrizane",
		[281036] = 3,
		[31850] = 2,
		[391613] = "Subterranean Proto-Dragon",
		[195321] = 10,
		[163073] = 12,
		[396721] = "Ancient Branch",
		[381365] = 9,
		[5277] = 4,
		[391603] = 3,
		[372152] = 11,
		[54861] = 11,
		[81297] = 2,
		[383414] = 4,
		[376257] = "Tarasek Earthreaver",
		[390435] = "Morrizane",
		[390581] = 1,
		[25771] = 2,
		[391430] = 12,
		[389558] = 12,
		[394677] = 7,
		[686] = 9,
		[688] = 9,
		[370960] = "Morrizane",
		[333120] = 12,
		[64843] = 5,
		[389148] = 2,
		[772] = 1,
		[394679] = 9,
		[702] = 9,
		[388537] = "Vexamus <Magic Book>",
		[373181] = 5,
		[392641] = "Thunderhead",
		[66198] = 6,
		[198396] = "Odyn",
		[384024] = "Melidrussa Chillworn",
		[392640] = "Thunderhead",
		[391610] = "Gusting Proto-Dragon",
		[388539] = 1,
		[373183] = 5,
		[27243] = 9,
		[390271] = 6,
		[392635] = "Kaurdyth",
		[389868] = 9,
		[58867] = "Spirit Wolf <Tetiro-Draenor>",
		[228598] = 8,
		[114571] = "Strife",
		[118922] = 3,
		[740] = 11,
		[387518] = 7,
		[47568] = 6,
		[2983] = 4,
		[375535] = "Magmatusk",
		[375234] = "Morrizane",
		[215479] = 10,
		[213243] = 12,
		[394686] = "Unstable Frost",
		[64844] = 5,
		[396734] = "Raszageth",
		[370607] = "Morrizane",
		[372088] = "Defier Draghar",
		[187650] = 3,
		[376260] = "Tarasek Earthreaver",
		[102543] = 11,
		[20589] = 5,
		[774] = 11,
		[388546] = "Vexamus <Magic Book>",
		[57934] = 4,
		[12472] = 8,
		[387523] = "Corrupted Manafiend",
		[392642] = "Thunderhead",
		[394558] = "Unstable Flame",
		[374215] = "Kurog Grimtotem",
		[121483] = "Wise Mari",
		[392474] = "Quarry Infuser",
		[202497] = 11,
		[392937] = 1,
		[347600] = 2,
		[315132] = 12,
		[17454] = 1,
		[374217] = "Kurog Grimtotem",
		[375241] = "The Scorching Forge",
		[384455] = 8,
		[106898] = 11,
		[374218] = "Kurog Grimtotem",
		[8921] = 11,
		[376266] = "Tarasek Earthreaver",
		[131347] = 12,
		[114646] = "Haunting Sha",
		[396007] = "The Songbird Queen",
		[120692] = 5,
		[388556] = 12,
		[236282] = 1,
		[390981] = 5,
		[391634] = "Glacial Proto-Dragon",
		[215816] = 8,
		[82326] = 2,
		[378286] = 2,
		[384459] = 3,
		[111759] = 5,
		[372459] = "[*] Burning",
		[382419] = 11,
		[388868] = "[*] Mana Void",
		[227723] = 8,
		[153501] = "Nhallish",
		[188172] = 7,
		[194310] = 6,
		[370410] = "Eranog",
		[396552] = "Magmas",
		[61648] = 3,
		[376272] = "Tarasek Earthreaver",
		[389581] = 2,
		[209667] = "Advisor Melandrus",
		[387534] = "Quarry Earthshaper",
		[194311] = 6,
		[388565] = 12,
		[345561] = "Teera",
		[91797] = "Rockcrawler <Astranith>",
		[212739] = 6,
		[53365] = 6,
		[374227] = "Morrizane",
		[375251] = "Magmatusk",
		[361195] = "Morrizane",
		[373204] = 5,
		[382418] = 11,
		[394709] = 2,
		[32747] = 12,
		[102547] = 11,
		[185099] = 10,
		[33110] = 5,
		[388562] = "Volatile Infuser <Dathea, Ascended>",
		[41635] = 5,
		[386515] = 12,
		[264689] = 2,
		[45524] = 6,
		[374238] = 12,
		[394706] = "Unstable Frost",
		[381670] = "Apex Blazewing",
		[376279] = "Terros",
		[344548] = 7,
		[325092] = 10,
		[89751] = "Dag'arad <Kêrberøs-Arygos>",
		[384470] = 3,
		[200969] = "King Tor",
		[386518] = 12,
		[394712] = "Unstable Frost",
		[368091] = "Vicious Hyena",
		[119952] = 2,
		[353759] = "Drakares-GrimBatol",
		[382428] = 5,
		[212743] = 4,
		[384476] = "Nokhud Longbow",
		[382425] = 5,
		[397783] = "Wise Mari",
		[376283] = 12,
		[389873] = "Colossal Stormfiend",
		[382426] = 5,
		[291631] = 6,
		[376284] = 12,
		[139546] = 4,
		[390617] = 5,
		[196496] = "Fenryr",
		[198412] = "Odyn",
		[220890] = 6,
		[394713] = 12,
		[974] = 7,
		[392666] = "Forgemaster Gorek",
		[50259] = 11,
		[394714] = 2,
		[982] = 3,
		[343527] = 2,
		[211210] = 2,
		[377912] = "Guardian Sentry",
		[89753] = "Dag'arad <Kêrberøs-Arygos>",
		[226510] = "Sanguine Ichor",
		[201428] = 12,
		[386526] = "Nullmagic Hornswog",
		[213771] = 11,
		[384479] = "Nokhud Longbow",
		[394544] = "Morrizane",
		[178963] = 12,
		[279043] = 4,
		[319236] = 6,
		[387359] = "[*] Waterlogged",
		[209676] = "Advisor Melandrus",
		[371172] = "Morrizane",
		[394973] = "Qalashi Lavabearer",
		[20271] = 2,
		[382434] = "Raszageth",
		[1022] = 2,
		[314867] = 5,
		[374250] = 12,
		[390625] = 2,
		[388583] = 9,
		[198030] = 12,
		[1044] = 2,
		[394972] = "Qalashi Lavabearer",
		[334320] = 9,
		[121557] = 5,
		[397793] = "Wise Mari",
		[209678] = "Advisor Melandrus",
		[374251] = "Akisu",
		[97547] = 11,
		[386781] = "Telash Greywing",
		[397798] = "Wise Mari",
		[289277] = 12,
		[372201] = "Qalashi Irontorch",
		[160029] = 11,
		[1160] = 1,
		[375273] = 12,
		[77472] = 7,
		[19647] = "Kreethun <Nyashia-Silvermoon>",
		[382440] = 8,
		[257284] = 3,
		[372203] = "Qalashi Irontorch",
		[387564] = "Conjured Lasher",
		[386536] = "Nullmagic Hornswog",
		[372208] = "[*] Djaradin Lava",
		[390636] = 5,
		[157981] = 8,
		[271877] = 4,
		[375276] = 12,
		[394729] = 5,
		[397799] = "Wise Mari",
		[394728] = "Unstable Earth",
		[22703] = 9,
		[385519] = 3,
		[157982] = 11,
		[236299] = 8,
		[102359] = 11,
		[384492] = "Nokhud Beastmaster",
		[397801] = "Wise Mari",
		[382445] = 8,
		[383469] = 2,
		[388588] = 5,
		[386544] = "Magic Book",
		[394731] = "Unstable Earth",
		[31661] = 8,
		[344572] = "Jochen <Lightør-Blackhand>",
		[110744] = 5,
		[386546] = "Arcane Elemental",
		[108503] = 9,
		[145629] = 6,
		[198934] = "Valarjar Mystic",
		[389410] = 12,
		[210824] = 8,
		[382458] = "Terros",
		[385520] = 3,
		[52437] = 1,
		[35546] = 4,
		[381657] = 4,
		[375306] = "Forgemaster Gorek",
		[394735] = "Unstable Earth",
		[384507] = 11,
		[372213] = "Qalashi Lavabearer",
		[110745] = 5,
		[292361] = 11,
		[372224] = "Qalashi Bonesplitter",
		[384499] = 11,
		[198936] = "[*] Rune of Healing",
		[386547] = "Teera",
		[387571] = "Primal Tsunami",
		[29166] = 11,
		[360954] = 2,
		[215430] = "Valarjar Thundercaller",
		[377344] = "Territorial Eagle",
		[23920] = 1,
		[384512] = "Nokhud Lancemaster",
		[386549] = "Arcane Elemental",
		[385536] = "Primalist Flamedancer",
		[5374] = 4,
		[196490] = 5,
		[209693] = 12,
		[383479] = 8,
		[388598] = 5,
		[393717] = 9,
		[207640] = 11,
		[91807] = 6,
		[388599] = 5,
		[394963] = 5,
		[393939] = 8,
		[375291] = "Forgemaster Gorek",
		[388600] = 5,
		[194844] = 6,
		[386553] = 2,
		[387596] = "Risen Mystic",
		[383701] = 10,
		[264735] = 3,
		[115098] = 10,
		[373257] = 12,
		[372222] = "Azureblade",
		[111771] = 9,
		[394745] = 5,
		[102560] = 11,
		[372223] = "Qalashi Bonetender",
		[117405] = 3,
		[271896] = 4,
		[383485] = 1,
		[210714] = 7,
		[385533] = 1,
		[1464] = 1,
		[379403] = 4,
		[372225] = "Qalashi Bonesplitter",
		[102558] = 11,
		[394748] = "Unstable Storm",
		[375348] = "Gusting Proto-Dragon",
		[372226] = "Qalashi Bonetender",
		[391688] = 1,
		[394749] = "Unstable Storm",
		[391889] = 11,
		[273947] = 6,
		[389631] = 8,
		[33757] = 7,
		[371204] = "Deaadevo-Ragnaros",
		[1680] = 1,
		[381442] = "Raszageth",
		[394751] = "Unstable Storm",
		[204062] = 12,
		[390669] = 5,
		[391888] = 11,
		[185123] = 12,
		[115356] = 7,
		[32239] = 3,
		[198944] = "Valarjar Shieldmaiden",
		[260881] = 7,
		[383492] = 8,
		[108446] = 9,
		[385540] = 3,
		[385553] = "Stormseeker Acolyte",
		[193826] = "God-King Skovald",
		[1784] = 4,
		[208165] = "Talixae Flamewreath",
		[390660] = 12,
		[77478] = 7,
		[188196] = 7,
		[369162] = 2,
		[193315] = 4,
		[32379] = 5,
		[372234] = "Morrizane",
		[372245] = "Drakares-GrimBatol",
		[317614] = 6,
		[391686] = "Dathea, Ascended",
		[383696] = 10,
		[153395] = "Carrion Worm",
		[1856] = 4,
		[132403] = 2,
		[85673] = 2,
		[157997] = 8,
		[187174] = 7,
		[371213] = "Deaadevo-Ragnaros",
		[373277] = 5,
		[393754] = "Broodguardian Ziruss",
		[387611] = "Ukhel Corruptor",
		[395784] = "Raszageth",
		[372238] = "Sennarth",
		[389685] = 10,
		[202028] = 11,
		[224127] = 7,
		[384524] = "Watcher Irideus",
		[346665] = 12,
		[381471] = 11,
		[379406] = "Qalashi Lavabearer",
		[152976] = "Possessed Soul",
		[197509] = "Bloodworm <Astranith>",
		[138130] = 10,
		[360823] = "Morrizane",
		[391882] = 11,
		[373265] = 12,
		[131894] = 3,
		[393763] = 11,
		[396812] = "Spellbound Scepter",
		[256374] = 4,
		[263725] = 8,
		[146739] = 9,
		[388623] = "Overgrown Ancient",
		[373267] = "Morrizane",
		[196911] = 4,
		[379410] = "Qalashi Lavabearer",
		[1776] = 4,
		[373268] = "Morrizane",
		[228128] = 5,
		[89766] = "Dag'arad <Kêrberøs-Arygos>",
		[388625] = "Overgrown Ancient",
		[375331] = "Dathea Stormlash",
		[325153] = 10,
		[399047] = "Kaurdyth",
		[145205] = 11,
		[131476] = 4,
		[393780] = "Flame Guardian",
		[191877] = 7,
		[384532] = 1,
		[394951] = 10,
		[221562] = 6,
		[132409] = 9,
		[384713] = 8,
		[153908] = "[*] Inhale",
		[85416] = 2,
		[88747] = 11,
		[122783] = 10,
		[375341] = "Subterranean Proto-Dragon",
		[390677] = 5,
		[102351] = 11,
		[101545] = 10,
		[395817] = "Primalist Frostsculptor",
		[268877] = 3,
		[395797] = "Primalist Frostsculptor",
		[396821] = 12,
		[287280] = 2,
		[391724] = "Flamegullet",
		[387608] = "Ukhel Corruptor",
		[117665] = "Sha of Doubt",
		[373276] = 5,
		[15290] = 5,
		[379419] = "Broodkeeper Diurna",
		[382541] = "Surging Ruiner",
		[123040] = 5,
		[341541] = 4,
		[77489] = 5,
		[107428] = 10,
		[388673] = 12,
		[184709] = 1,
		[228645] = 6,
		[388635] = "Volatile Spark",
		[373279] = "Thing From Beyond <Gorlirn>",
		[394802] = "Council Stormcaller",
		[375327] = "Subterranean Proto-Dragon",
		[389684] = 10,
		[360995] = "Morrizane",
		[387559] = "Primal Tsunami",
		[387613] = "Ukhel Corruptor",
		[273977] = 6,
		[373281] = 5,
		[34914] = 5,
		[387614] = "Ukhel Deathspeaker",
		[248622] = 1,
		[385567] = "Primalist Flamedancer",
		[23922] = 1,
		[391710] = 11,
		[388663] = 10,
		[385568] = "Primalist Flamedancer",
		[292407] = 6,
		[391711] = "Thundering Ravager",
		[381637] = 4,
		[198959] = "Valarjar Runecarver",
		[378426] = 10,
		[187698] = 3,
		[393783] = "Iskakx",
		[381475] = 11,
		[382499] = 12,
		[322098] = 5,
		[372262] = "Qalashi Bonesplitter",
		[207150] = 6,
		[199552] = 12,
		[228649] = 10,
		[388643] = "Raszageth",
		[2120] = 8,
		[382522] = 2,
		[375335] = 6,
		[388644] = "Tarasek Legionnaire",
		[377383] = "Alpha Eagle",
		[386631] = 1,
		[322101] = 10,
		[192307] = "Hyrja",
		[377384] = "Aqua Rager",
		[83381] = "Jochen <Lightør-Blackhand>",
		[45297] = 7,
		[372266] = "Qalashi Bonesplitter",
		[198962] = "Valarjar Runecarver",
		[191284] = "Hymdall",
		[108199] = 6,
		[184707] = 1,
		[315961] = 1,
		[388801] = "Risen Warrior",
		[324184] = 11,
		[30449] = 8,
		[381482] = "[*] Forgefire",
		[69041] = 5,
		[322105] = 5,
		[212784] = "Watchful Inquisitor",
		[385578] = "Azureblade",
		[378412] = 2,
		[387626] = 9,
		[393786] = 10,
		[394810] = 9,
		[65116] = 2,
		[387627] = "Volatile Infuser <Dathea, Ascended>",
		[388651] = "Vexamus <Magic Book>",
		[196917] = 2,
		[121253] = 10,
		[391723] = "Flamegullet",
		[210738] = 6,
		[101546] = 10,
		[190784] = 2,
		[322109] = 10,
		[204596] = 12,
		[385582] = 2,
		[355913] = "Morrizane",
		[375345] = "Morrizane",
		[386624] = 6,
		[385583] = 2,
		[394797] = 10,
		[391726] = "Thunderhead",
		[372275] = "Dathea Stormlash",
		[397888] = "Fallen Waterspeaker",
		[100784] = 10,
		[391727] = "Thunderhead",
		[396846] = 12,
		[260402] = 3,
		[122278] = 10,
		[387633] = 9,
		[204598] = 12,
		[385727] = 4,
		[394800] = "Council Earthcaller",
		[375349] = "Gusting Proto-Dragon",
		[388658] = 6,
		[373317] = 5,
		[5215] = 11,
		[187707] = 3,
		[372279] = "Dathea Stormlash",
		[381512] = "Erkhart Stormvein",
		[100780] = 10,
		[375351] = "Glacial Proto-Dragon",
		[394821] = "Primalist Gateway",
		[373304] = 5,
		[114089] = 7,
		[391732] = "Colossal Stormfiend",
		[386632] = 1,
		[373305] = 5,
		[386614] = 9,
		[375353] = "Glacial Proto-Dragon",
		[235313] = 8,
		[389686] = "Crystal Fury",
		[390710] = "Broodkeeper Diurna",
		[5487] = 11,
		[212791] = "Watchful Oculus",
		[393782] = "Flame Guardian",
		[258860] = 12,
		[372296] = "Irontorch Commander",
		[235314] = 8,
		[397878] = "Corrupt Living Water",
		[199483] = 3,
		[204090] = 3,
		[212792] = 8,
		[393784] = "Iskakx",
		[126664] = 1,
		[374348] = "Morrizane",
		[212800] = 12,
		[105421] = 2,
		[375487] = "Dragonspawn Flamebender",
		[386748] = "Dragonkiller Lance",
		[33763] = 11,
		[397881] = "Corrupt Living Water",
		[390715] = "Eranog",
		[117418] = 10,
		[205179] = 9,
		[393787] = "Iskakx",
		[122281] = 10,
		[353883] = 6,
		[274009] = 6,
		[30451] = 8,
		[390717] = "Eranog",
		[375361] = 7,
		[381517] = "Erkhart Stormvein",
		[194879] = 6,
		[199486] = 5,
		[212283] = 4,
		[225080] = 7,
		[393790] = "Iskakx",
		[374339] = "Refti Defender",
		[281178] = 2,
		[388672] = 12,
		[373316] = 5,
		[382530] = "Surging Ruiner",
		[3408] = 4,
		[372293] = "Irontorch Commander",
		[8221] = 1,
		[49376] = 11,
		[384699] = "Umbrelskul",
		[381518] = "Erkhart Stormvein",
		[336463] = 5,
		[325202] = 10,
		[164686] = "Sadana Bloodfury",
		[373331] = "Kurog Grimtotem",
		[397889] = "Fallen Waterspeaker",
		[374343] = "Echo of Doragosa",
		[397899] = "Sha-Touched Guardian",
		[355916] = "Morrizane",
		[207167] = 6,
		[19574] = 3,
		[318038] = 7,
		[380487] = "Terros",
		[123051] = "Mindbender <Jihoonpriest-TarrenMill>",
		[366155] = "Morrizane",
		[389714] = 8,
		[396868] = "Magmas",
		[397892] = "Imacu'tya",
		[271971] = "Dreadstalker <Kêrberøs-Arygos>",
		[374355] = "The Scorching Forge",
		[117679] = 11,
		[381513] = "Erkhart Stormvein",
		[125355] = 10,
		[389713] = 8,
		[243512] = 3,
		[381514] = "Erkhart Stormvein",
		[382538] = 2,
		[201594] = 3,
		[392776] = 1,
		[384597] = "Qalashi Warden",
		[374349] = "Morrizane",
		[53600] = 2,
		[382551] = 1,
		[373326] = "Echo of Doragosa",
		[207682] = 12,
		[391765] = "Raging Ember <Warlord Sargha>",
		[392778] = 1,
		[373327] = "Primal Flame",
		[50401] = 6,
		[292463] = 11,
		[211319] = 5,
		[252216] = 11,
		[374352] = "Echo of Doragosa",
		[319175] = 4,
		[212773] = "Duskwatch Reinforcement <Duskwatch Sentry>",
		[373329] = "Kurog Grimtotem",
		[205636] = 11,
		[193357] = 4,
		[388686] = 10,
		[389710] = 6,
		[207684] = 12,
		[381623] = 4,
		[360022] = "Akisu",
		[385616] = 4,
		[386640] = "Tarasek Looter",
		[394841] = "Primalist Gateway",
		[132951] = 12,
		[377427] = 5,
		[207685] = 12,
		[382555] = "Bracken Warscourge",
		[327264] = 10,
		[397903] = "Jazshariu",
		[325217] = 10,
		[391769] = "Dragon's Eruption",
		[343648] = 11,
		[397904] = "Sha-Touched Guardian",
		[325218] = 10,
		[391762] = 12,
		[372311] = "Qalashi Trainee",
		[196937] = 4,
		[197963] = "Odyn",
		[197961] = "Odyn",
		[269937] = 2,
		[381526] = "Kyrakka",
		[93622] = 11,
		[375384] = "Primalist Earthshaker",
		[372313] = 5,
		[397907] = "Baalgar the Watchful",
		[374361] = "Echo of Doragosa",
		[259387] = 3,
		[396884] = "Loamas",
		[397908] = "Baalgar the Watchful",
		[386647] = 9,
		[108211] = 4,
		[372315] = "Kadros Icewrath",
		[210294] = 2,
		[193356] = 4,
		[259388] = 3,
		[392791] = 1,
		[97462] = 1,
		[374364] = "Leymor",
		[258922] = 12,
		[395859] = "Haunting Sha",
		[397911] = "Depraved Mistweaver",
		[374365] = "Magmatusk",
		[197964] = "Odyn",
		[392793] = 1,
		[385627] = 4,
		[382556] = "Bracken Warscourge",
		[57330] = 6,
		[163201] = 1,
		[196941] = 2,
		[193358] = 4,
		[197965] = "Odyn",
		[222024] = 6,
		[397914] = "Depraved Mistweaver",
		[197966] = "Odyn",
		[391772] = "Dragon's Eruption",
		[384606] = 4,
		[263806] = 7,
		[193359] = 4,
		[387678] = 12,
		[372322] = "Opalfang",
		[281210] = 6,
		[390833] = 3,
		[395869] = "Lesser Sha",
		[377524] = "Alpha Eagle",
		[222026] = 6,
		[394846] = "Primalist Gateway",
		[197967] = "Odyn",
		[388704] = 12,
		[375397] = "Chargath, Bane of Scales",
		[81340] = 6,
		[382563] = "Kurog Grimtotem",
		[396895] = "Thing From Beyond <Gorlirn>",
		[273104] = 3,
		[292473] = 10,
		[395872] = "The Talking Fish",
		[97463] = 1,
		[377445] = 6,
		[382564] = "Kurog Grimtotem",
		[375475] = "Juvenile Frost Proto-Dragon",
		[258920] = 12,
		[389054] = "Arcane Forager",
		[209742] = "Image of Advisor Melandrus",
		[335467] = 5,
		[85948] = 6,
		[214350] = 8,
		[386661] = "Kadros Icewrath",
		[122470] = 10,
		[77758] = 11,
		[385638] = 3,
		[205648] = 7,
		[371306] = "Arcane Elemental",
		[384615] = 7,
		[377449] = 11,
		[384687] = "The Raging Tempest",
		[386660] = "Leymor",
		[225100] = "Guardian Construct",
		[184662] = 2,
		[194384] = 5,
		[395878] = "The Talking Fish",
		[156000] = 6,
		[393831] = 12,
		[265931] = 9,
		[93402] = 11,
		[347765] = 12,
		[73920] = 7,
		[271049] = 3,
		[192081] = 11,
		[182104] = 2,
		[377453] = 12,
		[211793] = 6,
		[391786] = 11,
		[384620] = "The Raging Tempest",
		[393834] = 12,
		[222031] = 12,
		[210253] = 2,
		[388716] = "Broodkeeper Diurna",
		[377455] = 9,
		[394859] = "Primalist Gateway",
		[42223] = 9,
		[396907] = "Yu'lon",
		[73921] = 7,
		[230222] = 8,
		[381613] = "Raszageth",
		[384623] = "Qalashi Blacksmith",
		[386173] = "Vexamus <Magic Book>",
		[383660] = "Qalashi Lavamancer",
		[394921] = "Braekkas",
		[397936] = "Depraved Mistweaver",
		[377458] = 1,
		[272012] = "Illidari Satyr <Kêrberøs-Arygos>",
		[230224] = 8,
		[384625] = "Azureblade",
		[377459] = 10,
		[272013] = "Vicious Hellhound <Kêrberøs-Arygos>",
		[77505] = 7,
		[77761] = 11,
		[390771] = 5,
		[106938] = "[*] Serpent Wave",
		[210261] = "Duskwatch Sentry",
		[388717] = "Broodkeeper Diurna",
		[377461] = 6,
		[377516] = "Territorial Eagle",
		[375901] = 5,
		[384628] = "The Raging Tempest",
		[377462] = 5,
		[276111] = 2,
		[339588] = 3,
		[271881] = 4,
		[377463] = 4,
		[394867] = "Primalist Gateway",
		[200025] = 2,
		[77762] = 7,
		[377464] = 9,
		[370298] = 3,
		[113862] = 8,
		[384631] = 4,
		[396908] = 1,
		[154469] = "[*] Ritual of Bones",
		[395893] = "Kurog Grimtotem",
		[5760] = 4,
		[271048] = 3,
		[367230] = "Morrizane",
		[395894] = "Kurog Grimtotem",
		[388728] = 12,
		[48743] = 6,
		[394864] = 5,
		[191837] = 10,
		[367231] = "Morrizane",
		[373364] = "Gerenth the Vile",
		[374397] = "Forgemaster Gorek",
		[363136] = 1,
		[396920] = "Morrizane",
		[394879] = 4,
		[394873] = "[*] Lightning Strike",
		[383612] = 7,
		[396921] = 2,
		[356995] = "Morrizane",
		[181089] = "Raszageth",
		[368299] = "Bonebolt Hunter",
		[384637] = "Raging Tempest <Dathea, Ascended>",
		[196447] = 9,
		[207707] = "Ebonclaw Packmate",
		[375424] = "Dathea, Ascended",
		[77764] = 11,
		[196448] = 9,
		[19577] = 3,
		[374405] = "[*] Gulp Swog Toxin",
		[376449] = "Goal of the Searing Blaze",
		[377473] = "Warlord Sargha",
		[370307] = "Eranog",
		[32182] = 7,
		[396925] = "Qalashi Lavamancer",
		[200561] = "Fenryr",
		[374403] = 12,
		[132463] = 10,
		[384644] = 2,
		[374407] = 6,
		[114108] = 11,
		[363143] = 11,
		[20473] = 2,
		[53351] = 3,
		[390785] = 11,
		[363144] = 11,
		[387629] = "Desecrated Ohuna",
		[194913] = 6,
		[211805] = 6,
		[363145] = 6,
		[388739] = 8,
		[357003] = 12,
		[386692] = 6,
		[343727] = "Shadowfiend <Zimby-TwistingNether>",
		[196819] = 4,
		[101568] = 6,
		[25912] = 2,
		[395907] = "Raszageth",
		[385700] = 6,
		[375342] = 2,
		[386694] = "Stormsurge Totem",
		[395908] = "Primal Icebulk",
		[370901] = "Morrizane",
		[381576] = "Terros",
		[374410] = "Magmatusk",
		[371339] = 6,
		[91800] = "Wormflayer <Astranith>",
		[381654] = 8,
		[398981] = "Stalwart Broodwarden",
		[132467] = 10,
		[30455] = 8,
		[392490] = 6,
		[123586] = 10,
		[375436] = "Magmatusk",
		[373424] = "Chargath, Bane of Scales",
		[211299] = "Watchful Inquisitor",
		[394888] = 4,
		[390911] = "Raszageth",
		[388746] = 12,
		[20153] = "Infernal <Nyashia-Silvermoon>",
		[375439] = "Magmatusk",
		[219498] = "Patrol Captain Gerdo",
		[116670] = 10,
		[365201] = "Void Spawn",
		[398985] = "Broodguardian Ziruss",
		[109248] = 3,
		[373392] = "Nokhud Longbow",
		[207203] = 6,
		[394891] = "Braekkas",
		[27576] = 4,
		[225119] = 8,
		[377488] = "Rune Seal Keeper",
		[395899] = "Primalist Chillblaster",
		[389774] = 1,
		[393869] = 11,
		[369299] = "Morrizane",
		[373464] = 5,
		[114113] = 11,
		[368276] = 5,
		[394894] = 4,
		[32375] = 5,
		[371348] = 6,
		[372372] = "Qalashi Trainee",
		[211300] = "Watchful Oculus",
		[371352] = "Unstable Curator",
		[324260] = 2,
		[394899] = 6,
		[59752] = 8,
		[51690] = 4,
		[371350] = 6,
		[183811] = 2,
		[58984] = 12,
		[371355] = 12,
		[16827] = "Rex <Setrit>",
		[388755] = 5,
		[88263] = 2,
		[48107] = 8,
		[383637] = 8,
		[121536] = 5,
		[117952] = 10,
		[386709] = 1,
		[371353] = 1,
		[384662] = "Forgewrought Monstrosity",
		[21562] = 5,
		[209767] = 2,
		[371354] = 12,
		[384663] = "Forgewrought Monstrosity",
		[7744] = 4,
		[202090] = 10,
		[281265] = 5,
		[388759] = 12,
		[381595] = "Terros",
		[374427] = "Tectonic Crusher",
		[26297] = 5,
		[371358] = "Unstable Curator",
		[22842] = 11,
		[374428] = "Tectonic Crusher",
		[374430] = "Tectonic Crusher",
		[392856] = "[*] Fractured Rubble",
		[373405] = "Sennarth",
		[11327] = 4,
		[197996] = 11,
		[347812] = 8,
		[373406] = "Overseer Lahar",
		[179057] = 12,
		[368287] = "Bonebolt Hunter",
		[31224] = 4,
		[209258] = 12,
		[382620] = "Bonebolt Hunter",
		[395930] = "Raszageth",
		[190319] = 8,
		[377503] = "Rune Seal Keeper",
		[394907] = "Braekkas",
		[128594] = 3,
		[102342] = 11,
		[184689] = 2,
		[375449] = "Magmatusk",
		[375457] = "Juvenile Frost Proto-Dragon",
		[343721] = 2,
		[377505] = "Terros",
		[371351] = 6,
		[375458] = "Juvenile Frost Proto-Dragon",
		[48108] = 8,
		[219488] = "Patrol Captain Gerdo",
		[34433] = 5,
		[148859] = 5,
		[386625] = 6,
		[381602] = "Kyrakka",
		[343312] = 12,
		[453] = 5,
		[343724] = 2,
		[209261] = 12,
		[390817] = "Raszageth",
		[383651] = "Qalashi Lavamancer",
		[116706] = 10,
		[371982] = 11,
		[382628] = "The Raging Tempest",
		[359082] = 12,
		[119996] = 10,
		[381605] = "Kyrakka",
		[8512] = 7,
		[209426] = 12,
		[368297] = "Bonebolt Hunter",
		[215405] = 3,
		[386725] = 12,
		[51052] = 6,
		[388773] = "Umbrelskul",
		[381607] = "Kyrakka",
		[106951] = 11,
		[118459] = "Jochen <Lightør-Blackhand>",
		[372394] = "Dathea Stormlash",
		[25914] = 2,
		[263840] = "Фенрир <Ханемия-Ревущийфьорд>",
		[382593] = "Cruel Bonecrusher",
		[356998] = 12,
		[34026] = 3,
		[115203] = 10,
		[395942] = 11,
		[258883] = 12,
		[271045] = 3,
		[980] = 9,
		[396918] = 5,
		[388777] = "Umbrelskul",
		[196980] = 4,
		[393781] = "Flame Guardian",
		[115129] = 10,
		[377451] = 2,
		[203123] = 11,
		[386731] = 2,
		[120517] = 5,
		[374389] = "Curious Swoglet",
		[393898] = "Raszageth",
		[394922] = "Braekkas",
		[285381] = 11,
		[384685] = 8,
		[389804] = "Unstable Curator",
		[388645] = "Raszageth",
		[50285] = "Rex <Setrit>",
		[384686] = "The Raging Tempest",
		[381615] = "Raszageth",
		[181113] = "Primalist Mage",
		[115399] = 10,
		[210803] = 10,
		[387691] = "Vexamus <Magic Book>",
		[397931] = "Minion of Doubt",
		[209741] = "Image of Advisor Melandrus",
		[344566] = 9,
		[377522] = "Raging Ember <Warlord Sargha>",
		[394926] = "Braekkas",
		[152962] = "Nhallish",
		[385951] = 4,
		[393903] = 11,
		[394927] = "Morrizane",
		[228597] = 8,
		[395035] = "Soulharvester Galtmaa",
		[389809] = 12,
		[258921] = 12,
		[221883] = 2,
		[316099] = 9,
		[389810] = 12,
		[5217] = 11,
		[387763] = "Morrizane",
		[33778] = 11,
		[355941] = "Morrizane",
		[2641] = 3,
		[152964] = "Void Spawn",
		[392883] = 10,
		[199033] = "Valarjar Aspirant",
		[386652] = 2,
		[391773] = "Dragon's Eruption",
		[94158] = 3,
		[389813] = 12,
		[59628] = 4,
		[371386] = 8,
		[388790] = 12,
		[199034] = "Valarjar Aspirant",
		[390838] = 6,
		[371387] = 8,
		[384696] = "Umbrelskul",
		[389815] = 12,
		[394934] = 12,
		[206151] = "Morrizane",
		[381525] = "Kyrakka",
		[240446] = "[*] Explosion",
		[199547] = 12,
		[396752] = 1,
		[361049] = 3,
		[2825] = 7,
		[258925] = 12,
		[375485] = "Dragonspawn Flamebender",
		[15487] = 5,
		[385723] = 2,
		[386747] = "Dragonkiller Lance",
		[381516] = "Erkhart Stormvein",
		[5761] = 4,
		[385724] = 2,
		[258926] = 12,
		[198013] = 12,
		[388796] = "Overgrown Ancient",
		[389820] = 2,
		[390844] = 5,
		[395963] = "Jumping Spiderling",
		[344659] = 1,
		[205180] = 9,
		[390845] = 5,
		[395964] = "Jumping Spiderling",
		[47585] = 5,
		[373442] = "Mindbender <Gorlirn>",
		[374466] = "Sennarth",
		[204157] = 12,
		[388799] = "Overgrown Ancient",
		[397897] = "Jazshariu",
		[267997] = "Vilefiend <Kêrberøs-Arygos>",
		[154442] = "Ner'zhul",
		[56814] = 4,
		[386623] = 6,
		[27827] = 5,
		[196414] = 9,
		[396991] = "Drakonid Breaker",
		[180612] = 6,
		[394944] = 10,
		[33891] = 11,
		[393795] = 3,
		[207230] = 6,
		[195457] = 4,
		[108238] = 11,
		[396993] = "Cyclas",
		[377542] = "[*] Burning Ground",
		[374471] = "Grounding Spear <Chargath, Bane of Scales>",
		[214397] = 1,
		[388804] = "Umbrelskul",
		[6353] = 9,
		[88751] = 11,
		[391876] = 11,
		[319190] = 4,
		[131474] = 3,
		[242551] = 12,
		[388659] = "Raszageth",
		[153485] = "Carrion Worm",
		[216371] = 2,
		[394949] = 10,
		[397886] = "Corrupt Droplet",
		[375343] = 4,
		[391722] = 11,
		[386760] = 9,
		[188290] = 6,
		[392903] = 2,
		[324312] = 10,
		[224125] = 7,
		[163212] = 10,
		[267999] = "Vilefiend <Kêrberøs-Arygos>",
		[6673] = 1,
		[213888] = 10,
		[385574] = "Raszageth",
		[387621] = 10,
		[137619] = 4,
		[224126] = 7,
		[220543] = 5,
		[53595] = 2,
		[385569] = "Raszageth",
		[3409] = 4,
		[383693] = "Nokhud Beastmaster",
		[377540] = 6,
		[393931] = 1,
		[382670] = "Teera",
		[390711] = "Broodkeeper Diurna",
		[392908] = 1,
		[219432] = 11,
		[115151] = 10,
		[374327] = "Caustic Spiderling",
		[131900] = 3,
		[373458] = "Primal Terrasentry",
		[374482] = "Grounding Spear <Chargath, Bane of Scales>",
		[195975] = 6,
		[388815] = "Raszageth",
		[389839] = 12,
		[394958] = 12,
		[36213] = "Greater Earth Elemental <Tetiro-Draenor>",
		[274156] = 6,
		[393935] = 8,
		[399054] = "Raszageth",
		[61295] = 7,
		[388817] = "Granyth",
		[383501] = 8,
		[374485] = "Blazing Fiend",
		[152979] = "Possessed Soul",
		[379404] = "Qalashi Lavabearer",
		[373462] = 5,
		[394961] = 5,
		[204167] = 6,
		[395781] = "Raszageth",
		[361178] = "Morrizane",
		[289308] = 8,
		[391891] = 11,
		[397010] = "Qalashi Honor Guard",
		[215429] = "Valarjar Thundercaller",
		[390868] = "Morrizane",
		[395987] = "Jumping Spiderling",
		[397011] = "Qalashi Honor Guard",
		[389845] = 9,
		[390869] = "Morrizane",
		[387798] = "Morrizane",
		[388822] = "Echo of Doragosa",
		[199050] = "Valarjar Shieldmaiden",
		[394965] = "Qalashi Lavamancer",
		[386556] = 2,
		[21169] = 7,
		[389847] = 12,
		[49184] = 6,
		[114074] = 7,
		[397014] = "Qalashi Emissary",
		[211336] = 5,
		[256893] = 2,
		[5246] = 1,
		[374271] = 6,
		[6201] = 9,
		[394968] = "Qalashi Lavabearer",
		[371422] = 1,
		[57841] = 4,
		[382245] = 4,
		[394969] = "Qalashi Lavabearer",
		[371423] = 1,
		[392922] = "Raszageth",
		[386540] = 8,
		[385952] = 1,
		[387804] = 2,
		[153496] = "Carrion Worm",
		[381662] = "Apex Blazewing",
		[394971] = "Qalashi Lavabearer",
		[371425] = 1,
		[392924] = "High Channeler Ryvati",
		[381663] = "Apex Blazewing",
		[205708] = 8,
		[395996] = 4,
		[186257] = 3,
		[381664] = 4,
		[256896] = 2,
		[152814] = "Shadowmoon Bone-Mender",
		[389860] = 12,
		[389855] = "Draconic Image",
		[394289] = 5,
		[105174] = 9,
		[186258] = 3,
		[381684] = 7,
		[394975] = "Void Lasher <Gorlirn>",
		[117014] = 7,
		[61425] = 5,
		[70890] = 6,
		[394976] = "Void Lasher <Gorlirn>",
		[397785] = "Wise Mari",
		[57842] = 4,
		[389858] = 12,
		[378597] = 7,
		[396001] = "The Songbird Queen",
		[196497] = "Fenryr",
		[24858] = 11,
		[152819] = "Shadowmoon Bone-Mender",
		[387812] = 2,
		[372456] = "Kurog Grimtotem",
		[393955] = 11,
		[394979] = "Void Lasher <Gorlirn>",
		[396003] = "The Songbird Queen",
		[386516] = 12,
		[373481] = 5,
		[390885] = 5,
		[362969] = "Morrizane",
		[190356] = 8,
		[393957] = 11,
		[207760] = 12,
		[387815] = 2,
		[52212] = 6,
		[61391] = 11,
		[317177] = 1,
		[334581] = 9,
		[190357] = 8,
		[393959] = 11,
		[343520] = "[*] Storming",
		[77535] = 6,
		[372461] = "Overseer Lahar",
		[246152] = 3,
		[1161] = 1,
		[232698] = 5,
		[210833] = 8,
		[393961] = 11,
		[355] = 1,
		[263642] = 12,
		[385844] = 12,
		[279302] = 6,
		[392451] = "Flame Channeler",
		[396010] = "The Crybaby Hozen",
		[356084] = 5,
		[279303] = 6,
		[374839] = "Forgemaster Gorek",
		[371441] = "Morrizane",
		[147362] = 3,
		[36554] = 4,
		[45334] = 11,
		[387822] = "Terros",
		[186265] = 3,
		[389870] = "Colossal Stormfiend",
		[375944] = "Blaring Caprine",
		[371984] = "Flashfrost Chillweaver",
		[375055] = "Chargath, Bane of Scales",
		[207311] = 6,
		[395545] = "Azure Spellweaver <Scahra>",
		[228532] = 12,
		[319233] = 6,
		[380174] = "Broodkeeper Diurna",
		[390896] = 12,
		[377105] = "Vault Guard",
		[397039] = 2,
		[381683] = "Nokhud Warspear",
		[374517] = "Forgemaster Gorek",
		[387826] = "Ukhel Beastcaller",
		[372470] = "Morrizane",
		[137639] = 10,
		[382708] = "Qalashi Warden",
		[285452] = 7,
		[397041] = 1,
		[370966] = 12,
		[390899] = 1,
		[396018] = "The Crybaby Hozen",
		[1329] = 4,
		[393971] = 4,
		[324540] = 9,
		[396019] = "The Golden Beetle",
		[397043] = "Cyclas",
		[5394] = 7,
		[185245] = 12,
		[396020] = "The Golden Beetle",
		[384379] = 8,
		[381688] = "Volatile Infuser <Dathea, Ascended>",
		[374043] = "Embar Firepath",
		[392545] = "Awakened Terrasentry",
		[298765] = 7,
		[377594] = "Raszageth",
		[80354] = "Morrizane",
		[396022] = "Eranog",
		[186270] = 3,
		[387504] = "Primal Tsunami",
		[66906] = 2,
		[396023] = "Eranog",
		[49143] = 6,
		[205766] = 8,
		[61684] = "Jochen <Lightør-Blackhand>",
		[382236] = 2,
		[319243] = 6,
		[377597] = "Raszageth",
		[388376] = 5,
		[396025] = "Eranog",
		[31230] = 4,
		[269651] = 8,
		[1449] = 8,
		[202140] = 12,
		[319245] = 6,
		[44949] = 1,
		[199581] = 9,
		[46968] = 1,
		[392956] = 3,
		[203975] = 11,
		[388379] = 12,
		[5938] = 4,
		[388862] = "Corrupted Manafiend",
		[207815] = "Patrol Captain Gerdo",
		[341770] = 4,
		[396029] = "The Golden Beetle",
		[388863] = "Corrupted Manafiend",
		[375750] = 2,
		[395006] = 8,
		[372158] = "Kurog Grimtotem",
		[392959] = 10,
		[207261] = "Patrol Captain Gerdo",
		[390912] = "Vile Lasher",
		[396031] = "Eranog",
		[401150] = 1,
		[385794] = 4,
		[313108] = 3,
		[185763] = 4,
		[388866] = "Corrupted Manafiend",
		[389890] = 12,
		[374534] = "Forgemaster Gorek",
		[387843] = "Spectral Invoker",
		[388867] = 10,
		[213405] = 12,
		[390915] = "Vile Lasher",
		[375591] = "Bubbling Sapling",
		[46585] = 6,
		[34428] = 1,
		[341776] = "Deaadevo-Ragnaros",
		[396035] = "Surging Ruiner",
		[192222] = 7,
		[135601] = 11,
		[390917] = "Morrizane",
		[387846] = 9,
		[17962] = 9,
		[377642] = 6,
		[390918] = "Vile Lasher",
		[387847] = 9,
		[201427] = 12,
		[83242] = 3,
		[386344] = 9,
		[387848] = 5,
		[5405] = 8,
		[386025] = "Primalist Stormspeaker",
		[390920] = "Kurog Grimtotem",
		[387849] = "Dathea, Ascended",
		[384300] = "Akisu",
		[385802] = 4,
		[18562] = 11,
		[372019] = 11,
		[386414] = 3,
		[375602] = "Arcane Tender",
		[272167] = "Bilescourge <Kêrberøs-Arygos>",
		[383756] = 3,
		[278310] = 8,
		[33917] = 11,
		[381933] = 7,
		[373046] = "Melidrussa Chillworn",
		[400169] = 5,
		[207267] = 6,
		[102793] = 11,
		[1725] = 4,
		[19236] = 5,
		[385806] = 4,
		[185565] = 4,
		[31935] = 2,
		[388878] = 5,
		[361237] = 11,
		[33702] = 9,
		[204197] = 5,
		[388879] = 5,
		[342857] = 12,
		[272172] = "Shivarra <Kêrberøs-Arygos>",
		[383761] = 3,
		[266030] = 9,
		[53652] = 2,
		[386833] = 9,
		[289577] = 5,
		[388881] = 5,
		[384823] = "Blazebound Firestorm <Kokia Blazehoof>",
		[383800] = 10,
		[372030] = "Sennarth",
		[388882] = "Infuser Sariya",
		[394001] = 10,
		[392563] = "Quarry Stonebreaker",
		[388407] = "Raging Tempest <Dathea, Ascended>",
		[257946] = 3,
		[385812] = "Volatile Infuser <Dathea, Ascended>",
		[1833] = 4,
		[375575] = "Dragonspawn Flamebender",
		[388884] = "Spellbound Scepter",
		[394003] = 6,
		[319836] = 8,
		[375576] = 2,
		[372505] = 11,
		[385814] = 12,
		[14914] = 5,
		[342817] = 12,
		[392981] = "[*] Blazing Chaos",
		[394005] = 5,
		[374554] = "[*] Magma Pool",
		[375578] = "Dragonspawn Flamebender",
		[116705] = 10,
		[394006] = 1,
		[382272] = 8,
		[387474] = "Primal Tsunami",
		[392983] = 10,
		[231843] = 2,
		[390936] = 1,
		[375580] = "Dathea, Ascended",
		[380699] = 1,
		[18499] = 1,
		[374557] = 6,
		[396056] = "Kurog Grimtotem",
		[382277] = "Balara",
		[394009] = 3,
		[390938] = "Aggravated Skitterfly",
		[121093] = 10,
		[278326] = 12,
		[381725] = 7,
		[385941] = 11,
		[84714] = 8,
		[390195] = 12,
		[394011] = 3,
		[31616] = 7,
		[371489] = "Flashfrost Chillweaver",
		[372055] = "Sennarth",
		[377763] = 6,
		[193455] = 3,
		[375585] = 12,
		[380704] = 10,
		[377633] = 6,
		[390942] = "Aggravated Skitterfly",
		[387871] = 12,
		[377166] = "Terros",
		[291639] = 6,
		[374563] = "Dazzling Dragonfly",
		[391967] = "The Raging Tempest",
		[371028] = 6,
		[365350] = 8,
		[390944] = "Aggravated Skitterfly",
		[85739] = 1,
		[2050] = 5,
		[45181] = 4,
		[153640] = 8,
		[259489] = 3,
		[383312] = 6,
		[207278] = "Patrol Captain Gerdo",
		[2098] = 4,
		[187827] = 12,
		[371033] = 5,
		[107574] = 1,
		[374567] = "Leymor",
		[383781] = 1,
		[193743] = 1,
		[104316] = 9,
		[382294] = 8,
		[8676] = 4,
		[397091] = 3,
		[122121] = 5,
		[214743] = 12,
		[396068] = "Kurog Grimtotem",
		[768] = 11,
		[394021] = 4,
		[374570] = "Leymor",
		[203819] = 12,
		[236776] = 3,
		[112870] = 9,
		[382761] = 2,
		[198067] = 7,
		[373089] = "Irontorch Commander",
		[398118] = 12,
		[199603] = 4,
		[228780] = 1,
		[384810] = 2,
		[45182] = 4,
		[198892] = "Storm Drake",
		[57723] = 2,
		[5740] = 9,
		[316220] = 4,
		[274838] = 11,
		[396073] = "The Nodding Tiger",
		[368432] = "Akisu",
		[49821] = 5,
		[323558] = 4,
		[202164] = 1,
		[58875] = 7,
		[365362] = 8,
		[195182] = 6,
		[386354] = "Opalfang",
		[388909] = 3,
		[114919] = 2,
		[115175] = 10,
		[259495] = 3,
		[397100] = "Magmas",
		[369459] = "Morrizane",
		[374578] = "Dazzling Dragonfly",
		[204213] = 5,
		[388911] = "Spellbound Battleaxe",
		[291655] = 8,
		[200758] = 4,
		[202166] = 1,
		[388912] = "Spellbound Battleaxe",
		[394031] = 4,
		[360826] = 4,
		[285514] = 7,
		[364343] = "Morrizane",
		[122] = 8,
		[115176] = 10,
		[157122] = 2,
		[117313] = 1,
		[381748] = "Morrizane",
		[374582] = "Leymor",
		[119381] = 10,
		[703] = 4,
		[373559] = "Sennarth",
		[280398] = 5,
		[202168] = 1,
		[393584] = "Horned Armoredon",
		[379256] = "Draconic Illusion",
		[390964] = 5,
		[184575] = 2,
		[394582] = "Morrizane",
		[394036] = 4,
		[374585] = 6,
		[371514] = "Embar Firepath",
		[388918] = "Broodkeeper Diurna",
		[162243] = 12,
		[374586] = "Forgemaster Gorek",
		[30146] = 9,
		[376634] = "Balakar Khan",
		[377658] = "Raszageth",
		[212988] = 12,
		[84721] = 8,
		[388920] = "Broodkeeper Diurna",
		[207289] = 6,
		[396424] = "Chargath, Bane of Scales",
		[392569] = "Flamegullet",
		[2818] = 4,
		[381755] = 7,
		[396665] = "Magmas",
		[93985] = 11,
		[372542] = "Irontorch Commander",
		[395003] = 4,
		[374625] = "Frozen Destroyer",
		[195072] = 12,
		[397113] = "Eranog",
		[377662] = "Raszageth",
		[390971] = 5,
		[400185] = 9,
		[198589] = 12,
		[119914] = 9,
		[386877] = 3,
		[213241] = 12,
		[397115] = "[*] Incinerate",
		[320334] = 12,
		[43265] = 6,
		[157128] = 2,
		[198590] = 9,
		[381760] = 11,
		[154671] = "Ner'zhul",
		[396093] = "The Nodding Tiger",
		[196543] = "Fenryr",
		[381761] = 7,
		[19483] = "Infernal <Nyashia-Silvermoon>",
		[391099] = 5,
		[397118] = 3,
		[394047] = 11,
		[378016] = 3,
		[116014] = 8,
		[102383] = 11,
		[320338] = 12,
		[197568] = 7,
		[383811] = 8,
		[185358] = 3,
		[394049] = 11,
		[390978] = 5,
		[285515] = 7,
		[388931] = 10,
		[394050] = 11,
		[853] = 2,
		[157131] = 2,
		[395669] = "Maruuk",
		[8613] = 12,
		[22568] = 11,
		[383814] = 12,
		[245686] = 1,
		[51399] = 6,
		[115181] = 10,
		[387910] = "Algeth'ar Echoknight",
		[157644] = 8,
		[211391] = "Legion Hound",
		[256948] = 6,
		[108271] = 7,
		[327510] = 2,
		[381769] = 2,
		[386888] = 7,
		[194249] = 5,
		[235450] = 8,
		[398150] = "Shadowmoon Dominator",
		[114158] = 2,
		[383818] = 4,
		[370602] = 11,
		[398151] = "Shadowmoon Loyalist",
		[164812] = 11,
		[381349] = "Broodkeeper Diurna",
		[382249] = "Trickclaw Mystic",
		[385444] = 12,
		[370511] = 4,
		[183752] = 12,
		[396194] = 1,
		[386208] = 1,
		[375082] = "Dathea, Ascended",
		[81281] = 11,
		[388940] = "Arcane Ravager",
		[398154] = "Defiled Spirit",
		[288613] = 3,
		[232893] = 12,
		[372561] = "Qalashi Hunter",
		[381775] = "Terros",
		[390989] = 5,
		[383823] = "Nokhud Hornsounder",
		[388942] = "Arcane Ravager",
		[394061] = 11,
		[228287] = 10,
		[375634] = "Drakonid Stormbringer",
		[274283] = 11,
		[394062] = 1,
		[164815] = 11,
		[372015] = 11,
		[384849] = 8,
		[383351] = 2,
		[374612] = "Skulking Zealot",
		[186401] = 12,
		[376660] = "Balakar Khan",
		[357209] = "Morrizane",
		[390993] = 5,
		[148022] = 8,
		[214980] = 6,
		[357210] = "Drakares-GrimBatol",
		[388544] = "Overgrown Ancient",
		[114216] = 5,
		[66] = 8,
		[381781] = "Terros",
		[209862] = "[*] Volcanic Plume",
		[388007] = 2,
		[190411] = 1,
		[257542] = 8,
		[228290] = 6,
		[43308] = 11,
		[3714] = 6,
		[134359] = 3,
		[246854] = 3,
		[1126] = 11,
		[51714] = 6,
		[357214] = "Morrizane",
		[187878] = 7,
		[212423] = "Risen Skulker <Astranith>",
		[372571] = "Morrizane",
		[176179] = 8,
		[388424] = "Primal Tsunami",
		[113394] = "Strife",
		[393047] = 10,
		[154175] = "Bonemaw",
		[195627] = 4,
		[106228] = "Sha of Doubt",
		[321529] = 8,
		[199361] = "Valarjar Trapper",
		[374621] = "Thundering Ravager",
		[387036] = 11,
		[194509] = 5,
		[211401] = "Blazing Imp",
		[374622] = "Thundering Ravager",
		[370665] = "Morrizane",
		[393050] = 10,
		[385884] = 8,
		[395098] = 12,
		[387932] = "Algeth'ar Echoknight",
		[214985] = 6,
		[386181] = "Vexamus <Magic Book>",
		[374624] = "Frozen Destroyer",
		[216521] = 10,
		[388957] = "Arcane Ravager",
		[90361] = "ЛокеНахак <Шадовхант-Ясеневыйлес>",
		[35079] = 3,
		[375649] = "Arcane Tender",
		[393053] = 10,
		[374776] = 6,
		[97341] = 7,
		[375950] = "Primalist Icecaller",
		[393054] = 12,
		[191037] = 11,
		[386912] = "[*] Stormsurge Cloud",
		[366742] = 11,
		[255937] = 2,
		[162264] = 12,
		[391008] = 11,
		[49028] = 6,
		[393056] = 10,
		[385890] = 1,
		[384004] = 10,
		[383843] = 2,
		[203415] = 3,
		[199852] = 1,
		[12654] = 8,
		[193092] = "Hymdall",
		[384868] = "Nokhud Longbow",
		[387080] = 2,
		[386916] = "The Raging Tempest",
		[381967] = 4,
		[215204] = "Vigilant Duskwatch",
		[394083] = 11,
		[370537] = "Morrizane",
		[392036] = "Morrizane",
		[162480] = 3,
		[388115] = "Raszageth",
		[51460] = 6,
		[132578] = 10,
		[124507] = 10,
		[308506] = "Hyraie-Hyjal",
		[382824] = 8,
		[212431] = 3,
		[167898] = 2,
		[205386] = 5,
		[395110] = 11,
		[48517] = 11,
		[376683] = "Balakar Khan",
		[385897] = 4,
		[386921] = "Dragonkiller Lance",
		[204242] = 2,
		[124988] = 11,
		[377708] = 4,
		[209485] = "Arcane Manifestation",
		[55090] = 6,
		[376685] = "Balakar Khan",
		[385899] = 9,
		[148135] = 10,
		[290948] = 7,
		[385073] = "Colossal Stormfiend",
		[387131] = "Dragonkiller Lance",
		[391019] = "Kurog Grimtotem",
		[109304] = 3,
		[372765] = "Sennarth",
		[63106] = 9,
		[135286] = 11,
		[17057] = 11,
		[388973] = "Morrizane",
		[192611] = 12,
		[115191] = 4,
		[385078] = "Crackling Vortex",
		[124503] = 10,
		[385903] = 8,
		[391022] = "Kurog Grimtotem",
		[108281] = 7,
		[345228] = 9,
		[336126] = 6,
		[280735] = 1,
		[48518] = 11,
		[388976] = "Arcane Ravager",
		[344955] = 6,
		[32645] = 4,
		[212436] = 3,
		[384882] = "[*] Stormsurge Lightning",
		[385906] = 8,
		[345980] = 6,
		[396144] = 2,
		[374854] = "Grounding Spear <Chargath, Bane of Scales>",
		[385907] = 4,
		[382836] = "Maruuk",
		[54149] = 2,
		[114255] = 5,
		[125174] = 10,
		[358267] = "Morrizane",
		[367481] = "Cruel Bonecrusher",
		[8690] = 11,
		[386277] = "Terros",
		[370553] = "Morrizane",
		[390371] = 7,
		[384014] = "Watcher Irideus",
		[63619] = "Mindbender <Gorlirn>",
		[370772] = 2,
		[347008] = "Dag'arad <Kêrberøs-Arygos>",
		[388982] = "Arcane Ravager",
		[394101] = 2,
		[234946] = 5,
		[367484] = "Claw Fighter",
		[372963] = "Melidrussa Chillworn",
		[217694] = 8,
		[391031] = "Primal Thundercloud",
		[367485] = "Claw Fighter",
		[388984] = "Arcane Ravager",
		[392280] = "Kaurdyth",
		[378747] = 3,
		[297871] = 10,
		[381957] = 8,
		[400474] = "Stormsurge Totem",
		[185311] = 4,
		[11366] = 8,
		[370817] = 4,
		[398200] = "[*] Djaradin Lava",
		[397407] = 11,
		[392058] = 3,
		[270232] = 8,
		[385916] = "Granyth",
		[392296] = 3,
		[23240] = 1,
		[372608] = 3,
		[390216] = 12,
		[388011] = 2,
		[392060] = 3,
		[378994] = 12,
		[394108] = 11,
		[370562] = "Morrizane",
		[392061] = 3,
		[372610] = 6,
		[381824] = 2,
		[384114] = 11,
		[108285] = 7,
		[155625] = 11,
		[386164] = 1,
		[370564] = "Morrizane",
		[44425] = 8,
		[394354] = 1,
		[398206] = "Exhumed Spirit",
		[120360] = 3,
		[187874] = 7,
		[12294] = 1,
		[394112] = 10,
		[108366] = 9,
		[153067] = "Nhallish",
		[202719] = 12,
		[382089] = 7,
		[199805] = "Stormforged Sentinel",
		[204255] = 12,
		[372615] = "Tamed Phoenix",
		[375943] = "Balakar Khan",
		[315341] = 4,
		[390276] = 6,
		[388996] = "[*] Energy Eruption",
		[312215] = 3,
		[162794] = 12,
		[8679] = 4,
		[387976] = 9,
		[267171] = 9,
		[378760] = 8,
		[260708] = 1,
		[388998] = 3,
		[47753] = 5,
		[384246] = 6,
		[30151] = "Dag'arad <Kêrberøs-Arygos>",
		[188389] = 7,
		[48265] = 6,
		[201846] = 7,
		[64901] = 5,
		[268467] = 8,
		[72968] = 4,
		[296863] = 4,
		[77575] = 6,
		[384906] = 2,
		[390299] = 9,
		[375985] = 7,
		[396168] = 10,
		[191634] = 7,
		[361361] = "Morrizane",
		[391050] = "High Channeler Ryvati",
		[209036] = "Duskwatch Sentry",
		[375986] = 7,
		[209378] = "Imacu'tya",
		[219788] = 6,
		[153072] = "Nhallish",
		[393099] = 10,
		[391215] = 12,
		[387261] = "Raszageth",
		[215956] = 9,
		[198813] = 12,
		[119582] = 10,
		[214169] = 1,
		[359317] = 1,
		[374994] = 9,
		[23881] = 1,
		[391054] = 2,
		[342938] = 9,
		[389007] = "[*] Wild Energy",
		[372971] = "Qalashi Blacksmith",
		[378770] = 3,
		[391403] = 5,
		[376723] = "Nokhud Stormcaster",
		[48778] = 6,
		[391056] = "Kurog Grimtotem",
		[371459] = 1,
	},
	["shield_spellid_cache"] = {
	},
	["latest_encounter_spell_pool_access"] = 1676570530,
	["auto_open_news_window"] = true,
	["got_first_run"] = true,
	["deathlog_healingdone_min"] = 1,
	["all_switch_config"] = {
		["scale"] = 1,
		["font_size"] = 10,
	},
	["update_warning_timeout"] = 10,
	["__profiles"] = {
		["Bhrian-Blackmoore"] = {
			["overall_clear_newtorghast"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["default_bg_color"] = 0.0941,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["update_interval"] = 0.3,
				["text_offset"] = 2,
				["font_face"] = "Friz Quadrata TT",
				["options_frame"] = {
				},
			},
			["animation_speed"] = 33,
			["default_bg_alpha"] = 0.5,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["instances_no_libwindow"] = false,
			["standard_skin"] = false,
			["disable_window_groups"] = false,
			["animate_scroll"] = false,
			["use_battleground_server_parser"] = false,
			["instances_suppress_trash"] = 0,
			["clear_ungrouped"] = true,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["force_activity_time_pvp"] = true,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["pvp_as_group"] = true,
			["numerical_system"] = 1,
			["report_lines"] = 5,
			["segments_amount"] = 40,
			["overall_clear_pvp"] = true,
			["auto_swap_to_dynamic_overall"] = false,
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["overall_clear_newboss"] = true,
			["overall_flag"] = 16,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["minimum_combat_time"] = 5,
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["use_scroll"] = false,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["disable_alldisplays_window"] = false,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["version"] = 1,
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
			},
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["broadcaster_enabled"] = false,
			["clear_graphic"] = true,
			["total_abbreviation"] = 2,
			["animation_speed_triggertravel"] = 5,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 40,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["trash_auto_remove"] = false,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["overall_clear_logout"] = false,
			["deny_score_messages"] = false,
			["segments_panic_mode"] = false,
			["show_arena_role_icon"] = false,
			["time_type_original"] = 2,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -289.9190521240234,
							["x"] = 478.615478515625,
							["w"] = 310,
							["h"] = 158,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["clickthrough_window"] = false,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["micro_displays_locked"] = true,
					["use_auto_align_multi_fontstrings"] = true,
					["rowareaborder_shown"] = false,
					["fullborder_shown"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["show_arena_role_icon"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["percent_type"] = 1,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["font_size"] = 16,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["show_faction_icon"] = true,
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["textL_enable_custom_text"] = false,
						["textL_outline_small"] = true,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["texture_custom_file"] = "Interface\\",
						["arena_role_icon_size_offset"] = -10,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["use_spec_icons"] = true,
						["textR_bracket"] = "(",
						["textR_enable_custom_text"] = false,
						["start_after_icon"] = true,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_background"] = "Details D'ictum (reverse)",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["texture_custom"] = "",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textR_outline"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["icon_desaturated"] = false,
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["__was_opened"] = true,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["skin"] = "Minimalistic",
					["show_sidebars"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["bars_inverted"] = false,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["fontstrings_text_limit_offset"] = -10,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["fontstrings_text3_anchor"] = 38,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["timeType"] = 1,
								["textAlign"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["switch_tank_in_combat"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["clickthrough_rows"] = false,
					["bars_sort_direction"] = 1,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["skin_custom"] = "",
					["hide_in_combat_alpha"] = 0,
					["ignore_mass_showhide"] = false,
					["switch_damager_in_combat"] = false,
					["libwindow"] = {
						["y"] = 57.74760055541992,
						["x"] = -26.438232421875,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_grow_direction"] = 1,
					["strata"] = "LOW",
					["backdrop_texture"] = "Details Ground",
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["grab_on_top"] = false,
					["hide_in_combat_type"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["auto_current"] = true,
					["switch_damager"] = false,
					["plugins_grow_direction"] = 1,
					["bg_alpha"] = 0.6,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -289.9190521240234,
							["x"] = 478.615478515625,
							["w"] = 310,
							["h"] = 158,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["menu_icons_size"] = 0.82,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["switch_all_roles_in_combat"] = false,
					["use_multi_fontstrings"] = true,
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["time_type"] = 2,
			["death_tooltip_width"] = 350,
			["report_schema"] = 1,
			["numerical_system_symbols"] = "auto",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["ps_abbreviation"] = 3,
			["instances_segments_locked"] = true,
			["deadlog_limit"] = 16,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
		},
		["Scahra-Blackmoore"] = {
			["overall_clear_newtorghast"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["disable_mythic_dungeon"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["default_bg_color"] = 0.0941,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2000000029802322,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
			["animation_speed"] = 33,
			["deadlog_limit"] = 16,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["instances_segments_locked"] = true,
			["ps_abbreviation"] = 3,
			["disable_window_groups"] = false,
			["data_broker_text"] = "",
			["use_battleground_server_parser"] = false,
			["instances_suppress_trash"] = 0,
			["clear_ungrouped"] = true,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["numerical_system_symbols"] = "auto",
			["report_schema"] = 1,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["death_tooltip_width"] = 350,
			["time_type"] = 2,
			["segments_amount"] = 40,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -344.8017349243164,
							["x"] = 377.119384765625,
							["w"] = 146.8962554931641,
							["h"] = 163.7298431396484,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["clickthrough_window"] = false,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["bars_sort_direction"] = 1,
					["use_auto_align_multi_fontstrings"] = true,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["fullborder_shown"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textL_outline_small"] = true,
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
							["enabled"] = false,
							["size"] = 12,
						},
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["height"] = 17,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["use_spec_icons"] = true,
						["percent_type"] = 1,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["show_faction_icon"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["arena_role_icon_size_offset"] = -10,
						["textR_bracket"] = "(",
						["texture_custom"] = "",
						["show_arena_role_icon"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["textL_class_colors"] = false,
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background"] = "Details D'ictum (reverse)",
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["textR_enable_custom_text"] = false,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["start_after_icon"] = true,
						["fast_ps_update"] = true,
						["textR_separator"] = "NONE",
						["font_size"] = 15,
					},
					["titlebar_texture"] = "Details Serenity",
					["ignore_mass_showhide"] = false,
					["plugins_grow_direction"] = 1,
					["icon_desaturated"] = false,
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["__snapH"] = true,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_inverted"] = false,
					["skin"] = "Minimalistic",
					["__was_opened"] = true,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["switch_tank"] = false,
					["grab_on_top"] = false,
					["use_multi_fontstrings"] = true,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["fontstrings_text3_anchor"] = 38,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["show_sidebars"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["switch_tank_in_combat"] = false,
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["menu_icons_size"] = 0.82,
					["micro_displays_locked"] = true,
					["backdrop_texture"] = "Details Ground",
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
						2, -- [1]
					},
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["hide_in_combat_alpha"] = 0,
					["rowareaborder_shown"] = false,
					["clickthrough_rows"] = false,
					["libwindow"] = {
						["y"] = 0,
						["x"] = -209.4862060546875,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["bars_grow_direction"] = 1,
					["show_statusbar"] = false,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["strata"] = "LOW",
					["switch_damager_in_combat"] = false,
					["switch_damager"] = false,
					["switch_all_roles_after_wipe"] = false,
					["auto_current"] = true,
					["bg_alpha"] = 0.6,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["show_timer"] = true,
						["enable_custom_text"] = false,
						["show_timer_bg"] = true,
					},
					["switch_all_roles_in_combat"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -344.8017349243164,
							["x"] = 377.119384765625,
							["w"] = 146.8962554931641,
							["h"] = 163.7298431396484,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["fontstrings_text_limit_offset"] = -10,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["skin_custom"] = "",
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -344.8017196655273,
							["x"] = 238.4356079101563,
							["w"] = 130.4713287353516,
							["h"] = 163.7298736572266,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["fontstrings_text3_anchor"] = 38,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["skin_custom"] = "",
					["use_auto_align_multi_fontstrings"] = true,
					["rowareaborder_shown"] = false,
					["fullborder_shown"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["show_arena_role_icon"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["percent_type"] = 1,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["start_after_icon"] = true,
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["size"] = 12,
							["enabled"] = false,
							["texture"] = "Details BarBorder 2",
						},
						["font_size"] = 15,
						["height"] = 17,
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["textL_translit_text"] = false,
						["texture_custom_file"] = "Interface\\",
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["use_spec_icons"] = true,
						["show_faction_icon"] = true,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["textL_enable_custom_text"] = false,
						["textL_outline_small"] = true,
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["icon_grayscale"] = false,
						["arena_role_icon_size_offset"] = -10,
						["textR_bracket"] = "(",
						["textR_enable_custom_text"] = false,
						["textR_outline"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textL_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_background"] = "Details D'ictum (reverse)",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["textR_class_colors"] = false,
						["alpha"] = 1,
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["texture_custom"] = "",
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["fast_ps_update"] = true,
						["textR_separator"] = "NONE",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["icon_desaturated"] = false,
					["switch_damager"] = false,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["__snapV"] = false,
					["__snapH"] = true,
					["menu_icons_size"] = 0.82,
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["skin"] = "Minimalistic",
					["__was_opened"] = true,
					["following"] = {
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["enabled"] = false,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["fontstrings_text_limit_offset"] = -10,
					["switch_tank_in_combat"] = false,
					["use_multi_fontstrings"] = true,
					["bars_grow_direction"] = 1,
					["bars_inverted"] = false,
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 3,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 2,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["clickthrough_window"] = false,
					["bg_g"] = 0.2352,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["micro_displays_locked"] = true,
					["bars_sort_direction"] = 1,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
						[3] = 1,
					},
					["micro_displays_side"] = 2,
					["hide_in_combat_alpha"] = 0,
					["hide_in_combat_type"] = 1,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["libwindow"] = {
						["y"] = 0,
						["x"] = 238.4355773925781,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["desaturated_menu"] = false,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["backdrop_texture"] = "Details Ground",
					["plugins_grow_direction"] = 1,
					["strata"] = "LOW",
					["grab_on_top"] = false,
					["ignore_mass_showhide"] = false,
					["clickthrough_rows"] = false,
					["auto_current"] = true,
					["bg_alpha"] = 0.6,
					["switch_all_roles_in_combat"] = false,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["enable_custom_text"] = false,
						["show_timer"] = true,
						["show_timer_bg"] = true,
					},
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -344.8017196655273,
							["x"] = 238.4356079101563,
							["w"] = 130.4713287353516,
							["h"] = 163.7298736572266,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["show_sidebars"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["height"] = 114.042518615723,
						["anchor"] = "all",
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["stretch_button_side"] = 1,
					["titlebar_height"] = 16,
					["switch_damager_in_combat"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [2]
			},
			["overall_clear_pvp"] = true,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["time_type_original"] = 2,
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["show_arena_role_icon"] = false,
			["overall_flag"] = 16,
			["deny_score_messages"] = false,
			["minimum_combat_time"] = 5,
			["overall_clear_logout"] = false,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["use_scroll"] = false,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["disable_alldisplays_window"] = false,
			["total_abbreviation"] = 2,
			["trash_auto_remove"] = false,
			["animation_speed_triggertravel"] = 5,
			["segments_amount_to_save"] = 40,
			["clear_graphic"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = false,
				["minimapPos"] = 261.7143896509058,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["version"] = 1,
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["segments_panic_mode"] = false,
			["overall_clear_newboss"] = true,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["report_lines"] = 5,
			["numerical_system"] = 1,
			["pvp_as_group"] = true,
			["force_activity_time_pvp"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["standard_skin"] = false,
			["instances_no_libwindow"] = false,
			["default_bg_alpha"] = 0.5,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["font_face"] = "Friz Quadrata TT",
				["text_offset"] = 2,
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
		},
		["Zakarum-Blackmoore"] = {
			["overall_clear_newtorghast"] = true,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["disable_mythic_dungeon"] = false,
				["use_animation_accel"] = true,
			},
			["all_players_are_group"] = false,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["remove_realm_from_name"] = true,
			["minimum_overall_combat_time"] = 10,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0.16, -- [1]
						0.16, -- [2]
						0.16, -- [3]
						0.47, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
			["report_to_who"] = "",
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[1467] = {
					0.5, -- [1]
					0.625, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[1468] = {
					0.625, -- [1]
					0.75, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.125, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[260] = {
					0, -- [1]
					0.125, -- [2]
					0.75, -- [3]
					0.875, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["all_in_one_windows"] = {
			},
			["tooltip"] = {
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["bar_color"] = {
					0.396, -- [1]
					0.396, -- [2]
					0.396, -- [3]
					0.87, -- [4]
				},
				["tooltip_max_pets"] = 2,
				["abbreviation"] = 2,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["background"] = {
					0.0941, -- [1]
					0.0941, -- [2]
					0.0941, -- [3]
					0.8, -- [4]
				},
				["divisor_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontshadow"] = false,
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["line_height"] = 17,
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 17,
					["H"] = 17,
				},
				["anchor_relative"] = "top",
				["anchored_to"] = 1,
				["show_amount"] = false,
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["commands"] = {
				},
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["border_size"] = 14,
				["maximize_method"] = 1,
				["tooltip_max_abilities"] = 6,
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["icon_border_texcoord"] = {
					["R"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["B"] = 0.921875,
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["default_bg_color"] = 0.0941,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.2,
			["bookmark_text_size"] = 11,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = false,
			["fade_speed"] = 0.15,
			["death_tooltip_spark"] = false,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["use_self_color"] = false,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["death_log_colors"] = {
				["debuff"] = "purple",
				["buff"] = "silver",
				["friendlyfire"] = "darkorange",
				["heal"] = "green",
				["cooldown"] = "yellow",
				["damage"] = "red",
			},
			["animation_speed"] = 33,
			["deadlog_limit"] = 16,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["instances_segments_locked"] = true,
			["ps_abbreviation"] = 3,
			["disable_window_groups"] = false,
			["data_broker_text"] = "",
			["use_battleground_server_parser"] = false,
			["instances_suppress_trash"] = 0,
			["clear_ungrouped"] = true,
			["options_window"] = {
				["scale"] = 1,
			},
			["animation_speed_maxtravel"] = 3,
			["numerical_system_symbols"] = "auto",
			["report_schema"] = 1,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["death_tooltip_width"] = 350,
			["time_type"] = 2,
			["segments_amount"] = 40,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -347.6666564941406,
							["x"] = 505.0537109375,
							["w"] = 310,
							["h"] = 158,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["show_statusbar"] = false,
					["clickthrough_window"] = false,
					["titlebar_shown"] = false,
					["menu_anchor"] = {
						20, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["bg_r"] = 0.243,
					["fullborder_size"] = 0.5,
					["hide_out_of_combat"] = false,
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons_2_shadow",
					["micro_displays_locked"] = true,
					["use_auto_align_multi_fontstrings"] = true,
					["rowareaborder_shown"] = false,
					["switch_all_roles_in_combat"] = false,
					["clickthrough_toolbaricons"] = false,
					["row_info"] = {
						["show_arena_role_icon"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							false, -- [3]
						},
						["percent_type"] = 1,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["faction_icon_size_offset"] = -10,
						["backdrop"] = {
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
							["enabled"] = false,
							["size"] = 12,
						},
						["font_size"] = 16,
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["show_faction_icon"] = true,
						["textL_translit_text"] = false,
						["height"] = 21,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_hyanda",
						["icon_size_offset"] = 0,
						["textL_enable_custom_text"] = false,
						["textR_outline"] = false,
						["overlay_color"] = {
							0.7, -- [1]
							0.7, -- [2]
							0.7, -- [3]
							0, -- [4]
						},
						["texture_custom_file"] = "Interface\\",
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small",
						["arena_role_icon_size_offset"] = -10,
						["icon_grayscale"] = false,
						["textR_enable_custom_text"] = false,
						["textR_bracket"] = "(",
						["texture_custom"] = "",
						["start_after_icon"] = true,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["textL_class_colors"] = false,
						["alpha"] = 1,
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["texture"] = "Details Hyanda",
						["texture_background"] = "Details D'ictum (reverse)",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["overlay_texture"] = "Details D'ictum",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["no_icon"] = false,
						["icon_offset"] = {
							0, -- [1]
							0, -- [2]
						},
						["use_spec_icons"] = true,
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_outline_small"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = "NONE",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
					},
					["titlebar_texture"] = "Details Serenity",
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["icon_desaturated"] = false,
					["desaturated_menu"] = false,
					["micro_displays_side"] = 2,
					["window_scale"] = 1,
					["hide_icon"] = false,
					["toolbar_side"] = 1,
					["bg_g"] = 0.2352,
					["menu_icons_alpha"] = 0.92,
					["bg_b"] = 0.2588,
					["switch_healer_in_combat"] = false,
					["color"] = {
						0.1215, -- [1]
						0.1176, -- [2]
						0.1294, -- [3]
						0.91, -- [4]
					},
					["hide_on_context"] = {
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [1]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [2]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [3]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [4]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [5]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [6]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [7]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [8]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [9]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [10]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [11]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [12]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [13]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [14]
						{
							["enabled"] = false,
							["inverse"] = false,
							["value"] = 100,
						}, -- [15]
					},
					["__was_opened"] = true,
					["use_multi_fontstrings"] = true,
					["skin"] = "Minimalistic",
					["fullborder_shown"] = false,
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["bars_inverted"] = false,
					["switch_healer"] = false,
					["fontstrings_text2_anchor"] = 73,
					["stretch_button_side"] = 1,
					["fontstrings_text_limit_offset"] = -10,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -2,
						["shadow"] = false,
					},
					["menu_icons_size"] = 0.82,
					["rowareaborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PSEGMENT"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["segmentType"] = 2,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 1,
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_PSEGMENT",
					},
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["version"] = 3,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["bg_alpha"] = 0.6,
					["fontstrings_text4_anchor"] = 0,
					["__locked"] = false,
					["menu_alpha"] = {
						["enabled"] = false,
						["onleave"] = 1,
						["ignorebars"] = false,
						["iconstoo"] = true,
						["onenter"] = 1,
					},
					["plugins_grow_direction"] = 1,
					["switch_damager"] = false,
					["bars_sort_direction"] = 1,
					["rowareaborder_size"] = 0.5,
					["clickthrough_incombatonly"] = true,
					["__snap"] = {
					},
					["fullborder_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["hide_in_combat_alpha"] = 0,
					["hide_in_combat_type"] = 1,
					["grab_on_top"] = false,
					["libwindow"] = {
						["y"] = 0,
						["x"] = 0,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["statusbar_info"] = {
						["alpha"] = 0.3777777777777,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["bars_grow_direction"] = 1,
					["backdrop_texture"] = "Details Ground",
					["strata"] = "LOW",
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["switch_damager_in_combat"] = false,
					["ignore_mass_showhide"] = false,
					["skin_custom"] = "",
					["auto_current"] = true,
					["clickthrough_rows"] = false,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["show_timer_arena"] = true,
						["text_face"] = "Accidental Presidency",
						["show_timer_always"] = true,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = {
							1.4, -- [1]
							2, -- [2]
						},
						["show_timer"] = true,
						["enable_custom_text"] = false,
						["show_timer_bg"] = true,
					},
					["switch_tank_in_combat"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -347.6666564941406,
							["x"] = 505.0537109375,
							["w"] = 310,
							["h"] = 158,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["fontstrings_text3_anchor"] = 38,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["wallpaper"] = {
						["enabled"] = false,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["level"] = 2,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["titlebar_height"] = 16,
					["show_sidebars"] = false,
					["menu_icons_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["titlebar_texture_color"] = {
						0.2, -- [1]
						0.2, -- [2]
						0.2, -- [3]
						0.8, -- [4]
					},
				}, -- [1]
			},
			["overall_clear_pvp"] = true,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["time_type_original"] = 2,
			["skin"] = "Minimalistic",
			["override_spellids"] = true,
			["show_arena_role_icon"] = false,
			["overall_flag"] = 16,
			["minimum_combat_time"] = 5,
			["deny_score_messages"] = false,
			["overall_clear_logout"] = false,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 158,
				["width"] = 310,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["use_scroll"] = false,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["SHAMAN"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["PET"] = {
					0.125, -- [1]
					0.248046875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DRUID"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["MONK"] = {
					0.25, -- [1]
					0.369140625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["UNKNOW"] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["PRIEST"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["WARLOCK"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				["Alliance"] = {
					0.248046875, -- [1]
					0.02968748, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["DEMONHUNTER"] = {
					0.36914063, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				["Horde"] = {
					0.37109375, -- [1]
					0.494140625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				["EVOKER"] = {
					0.50390625, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				["ROGUE"] = {
					0.248046875, -- [1]
					0.37109375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
			},
			["profile_save_pos"] = true,
			["disable_alldisplays_window"] = false,
			["total_abbreviation"] = 2,
			["trash_auto_remove"] = false,
			["animation_speed_triggertravel"] = 5,
			["segments_amount_to_save"] = 40,
			["clear_graphic"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["broadcaster_enabled"] = false,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["hide"] = false,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["text_type"] = 1,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					1, -- [1]
					1, -- [2]
					0.25, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["version"] = 1,
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["ARENA_GREEN"] = {
					0.686, -- [1]
					0.372, -- [2]
					0.905, -- [3]
				},
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["EVOKER"] = {
					0.2, -- [1]
					0.5764, -- [2]
					0.498, -- [3]
				},
				["SELF"] = {
					0.89019, -- [1]
					0.32156, -- [2]
					0.89019, -- [3]
				},
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["chat_tab_embed"] = {
				["enabled"] = false,
				["y_offset"] = 0,
				["x_offset"] = 0,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["font_sizes"] = {
				["menus"] = 10,
			},
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["segments_panic_mode"] = false,
			["overall_clear_newboss"] = true,
			["player_details_window"] = {
				["scale"] = 1,
				["skin"] = "ElvUI",
				["bar_texture"] = "Skyline",
			},
			["auto_swap_to_dynamic_overall"] = false,
			["report_lines"] = 5,
			["numerical_system"] = 1,
			["pvp_as_group"] = true,
			["force_activity_time_pvp"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["death_tooltip_texture"] = "Details Serenity",
			["disable_reset_button"] = false,
			["animate_scroll"] = false,
			["standard_skin"] = false,
			["instances_no_libwindow"] = false,
			["default_bg_alpha"] = 0.5,
			["realtime_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = false,
				["sample_size"] = 3,
				["frame_settings"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["point"] = "TOP",
					["scale"] = 1,
					["width"] = 300,
					["y"] = -110,
					["x"] = 0,
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = true,
					["height"] = 23,
				},
				["font_face"] = "Friz Quadrata TT",
				["text_offset"] = 2,
				["update_interval"] = 0.3,
				["options_frame"] = {
				},
			},
		},
	},
	["immersion_special_units"] = true,
	["installed_skins_cache"] = {
	},
	["boss_mods_timers"] = {
		["encounter_timers_bw"] = {
		},
		["latest_boss_mods_access"] = 1676570530,
		["encounter_timers_dbm"] = {
			["371624"] = {
				"371624", -- [1]
				"Timer371624cdcount	1", -- [2]
				"~Conductive Mark (1)", -- [3]
				15.7, -- [4]
				237587, -- [5]
				"cdcount", -- [6]
				371624, -- [7]
				3, -- [8]
				"2486", -- [9]
				["id"] = 2590,
			},
			["373027"] = {
				"373027", -- [1]
				"Timer373027cdcount	1", -- [2]
				"~Suffocating Webs (1)", -- [3]
				18.1, -- [4]
				237431, -- [5]
				"cdcount", -- [6]
				373027, -- [7]
				3, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["390548"] = {
				"390548", -- [1]
				"Timer390548cd", -- [2]
				"~Sundering Strike", -- [3]
				8, -- [4]
				135906, -- [5]
				"cd", -- [6]
				390548, -- [7]
				5, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["396023"] = {
				"396023", -- [1]
				"Timer396023cdcount	1", -- [2]
				"~Incinerating Roar (1)", -- [3]
				9.8, -- [4]
				642418, -- [5]
				"cdcount", -- [6]
				396023, -- [7]
				2, -- [8]
				"2480", -- [9]
				["id"] = 2587,
			},
			["377612"] = {
				"377612", -- [1]
				"Timer377612cdcount	1", -- [2]
				"~Hurricane Wing (1)", -- [3]
				35, -- [4]
				4640499, -- [5]
				"cdcount", -- [6]
				377612, -- [7]
				2, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["396364"] = {
				"396364", -- [1]
				"Timer396364fades2", -- [2]
				"Negative Charge fades", -- [3]
				15, -- [4]
				135768, -- [5]
				"fades", -- [6]
				396364, -- [7]
				5, -- [8]
				"MPlusAffixes", -- [9]
				["id"] = 1677,
			},
			["370615"] = {
				"370615", -- [1]
				"Timer370615cdcount	1", -- [2]
				"~Molten Cleave (1)", -- [3]
				37.9, -- [4]
				524795, -- [5]
				"cdcount", -- [6]
				370615, -- [7]
				3, -- [8]
				"2480", -- [9]
				["id"] = 2587,
			},
			["372082"] = {
				"372082", -- [1]
				"Timer372082cdcount	1", -- [2]
				"~Enveloping Webs (1)", -- [3]
				17.2, -- [4]
				237430, -- [5]
				"cdcount", -- [6]
				372082, -- [7]
				3, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["375575"] = {
				"375575", -- [1]
				"Timer375575cd	Creature-0-3111-2522-6443-191230-0000405432", -- [2]
				"~Flame Sentry", -- [3]
				12.2, -- [4]
				134337, -- [5]
				"cd", -- [6]
				375575, -- [7]
				3, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["388410"] = {
				"388410", -- [1]
				"Timer388410cdcount	1", -- [2]
				"~Crosswinds (1)", -- [3]
				25.5, -- [4]
				4555542, -- [5]
				"cdcount", -- [6]
				388410, -- [7]
				3, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["385812"] = {
				"385812", -- [1]
				"Timer385812cd	Creature-0-3109-2522-22860-192934-000049A34D", -- [2]
				"~Aerial Slash", -- [3]
				12, -- [4]
				4643990, -- [5]
				"cd", -- [6]
				385812, -- [7]
				5, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["375580"] = {
				"375580", -- [1]
				"Timer375580cdcount	1", -- [2]
				"~Zephyr Slam (1)", -- [3]
				15.7, -- [4]
				1029596, -- [5]
				"cdcount", -- [6]
				375580, -- [7]
				5, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["378829"] = {
				"378829", -- [1]
				"Timer378829cdcount	1", -- [2]
				"~Charges (1)", -- [3]
				53.5, -- [4]
				839979, -- [5]
				"cdcount", -- [6]
				378829, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["374430"] = {
				"374430", -- [1]
				"Timer374430cd", -- [2]
				"~Violent Upheaval", -- [3]
				20.6, -- [4]
				136025, -- [5]
				"cd", -- [6]
				374430, -- [7]
				3, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["374043"] = {
				"374043", -- [1]
				"Timer374043cdcount	1", -- [2]
				"~Meteor Axe (1)", -- [3]
				29.6, -- [4]
				1282282, -- [5]
				"cdcount", -- [6]
				374043, -- [7]
				3, -- [8]
				"2486", -- [9]
				["id"] = 2590,
			},
			["386410"] = {
				"386410", -- [1]
				"Timer386410cdcount	1", -- [2]
				"~Blast (1)", -- [3]
				22.5, -- [4]
				4630364, -- [5]
				"cdcount", -- [6]
				386410, -- [7]
				5, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["373059"] = {
				"373059", -- [1]
				"Timer373059cdcount	1", -- [2]
				"~Primal Blizzard (1)", -- [3]
				48, -- [4]
				135833, -- [5]
				"cdcount", -- [6]
				373059, -- [7]
				2, -- [8]
				"2486", -- [9]
				["id"] = 2590,
			},
			["370307"] = {
				"370307", -- [1]
				"Timer370307cdcount	1", -- [2]
				"~Army of Flame (1)", -- [3]
				91.7, -- [4]
				135790, -- [5]
				"cdcount", -- [6]
				370307, -- [7]
				2, -- [8]
				"2480", -- [9]
				["id"] = 2587,
			},
			["376126"] = {
				"376126", -- [1]
				"Timer376126cd", -- [2]
				"~Lightning Strikes", -- [3]
				4.8, -- [4]
				135990, -- [5]
				"cd", -- [6]
				376126, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["375630"] = {
				"375630", -- [1]
				"Timer375630cd	Creature-0-3111-2522-6443-191232-000040540A", -- [2]
				"~Ionizing Charge", -- [3]
				10, -- [4]
				1370984, -- [5]
				"cd", -- [6]
				375630, -- [7]
				3, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["385574"] = {
				"385574", -- [1]
				"Timer385574cdcount	1", -- [2]
				"~Storm Wave (1)", -- [3]
				43.5, -- [4]
				4630450, -- [5]
				"cdcount", -- [6]
				385574, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["371983"] = {
				"371983", -- [1]
				"Timer371983cdcount	1", -- [2]
				"~Repelling Burst (1)", -- [3]
				27.8, -- [4]
				252188, -- [5]
				"cdcount", -- [6]
				371983, -- [7]
				2, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["375870"] = {
				"375870", -- [1]
				"Timer375870cdcount	1", -- [2]
				"~Mortal Stoneclaws (1)", -- [3]
				3.4, -- [4]
				134294, -- [5]
				"cdcount", -- [6]
				375870, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["375457"] = {
				"375457", -- [1]
				"Timer375457cd	Creature-0-3111-2522-6443-191222-00004053F1", -- [2]
				"~Chilling Tantrum", -- [3]
				11.1, -- [4]
				1580441, -- [5]
				"cd", -- [6]
				375457, -- [7]
				3, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["396022"] = {
				"396022", -- [1]
				"Timer396022cdcount	2", -- [2]
				"~Molten Spikes (2)", -- [3]
				21.4, -- [4]
				1058935, -- [5]
				"cdcount", -- [6]
				396022, -- [7]
				3, -- [8]
				"2480", -- [9]
				["id"] = 2587,
			},
			["nil"] = {
				"nil", -- [1]
				"%s	Pull in", -- [2]
				"Pull in", -- [3]
				12, -- [4]
				132349, -- [5]
				nil, -- [6]
				nil, -- [7]
				0, -- [8]
				"PullTimerCountdownDummy", -- [9]
				["id"] = 2607,
			},
			["372238"] = {
				"372238", -- [1]
				"Timer372238cdcount	2", -- [2]
				"~Call Spiderlings (2)", -- [3]
				25.5, -- [4]
				134321, -- [5]
				"cdcount", -- [6]
				372238, -- [7]
				1, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["385065"] = {
				"385065", -- [1]
				"Timer385065cdcount	1", -- [2]
				"~Deep Breath (1)", -- [3]
				13.3, -- [4]
				4640481, -- [5]
				"cdcount", -- [6]
				385065, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["376272"] = {
				"376272", -- [1]
				"Timer376272cd	Creature-0-3894-2522-27819-191225-00006E74C0", -- [2]
				"~Burrowing Strike", -- [3]
				8.1, -- [4]
				132363, -- [5]
				"cd", -- [6]
				376272, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["391686"] = {
				"391686", -- [1]
				"Timer391686cdcount	1", -- [2]
				"~Conductive Mark (1)", -- [3]
				4.6, -- [4]
				237587, -- [5]
				"cdcount", -- [6]
				391686, -- [7]
				3, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["380487"] = {
				"380487", -- [1]
				"Timer380487nextcount	1", -- [2]
				"Rock Blast (1)", -- [3]
				6, -- [4]
				1044087, -- [5]
				"nextcount", -- [6]
				380487, -- [7]
				3, -- [8]
				"2500", -- [9]
				["id"] = 2639,
			},
			["375475"] = {
				"375475", -- [1]
				"Timer375475cd	Creature-0-3894-2522-27819-191222-00006E7470", -- [2]
				"~Rending Bite", -- [3]
				11, -- [4]
				236305, -- [5]
				"cd", -- [6]
				375475, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["380176"] = {
				"380176", -- [1]
				"Timer380176cdcount	1", -- [2]
				"Staff", -- [3]
				15.95000000002328, -- [4]
				4543115, -- [5]
				"cdcount", -- [6]
				380176, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["385068"] = {
				"385068", -- [1]
				"Timer385068cdcount	1", -- [2]
				"~Ball Lightning (1)", -- [3]
				8.4, -- [4]
				613397, -- [5]
				"cdcount", -- [6]
				385068, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["373405"] = {
				"373405", -- [1]
				"Timer373405cdcount	1", -- [2]
				"~Gossamer Burst (1)", -- [3]
				31.4, -- [4]
				460954, -- [5]
				"cdcount", -- [6]
				373405, -- [7]
				2, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["375879"] = {
				"375879", -- [1]
				"Timer375879nextcount	2", -- [2]
				"Broodkeeper's Fury (2)", -- [3]
				30, -- [4]
				132345, -- [5]
				"nextcount", -- [6]
				375879, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["372027"] = {
				"372027", -- [1]
				"Timer372027cdcount	1", -- [2]
				"~Slashing Blaze (1)", -- [3]
				10, -- [4]
				237582, -- [5]
				"cdcount", -- [6]
				372027, -- [7]
				5, -- [8]
				"2486", -- [9]
				["id"] = 2590,
			},
			["388643"] = {
				"388643", -- [1]
				"Timer388643cdcount	1", -- [2]
				"~Sparks (1)", -- [3]
				85, -- [4]
				136099, -- [5]
				"cdcount", -- [6]
				388643, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["370991"] = {
				"370991", -- [1]
				"Timer370991cdcount	1", -- [2]
				"~Earthen Pillar (1)", -- [3]
				6.9, -- [4]
				1016245, -- [5]
				"cdcount", -- [6]
				370991, -- [7]
				3, -- [8]
				"2486", -- [9]
				["id"] = 2590,
			},
			["376073"] = {
				"376073", -- [1]
				"Timer376073cdcount	1", -- [2]
				"~Rapid Incubation (1)", -- [3]
				14.3, -- [4]
				1385911, -- [5]
				"cdcount", -- [6]
				376073, -- [7]
				1, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["377658"] = {
				"377658", -- [1]
				"Timer377658cdcount	1", -- [2]
				"~Electrified Jaws (1)", -- [3]
				5, -- [4]
				839974, -- [5]
				"cdcount", -- [6]
				377658, -- [7]
				5, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["375485"] = {
				"375485", -- [1]
				"Timer375485cd	Creature-0-3894-2522-27819-191230-00006E74AC", -- [2]
				"~Cauterizing Flashflames", -- [3]
				11.7, -- [4]
				236290, -- [5]
				"cd", -- [6]
				375485, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["257554"] = {
				"257554", -- [1]
				"Timer257554addscustom	1", -- [2]
				"Adds (1)", -- [3]
				35.6, -- [4]
				642418, -- [5]
				"addscustom", -- [6]
				257554, -- [7]
				1, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["376943"] = {
				"376943", -- [1]
				"Timer376943cdcount	1", -- [2]
				"~Cyclone (1)", -- [3]
				35.2, -- [4]
				511543, -- [5]
				"cdcount", -- [6]
				376943, -- [7]
				2, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["374622"] = {
				"374622", -- [1]
				"Timer374622cd", -- [2]
				"~Storm Break", -- [3]
				7.2, -- [4]
				132331, -- [5]
				"cd", -- [6]
				374622, -- [7]
				2, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["374624"] = {
				"374624", -- [1]
				"Timer374624cd", -- [2]
				"~Freezing Tempest", -- [3]
				30.4, -- [4]
				135833, -- [5]
				"cd", -- [6]
				374624, -- [7]
				2, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["390715"] = {
				"390715", -- [1]
				"Timer390715cdcount	1", -- [2]
				"~Flamerift (1)", -- [3]
				13.9, -- [4]
				134153, -- [5]
				"cdcount", -- [6]
				390715, -- [7]
				3, -- [8]
				"2480", -- [9]
				["id"] = 2587,
			},
			["388716"] = {
				"388716", -- [1]
				"Timer388716cdcount	1", -- [2]
				"~Icy Shroud (1)", -- [3]
				26.5, -- [4]
				135782, -- [5]
				"cdcount", -- [6]
				388716, -- [7]
				2, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["372056"] = {
				"372056", -- [1]
				"Timer372056cdcount	1", -- [2]
				"~Crush (1)", -- [3]
				18.1, -- [4]
				132358, -- [5]
				"cdcount", -- [6]
				372056, -- [7]
				5, -- [8]
				"2486", -- [9]
				["id"] = 2590,
			},
			["381615"] = {
				"381615", -- [1]
				"Timer381615cdcount	1", -- [2]
				"~Bombs (1)", -- [3]
				15, -- [4]
				237587, -- [5]
				"cdcount", -- [6]
				381615, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["388918"] = {
				"388918", -- [1]
				"Timer388918cdcount	1", -- [2]
				"~Frozen Shroud (1)", -- [3]
				40.5, -- [4]
				1717108, -- [5]
				"cdcount", -- [6]
				388918, -- [7]
				2, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["375871"] = {
				"375871", -- [1]
				"Timer375871cdcount	1", -- [2]
				"~Wildfire (1)", -- [3]
				8.4, -- [4]
				136186, -- [5]
				"cdcount", -- [6]
				375871, -- [7]
				3, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["382434"] = {
				"382434", -- [1]
				"Timer382434cd", -- [2]
				"~Storm Nova", -- [3]
				13.4, -- [4]
				839983, -- [5]
				"cd", -- [6]
				382434, -- [7]
				2, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["371976"] = {
				"371976", -- [1]
				"Timer371976cdcount	1", -- [2]
				"~Chilling Blast (1)", -- [3]
				15.2, -- [4]
				135782, -- [5]
				"cdcount", -- [6]
				371976, -- [7]
				3, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["376257"] = {
				"376257", -- [1]
				"Timer376257cd	Creature-0-3111-2522-6443-191225-000040544B", -- [2]
				"~Tremors", -- [3]
				11, -- [4]
				451165, -- [5]
				"cd", -- [6]
				376257, -- [7]
				3, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["389870"] = {
				"389870", -- [1]
				"Timer389870cdcount	1", -- [2]
				"~Teleport (1)", -- [3]
				21.8, -- [4]
				4554460, -- [5]
				"cdcount", -- [6]
				389870, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["396369"] = {
				"396369", -- [1]
				"Timer396369fades2", -- [2]
				"Positive Charge fades", -- [3]
				15, -- [4]
				135769, -- [5]
				"fades", -- [6]
				396369, -- [7]
				5, -- [8]
				"MPlusAffixes", -- [9]
				["id"] = 1677,
			},
			["375842"] = {
				"375842", -- [1]
				"Timer375842cdcount	1", -- [2]
				"Staff", -- [3]
				16.9, -- [4]
				4543115, -- [5]
				"cdcount", -- [6]
				375842, -- [7]
				5, -- [8]
				"2493", -- [9]
				["id"] = 2614,
			},
			["387261"] = {
				"387261", -- [1]
				"Timer387261cdcount	1", -- [2]
				"~Stormsurge (1)", -- [3]
				8.5, -- [4]
				4630499, -- [5]
				"cdcount", -- [6]
				387261, -- [7]
				2, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["388302"] = {
				"388302", -- [1]
				"Timer388302cdcount	1", -- [2]
				"~Tornados (1)", -- [3]
				7, -- [4]
				4037123, -- [5]
				"cdcount", -- [6]
				388302, -- [7]
				3, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["377594"] = {
				"377594", -- [1]
				"Timer377594cdcount	1", -- [2]
				"~Breath (1)", -- [3]
				23, -- [4]
				839983, -- [5]
				"cdcount", -- [6]
				377594, -- [7]
				3, -- [8]
				"2499", -- [9]
				["id"] = 2607,
			},
			["383073"] = {
				"383073", -- [1]
				"Timer383073nextcount	1", -- [2]
				"Shattering Impact (1)", -- [3]
				27, -- [4]
				451165, -- [5]
				"nextcount", -- [6]
				383073, -- [7]
				3, -- [8]
				"2500", -- [9]
				["id"] = 2639,
			},
			["374427"] = {
				"374427", -- [1]
				"Timer374427cd", -- [2]
				"~Ground Shatter", -- [3]
				5.9, -- [4]
				451165, -- [5]
				"cd", -- [6]
				374427, -- [7]
				3, -- [8]
				"2491", -- [9]
				["id"] = 2605,
			},
			["374112"] = {
				"374112", -- [1]
				"Timer374112cd	Creature-0-1631-2522-13880-189234-000040736B", -- [2]
				"~Freezing Breath", -- [3]
				11.1, -- [4]
				136158, -- [5]
				"cd", -- [6]
				374112, -- [7]
				5, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["ej24899"] = {
				"ej24899", -- [1]
				"Timerej24899cdcount	2", -- [2]
				"~Frostbreath Arachnid (2)", -- [3]
				103.1, -- [4]
				false, -- [5]
				"cdcount", -- [6]
				"ej24899", -- [7]
				1, -- [8]
				"2482", -- [9]
				["id"] = 2592,
			},
			["376279"] = {
				"376279", -- [1]
				"Timer376279nextcount	1", -- [2]
				"Concussive Slam (1)", -- [3]
				16, -- [4]
				236316, -- [5]
				"nextcount", -- [6]
				376279, -- [7]
				5, -- [8]
				"2500", -- [9]
				["id"] = 2639,
			},
			["377166"] = {
				"377166", -- [1]
				"Timer377166nextcount	1", -- [2]
				"Annihilation (1)", -- [3]
				90, -- [4]
				459027, -- [5]
				"nextcount", -- [6]
				377166, -- [7]
				3, -- [8]
				"2500", -- [9]
				["id"] = 2639,
			},
			["387849"] = {
				"387849", -- [1]
				"Timer387849cdcount	1", -- [2]
				"~Coalescing Storm (1)", -- [3]
				70, -- [4]
				4554454, -- [5]
				"cdcount", -- [6]
				387849, -- [7]
				1, -- [8]
				"2502", -- [9]
				["id"] = 2635,
			},
			["377505"] = {
				"377505", -- [1]
				"Timer377505next", -- [2]
				"Frenzied Devastation", -- [3]
				387.9, -- [4]
				236305, -- [5]
				"next", -- [6]
				377505, -- [7]
				2, -- [8]
				"2500", -- [9]
				["id"] = 2639,
			},
		},
	},
	["check_stuttering"] = true,
	["damage_scroll_auto_open"] = true,
	["played_class_time"] = true,
	["exp90temp"] = {
		["delete_damage_TCOB"] = true,
	},
	["class_time_played"] = {
		[9] = {
			["WARRIOR"] = 42.18800000000192,
			["PALADIN"] = 3080.616000000038,
			["DEMONHUNTER"] = 179095.022,
		},
	},
	["damage_scroll_position"] = {
		["scale"] = 1,
	},
	["tutorial"] = {
		["bookmark_tutorial"] = false,
		["main_help_button"] = 47,
		["WINDOW_GROUP_MAKING1"] = true,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["logons"] = 47,
		["version_announce"] = 0,
		["ctrl_click_close_tutorial"] = false,
		["unlock_button"] = 1,
		["MIN_COMBAT_TIME"] = true,
	},
	["spell_category_savedtable"] = {
	},
	["mythic_plus"] = {
		["make_overall_boss_only"] = false,
		["mythicrun_chart_frame"] = {
			["y"] = 47.52915573120117,
			["x"] = -345.6042175292969,
			["point"] = "BOTTOMLEFT",
			["scale"] = 1,
		},
		["merge_boss_trash"] = true,
		["delay_to_show_graphic"] = 5,
		["always_in_combat"] = false,
		["make_overall_when_done"] = true,
		["delete_trash_after_merge"] = true,
		["show_damage_graphic"] = true,
		["mythicrun_chart_frame_ready"] = {
			["y"] = 0.0001068115234375,
			["x"] = -3.0517578125e-05,
			["point"] = "CENTER",
			["scale"] = 1,
		},
		["boss_dedicated_segment"] = true,
		["mythicrun_chart_frame_minimized"] = {
			["y"] = 0,
			["x"] = 3.0517578125e-05,
			["point"] = "CENTER",
			["scale"] = 1,
		},
		["last_mythicrun_chart"] = {
		},
	},
	["show_warning_id1"] = true,
	["run_code"] = {
		["on_specchanged"] = "\n-- run when the player changes its spec",
		["on_zonechanged"] = "\n-- when the player changes zone, this code will run",
		["on_init"] = "\n-- code to run when Details! initializes, put here code which only will run once\n-- this also will run then the profile is changed\n\n--size of the death log tooltip in the Deaths display (default 350)\nDetails.death_tooltip_width = 350;\n\n--when in arena or battleground, details! silently switch to activity time (goes back to the old setting on leaving, default true)\nDetails.force_activity_time_pvp = true;\n\n--speed of the bar animations (default 33)\nDetails.animation_speed = 33;\n\n--threshold to trigger slow or fast speed (default 0.45)\nDetails.animation_speed_mintravel = 0.45;\n\n--call to update animations\nDetails:RefreshAnimationFunctions();\n\n--max window size, does require a /reload to work (default 480 x 450)\nDetails.max_window_size.width = 480;\nDetails.max_window_size.height = 450;\n\n--use the arena team color as the class color (default true)\nDetails.color_by_arena_team = true;\n\n--how much time the update warning is shown (default 10)\nDetails.update_warning_timeout = 10;",
		["on_groupchange"] = "\n-- this code runs when the player enter or leave a group",
		["on_leavecombat"] = "\n-- this code runs when the player leave combat",
		["on_entercombat"] = "\n-- this code runs when the player enters in combat",
	},
	["latest_npcid_pool_access"] = 1676570530,
	["exit_errors"] = {
	},
	["merge_player_abilities"] = false,
	["realm_sync"] = true,
	["createauraframe"] = {
	},
	["data_wipes_exp"] = {
		["9"] = false,
		["14"] = false,
		["13"] = false,
		["12"] = false,
		["11"] = false,
		["10"] = true,
	},
	["spell_category_latest_query"] = 0,
	["switchSaved"] = {
		["slots"] = 16,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
			{
			}, -- [5]
			{
			}, -- [6]
			{
			}, -- [7]
			{
			}, -- [8]
			{
			}, -- [9]
			{
			}, -- [10]
			{
			}, -- [11]
			{
			}, -- [12]
			{
			}, -- [13]
			{
			}, -- [14]
			{
			}, -- [15]
			{
			}, -- [16]
		},
	},
	["report_where"] = "SAY",
	["aura_tracker_frame"] = {
		["scaletable"] = {
			["scale"] = 1,
		},
		["position"] = {
		},
	},
	["slash_me_used"] = false,
	["spell_category_latest_save"] = 0,
	["item_level_pool"] = {
		["Player-580-0A5B7AC2"] = {
			["time"] = 1676587739,
			["name"] = "Selenerah",
			["ilvl"] = 402,
		},
		["Player-580-076F90A2"] = {
			["time"] = 1676581493,
			["name"] = "Happenslol",
			["ilvl"] = 416.125,
		},
		["Player-580-077EDF5D"] = {
			["time"] = 1676581388,
			["name"] = "Hakizu",
			["ilvl"] = 404.875,
		},
		["Player-580-0A59523C"] = {
			["time"] = 1676587972,
			["name"] = "Nilandra",
			["ilvl"] = 411.75,
		},
		["Player-580-08C239B5"] = {
			["time"] = 1676587972,
			["name"] = "Scahra",
			["ilvl"] = 414.25,
		},
		["Player-580-09E8D55A"] = {
			["time"] = 1676584588,
			["name"] = "Gorlirn",
			["ilvl"] = 411.5,
		},
		["Player-580-09EA67DE"] = {
			["name"] = "Happensbzzt",
			["time"] = 1676573043,
			["ilvl"] = 397.5,
		},
		["Player-3691-06B2BF62"] = {
			["time"] = 1676581420,
			["name"] = "Xeonidas",
			["ilvl"] = 405.4375,
		},
		["Player-580-0917B847"] = {
			["time"] = 1676581494,
			["name"] = "Astranith",
			["ilvl"] = 415.875,
		},
		["Player-580-0833434B"] = {
			["time"] = 1676587715,
			["name"] = "Aubry",
			["ilvl"] = 412.375,
		},
		["Player-580-0A5D07A0"] = {
			["time"] = 1676581656,
			["name"] = "Morrizane",
			["ilvl"] = 408.4375,
		},
	},
	["savedStyles"] = {
	},
	["always_use_profile_exception"] = {
	},
	["details_auras"] = {
	},
	["spellid_ignored"] = {
	},
	["savedTimeCaptures"] = {
	},
	["latest_news_saw"] = "10.0.5 10562",
	["custom"] = {
		{
			["source"] = false,
			["tooltip"] = "\n			",
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format(\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing damage.",
			["attribute"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor(value/60), math.floor(value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["name"] = "Damage Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, amount = 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n\n				--do the loop:\n				for _, player in ipairs( damage_container ) do\n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player\n						instance_container:AddValue (player, activity)\n					end\n				end\n\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Red",
			["script_version"] = 3,
		}, -- [1]
		{
			["source"] = false,
			["tooltip"] = "\n			",
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format(\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing healing.",
			["attribute"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor(value/60), math.floor(value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["name"] = "Healing Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_HEAL )\n\n				--do the loop:\n				for _, player in ipairs( damage_container ) do\n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player\n						instance_container:AddValue (player, activity)\n					end\n				end\n\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\UI-MicroStream-Green",
			["script_version"] = 2,
		}, -- [2]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor(value)\n			",
			["desc"] = "Show the crowd control amount for each player.",
			["attribute"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs(misc_actors) do\n					if (character.cc_done and character:IsPlayer()) then\n						local cc_done = floor(character.cc_done)\n						instance_container:AddValue (character, cc_done)\n						total = total + cc_done\n						if (cc_done > top) then\n							top = cc_done\n						end\n						amount = amount + 1\n					end\n				end\n\n				return total, top, amount\n			",
			["name"] = "Crowd Control Done",
			["tooltip"] = "				local actor, combat, instance = ...\n				local spells = {}\n				for spellid, spell in pairs(actor.cc_done_spells._ActorTable) do\n				    tinsert(spells, {spellid, spell.counter})\n				end\n\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs(spells) do\n				    local name, _, icon = GetSpellInfo(spell [1])\n				    GameCooltip:AddLine(name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n				local targets = {}\n				for playername, amount in pairs(actor.cc_done_targets) do\n				    tinsert(targets, {playername, amount})\n				end\n\n				table.sort (targets, _detalhes.Sort2)\n\n				_detalhes:AddTooltipSpellHeaderText (\"Targets\", \"yellow\", #targets)\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass(actor.nome)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, target in ipairs(targets) do\n				    GameCooltip:AddLine(target[1], target [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n\n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass(target [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    end\n				    --\n				end\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_FreezingBreath",
			["script_version"] = 11,
		}, -- [3]
		{
			["source"] = false,
			["author"] = "Details!",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor(value)\n			",
			["desc"] = "Show the amount of crowd control received for each player.",
			["attribute"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amt = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n				DETAILS_CUSTOM_CC_RECEIVED_CACHE = DETAILS_CUSTOM_CC_RECEIVED_CACHE or {}\n				wipe (DETAILS_CUSTOM_CC_RECEIVED_CACHE)\n\n				for index, character in ipairs(misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n\n					for player_name, amount in pairs(character.cc_done_targets) do\n					    local target = combat (1, player_name) or combat (2, player_name)\n					    if (target and target:IsPlayer()) then\n						instance_container:AddValue (target, amount)\n						total = total + amount\n						if (amount > top) then\n						    top = amount\n						end\n						if (not DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name]) then\n						    DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name] = true\n						    amt = amt + 1\n						end\n					    end\n					end\n\n				    end\n				end\n\n				return total, top, amt\n			",
			["name"] = "Crowd Control Received",
			["tooltip"] = "				local actor, combat, instance = ...\n				local name = actor:name()\n				local spells, from = {}, {}\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs(misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n					local on_actor = character.cc_done_targets [name]\n					if (on_actor) then\n					    tinsert(from, {character:name(), on_actor})\n\n					    for spellid, spell in pairs(character.cc_done_spells._ActorTable) do\n\n						local spell_on_actor = spell.targets [name]\n						if (spell_on_actor) then\n						    local has_spell\n						    for index, spell_table in ipairs(spells) do\n							if (spell_table [1] == spellid) then\n							    spell_table [2] = spell_table [2] + spell_on_actor\n							    has_spell = true\n							end\n						    end\n						    if (not has_spell) then\n							tinsert(spells, {spellid, spell_on_actor})\n						    end\n						end\n\n					    end\n					end\n				    end\n				end\n\n				table.sort (from, _detalhes.Sort2)\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs(spells) do\n				    local name, _, icon = GetSpellInfo(spell [1])\n				    GameCooltip:AddLine(name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				end\n\n				_detalhes:AddTooltipSpellHeaderText (\"From\", \"yellow\", #from)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, t in ipairs(from) do\n				    GameCooltip:AddLine(t[1], t[2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n\n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass(t [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon(class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    end\n\n				end\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Frost_ChainsOfIce",
			["script_version"] = 3,
		}, -- [4]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				local dps = _detalhes:ToK (floor(value) / combat:GetCombatTime())\n				local percent = string.format(\"%.1f\", value/total*100)\n				return dps .. \", \" .. percent\n			",
			["desc"] = "Show your spells in the window.",
			["tooltip"] = "			--config:\n			--Background RBG and Alpha:\n			local R, G, B, A = 0, 0, 0, 0.75\n			local R, G, B, A = 0.1960, 0.1960, 0.1960, 0.8697\n\n			--get the parameters passed\n			local spell, combat, instance = ...\n\n			--get the cooltip object (we dont use the convencional GameTooltip here)\n			local GC = GameCooltip\n			GC:SetOption(\"YSpacingMod\", 0)\n\n			local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n\n			if (spell.n_dmg) then\n\n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n\n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n\n			    local debuff_uptime_total, cast_string = \"\", \"\"\n			    local misc_actor = instance.showing (4, _detalhes.playername)\n			    if (misc_actor) then\n				local debuff_uptime = misc_actor.debuff_uptime_spells and misc_actor.debuff_uptime_spells._ActorTable [spell.id] and misc_actor.debuff_uptime_spells._ActorTable [spell.id].uptime\n				if (debuff_uptime) then\n				    debuff_uptime_total = floor(debuff_uptime / instance.showing:GetCombatTime() * 100)\n				end\n\n				local spell_cast = misc_actor.spell_cast and misc_actor.spell_cast [spell.id]\n\n				if (not spell_cast and misc_actor.spell_cast) then\n				    local spellname = GetSpellInfo(spell.id)\n				    for casted_spellid, amount in pairs(misc_actor.spell_cast) do\n					local casted_spellname = GetSpellInfo(casted_spellid)\n					if (casted_spellname == spellname) then\n					    spell_cast = amount .. \" (|cFFFFFF00?|r)\"\n					end\n				    end\n				end\n				if (not spell_cast) then\n				    spell_cast = \"(|cFFFFFF00?|r)\"\n				end\n				cast_string = cast_string .. spell_cast\n			    end\n\n			    --Cooltip code\n			    GC:AddLine(\"Casts:\", cast_string or \"?\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    if (debuff_uptime_total ~= \"\") then\n				GC:AddLine(\"Uptime:\", (debuff_uptime_total or \"?\") .. \"%\")\n				GC:AddStatusBar (100, 1, R, G, B, A)\n			    end\n\n			    GC:AddLine(\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local average = spell.total / total_hits\n			    GC:AddLine(\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"E-Dps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Normal Hits: \", spell.n_amt .. \" (\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local n_average = spell.n_dmg / spell.n_amt\n			    local T = (combat_time*spell.n_dmg)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n\n			    GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format(\"%.1f\",spell.n_dmg / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Critical Hits: \", spell.c_amt .. \" (\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_dmg/spell.c_amt\n				local T = (combat_time*spell.c_dmg)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_dmg / T\n\n				GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine(\"Average / E-Dps: \",  \"0 / 0\")\n			    end\n\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n\n			elseif (spell.n_curado) then\n\n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n\n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n\n			    --Cooltip code\n			    GC:AddLine(\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local average = spell.total / total_hits\n			    GC:AddLine(\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"E-Hps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    GC:AddLine(\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Normal Hits: \", spell.n_amt .. \" (\" ..floor( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    local n_average = spell.n_curado / spell.n_amt\n			    local T = (combat_time*spell.n_curado)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n\n			    GC:AddLine(\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format(\"%.1f\",spell.n_curado / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    --GC:AddLine(\" \")\n\n			    GC:AddLine(\"Critical Hits: \", spell.c_amt .. \" (\" ..floor( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n\n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_curado/spell.c_amt\n				local T = (combat_time*spell.c_curado)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_curado / T\n\n				GC:AddLine(\"Average / E-Hps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine(\"Average / E-Hps: \",  \"0 / 0\")\n			    end\n\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			end\n			",
			["attribute"] = false,
			["name"] = "My Spells",
			["script"] = "				--get the parameters passed\n				local combat, instance_container, instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				local player\n				local pet_attribute\n\n				local role = DetailsFramework.UnitGroupRolesAssigned(\"player\")\n				local spec = DetailsFramework.GetSpecialization()\n				role = spec and DetailsFramework.GetSpecializationRole (spec) or role\n\n				if (role == \"DAMAGER\") then\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				elseif (role == \"HEALER\") then\n					player = combat (DETAILS_ATTRIBUTE_HEAL, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_HEAL\n				else\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				end\n\n				--do the loop\n\n				if (player) then\n					local spells = player:GetSpellList()\n					for spellid, spell in pairs(spells) do\n						instance_container:AddValue (spell, spell.total)\n						total = total + spell.total\n						if (top < spell.total) then\n							top = spell.total\n						end\n						amount = amount + 1\n					end\n\n					for _, PetName in ipairs(player.pets) do\n						local pet = combat (pet_attribute, PetName)\n						if (pet) then\n							for spellid, spell in pairs(pet:GetSpellList()) do\n								instance_container:AddValue (spell, spell.total, nil, \" (\" .. PetName:gsub((\" <.*\"), \"\") .. \")\")\n								total = total + spell.total\n								if (top < spell.total) then\n									top = spell.total\n								end\n								amount = amount + 1\n							end\n						end\n					end\n				end\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\CHATFRAME\\UI-ChatIcon-Battlenet",
			["script_version"] = 8,
		}, -- [5]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with skull.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [128]\n				if (DamageOnStar) then\n				    --RAID_TARGET_8 is the built-in localized word for 'Skull'.\n				    GameCooltip:AddLine(RAID_TARGET_8 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_8\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["attribute"] = false,
			["name"] = "Damage On Skull Marked Targets",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--raid target flags:\n				-- 128: skull\n				-- 64: cross\n				-- 32: square\n				-- 16: moon\n				-- 8: triangle\n				-- 4: diamond\n				-- 2: circle\n				-- 1: star\n\n				--do the loop\n				for _, actor in ipairs(Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					if (actor.raid_targets [128]) then\n					    CustomContainer:AddValue (actor, actor.raid_targets [128])\n					end\n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_8",
			["script_version"] = 3,
		}, -- [6]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with any other mark.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object\n				local GameCooltip = GameCooltip\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [1]\n				if (DamageOnStar) then\n				    GameCooltip:AddLine(RAID_TARGET_1 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_1\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCircle = RaidTargets [2]\n				if (DamageOnCircle) then\n				    GameCooltip:AddLine(RAID_TARGET_2 .. \":\", format_func (_, DamageOnCircle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_2\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnDiamond = RaidTargets [4]\n				if (DamageOnDiamond) then\n				    GameCooltip:AddLine(RAID_TARGET_3 .. \":\", format_func (_, DamageOnDiamond))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_3\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnTriangle = RaidTargets [8]\n				if (DamageOnTriangle) then\n				    GameCooltip:AddLine(RAID_TARGET_4 .. \":\", format_func (_, DamageOnTriangle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_4\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnMoon = RaidTargets [16]\n				if (DamageOnMoon) then\n				    GameCooltip:AddLine(RAID_TARGET_5 .. \":\", format_func (_, DamageOnMoon))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_5\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnSquare = RaidTargets [32]\n				if (DamageOnSquare) then\n				    GameCooltip:AddLine(RAID_TARGET_6 .. \":\", format_func (_, DamageOnSquare))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_6\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCross = RaidTargets [64]\n				if (DamageOnCross) then\n				    GameCooltip:AddLine(RAID_TARGET_7 .. \":\", format_func (_, DamageOnCross))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_7\", 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["attribute"] = false,
			["name"] = "Damage On Other Marked Targets",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for _, actor in ipairs(Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					local total = (actor.raid_targets [1] or 0) --star\n					total = total + (actor.raid_targets [2] or 0) --circle\n					total = total + (actor.raid_targets [4] or 0) --diamond\n					total = total + (actor.raid_targets [8] or 0) --tiangle\n					total = total + (actor.raid_targets [16] or 0) --moon\n					total = total + (actor.raid_targets [32] or 0) --square\n					total = total + (actor.raid_targets [64] or 0) --cross\n\n					if (total > 0) then\n					    CustomContainer:AddValue (actor, total)\n					end\n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_5",
			["script_version"] = 3,
		}, -- [7]
		{
			["source"] = false,
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip2\n\n				--Cooltip code\n				--get the overall combat\n				local OverallCombat = Details:GetCombat(-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat(0)\n\n				local AllSpells = {}\n\n				local playerTotal = 0\n\n				--overall\n				local player = OverallCombat [1]:GetActor(actor.nome)\n				if (player) then\n					playerTotal = playerTotal + player.total\n					local playerSpells = player:GetSpellList()\n					for spellID, spellTable in pairs(playerSpells) do\n						AllSpells [spellID] = spellTable.total\n					end\n				end\n				--current\n				if (Details.in_combat) then\n					local player = CurrentCombat [1]:GetActor(actor.nome)\n					if (player) then\n						playerTotal = playerTotal + player.total\n						local playerSpells = player:GetSpellList()\n						for spellID, spellTable in pairs(playerSpells) do\n							AllSpells [spellID] = (AllSpells [spellID] or 0) + (spellTable.total or 0)\n						end\n					end\n				end\n\n				local sortedList = {}\n				for spellID, total in pairs(AllSpells) do\n					tinsert(sortedList, {spellID, total})\n				end\n				table.sort (sortedList, Details.Sort2)\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--build the tooltip\n\n				local topSpellTotal = sortedList and sortedList[1] and sortedList[1][2] or 0\n\n				for i, t in ipairs(sortedList) do\n					local spellID, total = unpack(t)\n					if (total > 1) then\n						local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n\n						local spellPercent = total / playerTotal * 100\n						local formatedSpellPercent = format(\"%.1f\", spellPercent)\n\n						if (string.len(formatedSpellPercent) < 4) then\n							formatedSpellPercent = formatedSpellPercent  .. \"0\"\n						end\n\n						GameCooltip:AddLine(spellName, format_func (_, total) .. \"    \" .. formatedSpellPercent  .. \"%\")\n\n						Details:AddTooltipBackgroundStatusbar(false, total / topSpellTotal * 100)\n						GameCooltip:AddIcon (spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height, 0.078125, 0.921875, 0.078125, 0.921875)\n\n					end\n				end\n			",
			["attribute"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n\n				--get the time of overall combat\n				local OverallCombatTime = Details:GetCombat(-1):GetCombatTime()\n\n				--get the time of current combat if the player is in combat\n				if (Details.in_combat) then\n					local CurrentCombatTime = Details:GetCombat(0):GetCombatTime()\n					OverallCombatTime = OverallCombatTime + CurrentCombatTime\n				end\n\n				--calculate the DPS and return it as percent\n				local totalValue = value\n\n				--build the string\n				local ToK = Details:GetCurrentToKFunction()\n				local s = ToK (_, value / OverallCombatTime)\n\n				return s\n			",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return value\n			",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the overall combat\n				local OverallCombat = Details:GetCombat(-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat(0)\n\n				if (not OverallCombat.GetActorList or not CurrentCombat.GetActorList) then\n					return 0, 0, 0\n				end\n\n				--get the damage actor container for overall\n				local damage_container_overall = OverallCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				--get the damage actor container for current\n				local damage_container_current = CurrentCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n\n				--do the loop:\n				for _, player in ipairs( damage_container_overall ) do\n					--only player in group\n					if (player:IsGroupPlayer()) then\n						instance_container:AddValue (player, player.total)\n					end\n				end\n\n				if (Details.in_combat) then\n					for _, player in ipairs( damage_container_current ) do\n						--only player in group\n						if (player:IsGroupPlayer()) then\n							instance_container:AddValue (player, player.total)\n						end\n					end\n				end\n\n				total, top =  instance_container:GetTotalAndHighestValue()\n				amount =  instance_container:GetNumActors()\n\n				--return:\n				return total, top, amount\n			",
			["displayName"] = "Damage Done",
			["name"] = "Dynamic Overall Damage",
			["desc"] = "Show overall damage done on the fly.",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\Buttons\\Spell-Reset",
			["script_version"] = 8,
		}, -- [8]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Damage done to shields",
			["tooltip"] = "				--get the parameters passed\n				local actor, Combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				--get the actor total damage absorbed\n				local totalAbsorb = actor.totalabsorbed\n				local format_func = Details:GetCurrentToKFunction()\n\n				--get the damage absorbed by all the actor pets\n				for petIndex, petName in ipairs(actor.pets) do\n				    local pet = Combat :GetActor(1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n				    end\n				end\n\n				GameCooltip:AddLine(actor:Name(), format_func (_, actor.totalabsorbed))\n				Details:AddTooltipBackgroundStatusbar()\n\n				for petIndex, petName in ipairs(actor.pets) do\n				    local pet = Combat :GetActor(1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n\n					GameCooltip:AddLine(petName, format_func (_, pet.totalabsorbed))\n					Details:AddTooltipBackgroundStatusbar()\n\n				    end\n				end\n			",
			["attribute"] = false,
			["name"] = "Damage on Shields",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for index, actor in ipairs(Combat:GetActorList(1)) do\n				    if (actor:IsPlayer()) then\n\n					--get the actor total damage absorbed\n					local totalAbsorb = actor.totalabsorbed\n\n					--get the damage absorbed by all the actor pets\n					for petIndex, petName in ipairs(actor.pets) do\n					    local pet = Combat :GetActor(1, petName)\n					    if (pet) then\n						totalAbsorb = totalAbsorb + pet.totalabsorbed\n					    end\n					end\n\n					--add the value to the actor on the custom container\n					CustomContainer:AddValue (actor, totalAbsorb)\n\n				    end\n				end\n				--loop end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\Spell_Holy_PowerWordShield",
			["script_version"] = 1,
		}, -- [9]
		{
			["source"] = false,
			["author"] = "Rhythm",
			["total_script"] = "        local value, top, total, Combat, Instance, Actor = ...\n\n        if _G.Details_ExplosiveOrbs then\n            return _G.Details_ExplosiveOrbs:GetDisplayText(Combat:GetCombatNumber(), Actor.my_actor:guid())\n        end\n        return \"\"\n    ",
			["desc"] = "Show how many explosive orbs players target and hit.",
			["attribute"] = false,
			["script"] = "        local Combat, CustomContainer, Instance = ...\n        local total, top, amount = 0, 0, 0\n\n        if _G.Details_ExplosiveOrbs then\n            local CombatNumber = Combat:GetCombatNumber()\n            local Container = Combat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n            for _, Actor in Container:ListActors() do\n                if Actor:IsGroupPlayer() then\n                    -- we only record the players in party\n                    local target, hit = _G.Details_ExplosiveOrbs:GetRecord(CombatNumber, Actor:guid())\n                    if target > 0 or hit > 0 then\n                        CustomContainer:AddValue(Actor, hit)\n                    end\n                end\n            end\n\n            total, top = CustomContainer:GetTotalAndHighestValue()\n            amount = CustomContainer:GetNumActors()\n        end\n\n        return total, top, amount\n    ",
			["name"] = "Explosive Orbs",
			["tooltip"] = "        local Actor, Combat, Instance = ...\n        local GameCooltip = GameCooltip\n\n        if _G.Details_ExplosiveOrbs then\n            local actorName = Actor:name()\n            local Actor = Combat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE):GetActor(actorName)\n            if not Actor then return end\n\n            local sortedList = {}\n            local orbName = _G.Details_ExplosiveOrbs:RequireOrbName()\n            local Container = Combat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n\n            for spellID, spellTable in pairs(Actor:GetSpellList()) do\n                local amount = spellTable.targets[orbName]\n                if amount then\n                    tinsert(sortedList, {spellID, amount})\n                end\n            end\n\n            -- handle pet\n            for _, petName in ipairs(Actor.pets) do\n                local petActor = Container:GetActor(petName)\n                for spellID, spellTable in pairs(petActor:GetSpellList()) do\n                    local amount = spellTable.targets[orbName]\n                    if amount then\n                        tinsert(sortedList, {spellID, amount, petName})\n                    end\n                end\n            end\n\n            sort(sortedList, Details.Sort2)\n\n            local format_func = Details:GetCurrentToKFunction()\n            for _, tbl in ipairs(sortedList) do\n                local spellID, amount, petName = unpack(tbl)\n                local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n                if petName then\n                    spellName = spellName .. ' (' .. petName .. ')'\n                end\n\n                GameCooltip:AddLine(spellName, format_func(_, amount))\n                Details:AddTooltipBackgroundStatusbar()\n                GameCooltip:AddIcon(spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n            end\n        end\n    ",
			["target"] = false,
			["spellid"] = false,
			["icon"] = 2175503,
			["script_version"] = 11,
		}, -- [10]
		{
			["source"] = false,
			["author"] = "Rhythm",
			["total_script"] = "        local value, top, total, Combat, Instance, Actor = ...\n\n        if _G.Details_ExplosiveOrbs then\n            return _G.Details_ExplosiveOrbs:GetDisplayText(Details:GetCombat(-1):GetCombatNumber(), Actor.my_actor:guid())\n        end\n        return \"\"\n    ",
			["desc"] = "Show how many explosive orbs players target and hit.",
			["attribute"] = false,
			["script"] = "        local Combat, CustomContainer, Instance = ...\n        local total, top, amount = 0, 0, 0\n\n        if _G.Details_ExplosiveOrbs then\n            local OverallCombat = Details:GetCombat(-1)\n            local CombatNumber = OverallCombat:GetCombatNumber()\n            local Container = OverallCombat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n            for _, Actor in Container:ListActors() do\n                if Actor:IsGroupPlayer() then\n                    -- we only record the players in party\n                    local target, hit = _G.Details_ExplosiveOrbs:GetRecord(CombatNumber, Actor:guid())\n                    if target > 0 or hit > 0 then\n                        CustomContainer:AddValue(Actor, hit)\n                    end\n                end\n            end\n\n            total, top = CustomContainer:GetTotalAndHighestValue()\n            amount = CustomContainer:GetNumActors()\n        end\n\n        return total, top, amount\n    ",
			["name"] = "Dynamic Overall Explosive Orbs",
			["tooltip"] = "        local Actor, Combat, Instance = ...\n        local GameCooltip = GameCooltip\n\n        if _G.Details_ExplosiveOrbs then\n            local actorName = Actor:name()\n            local orbName = _G.Details_ExplosiveOrbs:RequireOrbName()\n\n            local OverallCombat = Details:GetCombat(-1)\n            local CurrentCombat = Details:GetCombat(0)\n\n            local OverallContainer = OverallCombat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n            local CurrentContainer = CurrentCombat:GetContainer(DETAILS_ATTRIBUTE_DAMAGE)\n\n            local AllSpells = {}\n\n            -- handle overall\n            local Actor = OverallContainer:GetActor(actorName)\n            local ActorSpells = Actor:GetSpellList()\n\n            -- handle player\n            AllSpells[actorName] = {}\n            for spellID, spellTable in pairs(ActorSpells) do\n                AllSpells[actorName][spellID] = spellTable.targets[orbName]\n            end\n\n            -- handle pet\n            for _, petName in ipairs(Actor.pets) do\n                local petActor = OverallContainer:GetActor(petName)\n                local petActorSpells = petActor:GetSpellList()\n\n                AllSpells[petName] = {}\n                for spellID, spellTable in pairs(petActorSpells) do\n                    AllSpells[petName][spellID] = spellTable.targets[orbName]\n                end\n            end\n\n            if Details.in_combat then\n                -- handle current\n                local Actor = CurrentContainer:GetActor(actorName)\n                local ActorSpells = Actor:GetSpellList()\n\n                -- handle player\n                for spellID, spellTable in pairs(ActorSpells) do\n                    AllSpells[actorName][spellID] = (AllSpells[actorName][spellID] or 0) + (spellTable.targets[orbName] or 0)\n                end\n\n                -- handle pet\n                for _, petName in ipairs(Actor.pets) do\n                    local petActor = CurrentContainer:GetActor(petName)\n                    local petActorSpells = petActor:GetSpellList()\n\n                    if not AllSpells[petName] then\n                        AllSpells[petName] = {}\n                    end\n\n                    for spellID, spellTable in pairs(petActorSpells) do\n                        AllSpells[petName][spellID] = (AllSpells[petName][spellID] or 0) + (spellTable.targets[orbName] or 0)\n                    end\n                end\n            end\n\n            local sortedList = {}\n            for name, spellTable in pairs(AllSpells) do\n                for spellID, amount in pairs(spellTable) do\n                    tinsert(sortedList, {spellID, amount, name ~= actorName and name})\n                end\n            end\n\n            sort(sortedList, Details.Sort2)\n\n            local format_func = Details:GetCurrentToKFunction()\n            for _, tbl in ipairs(sortedList) do\n                local spellID, amount, petName = unpack(tbl)\n                local spellName, _, spellIcon = Details.GetSpellInfo(spellID)\n                if petName then\n                    spellName = spellName .. ' (' .. petName .. ')'\n                end\n\n                GameCooltip:AddLine(spellName, format_func(_, amount))\n                Details:AddTooltipBackgroundStatusbar()\n                GameCooltip:AddIcon(spellIcon, 1, 1, _detalhes.tooltip.line_height, _detalhes.tooltip.line_height)\n            end\n        end\n    ",
			["target"] = false,
			["spellid"] = false,
			["icon"] = 2175503,
			["script_version"] = 11,
		}, -- [11]
		{
			["source"] = false,
			["author"] = "Terciob",
			["icon"] = "Interface\\ICONS\\INV_Potion_03",
			["tooltip"] = "				local actorObject, combatObject, instanceObject = ...\n\n				local iconSize = 20\n				\n				local buffUptimeContainer = actorObject:GetSpellContainer(\"buff\")\n				if (buffUptimeContainer) then\n					for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n						local spellTable = buffUptimeContainer:GetSpell(spellId)\n						if (spellTable) then\n							local used = spellTable.activedamt\n							if (used and used > 0) then\n								local spellName, _, spellIcon = GetSpellInfo(spellId)\n								GameCooltip:AddLine(spellName, used)\n								GameCooltip:AddIcon(spellIcon, 1, 1, iconSize, iconSize)\n								Details:AddTooltipBackgroundStatusbar()\n							end\n						end\n					end\n				end\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				value = math.floor(value)\n				return \"\"\n			",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return math.floor(value) .. \" \"\n			",
			["spellid"] = false,
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["name"] = "Potion Used",
			["attribute"] = false,
			["target"] = false,
			["script"] = "				local combatObject, customContainer, instanceObject = ...\n				local total, top, amount = 0, 0, 0\n				\n				--get the misc actor container\n				local listOfUtilityActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_MISC)\n				\n				--do the loop:\n				for _, actorObject in ipairs(listOfUtilityActors) do\n					--only player in group\n					if (actorObject:IsGroupPlayer()) then\n						local bFoundPotion = false\n						\n						--get the spell debuff uptime container\n						local debuffUptimeContainer = actorObject:GetSpellContainer(\"debuff\")\n						if (debuffUptimeContainer) then\n							--potion of focus (can't use as pre-potion, so, its amount is always 1\n							local focusPotion = debuffUptimeContainer:GetSpell(DETAILS_FOCUS_POTION_ID)\n							if (focusPotion) then\n								total = total + 1\n								bFoundPotion = true\n								if (top < 1) then\n									top = 1\n								end\n								--add amount to the player\n								customContainer:AddValue(actorObject, 1)\n							end\n						end\n						\n						--get the spell buff uptime container\n						local buffUptimeContainer = actorObject:GetSpellContainer(\"buff\")\n						if (buffUptimeContainer) then\n							for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n								local spellTable = buffUptimeContainer:GetSpell(spellId)\n								if (spellTable) then\n									local used = spellTable.activedamt\n									if (used and used > 0) then\n										total = total + used\n										bFoundPotion = true\n										if (used > top) then\n											top = used\n										end\n										\n										--add amount to the player\n										customContainer:AddValue(actorObject, used)\n									end\n								end\n							end\n						end\n						\n						if (bFoundPotion) then\n							amount = amount + 1\n						end\n					end\n				end\n				\n				--return:\n				return total, top, amount\n				",
			["import_string"] = "1EvBVnkoq4FlxKwDWDjCn6Q0kfD7kL(YwruUMOLK7JaoGPX3rSrgZwLV4F73yJ5LMxjPDfBBzHXZZZmEMhg7p0FHVxoRGhH9x57HkeRzCFVhWcejn)x89YWWROIG8iojt47LYIqPYWFGslW9LHcwM(3cuk83i2MvibCdHMlq0iSm8lYqhhh5e5e9s0pydsS2jjLX4w6hAREnhlk4uzyVEYWbdYfCc9fNeghm2Q3NCgM0RVb2)qd3Vn8MBSvohwYN6P8GCIVxmopY3ZBn7vz4RRzkMid3cXNmKJiXYWICm8BKmmJjim4LXfkKGyynqomnIvqfyUJVNgLpG4UkW2pQljV6Fg2tIyu)Nh(N3(5H367rrBW(EZn8CjqCyRkdNMsIv7vce)fSqD3oCSKnZw9V4ifNIkYfSn3ZOWwkfZBXYstA4Qz9vrvzmI2OYiAJUPV5hfBhmaq3K22qYJalJemUcEds1omLKlMLSuqsjITJvwLR9xBIo6jSq)QPGXwp84IXUt9cgVyX3DVB5Ihd(BxV7TlXnMzGfYLzJKtsuOg03qGQGsTXtYqeEU1bWhs(GBMidlVgmGrt3cffPOTaX1l(foRiRXesIm0QfcJCZFszXC9sSST1KI2SGQltsy13G8yC1Uje9jO0C8(MV)tANP17)a3XRksacvKjiBWVjNFe4lxXsT911cAE0oMGnbpfc1wy1RCH9S33Z6mYb97rZfnHuv7hdCscdQrbFfHO)Qq3IcScEqghBSd2CZzQkxrEtfjrDF6ROTWFhECSmjaniTs)hK41jG6kWVn7(LEbZNTWD2ZbUpyFCC0PJwOC2Kq1LUFtZjZD)(jJNQR9kOe8c85xMMMqRTm8Vay6mjBiBMgSoqqmn(8gnyakoUzpvu1BB6ep763rDB0444)rPU2UvTVoqNCr88WKVl9MxAN5v2xEYUYRPNulJQJb34(vFFCo71k9WsT0PU3fmB(Jph89XUpemE6utVH3okQNPBuJZc0Q0YpvEYwrdNS7yTDJRV4IBd5kNr4lTzPdSBq(bogTr0D3PPJzGdA9ShFf(a6fZStPvOD7f7PRu(4eX4x1QdxDOTRcZ1fwDs05891)SLTUszmvoXU7EVtjJtA07rBSujQvz2zlnAnRz1Th(BHVHb6)t5tGPdlh3EuZC3hCCw942ibCkJvfc9rFemwQGKvpf9Bt87mt9XMGUEK33POENfX)5iA)HksFPIYVtr4par32H)ZWHW6xE8IYqmYixwf5U0e2f8jQNqQ0NUut1KpfYIwTbQJD474gfRSQ5NAEhZpMdY7yQUDsb8cwJjVSwC632boywTc)fLo4ou0)Po2engoDQOiFfcoy07rCPQ12x47))d",
			["script_version"] = 8,
		}, -- [12]
		{
			["source"] = false,
			["total_script"] = false,
			["author"] = "Terciob",
			["percent_script"] = false,
			["desc"] = "Show who in your raid group used the healthstone or a heal potion.",
			["icon"] = "Interface\\ICONS\\INV_Stone_04",
			["spellid"] = false,
			["name"] = "Health Potion & Stone",
			["script"] = "				local combatObject, instanceContainer, instanceObject = ...\n				local total, top, amount = 0, 0, 0\n				\n				local listOfHealingActors = combatObject:GetActorList(DETAILS_ATTRIBUTE_HEAL)\n				for _, actorObject in ipairs(listOfHealingActors) do\n					local listOfSpells = actorObject:GetSpellList()\n					local found = false\n					\n					for spellId, spellTable in pairs(listOfSpells) do\n						if (LIB_OPEN_RAID_HEALING_POTIONS[spellId]) then\n							instanceContainer:AddValue(actorObject, spellTable.total)\n							total = total + spellTable.total\n							if (top < spellTable.total) then\n								top = spellTable.total\n							end\n							found = true\n						end\n					end\n					\n					if (found) then\n						amount = amount + 1\n					end\n				end\n				\n				return total, top, amount\n			",
			["target"] = false,
			["tooltip"] = "				local actorObject, combatObject, instanceObject = ...\n				local spellContainer = actorObject:GetSpellContainer(\"spell\")\n				\n				local iconSize = 20\n				\n				local allHealingPotions = {6262}\n				for spellId, potionPower in pairs(LIB_OPEN_RAID_ALL_POTIONS) do\n					allHealingPotions[#allHealingPotions+1] = spellId\n				end\n				\n				for i = 1, #allHealingPotions do\n					local spellId = allHealingPotions[i]\n					local spellTable = spellContainer:GetSpell(spellId)\n					if (spellTable) then\n						local spellName, _, spellIcon = GetSpellInfo(spellId)\n						GameCooltip:AddLine(spellName, Details:ToK(spellTable.total))\n						GameCooltip:AddIcon(spellIcon, 1, 1, iconSize, iconSize)\n						GameCooltip:AddStatusBar (100, 1, 0, 0, 0, 0.75)\n					end\n				end\n			",
			["attribute"] = false,
			["script_version"] = 18,
		}, -- [13]
	},
	["performance_profiles"] = {
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["RaidFinder"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Mythic"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid30"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["exit_log"] = {
		"1 - Closing Janela Info.", -- [1]
		"2 - Clearing user place from instances.", -- [2]
		"  - 1 has baseFrame: yes.", -- [3]
		"  - 2 has baseFrame: yes.", -- [4]
		"4 - Reversing switches.", -- [5]
		"6 - Saving Config.", -- [6]
		"7 - Saving Profiles.", -- [7]
		"8 - Saving nicktag cache.", -- [8]
	},
	["show_warning_id1_amount"] = 2,
	["parser_options"] = {
		["energy_overflow"] = false,
		["shield_overheal"] = false,
	},
	["latest_spell_pool_access"] = 1676570530,
}
__details_backup = {
	["_exit_error"] = {
	},
	["_instance_backup"] = {
	},
}
