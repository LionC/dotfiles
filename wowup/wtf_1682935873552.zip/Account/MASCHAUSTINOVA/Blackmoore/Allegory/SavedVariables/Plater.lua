
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-580-0A6159F7"] = true,
	},
	["spellRangeCheckRangeEnemy"] = {
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["minimap"] = {
		["minimapPos"] = 111.5202631893431,
	},
}
