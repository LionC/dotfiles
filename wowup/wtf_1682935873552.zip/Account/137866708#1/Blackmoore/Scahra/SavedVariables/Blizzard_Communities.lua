
g_clubIdToSeenApplicants = {
	[168417912] = {
		["Player-580-0A66C935"] = true,
	},
}
