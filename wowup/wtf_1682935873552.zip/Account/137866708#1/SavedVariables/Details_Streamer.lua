
Details_StreamerDB = {
	["characters"] = {
		["Xyresia - Blackmoore"] = "Lionc - Blackmoore",
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
		["Bhrian - Blackmoore"] = "Lionc - Blackmoore",
		["Nißa - Blackmoore"] = "Lionc - Blackmoore",
	},
	["profiles"] = {
		["Lionc - Blackmoore"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["main_frame_size"] = {
				300, -- [1]
				500, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 259.4955042100957,
				["radius"] = 160,
				["hide"] = false,
			},
			["point"] = "CENTER",
			["arrow_anchor_x"] = 0,
			["y"] = -7.62939453125e-06,
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_height"] = 20,
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["main_frame_strata"] = "LOW",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = -6.103515625e-05,
				["x"] = 0.000152587890625,
				["update_speed"] = 0.05,
				["size"] = 32,
				["attribute_type"] = 1,
			},
			["x"] = 0,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["arrow_anchor_y"] = 0,
			["font_size"] = 10,
			["main_frame_locked"] = false,
			["author"] = "Details! Team",
		},
	},
}
