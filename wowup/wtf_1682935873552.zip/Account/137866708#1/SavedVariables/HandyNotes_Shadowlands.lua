
HandyNotes_ShadowlandsDB = {
	["profileKeys"] = {
		["Gaeralt - Blackmoore"] = "Default",
		["Lionc - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
