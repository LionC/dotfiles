
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[577] = 30,
		[581] = 30,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-580-08C239B5"] = true,
	},
	["spellRangeCheckRangeEnemy"] = {
		[577] = 30,
		[581] = 30,
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["minimap"] = {
		["minimapPos"] = 245.2591963469805,
	},
}
