
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 151,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006204,
							["damage_from"] = {
								["Omen"] = true,
								["Environment (Falling)"] = true,
							},
							["targets"] = {
								["Omen"] = 604811,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 604811.006204,
							["friendlyfire"] = {
							},
							["end_time"] = 1675437948,
							["dps_started"] = false,
							["total"] = 604811.006204,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16613,
										["targets"] = {
											["Omen"] = 176550,
										},
										["n_dmg"] = 176550,
										["n_min"] = 9582,
										["g_dmg"] = 0,
										["counter"] = 12,
										["ChartData"] = {
											[26] = 176550,
											[23] = 176550,
											[20] = 116291,
											[17] = 16613,
										},
										["total"] = 176550,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 46716,
										["g_amt"] = 0,
										["n_max"] = 14533,
										["targets"] = {
											["Omen"] = 61249,
										},
										["n_dmg"] = 14533,
										["n_min"] = 14533,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 46716,
											[17] = 46716,
											[8] = 46716,
											[26] = 61249,
											[23] = 46716,
											[14] = 46716,
											[5] = 46716,
											[20] = 46716,
										},
										["total"] = 61249,
										["c_max"] = 46716,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 46716,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 33565,
										["targets"] = {
											["Omen"] = 33565,
										},
										["n_dmg"] = 33565,
										["n_min"] = 33565,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[26] = 33565,
											[23] = 33565,
											[20] = 33565,
											[17] = 33565,
										},
										["total"] = 33565,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13154,
										["targets"] = {
											["Omen"] = 13154,
										},
										["n_dmg"] = 13154,
										["n_min"] = 13154,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 13154,
											[17] = 13154,
											[8] = 13154,
											[26] = 13154,
											[23] = 13154,
											[14] = 13154,
											[5] = 13154,
											[20] = 13154,
										},
										["total"] = 13154,
										["c_max"] = 0,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10639,
										["targets"] = {
											["Omen"] = 10639,
										},
										["n_dmg"] = 10639,
										["n_min"] = 10639,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[26] = 10639,
											[23] = 10639,
											[20] = 10639,
											[17] = 10639,
										},
										["total"] = 10639,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 55315,
										["g_amt"] = 0,
										["n_max"] = 21771,
										["targets"] = {
											["Omen"] = 177429,
										},
										["n_dmg"] = 122114,
										["e_dmg"] = {
											23024, -- [1]
										},
										["e_lvl"] = {
											1, -- [1]
										},
										["n_min"] = 3953,
										["g_dmg"] = 0,
										["counter"] = 21,
										["ChartData"] = {
											[11] = 62964,
											[17] = 88819,
											[8] = 51621,
											[26] = 173101,
											[23] = 154405,
											[14] = 76793,
											[5] = 38828,
											[20] = 128502,
										},
										["total"] = 177429,
										["c_max"] = 13829,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 13828,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 17,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 46322,
										["targets"] = {
											["Omen"] = 78479,
										},
										["n_dmg"] = 78479,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											78479, -- [1]
										},
										["n_min"] = 32157,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 46322,
											[17] = 46322,
											[26] = 78479,
											[14] = 46322,
											[23] = 78479,
											[20] = 78479,
										},
										["total"] = 78479,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[389839] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 53746,
										["targets"] = {
											["Omen"] = 53746,
										},
										["n_dmg"] = 53746,
										["n_min"] = 53746,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 53746,
											[17] = 53746,
											[8] = 53746,
											[26] = 53746,
											[14] = 53746,
											[23] = 53746,
											[20] = 53746,
										},
										["total"] = 53746,
										["c_max"] = 0,
										["id"] = 389839,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 53390.006204,
							["start_time"] = 1675437919,
							["delay"] = 0,
							["last_event"] = 1675437948,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 132175.00753,
							["damage_from"] = {
								["Ormthang"] = true,
								["Noctavian-Khaz'goroth"] = true,
								["Blasphemy <Létizia-Baelgun>"] = true,
								["Esera-Norgannon"] = true,
								["Deanisa-DunMorogh"] = true,
								["Collectivevx-Blackrock"] = true,
								["Allegory"] = true,
								["Zurasius"] = true,
								["Mirror Image <Noctavian-Khaz'goroth>"] = true,
								["Morion-Lothar"] = true,
								["Jubtip"] = true,
								["Forodim-Tichondrius"] = true,
								["Infernal <Létizia-Baelgun>"] = true,
								["Létizia-Baelgun"] = true,
								["Vygosa"] = true,
								["Guildoran-Thrall"] = true,
								["Firmi-Ysera"] = true,
							},
							["targets"] = {
								["Infernal <Létizia-Baelgun>"] = 105652,
								["Collectivevx-Blackrock"] = 9978,
								["Ormthang"] = 103993,
								["Esera-Norgannon"] = 32418,
								["Allegory"] = 48763,
								["Mirror Image <Noctavian-Khaz'goroth>"] = 66741,
								["Blasphemy <Létizia-Baelgun>"] = 17103,
								["Létizia-Baelgun"] = 51622,
								["Morion-Lothar"] = 53707,
								["Jubtip"] = 52954,
								["Forodim-Tichondrius"] = 128407,
								["Deanisa-DunMorogh"] = 56455,
								["Guildoran-Thrall"] = 103489,
								["Firmi-Ysera"] = 68394,
								["Zurasius"] = 157144,
								["Vygosa"] = 53459,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-1469-1-218-15467-00005D2757",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "15467",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1110279.00753,
							["fight_component"] = true,
							["end_time"] = 1675437948,
							["dps_started"] = false,
							["total"] = 1110279.00753,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Omen",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 2,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 34588,
										["targets"] = {
											["Firmi-Ysera"] = 31090,
											["Zurasius"] = 52600,
											["Forodim-Tichondrius"] = 34588,
										},
										["n_dmg"] = 118278,
										["n_min"] = 6420,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 118278,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["a_dmg"] = 45355,
										["spellschool"] = 1,
										["extra"] = {
										},
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 4,
										["n_amt"] = 7,
										["b_dmg"] = 13024,
										["r_amt"] = 0,
									}, -- [1]
									[104903] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9369,
										["targets"] = {
											["Infernal <Létizia-Baelgun>"] = 1577,
											["Firmi-Ysera"] = 11498,
											["Zurasius"] = 1088,
										},
										["n_dmg"] = 14163,
										["n_min"] = 1088,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 14163,
										["c_max"] = 0,
										["id"] = 104903,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 2129,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 1,
										["n_amt"] = 4,
										["b_dmg"] = 2129,
										["r_amt"] = 0,
									},
									[26540] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19312,
										["targets"] = {
											["Mirror Image <Noctavian-Khaz'goroth>"] = 66741,
											["Collectivevx-Blackrock"] = 9978,
											["Ormthang"] = 103993,
											["Firmi-Ysera"] = 25806,
											["Infernal <Létizia-Baelgun>"] = 104075,
											["Létizia-Baelgun"] = 51622,
											["Blasphemy <Létizia-Baelgun>"] = 17103,
											["Allegory"] = 48763,
											["Morion-Lothar"] = 53707,
											["Jubtip"] = 52954,
											["Forodim-Tichondrius"] = 93819,
											["Deanisa-DunMorogh"] = 56455,
											["Guildoran-Thrall"] = 103489,
											["Vygosa"] = 53459,
											["Zurasius"] = 103456,
											["Esera-Norgannon"] = 32418,
										},
										["n_dmg"] = 977838,
										["n_min"] = 9978,
										["g_dmg"] = 0,
										["counter"] = 58,
										["total"] = 977838,
										["c_max"] = 0,
										["id"] = 26540,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 347683,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 21,
										["n_amt"] = 58,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 5560814.00753,
							["start_time"] = 1675437921,
							["delay"] = 0,
							["last_event"] = 1675437948,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 151,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Allegory"] = 151,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = true,
							["classe"] = "EVOKER",
							["totalover"] = 151.005963,
							["total_without_pet"] = 4627.005963,
							["total"] = 4627.005963,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = true,
							["serial"] = "Player-580-0A6159F7",
							["totalabsorb"] = 0.005963,
							["last_hps"] = 0,
							["targets"] = {
								["Allegory"] = 4627,
							},
							["totalover_without_pet"] = 0.005963,
							["healing_taken"] = 4627.005963,
							["timeMachine"] = 1,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
								["Allegory"] = true,
							},
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[372014] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Allegory"] = 151,
										},
										["n_max"] = 4627,
										["targets"] = {
											["Allegory"] = 4627,
										},
										["n_min"] = 4627,
										["counter"] = 1,
										["overheal"] = 151,
										["total"] = 4627,
										["c_max"] = 0,
										["id"] = 372014,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_curado"] = 4627,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["start_time"] = 1675440827,
							["spec"] = 1467,
							["custom"] = 0,
							["tipo"] = 2,
							["aID"] = "580-0A6159F7",
							["totaldenied"] = 0.005963,
							["delay"] = 1675440827,
							["last_event"] = 1675440827,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 151,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.007957,
							["resource"] = 0.007957,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "EVOKER",
							["totalover"] = 0.007957,
							["total"] = 0.007957,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 1467,
							["aID"] = "580-0A6159F7",
							["flag_original"] = 1300,
							["last_event"] = 0,
							["alternatepower"] = 6.007957,
							["passiveover"] = 0.007957,
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 151,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 2,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 26,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 141,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 29,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["activedamt"] = 1,
										["id"] = 390936,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[303601] = {
										["activedamt"] = 1,
										["id"] = 303601,
										["targets"] = {
										},
										["uptime"] = 29,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 29,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 42,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[26649] = 1,
								[370452] = 2,
								[356995] = 3,
								[26624] = 1,
								[362969] = 1,
								[375087] = 1,
								[361469] = 1,
								[26374] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675437948,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Omen",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[104903] = 3,
								[26540] = 2,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-1469-1-218-15467-00005D2757",
							["aID"] = "15467",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 151,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["tempo_start"] = 1675437919,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Allegory"] = {
						["total"] = 6,
						["last"] = 0,
					},
				},
				["combat_counter"] = 745,
				["playing_solo"] = true,
				["totals"] = {
					1715089.689553998, -- [1]
					4626.897382999966, -- [2]
					{
						-0.01662499999998435, -- [1]
						[0] = -0.045559,
						["alternatepower"] = 0,
						[3] = -0.01510100000001557,
						[6] = -0.004162000000007993,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Allegory"] = {
						{
							true, -- [1]
							3, -- [2]
							4627, -- [3]
							1675440827.608, -- [4]
							234293, -- [5]
							"Environment (Falling)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							false, -- [1]
							372014, -- [2]
							4778, -- [3]
							1675440827.608, -- [4]
							238920, -- [5]
							"Allegory", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 3,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "16:25:48",
				["hasTimer"] = 28.03299999999581,
				["cleu_timeline"] = {
				},
				["enemy"] = "Omen",
				["TotalElapsedCombatTime"] = 398987.441,
				["CombatEndedAt"] = 398987.441,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "16:25:20",
				["end_time"] = 398987.441,
				["combat_id"] = 151,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Silky Moth"] = 1,
					["Mirror Image"] = 1,
					["Omen"] = 1,
					["Squirrel"] = 2,
					["Deer"] = 1,
				},
				["totals_grupo"] = {
					604811, -- [1]
					4627, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 604811.006204,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 398958.699,
				["contra"] = "Omen",
				["TimeData"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 150,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002078,
							["damage_from"] = {
							},
							["targets"] = {
								["Minion of Omen"] = 160487,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 160487.002078,
							["friendlyfire"] = {
							},
							["end_time"] = 1675437703,
							["dps_started"] = false,
							["total"] = 160487.002078,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 47600,
										["targets"] = {
											["Minion of Omen"] = 47600,
										},
										["n_dmg"] = 47600,
										["n_min"] = 47600,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 47600,
											[17] = 47600,
											[15] = 47600,
											[5] = 47600,
											[8] = 47600,
										},
										["total"] = 47600,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10309,
										["g_amt"] = 0,
										["n_max"] = 19552,
										["targets"] = {
											["Minion of Omen"] = 55257,
										},
										["n_dmg"] = 44948,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											55257, -- [1]
										},
										["n_min"] = 3586,
										["g_dmg"] = 0,
										["counter"] = 8,
										["ChartData"] = {
											[11] = 24135,
											[15] = 28668,
											[17] = 43650,
										},
										["total"] = 55257,
										["c_max"] = 10309,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10309,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 7,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 24821,
										["targets"] = {
											["Minion of Omen"] = 24821,
										},
										["n_dmg"] = 24821,
										["n_min"] = 24821,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[17] = 24821,
										},
										["total"] = 24821,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11473,
										["targets"] = {
											["Minion of Omen"] = 32809,
										},
										["n_dmg"] = 32809,
										["n_min"] = 10352,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 32809,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002078,
							["start_time"] = 1675437683,
							["delay"] = 0,
							["last_event"] = 1675437703,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002123,
							["serial"] = "Creature-0-1469-1-218-15466-00005D262E",
							["damage_from"] = {
								["Ormthang"] = true,
								["Noctavian-Khaz'goroth"] = true,
								["Morion-Lothar"] = true,
								["Collectivevx-Blackrock"] = true,
								["Deanisa-DunMorogh"] = true,
								["Guildoran-Thrall"] = true,
								["Allegory"] = true,
								["Zurasius"] = true,
								["Létizia-Baelgun"] = true,
							},
							["targets"] = {
								["Collectivevx-Blackrock"] = 6115,
							},
							["pets"] = {
							},
							["monster"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "15466",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6115.002123,
							["end_time"] = 1675437919,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 6115.002123,
							["classe"] = "UNKNOW",
							["friendlyfire"] = {
							},
							["nome"] = "Minion of Omen",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6115,
										["targets"] = {
											["Collectivevx-Blackrock"] = 6115,
										},
										["n_dmg"] = 6115,
										["n_min"] = 6115,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6115,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 844506.002123,
							["start_time"] = 1675437876,
							["delay"] = 1675437745,
							["last_event"] = 1675437745,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 150,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 150,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 150,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 77,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[303601] = {
										["activedamt"] = 1,
										["id"] = 303601,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[358267] = {
										["activedamt"] = 1,
										["id"] = 358267,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["activedamt"] = 1,
										["id"] = 390936,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 16,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[26624] = 3,
								[361469] = 1,
								[26374] = 3,
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675437703,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 150,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 398955.382,
				["tempo_start"] = 1675437683,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 744,
				["playing_solo"] = true,
				["totals"] = {
					166601.9255730003, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = -0.019623,
						["alternatepower"] = 0,
						[3] = -0.003416,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "16:21:44",
				["hasTimer"] = 20.00800000003073,
				["cleu_timeline"] = {
				},
				["enemy"] = "Minion of Omen",
				["TotalElapsedCombatTime"] = 13.44099999999162,
				["CombatEndedAt"] = 398952.465,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "16:21:23",
				["end_time"] = 398743.028,
				["combat_id"] = 150,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Minion of Omen"] = 1,
				},
				["totals_grupo"] = {
					160487, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 160487.002078,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 398722.244,
				["contra"] = "Minion of Omen",
				["TimeData"] = {
				},
			}, -- [2]
			{
				{
					["combatId"] = 149,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005634,
							["damage_from"] = {
							},
							["targets"] = {
								["Minion of Omen"] = 131314,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 131314.005634,
							["friendlyfire"] = {
							},
							["end_time"] = 1675437491,
							["dps_started"] = false,
							["total"] = 131314.005634,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 47867,
										["g_amt"] = 0,
										["n_max"] = 12806,
										["targets"] = {
											["Minion of Omen"] = 108569,
										},
										["n_dmg"] = 60702,
										["n_min"] = 11493,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 108569,
										["c_max"] = 25727,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 22140,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 22745,
										["targets"] = {
											["Minion of Omen"] = 22745,
										},
										["n_dmg"] = 22745,
										["n_min"] = 22745,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 22745,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.005634,
							["start_time"] = 1675437486,
							["delay"] = 0,
							["last_event"] = 1675437490,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 61591.004423,
							["serial"] = "Creature-0-1469-1-218-15466-00005D258A",
							["damage_from"] = {
								["Jubtip"] = true,
								["Guildoran-Thrall"] = true,
								["Deanisa-DunMorogh"] = true,
								["Létizia-Baelgun"] = true,
								["Vygosa"] = true,
								["Zurasius"] = true,
								["Allegory"] = true,
							},
							["targets"] = {
								["Létizia-Baelgun"] = 29954,
								["Vygosa"] = 8595,
								["Zurasius"] = 31637,
							},
							["pets"] = {
							},
							["monster"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "15466",
							["raid_targets"] = {
							},
							["total_without_pet"] = 70186.004423,
							["end_time"] = 1675437683,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 70186.004423,
							["classe"] = "UNKNOW",
							["friendlyfire"] = {
							},
							["nome"] = "Minion of Omen",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11734,
										["targets"] = {
											["Létizia-Baelgun"] = 29954,
											["Vygosa"] = 8595,
											["Zurasius"] = 31637,
										},
										["n_dmg"] = 70186,
										["n_min"] = 2102,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 70186,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 18,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1356940.004423,
							["start_time"] = 1675437618,
							["delay"] = 1675437640,
							["last_event"] = 1675437640,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 149,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 149,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 149,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 16,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[303601] = {
										["activedamt"] = 1,
										["id"] = 303601,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[389820] = {
										["activedamt"] = 1,
										["id"] = 389820,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 8,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675437491,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 149,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 398710.202,
				["tempo_start"] = 1675437486,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 743,
				["playing_solo"] = true,
				["totals"] = {
					201499.9539169999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = -0.013652,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "16:18:12",
				["hasTimer"] = 4.001000000047498,
				["cleu_timeline"] = {
				},
				["enemy"] = "Minion of Omen",
				["TotalElapsedCombatTime"] = 5.75,
				["CombatEndedAt"] = 398639.969,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "16:18:07",
				["end_time"] = 398530.556,
				["combat_id"] = 149,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Minion of Omen"] = 1,
				},
				["totals_grupo"] = {
					131314, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 131314.005634,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 398525.898,
				["contra"] = "Minion of Omen",
				["TimeData"] = {
				},
			}, -- [3]
			{
				{
					["combatId"] = 148,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007509,
							["damage_from"] = {
								["Cygenoth"] = true,
							},
							["targets"] = {
								["Cygenoth"] = 1131736,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1131736.007509,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435942,
							["dps_started"] = false,
							["total"] = 1131736.007509,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 16686,
										["g_amt"] = 0,
										["n_max"] = 9646,
										["targets"] = {
											["Cygenoth"] = 33808,
										},
										["n_dmg"] = 17122,
										["n_min"] = 7476,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[59] = 33808,
											[35] = 9646,
											[56] = 33808,
											[53] = 33808,
											[29] = 9646,
											[50] = 33808,
											[47] = 33808,
											[32] = 9646,
											[44] = 33808,
											[41] = 9646,
											[38] = 9646,
											[20] = 9646,
											[17] = 9646,
											[23] = 9646,
											[26] = 9646,
										},
										["total"] = 33808,
										["c_max"] = 16686,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 16686,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 108146,
										["g_amt"] = 0,
										["n_max"] = 42939,
										["targets"] = {
											["Cygenoth"] = 180574,
										},
										["n_dmg"] = 72428,
										["e_lvl"] = {
											2, -- [1]
										},
										["e_dmg"] = {
											180574, -- [1]
										},
										["n_min"] = 29489,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[59] = 180574,
											[32] = 137635,
											[17] = 137635,
											[9] = 108146,
											[35] = 137635,
											[38] = 137635,
											[20] = 137635,
											[41] = 137635,
											[11] = 108146,
											[44] = 137635,
											[23] = 137635,
											[47] = 137635,
											[50] = 137635,
											[26] = 137635,
											[53] = 137635,
											[14] = 108146,
											[56] = 180574,
											[29] = 137635,
											[6] = 108146,
										},
										["total"] = 180574,
										["c_max"] = 108146,
										["e_amt"] = 2,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 108146,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["e_total"] = 2,
										["r_amt"] = 0,
									},
									[353759] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 61946,
										["g_amt"] = 0,
										["n_max"] = 16712,
										["targets"] = {
											["Cygenoth"] = 82215,
										},
										["n_dmg"] = 20269,
										["n_min"] = 3557,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[56] = 16712,
											[59] = 82215,
										},
										["total"] = 82215,
										["c_max"] = 38440,
										["id"] = 353759,
										["r_dmg"] = 0,
										["spellschool"] = 12,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 23506,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 29935,
										["g_amt"] = 0,
										["n_max"] = 15674,
										["targets"] = {
											["Cygenoth"] = 175866,
										},
										["n_dmg"] = 145931,
										["n_min"] = 12850,
										["g_dmg"] = 0,
										["counter"] = 12,
										["ChartData"] = {
											[59] = 175866,
											[32] = 175866,
											[17] = 123612,
											[9] = 68749,
											[35] = 175866,
											[38] = 175866,
											[20] = 136677,
											[41] = 175866,
											[11] = 68749,
											[44] = 175866,
											[23] = 175866,
											[47] = 175866,
											[50] = 175866,
											[26] = 175866,
											[53] = 175866,
											[14] = 68749,
											[56] = 175866,
											[29] = 175866,
											[6] = 68749,
										},
										["total"] = 175866,
										["c_max"] = 29935,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 29935,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 35363,
										["g_amt"] = 0,
										["n_max"] = 19122,
										["targets"] = {
											["Cygenoth"] = 89903,
										},
										["n_dmg"] = 54540,
										["n_min"] = 9018,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[59] = 80885,
											[32] = 70643,
											[17] = 35280,
											[35] = 70643,
											[38] = 70643,
											[20] = 70643,
											[41] = 70643,
											[11] = 16158,
											[44] = 80885,
											[23] = 70643,
											[47] = 80885,
											[50] = 80885,
											[26] = 70643,
											[53] = 80885,
											[14] = 35280,
											[56] = 80885,
											[29] = 70643,
										},
										["total"] = 89903,
										["c_max"] = 35363,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 35363,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 66295,
										["g_amt"] = 0,
										["n_max"] = 48221,
										["targets"] = {
											["Cygenoth"] = 274665,
										},
										["n_dmg"] = 208370,
										["n_min"] = 27140,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[59] = 274665,
											[32] = 142973,
											[17] = 103687,
											[9] = 66295,
											[35] = 142973,
											[38] = 142973,
											[20] = 103687,
											[41] = 191194,
											[11] = 66295,
											[44] = 191194,
											[23] = 103687,
											[47] = 218853,
											[50] = 247525,
											[26] = 103687,
											[53] = 274665,
											[14] = 103687,
											[56] = 274665,
											[29] = 103687,
										},
										["total"] = 274665,
										["c_max"] = 66295,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 66295,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20753,
										["targets"] = {
											["Cygenoth"] = 55818,
										},
										["n_dmg"] = 55818,
										["n_min"] = 15808,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[59] = 55818,
											[32] = 40010,
											[17] = 19257,
											[35] = 40010,
											[38] = 40010,
											[20] = 19257,
											[41] = 40010,
											[11] = 19257,
											[44] = 40010,
											[23] = 19257,
											[47] = 40010,
											[50] = 55818,
											[26] = 40010,
											[53] = 55818,
											[14] = 19257,
											[56] = 55818,
											[29] = 40010,
										},
										["total"] = 55818,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 76355,
										["g_amt"] = 0,
										["n_max"] = 21093,
										["targets"] = {
											["Cygenoth"] = 238887,
										},
										["n_dmg"] = 162532,
										["e_lvl"] = {
											2, -- [1]
										},
										["e_dmg"] = {
											238887, -- [1]
										},
										["n_min"] = 1054,
										["g_dmg"] = 0,
										["counter"] = 34,
										["ChartData"] = {
											[59] = 234151,
											[32] = 148197,
											[17] = 105276,
											[9] = 37641,
											[35] = 148197,
											[38] = 166063,
											[20] = 116146,
											[41] = 174587,
											[11] = 57865,
											[44] = 188312,
											[23] = 132460,
											[47] = 196852,
											[50] = 213224,
											[26] = 137715,
											[53] = 218027,
											[14] = 79396,
											[56] = 226705,
											[29] = 148197,
											[6] = 21093,
										},
										["total"] = 238887,
										["c_max"] = 15007,
										["e_amt"] = 2,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 9607,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 28,
										["e_total"] = 2,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 248033.007509,
							["start_time"] = 1675435881,
							["delay"] = 0,
							["last_event"] = 1675435942,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006534,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 248033,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185660-00005D1ED4",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185660",
							["raid_targets"] = {
							},
							["total_without_pet"] = 248033.006534,
							["fight_component"] = true,
							["end_time"] = 1675435942,
							["dps_started"] = false,
							["total"] = 248033.006534,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Cygenoth",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10262,
										["targets"] = {
											["Allegory"] = 30094,
										},
										["n_dmg"] = 30094,
										["n_min"] = 5269,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 30094,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[394267] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 58194,
										["targets"] = {
											["Allegory"] = 58194,
										},
										["n_dmg"] = 58194,
										["n_min"] = 58194,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 58194,
										["c_max"] = 0,
										["id"] = 394267,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[394262] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 394262,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[394275] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 22350,
										["targets"] = {
											["Allegory"] = 44373,
										},
										["n_dmg"] = 44373,
										["n_min"] = 22023,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 44373,
										["c_max"] = 0,
										["id"] = 394275,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[394167] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9157,
										["targets"] = {
											["Allegory"] = 115372,
										},
										["n_dmg"] = 115372,
										["n_min"] = 6409,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 115372,
										["c_max"] = 0,
										["id"] = 394167,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 15,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1131736.006534,
							["start_time"] = 1675435909,
							["delay"] = 1675435921,
							["last_event"] = 1675435939,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 148,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Allegory"] = 7849,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "EVOKER",
							["totalover"] = 7849.006592,
							["total_without_pet"] = 168037.006592,
							["total"] = 168037.006592,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-580-0A6159F7",
							["totalabsorb"] = 0.006592,
							["last_hps"] = 0,
							["targets"] = {
								["Allegory"] = 168037,
							},
							["totalover_without_pet"] = 0.006592,
							["healing_taken"] = 168037.006592,
							["fight_component"] = true,
							["end_time"] = 1675435942,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
								["Allegory"] = true,
							},
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[374349] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Allegory"] = 3590,
										},
										["n_max"] = 3590,
										["targets"] = {
											["Allegory"] = 22052,
										},
										["n_min"] = 2718,
										["counter"] = 9,
										["overheal"] = 3590,
										["total"] = 22052,
										["c_max"] = 0,
										["id"] = 374349,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_curado"] = 22052,
										["totaldenied"] = 0,
										["n_amt"] = 9,
										["absorbed"] = 0,
									},
									[387763] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 22378,
										["targets"] = {
											["Allegory"] = 22378,
										},
										["n_min"] = 22378,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 22378,
										["c_max"] = 0,
										["id"] = 387763,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_curado"] = 22378,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["absorbed"] = 0,
									},
									[361195] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 27712,
										["targets"] = {
											["Allegory"] = 27712,
										},
										["n_min"] = 27712,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 27712,
										["c_max"] = 0,
										["id"] = 361195,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_curado"] = 27712,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["absorbed"] = 0,
									},
									[355916] = {
										["c_amt"] = 1,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Allegory"] = 4259,
										},
										["n_max"] = 0,
										["targets"] = {
											["Allegory"] = 31251,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 4259,
										["total"] = 31251,
										["c_max"] = 31251,
										["id"] = 355916,
										["targets_absorbs"] = {
										},
										["c_min"] = 31251,
										["c_curado"] = 31251,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 0,
										["absorbed"] = 0,
									},
									[390941] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 64644,
										["targets"] = {
											["Allegory"] = 64644,
										},
										["n_min"] = 64644,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 64644,
										["c_max"] = 0,
										["id"] = 390941,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_curado"] = 64644,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["start_time"] = 1675435923,
							["spec"] = 1467,
							["custom"] = 0,
							["tipo"] = 2,
							["aID"] = "580-0A6159F7",
							["totaldenied"] = 0.006592,
							["delay"] = 1675435926,
							["last_event"] = 1675435926,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 148,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001871,
							["resource"] = 0.001871,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "EVOKER",
							["totalover"] = 0.001871,
							["total"] = 0.001871,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 1467,
							["aID"] = "580-0A6159F7",
							["flag_original"] = 1300,
							["last_event"] = 0,
							["alternatepower"] = 18.001871,
							["passiveover"] = 0.001871,
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 148,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 32,
										["appliedamt"] = 7,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 3,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[353759] = {
										["activedamt"] = 0,
										["id"] = 353759,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 59,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 48,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["cooldowns_defensive"] = 3.006067,
							["buff_uptime"] = 255,
							["aID"] = "580-0A6159F7",
							["cooldowns_defensive_targets"] = {
								["--x--x--"] = 3,
							},
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 61,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 61,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357210] = {
										["activedamt"] = 1,
										["id"] = 357210,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 2,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[363916] = {
										["activedamt"] = 2,
										["id"] = 363916,
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 3,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 3,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[374349] = {
										["activedamt"] = 1,
										["id"] = 374349,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 4,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 4,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[374348] = {
										["activedamt"] = 1,
										["id"] = 374348,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["activedamt"] = 1,
										["id"] = 390936,
										["targets"] = {
										},
										["uptime"] = 17,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 2,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["fight_component"] = true,
							["debuff_uptime"] = 158,
							["cooldowns_defensive_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[363916] = {
										["id"] = 363916,
										["targets"] = {
											["--x--x--"] = 2,
										},
										["counter"] = 2,
									},
									[374348] = {
										["id"] = 374348,
										["targets"] = {
											["--x--x--"] = 1,
										},
										["counter"] = 1,
									},
								},
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 2,
								[362969] = 3,
								[357210] = 1,
								[374348] = 1,
								[375087] = 1,
								[357211] = 4,
								[360995] = 1,
								[355913] = 1,
								[361195] = 1,
								[361469] = 7,
								[370452] = 3,
								[363916] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435942,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Cygenoth",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[394262] = 2,
								[394275] = 2,
								[394167] = 3,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185660-00005D1ED4",
							["aID"] = "185660",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 148,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["tempo_start"] = 1675435881,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Allegory"] = {
						["total"] = 18,
						["last"] = 0,
					},
				},
				["combat_counter"] = 742,
				["playing_solo"] = true,
				["totals"] = {
					1379768.900503, -- [1]
					168036.99614, -- [2]
					{
						-0.007037, -- [1]
						[0] = -0.017221,
						["alternatepower"] = 0,
						[3] = -0.00594300000000203,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 3,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:52:23",
				["hasTimer"] = 61.08299999998417,
				["cleu_timeline"] = {
				},
				["enemy"] = "Cygenoth",
				["TotalElapsedCombatTime"] = 396982.109,
				["CombatEndedAt"] = 396982.109,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:51:21",
				["end_time"] = 396982.109,
				["combat_id"] = 148,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Cygenoth"] = 1,
				},
				["totals_grupo"] = {
					1131736, -- [1]
					168037, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 3,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Allegory"] = 168037.006592,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 1131736.007509,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396920.285,
				["contra"] = "Cygenoth",
				["TimeData"] = {
				},
			}, -- [4]
			{
				{
					["combatId"] = 147,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004395,
							["damage_from"] = {
								["Worldbreaker Bulwark"] = true,
							},
							["targets"] = {
								["Worldbreaker Bulwark"] = 227770,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 227770.004395,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435856,
							["dps_started"] = false,
							["total"] = 227770.004395,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20638,
										["targets"] = {
											["Worldbreaker Bulwark"] = 20638,
										},
										["n_dmg"] = 20638,
										["n_min"] = 20638,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 20638,
											[17] = 20638,
											[8] = 20638,
											[14] = 20638,
											[6] = 20638,
										},
										["total"] = 20638,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 24323,
										["g_amt"] = 0,
										["n_max"] = 10514,
										["targets"] = {
											["Worldbreaker Bulwark"] = 34837,
										},
										["n_dmg"] = 10514,
										["n_min"] = 10514,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 34837,
											[14] = 34837,
											[17] = 34837,
											[8] = 10514,
										},
										["total"] = 34837,
										["c_max"] = 24323,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 24323,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 65475,
										["targets"] = {
											["Worldbreaker Bulwark"] = 109503,
										},
										["n_dmg"] = 109503,
										["n_min"] = 21900,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 65475,
											[17] = 87603,
											[8] = 65475,
											[14] = 65475,
											[6] = 65475,
										},
										["total"] = 109503,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7502,
										["targets"] = {
											["Worldbreaker Bulwark"] = 7502,
										},
										["n_dmg"] = 7502,
										["n_min"] = 7502,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 7502,
											[14] = 7502,
											[17] = 7502,
											[8] = 7502,
										},
										["total"] = 7502,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 55290,
										["targets"] = {
											["Worldbreaker Bulwark"] = 55290,
										},
										["n_dmg"] = 55290,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											55290, -- [1]
										},
										["n_min"] = 55290,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 55290,
											[17] = 55290,
											[8] = 55290,
											[14] = 55290,
											[6] = 55290,
										},
										["total"] = 55290,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 25000.004395,
							["start_time"] = 1675435836,
							["delay"] = 0,
							["last_event"] = 1675435855,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008555,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 25000,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185596-00005D1ED4",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185596",
							["raid_targets"] = {
							},
							["total_without_pet"] = 25000.008555,
							["fight_component"] = true,
							["end_time"] = 1675435856,
							["dps_started"] = false,
							["total"] = 25000.008555,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Bulwark",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 8964,
										["g_amt"] = 0,
										["n_max"] = 6255,
										["targets"] = {
											["Allegory"] = 25000,
										},
										["n_dmg"] = 16036,
										["n_min"] = 4805,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 25000,
										["c_max"] = 8964,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 8964,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387410] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 387410,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 227770.008555,
							["start_time"] = 1675435842,
							["delay"] = 0,
							["last_event"] = 1675435853,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 147,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 147,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 147,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = -1,
										["id"] = 370452,
										["targets"] = {
										},
										["actived_at"] = 1675435842,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 48,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 9,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[357211] = 2,
								[361469] = 3,
								[362969] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435856,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Bulwark",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[387410] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185596-00005D1ED4",
							["aID"] = "185596",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 147,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396909.784,
				["tempo_start"] = 1675435836,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 741,
				["playing_solo"] = true,
				["totals"] = {
					252769.98505, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:50:56",
				["hasTimer"] = 19.00899999996182,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Bulwark",
				["TotalElapsedCombatTime"] = 396895.251,
				["CombatEndedAt"] = 396895.251,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:50:36",
				["end_time"] = 396895.251,
				["combat_id"] = 147,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Bulwark"] = 1,
				},
				["totals_grupo"] = {
					227770, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 227770.004395,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396875.551,
				["contra"] = "Worldbreaker Bulwark",
				["TimeData"] = {
				},
			}, -- [5]
			{
				{
					["combatId"] = 146,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002185,
							["damage_from"] = {
								["Weaponmaster Vordak"] = true,
								["Worldbreaker Cultist"] = true,
							},
							["targets"] = {
								["Weaponmaster Vordak"] = 648568,
								["Worldbreaker Cultist"] = 125062,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 773630.002185,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435822,
							["dps_started"] = false,
							["total"] = 773630.002185,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[357209] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6040,
										["g_amt"] = 0,
										["n_max"] = 40315,
										["targets"] = {
											["Weaponmaster Vordak"] = 69519,
											["Worldbreaker Cultist"] = 40315,
										},
										["n_dmg"] = 103794,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											109834, -- [1]
										},
										["n_min"] = 2611,
										["g_dmg"] = 0,
										["counter"] = 16,
										["ChartData"] = {
											[35] = 63191,
											[50] = 109834,
											[29] = 51874,
											[47] = 69519,
											[44] = 69519,
											[32] = 54517,
											[41] = 69519,
											[38] = 69519,
											[20] = 30742,
											[17] = 23136,
											[15] = 15526,
											[23] = 34545,
											[26] = 45421,
										},
										["total"] = 109834,
										["c_max"] = 6040,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 6040,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 15,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20433,
										["targets"] = {
											["Weaponmaster Vordak"] = 20433,
										},
										["n_dmg"] = 20433,
										["n_min"] = 20433,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[50] = 20433,
											[47] = 20433,
											[26] = 20433,
											[44] = 20433,
											[41] = 20433,
											[15] = 20433,
											[8] = 20433,
											[38] = 20433,
											[17] = 20433,
											[5] = 20433,
											[35] = 20433,
											[20] = 20433,
											[32] = 20433,
											[29] = 20433,
											[12] = 20433,
											[23] = 20433,
										},
										["total"] = 20433,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[353759] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 47710,
										["g_amt"] = 0,
										["n_max"] = 10373,
										["targets"] = {
											["Weaponmaster Vordak"] = 47155,
											["Worldbreaker Cultist"] = 47645,
										},
										["n_dmg"] = 47090,
										["n_min"] = 2557,
										["g_dmg"] = 0,
										["counter"] = 8,
										["ChartData"] = {
											[50] = 94800,
											[44] = 94800,
											[38] = 94800,
											[32] = 94800,
											[29] = 94800,
											[41] = 94800,
											[35] = 94800,
											[47] = 94800,
										},
										["total"] = 94800,
										["c_max"] = 23855,
										["id"] = 353759,
										["r_dmg"] = 0,
										["spellschool"] = 12,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 23855,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 95335,
										["g_amt"] = 0,
										["n_max"] = 13761,
										["targets"] = {
											["Weaponmaster Vordak"] = 91708,
											["Worldbreaker Cultist"] = 37102,
										},
										["n_dmg"] = 33475,
										["n_min"] = 8681,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[50] = 128810,
											[47] = 85465,
											[26] = 85465,
											[44] = 85465,
											[41] = 85465,
											[15] = 49490,
											[8] = 13761,
											[38] = 85465,
											[17] = 49490,
											[5] = 13761,
											[35] = 85465,
											[20] = 49490,
											[32] = 85465,
											[29] = 85465,
											[12] = 49490,
											[23] = 85465,
										},
										["total"] = 128810,
										["c_max"] = 35729,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 17276,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 60315,
										["g_amt"] = 0,
										["n_max"] = 15023,
										["targets"] = {
											["Weaponmaster Vordak"] = 150453,
										},
										["n_dmg"] = 90138,
										["n_min"] = 15023,
										["g_dmg"] = 0,
										["counter"] = 8,
										["ChartData"] = {
											[26] = 150453,
											[50] = 150453,
											[47] = 150453,
											[29] = 150453,
											[44] = 150453,
											[41] = 150453,
											[32] = 150453,
											[38] = 150453,
											[35] = 150453,
											[20] = 60092,
											[17] = 60092,
											[15] = 60092,
											[23] = 60092,
											[12] = 15023,
										},
										["total"] = 150453,
										["c_max"] = 34553,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 25762,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37773,
										["targets"] = {
											["Weaponmaster Vordak"] = 111592,
										},
										["n_dmg"] = 111592,
										["n_min"] = 21510,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[50] = 111592,
											[47] = 111592,
											[26] = 111592,
											[44] = 111592,
											[41] = 111592,
											[15] = 68252,
											[8] = 68252,
											[38] = 111592,
											[17] = 68252,
											[5] = 30479,
											[35] = 111592,
											[20] = 68252,
											[32] = 111592,
											[29] = 111592,
											[12] = 68252,
											[23] = 111592,
										},
										["total"] = 111592,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11645,
										["targets"] = {
											["Weaponmaster Vordak"] = 11645,
										},
										["n_dmg"] = 11645,
										["n_min"] = 11645,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[50] = 11645,
											[26] = 11645,
											[47] = 11645,
											[44] = 11645,
											[29] = 11645,
											[8] = 11645,
											[41] = 11645,
											[17] = 11645,
											[38] = 11645,
											[35] = 11645,
											[20] = 11645,
											[32] = 11645,
											[15] = 11645,
											[23] = 11645,
											[12] = 11645,
										},
										["total"] = 11645,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 66475,
										["g_amt"] = 0,
										["n_max"] = 57982,
										["targets"] = {
											["Weaponmaster Vordak"] = 146063,
										},
										["n_dmg"] = 79588,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											146063, -- [1]
										},
										["n_min"] = 21606,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[50] = 146063,
											[47] = 146063,
											[26] = 146063,
											[44] = 146063,
											[41] = 146063,
											[15] = 124457,
											[8] = 57982,
											[38] = 146063,
											[17] = 124457,
											[5] = 57982,
											[35] = 146063,
											[20] = 124457,
											[32] = 146063,
											[29] = 146063,
											[12] = 57982,
											[23] = 124457,
										},
										["total"] = 146063,
										["c_max"] = 66475,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 66475,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 313959.002185,
							["start_time"] = 1675435781,
							["delay"] = 1675435809,
							["last_event"] = 1675435822,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001344,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Ayasanth"] = 25269,
								["Allegory"] = 223059,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-186219-00005D1ED4",
							["damage_from"] = {
								["Ayasanth"] = true,
								["Allegory"] = true,
							},
							["aID"] = "186219",
							["raid_targets"] = {
							},
							["total_without_pet"] = 248328.001344,
							["fight_component"] = true,
							["end_time"] = 1675435822,
							["dps_started"] = false,
							["total"] = 248328.001344,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Weaponmaster Vordak",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10625,
										["targets"] = {
											["Allegory"] = 142170,
										},
										["n_dmg"] = 142170,
										["n_min"] = 7313,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 142170,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 16,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387410] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26963,
										["targets"] = {
											["Ayasanth"] = 25269,
											["Allegory"] = 80889,
										},
										["n_dmg"] = 106158,
										["n_min"] = 8423,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 106158,
										["c_max"] = 0,
										["id"] = 387410,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 687360.001344,
							["start_time"] = 1675435774,
							["delay"] = 0,
							["last_event"] = 1675435818,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005864,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 90900,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185595-00005D1EF4",
							["damage_from"] = {
								["Ayasanth"] = true,
								["Allegory"] = true,
							},
							["aID"] = "185595",
							["raid_targets"] = {
							},
							["total_without_pet"] = 90900.005864,
							["fight_component"] = true,
							["end_time"] = 1675435822,
							["dps_started"] = false,
							["total"] = 90900.005864,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4980,
										["targets"] = {
											["Allegory"] = 18196,
										},
										["n_dmg"] = 18196,
										["n_min"] = 4148,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 18196,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387388] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14838,
										["targets"] = {
											["Allegory"] = 72704,
										},
										["n_dmg"] = 72704,
										["n_min"] = 14238,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 72704,
										["c_max"] = 0,
										["id"] = 387388,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 5,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 128971.005864,
							["start_time"] = 1675435795,
							["delay"] = 0,
							["last_event"] = 1675435819,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 146,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 66833,
							["targets_overheal"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "EVOKER",
							["totalover"] = 0.007233,
							["total_without_pet"] = 224923.007233,
							["total"] = 224923.007233,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-580-0A6159F7",
							["totalabsorb"] = 0.007233,
							["last_hps"] = 0,
							["targets"] = {
								["Allegory"] = 224923,
							},
							["totalover_without_pet"] = 0.007233,
							["healing_taken"] = 224923.007233,
							["fight_component"] = true,
							["end_time"] = 1675435822,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
								["Allegory"] = true,
							},
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[361509] = {
										["c_amt"] = 1,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 45330,
										["targets"] = {
											["Allegory"] = 224923,
										},
										["n_min"] = 44184,
										["counter"] = 4,
										["overheal"] = 0,
										["total"] = 224923,
										["c_max"] = 90892,
										["id"] = 361509,
										["targets_absorbs"] = {
										},
										["c_min"] = 90892,
										["c_curado"] = 90892,
										["n_curado"] = 134031,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["start_time"] = 1675435810,
							["spec"] = 1467,
							["custom"] = 0,
							["tipo"] = 2,
							["aID"] = "580-0A6159F7",
							["totaldenied"] = 0.007233,
							["delay"] = 0,
							["last_event"] = 1675435818,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 146,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 146,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 3,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[353759] = {
										["activedamt"] = 0,
										["id"] = 353759,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 191,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[372014] = {
										["activedamt"] = 2,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 51,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357210] = {
										["activedamt"] = 1,
										["id"] = 357210,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 3,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 3,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 26,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370553] = {
										["activedamt"] = 1,
										["id"] = 370553,
										["targets"] = {
										},
										["uptime"] = 19,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383813] = {
										["activedamt"] = 1,
										["id"] = 383813,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 51,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["fight_component"] = true,
							["debuff_uptime"] = 53,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 2,
								[362969] = 1,
								[357210] = 1,
								[370553] = 1,
								[375087] = 1,
								[357211] = 4,
								[361509] = 4,
								[361469] = 7,
								[370452] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435822,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Weaponmaster Vordak",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[387410] = 3,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-186219-00005D1ED4",
							["aID"] = "186219",
						}, -- [2]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[387388] = 5,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185595-00005D1EF4",
							["aID"] = "185595",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 146,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396874.893,
				["tempo_start"] = 1675435771,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 740,
				["playing_solo"] = true,
				["totals"] = {
					1112857.997377, -- [1]
					224923, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:50:23",
				["hasTimer"] = 51.05999999999767,
				["cleu_timeline"] = {
				},
				["enemy"] = "Weaponmaster Vordak",
				["TotalElapsedCombatTime"] = 396862.126,
				["CombatEndedAt"] = 396862.126,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:49:31",
				["end_time"] = 396862.126,
				["combat_id"] = 146,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Weaponmaster Vordak"] = 1,
					["Worldbreaker Cultist"] = 1,
				},
				["totals_grupo"] = {
					773630, -- [1]
					224923, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Allegory"] = 224923.007233,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 773630.002185,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396810.367,
				["contra"] = "Weaponmaster Vordak",
				["TimeData"] = {
				},
			}, -- [6]
			{
				{
					["combatId"] = 145,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005119,
							["damage_from"] = {
								["Worldbreaker Cultist"] = true,
							},
							["targets"] = {
								["Worldbreaker Cultist"] = 108798,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 108798.005119,
							["friendlyfire"] = {
							},
							["end_time"] = 1675435752,
							["dps_started"] = false,
							["total"] = 108798.005119,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 26627,
										["g_amt"] = 0,
										["n_max"] = 13065,
										["targets"] = {
											["Worldbreaker Cultist"] = 83408,
										},
										["n_dmg"] = 56781,
										["n_min"] = 9287,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 83408,
										["c_max"] = 26627,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 26627,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17747,
										["targets"] = {
											["Worldbreaker Cultist"] = 25390,
										},
										["n_dmg"] = 25390,
										["e_dmg"] = {
											25390, -- [1]
										},
										["n_min"] = 3711,
										["g_dmg"] = 0,
										["counter"] = 3,
										["e_lvl"] = {
											1, -- [1]
										},
										["total"] = 25390,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 14340.005119,
							["start_time"] = 1675435748,
							["delay"] = 0,
							["last_event"] = 1675435752,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006952,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 14340,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185595-00005D1ED4",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185595",
							["raid_targets"] = {
							},
							["total_without_pet"] = 14340.006952,
							["fight_component"] = true,
							["end_time"] = 1675435752,
							["dps_started"] = false,
							["total"] = 14340.006952,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[387388] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14340,
										["targets"] = {
											["Allegory"] = 14340,
										},
										["n_dmg"] = 14340,
										["n_min"] = 14340,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14340,
										["c_max"] = 0,
										["id"] = 387388,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 108798.006952,
							["start_time"] = 1675435752,
							["delay"] = 0,
							["last_event"] = 1675435752,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 145,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 145,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 145,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 12,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 7,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435752,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[387388] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185595-00005D1ED4",
							["aID"] = "185595",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 145,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396809.851,
				["tempo_start"] = 1675435748,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 739,
				["playing_solo"] = true,
				["totals"] = {
					123138, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:49:13",
				["hasTimer"] = 4.007999999972526,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Cultist",
				["TotalElapsedCombatTime"] = 4.875,
				["CombatEndedAt"] = 396792.193,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:49:08",
				["end_time"] = 396792.193,
				["combat_id"] = 145,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Cultist"] = 1,
				},
				["totals_grupo"] = {
					108798, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 108798.005119,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396787.318,
				["contra"] = "Worldbreaker Cultist",
				["TimeData"] = {
				},
			}, -- [7]
			{
				{
					["combatId"] = 144,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008075,
							["damage_from"] = {
								["Qalashi Necksnapper"] = true,
							},
							["targets"] = {
								["Qalashi Necksnapper"] = 228253,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 228253.008075,
							["friendlyfire"] = {
							},
							["end_time"] = 1675435656,
							["dps_started"] = false,
							["total"] = 228253.008075,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12629,
										["targets"] = {
											["Qalashi Necksnapper"] = 67174,
										},
										["n_dmg"] = 67174,
										["n_min"] = 8800,
										["g_dmg"] = 0,
										["counter"] = 6,
										["ChartData"] = {
											[11] = 24893,
										},
										["total"] = 67174,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 11270,
										["g_amt"] = 0,
										["n_max"] = 21125,
										["targets"] = {
											["Qalashi Necksnapper"] = 54351,
										},
										["n_dmg"] = 43081,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											54351, -- [1]
										},
										["n_min"] = 3595,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[8] = 37333,
											[11] = 50756,
											[5] = 21125,
										},
										["total"] = 54351,
										["c_max"] = 11270,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 11270,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29643,
										["targets"] = {
											["Qalashi Necksnapper"] = 56463,
										},
										["n_dmg"] = 56463,
										["n_min"] = 26820,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[8] = 29643,
											[11] = 56463,
											[5] = 29643,
										},
										["total"] = 56463,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 50265,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Qalashi Necksnapper"] = 50265,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 50265,
										["c_max"] = 50265,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 50265,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 39943.008075,
							["start_time"] = 1675435645,
							["delay"] = 0,
							["last_event"] = 1675435655,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002622,
							["serial"] = "Creature-0-3896-2444-650-186109-00005D0564",
							["damage_from"] = {
								["Allegory"] = true,
								["Worldbreaker Guard"] = true,
								["Worldbreaker Cultist"] = true,
								["Worldbreaker Brute"] = true,
							},
							["targets"] = {
								["Allegory"] = 39943,
								["Worldbreaker Guard"] = 86173,
								["Worldbreaker Brute"] = 67033,
							},
							["pets"] = {
							},
							["monster"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "186109",
							["raid_targets"] = {
							},
							["total_without_pet"] = 193149.002622,
							["end_time"] = 1675435748,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 193149.002622,
							["classe"] = "UNKNOW",
							["friendlyfire"] = {
							},
							["nome"] = "Qalashi Necksnapper",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 14363,
										["g_amt"] = 0,
										["n_max"] = 7226,
										["targets"] = {
											["Allegory"] = 32680,
											["Worldbreaker Guard"] = 86173,
											["Worldbreaker Brute"] = 67033,
										},
										["n_dmg"] = 171523,
										["n_min"] = 4468,
										["g_dmg"] = 0,
										["counter"] = 32,
										["total"] = 185886,
										["c_max"] = 14363,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 14363,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 29,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[369751] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Allegory"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 369751,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[376472] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7263,
										["targets"] = {
											["Allegory"] = 7263,
										},
										["n_dmg"] = 7263,
										["n_min"] = 7263,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7263,
										["c_max"] = 0,
										["id"] = 376472,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 496580.002622,
							["start_time"] = 1675435720,
							["delay"] = 1675435668,
							["last_event"] = 1675435668,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 144,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 144,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.002244,
							["resource"] = 0.002244,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "EVOKER",
							["totalover"] = 0.002244,
							["total"] = 0.002244,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 1467,
							["aID"] = "580-0A6159F7",
							["flag_original"] = 1300,
							["last_event"] = 0,
							["alternatepower"] = 13.002244,
							["passiveover"] = 0.002244,
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 144,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 40,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 2,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 2,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 15,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[361469] = 2,
								[356995] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435656,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Qalashi Necksnapper",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[369751] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-186109-00005D0564",
							["aID"] = "186109",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 144,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396701.364,
				["tempo_start"] = 1675435641,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Allegory"] = {
						["total"] = 13,
						["last"] = 0,
					},
				},
				["combat_counter"] = 738,
				["playing_solo"] = true,
				["totals"] = {
					421401.9720760001, -- [1]
					-0.0043, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:47:36",
				["hasTimer"] = 14.07400000002235,
				["cleu_timeline"] = {
				},
				["enemy"] = "Qalashi Necksnapper",
				["TotalElapsedCombatTime"] = 1.332999999984168,
				["CombatEndedAt"] = 396702.697,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:47:22",
				["end_time"] = 396695.355,
				["combat_id"] = 144,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Qalashi Necksnapper"] = 1,
				},
				["totals_grupo"] = {
					228253, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 228253.008075,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396680.931,
				["contra"] = "Qalashi Necksnapper",
				["TimeData"] = {
				},
			}, -- [8]
			{
				{
					["combatId"] = 143,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001847,
							["damage_from"] = {
								["Worldbreaker Cultist"] = true,
								["Worldbreaker Guard"] = true,
							},
							["targets"] = {
								["Qalashi Necksnapper"] = 49396,
								["Worldbreaker Cultist"] = 234187,
								["Worldbreaker Guard"] = 151633,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 435216.001847,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435639,
							["dps_started"] = false,
							["total"] = 435216.001847,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6752,
										["targets"] = {
											["Worldbreaker Cultist"] = 6752,
										},
										["n_dmg"] = 6752,
										["n_min"] = 6752,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 6752,
											[17] = 6752,
											[8] = 6752,
											[23] = 6752,
											[14] = 6752,
											[5] = 6752,
											[20] = 6752,
										},
										["total"] = 6752,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 55027,
										["g_amt"] = 0,
										["n_max"] = 13408,
										["targets"] = {
											["Qalashi Necksnapper"] = 49396,
											["Worldbreaker Cultist"] = 82772,
											["Worldbreaker Guard"] = 75327,
										},
										["n_dmg"] = 152468,
										["n_min"] = 9370,
										["g_dmg"] = 0,
										["counter"] = 15,
										["ChartData"] = {
											[11] = 151867,
											[17] = 207495,
											[8] = 151867,
											[23] = 207495,
											[14] = 184412,
											[5] = 151867,
											[20] = 207495,
										},
										["total"] = 207495,
										["c_max"] = 30191,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 24836,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 13,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 36802,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Worldbreaker Guard"] = 36802,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[20] = 36802,
											[23] = 36802,
										},
										["total"] = 36802,
										["c_max"] = 36802,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 36802,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20968,
										["targets"] = {
											["Worldbreaker Cultist"] = 20968,
										},
										["n_dmg"] = 20968,
										["n_min"] = 20968,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 20968,
											[17] = 20968,
											[8] = 20968,
											[14] = 20968,
											[23] = 20968,
											[20] = 20968,
										},
										["total"] = 20968,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13837,
										["targets"] = {
											["Worldbreaker Cultist"] = 48315,
										},
										["n_dmg"] = 48315,
										["n_min"] = 10963,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[11] = 13837,
											[17] = 48315,
											[14] = 48315,
											[23] = 48315,
											[20] = 48315,
										},
										["total"] = 48315,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 49342,
										["targets"] = {
											["Worldbreaker Cultist"] = 75380,
											["Worldbreaker Guard"] = 39504,
										},
										["n_dmg"] = 114884,
										["e_dmg"] = {
											39504, -- [1]
										},
										["e_lvl"] = {
											1, -- [1]
										},
										["n_min"] = 26038,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[11] = 49342,
											[17] = 75380,
											[8] = 49342,
											[23] = 114884,
											[14] = 75380,
											[5] = 49342,
											[20] = 75380,
										},
										["total"] = 114884,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 16321.001847,
							["start_time"] = 1675435614,
							["delay"] = 0,
							["last_event"] = 1675435638,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001634,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Worldbreaker Brute"] = 79360,
								["Worldbreaker Guard"] = 121291,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-186109-00005D0564",
							["damage_from"] = {
								["Allegory"] = true,
								["Worldbreaker Guard"] = true,
								["Worldbreaker Cultist"] = true,
								["Worldbreaker Brute"] = true,
							},
							["aID"] = "186109",
							["raid_targets"] = {
							},
							["total_without_pet"] = 200651.001634,
							["fight_component"] = true,
							["end_time"] = 1675435641,
							["dps_started"] = false,
							["total"] = 200651.001634,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Qalashi Necksnapper",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9338,
										["targets"] = {
											["Worldbreaker Brute"] = 79360,
											["Worldbreaker Guard"] = 121291,
										},
										["n_dmg"] = 200651,
										["n_min"] = 5121,
										["g_dmg"] = 0,
										["counter"] = 36,
										["total"] = 200651,
										["c_max"] = 0,
										["a_dmg"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["PARRY"] = 3,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 30,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[369788] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 369788,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 391362.001634,
							["start_time"] = 1675435615,
							["delay"] = 0,
							["last_event"] = 1675435641,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002566,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 11727,
								["Qalashi Necksnapper"] = 139270,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185594-00005D0598",
							["damage_from"] = {
								["Allegory"] = true,
								["Qalashi Necksnapper"] = true,
							},
							["aID"] = "185594",
							["raid_targets"] = {
							},
							["total_without_pet"] = 150997.002566,
							["fight_component"] = true,
							["end_time"] = 1675435641,
							["dps_started"] = false,
							["total"] = 150997.002566,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Guard",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10062,
										["g_amt"] = 0,
										["n_max"] = 6473,
										["targets"] = {
											["Allegory"] = 11727,
											["Qalashi Necksnapper"] = 139270,
										},
										["n_dmg"] = 140935,
										["n_min"] = 3693,
										["g_dmg"] = 0,
										["counter"] = 32,
										["total"] = 150997,
										["c_max"] = 10062,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10062,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 28,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377609] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 377609,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 272924.002566,
							["start_time"] = 1675435615,
							["delay"] = 0,
							["last_event"] = 1675435641,
						}, -- [3]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001912,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 4594,
								["Qalashi Necksnapper"] = 39767,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185595-00005D0578",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185595",
							["raid_targets"] = {
							},
							["total_without_pet"] = 44361.001912,
							["fight_component"] = true,
							["end_time"] = 1675435639,
							["dps_started"] = false,
							["total"] = 44361.001912,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5842,
										["targets"] = {
											["Allegory"] = 4594,
											["Qalashi Necksnapper"] = 39767,
										},
										["n_dmg"] = 44361,
										["n_min"] = 3922,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 44361,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387388] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 387388,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 7,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 234187.001912,
							["start_time"] = 1675435614,
							["delay"] = 0,
							["last_event"] = 1675435638,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 143,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 143,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 143,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 4,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 57,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 25,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 2,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 25,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 17,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[361469] = 1,
								[362969] = 1,
								[356995] = 1,
								[357211] = 5,
								[370452] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435639,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[387388] = 7,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185595-00005D0AB8",
							["aID"] = "185595",
						}, -- [2]
						{
							["monster"] = true,
							["nome"] = "Qalashi Necksnapper",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[369788] = 2,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-186109-00005D0564",
							["aID"] = "186109",
						}, -- [3]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Guard",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[377609] = 3,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185594-00005D0AAD",
							["aID"] = "185594",
						}, -- [4]
					},
				}, -- [4]
				{
					["combatId"] = 143,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396679.297,
				["tempo_start"] = 1675435614,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Dragonarion-Lordaeron"] = {
						["total"] = 4,
						["last"] = 0,
					},
				},
				["combat_counter"] = 737,
				["playing_solo"] = true,
				["totals"] = {
					831224.986805, -- [1]
					0, -- [2]
					{
						-0.002739, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:47:19",
				["hasTimer"] = 24.14999999996508,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Cultist",
				["TotalElapsedCombatTime"] = 396678.497,
				["CombatEndedAt"] = 396678.497,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:46:55",
				["end_time"] = 396678.497,
				["combat_id"] = 143,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Cultist"] = 2,
					["Worldbreaker Guard"] = 1,
				},
				["totals_grupo"] = {
					435216, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 435216.001847,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396653.997,
				["contra"] = "Worldbreaker Cultist",
				["TimeData"] = {
				},
			}, -- [9]
			{
				{
					["combatId"] = 142,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005013,
							["damage_from"] = {
								["Lava Snail"] = true,
								["Worldbreaker Brute"] = true,
							},
							["targets"] = {
								["Djaradin Crustshaper"] = 240178,
								["Lava Snail"] = 115510,
								["Emberling"] = 17014,
								["Worldbreaker Brute"] = 110756,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 483458.005013,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435602,
							["dps_started"] = false,
							["total"] = 483458.005013,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9934,
										["targets"] = {
											["Djaradin Crustshaper"] = 9639,
											["Worldbreaker Brute"] = 9934,
										},
										["n_dmg"] = 19573,
										["n_min"] = 9639,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 19573,
											[17] = 19573,
											[8] = 19573,
											[14] = 19573,
											[20] = 19573,
										},
										["total"] = 19573,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 40347,
										["g_amt"] = 0,
										["n_max"] = 17014,
										["targets"] = {
											["Djaradin Crustshaper"] = 26544,
											["Lava Snail"] = 40347,
											["Emberling"] = 17014,
											["Worldbreaker Brute"] = 41105,
										},
										["n_dmg"] = 84663,
										["n_min"] = 13203,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[11] = 53017,
											[17] = 125010,
											[8] = 53017,
											[14] = 125010,
											[5] = 53017,
											[20] = 125010,
										},
										["total"] = 125010,
										["c_max"] = 40347,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 40347,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 75163,
										["targets"] = {
											["Lava Snail"] = 75163,
										},
										["n_dmg"] = 75163,
										["e_lvl"] = {
											[4] = 1,
										},
										["e_dmg"] = {
											[4] = 75163,
										},
										["n_min"] = 75163,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[20] = 75163,
										},
										["total"] = 75163,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["e_total"] = 4,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 30476,
										["targets"] = {
											["Djaradin Crustshaper"] = 30476,
										},
										["n_dmg"] = 30476,
										["n_min"] = 30476,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 30476,
											[17] = 30476,
											[8] = 30476,
											[14] = 30476,
											[20] = 30476,
										},
										["total"] = 30476,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16613,
										["targets"] = {
											["Djaradin Crustshaper"] = 97793,
											["Worldbreaker Brute"] = 59717,
										},
										["n_dmg"] = 157510,
										["n_min"] = 10982,
										["g_dmg"] = 0,
										["counter"] = 11,
										["ChartData"] = {
											[11] = 97793,
											[17] = 157510,
											[8] = 14728,
											[14] = 110599,
											[20] = 157510,
										},
										["total"] = 157510,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 43388,
										["targets"] = {
											["Djaradin Crustshaper"] = 75726,
										},
										["n_dmg"] = 75726,
										["n_min"] = 32338,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[11] = 75726,
											[17] = 75726,
											[8] = 43388,
											[14] = 75726,
											[5] = 43388,
											[20] = 75726,
										},
										["total"] = 75726,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 21352.005013,
							["start_time"] = 1675435580,
							["delay"] = 0,
							["last_event"] = 1675435601,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004237,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Djaradin Crustshaper"] = 77821,
								["Qalashi Necksnapper"] = 194792,
								["Allegory"] = 10906,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185589-00005D0A51",
							["damage_from"] = {
								["Djaradin Crustshaper"] = true,
								["Qalashi Necksnapper"] = true,
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
							},
							["aID"] = "185589",
							["raid_targets"] = {
							},
							["total_without_pet"] = 283519.004237,
							["fight_component"] = true,
							["end_time"] = 1675435614,
							["dps_started"] = false,
							["total"] = 283519.004237,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 56567,
										["g_amt"] = 0,
										["n_max"] = 7902,
										["targets"] = {
											["Djaradin Crustshaper"] = 77821,
											["Qalashi Necksnapper"] = 194792,
											["Allegory"] = 10906,
										},
										["n_dmg"] = 226952,
										["n_min"] = 4792,
										["g_dmg"] = 0,
										["counter"] = 49,
										["total"] = 283519,
										["c_max"] = 15853,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 10,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 11636,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 34,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387398] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Djaradin Crustshaper"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 387398,
										["r_dmg"] = 0,
										["MISS"] = 3,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 6,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 335513.004237,
							["start_time"] = 1675435581,
							["delay"] = 0,
							["last_event"] = 1675435613,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005627,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Worldbreaker Brute"] = 54955,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-186110-00005D0A36",
							["damage_from"] = {
								["Worldbreaker Brute"] = true,
								["Allegory"] = true,
							},
							["aID"] = "186110",
							["raid_targets"] = {
							},
							["total_without_pet"] = 54955.005627,
							["fight_component"] = true,
							["end_time"] = 1675435614,
							["dps_started"] = false,
							["total"] = 54955.005627,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Djaradin Crustshaper",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6704,
										["targets"] = {
											["Worldbreaker Brute"] = 54955,
										},
										["n_dmg"] = 54955,
										["n_min"] = 4810,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 54955,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[369055] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 369055,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 5,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[369193] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 369193,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 317999.005627,
							["start_time"] = 1675435581,
							["delay"] = 0,
							["last_event"] = 1675435614,
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.001749,
							["serial"] = "Creature-0-3896-2444-650-191628-00005D054D",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 10446,
							},
							["pets"] = {
							},
							["damage_from"] = {
								["Allegory"] = true,
							},
							["fight_component"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 10446.001749,
							["end_time"] = 1675435602,
							["dps_started"] = false,
							["total"] = 10446.001749,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["nome"] = "Lava Snail",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4114,
										["targets"] = {
											["Allegory"] = 10446,
										},
										["n_dmg"] = 10446,
										["n_min"] = 3076,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 10446,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "191628",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675435600,
							["damage_taken"] = 115510.001749,
							["start_time"] = 1675435596,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.006499,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-193026-00005D1413",
							["pets"] = {
							},
							["aID"] = "193026",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006499,
							["damage_from"] = {
								["Allegory"] = true,
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.006499,
							["end_time"] = 1675435602,
							["friendlyfire"] = {
							},
							["nome"] = "Emberling",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Allegory"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675435595,
							["damage_taken"] = 17014.006499,
							["start_time"] = 1675435602,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 142,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 142,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 142,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 4,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 3,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 90,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 22,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 3,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 3,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["activedamt"] = 1,
										["id"] = 390936,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 22,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 14,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[361469] = 1,
								[362969] = 1,
								[356995] = 4,
								[375087] = 1,
								[357211] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435602,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[387398] = 6,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185589-00005D05B5",
							["aID"] = "185589",
						}, -- [2]
						{
							["monster"] = true,
							["nome"] = "Djaradin Crustshaper",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[369055] = 5,
								[369193] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-186110-00005D059F",
							["aID"] = "186110",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 142,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396653.517,
				["tempo_start"] = 1675435580,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 736,
				["playing_solo"] = true,
				["totals"] = {
					832377.973882, -- [1]
					-0.01239100000384497, -- [2]
					{
						0, -- [1]
						[0] = -0.007239,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:46:43",
				["hasTimer"] = 21.07500000001164,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Brute",
				["TotalElapsedCombatTime"] = 396641.613,
				["CombatEndedAt"] = 396641.613,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:46:21",
				["end_time"] = 396641.613,
				["combat_id"] = 142,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Djaradin Crustshaper"] = 1,
					["Lava Snail"] = 1,
					["Worldbreaker Brute"] = 1,
					["Emberling"] = 1,
				},
				["totals_grupo"] = {
					483458, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 483458.005013,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396620.172,
				["contra"] = "Djaradin Crustshaper",
				["TimeData"] = {
				},
			}, -- [10]
			{
				{
					["combatId"] = 141,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002837,
							["damage_from"] = {
								["Worldbreaker Cultist"] = true,
							},
							["targets"] = {
								["Djaradin Crustshaper"] = 12575,
								["Worldbreaker Cultist"] = 114802,
								["Worldbreaker Brute"] = 29390,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 156767.002837,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435576,
							["dps_started"] = false,
							["total"] = 156767.002837,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[361500] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 64405,
										["g_amt"] = 0,
										["n_max"] = 31297,
										["targets"] = {
											["Worldbreaker Cultist"] = 95702,
										},
										["n_dmg"] = 31297,
										["n_min"] = 31297,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 95702,
										["c_max"] = 64405,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 64405,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 29390,
										["g_amt"] = 0,
										["n_max"] = 12575,
										["targets"] = {
											["Djaradin Crustshaper"] = 12575,
											["Worldbreaker Cultist"] = 19100,
											["Worldbreaker Brute"] = 29390,
										},
										["n_dmg"] = 31675,
										["n_min"] = 9425,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 61065,
										["c_max"] = 29390,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 29390,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 14885.002837,
							["start_time"] = 1675435570,
							["delay"] = 0,
							["last_event"] = 1675435575,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005786,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Djaradin Crustshaper"] = 34027,
								["Qalashi Necksnapper"] = 73095,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185589-00005D05B5",
							["damage_from"] = {
								["Djaradin Crustshaper"] = true,
								["Qalashi Necksnapper"] = true,
								["Allegory"] = true,
							},
							["aID"] = "185589",
							["raid_targets"] = {
							},
							["total_without_pet"] = 107122.005786,
							["fight_component"] = true,
							["end_time"] = 1675435580,
							["dps_started"] = false,
							["total"] = 107122.005786,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 32360,
										["g_amt"] = 0,
										["n_max"] = 8290,
										["targets"] = {
											["Djaradin Crustshaper"] = 34027,
											["Qalashi Necksnapper"] = 73095,
										},
										["n_dmg"] = 74762,
										["n_min"] = 5290,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 107122,
										["c_max"] = 16584,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 15776,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387398] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 387398,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 87715.005786,
							["start_time"] = 1675435571,
							["delay"] = 0,
							["last_event"] = 1675435579,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005202,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 14885,
								["Qalashi Necksnapper"] = 29429,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185595-00005D0A56",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185595",
							["raid_targets"] = {
							},
							["total_without_pet"] = 44314.005202,
							["fight_component"] = true,
							["end_time"] = 1675435580,
							["dps_started"] = false,
							["total"] = 44314.005202,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5377,
										["targets"] = {
											["Qalashi Necksnapper"] = 29429,
										},
										["n_dmg"] = 29429,
										["n_min"] = 4169,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 29429,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387388] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14885,
										["targets"] = {
											["Allegory"] = 14885,
										},
										["n_dmg"] = 14885,
										["n_min"] = 14885,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14885,
										["c_max"] = 0,
										["id"] = 387388,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 114802.005202,
							["start_time"] = 1675435570,
							["delay"] = 0,
							["last_event"] = 1675435580,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007794,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Worldbreaker Brute"] = 27467,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-186110-00005D059F",
							["damage_from"] = {
								["Allegory"] = true,
								["Worldbreaker Brute"] = true,
							},
							["aID"] = "186110",
							["raid_targets"] = {
							},
							["total_without_pet"] = 27467.007794,
							["fight_component"] = true,
							["end_time"] = 1675435580,
							["dps_started"] = false,
							["total"] = 27467.007794,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Djaradin Crustshaper",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6021,
										["targets"] = {
											["Worldbreaker Brute"] = 27467,
										},
										["n_dmg"] = 27467,
										["n_min"] = 4726,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 27467,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[369055] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 369055,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 46602.00779400001,
							["start_time"] = 1675435570,
							["delay"] = 0,
							["last_event"] = 1675435580,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 141,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 141,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 141,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 18,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 2,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[361469] = 1,
								[357211] = 2,
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435576,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Djaradin Crustshaper",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[369055] = 3,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-186110-00005D0A36",
							["aID"] = "186110",
						}, -- [2]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[387398] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185589-00005D0A51",
							["aID"] = "185589",
						}, -- [3]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[387388] = 4,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185595-00005D0A56",
							["aID"] = "185595",
						}, -- [4]
					},
				}, -- [4]
				{
					["combatId"] = 141,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396619.384,
				["tempo_start"] = 1675435570,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 735,
				["playing_solo"] = true,
				["totals"] = {
					335669.987156, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:46:16",
				["hasTimer"] = 5.032999999995809,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Cultist",
				["TotalElapsedCombatTime"] = 396615.23,
				["CombatEndedAt"] = 396615.23,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:46:10",
				["end_time"] = 396615.23,
				["combat_id"] = 141,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Cultist"] = 1,
				},
				["totals_grupo"] = {
					156767, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 156767.002837,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396609.497,
				["contra"] = "Worldbreaker Cultist",
				["TimeData"] = {
				},
			}, -- [11]
			{
				{
					["combatId"] = 140,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005442,
							["damage_from"] = {
								["Lava Slug"] = true,
							},
							["targets"] = {
								["Worldbreaker Smith"] = 83513,
								["Lava Slug"] = 34359,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 117872.005442,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435567,
							["dps_started"] = false,
							["total"] = 117872.005442,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10277,
										["targets"] = {
											["Worldbreaker Smith"] = 20224,
										},
										["n_dmg"] = 20224,
										["n_min"] = 9947,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 20224,
										},
										["total"] = 20224,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 37187,
										["g_amt"] = 0,
										["n_max"] = 22205,
										["targets"] = {
											["Worldbreaker Smith"] = 37187,
											["Lava Slug"] = 34359,
										},
										["n_dmg"] = 34359,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											71546, -- [1]
										},
										["n_min"] = 3836,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[5] = 67710,
										},
										["total"] = 71546,
										["c_max"] = 37187,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 37187,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26102,
										["targets"] = {
											["Worldbreaker Smith"] = 26102,
										},
										["n_dmg"] = 26102,
										["n_min"] = 26102,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 26102,
										},
										["total"] = 26102,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 4169.005442,
							["start_time"] = 1675435560,
							["delay"] = 0,
							["last_event"] = 1675435567,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005467,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Dragonarion-Lordaeron"] = 18942,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185591-00005D09FE",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
								["Mindbender <Dragonarion-Lordaeron>"] = true,
							},
							["aID"] = "185591",
							["raid_targets"] = {
							},
							["total_without_pet"] = 18942.005467,
							["fight_component"] = true,
							["end_time"] = 1675435567,
							["dps_started"] = false,
							["total"] = 18942.005467,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[390927] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18942,
										["targets"] = {
											["Dragonarion-Lordaeron"] = 18942,
										},
										["n_dmg"] = 18942,
										["n_min"] = 18942,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 18942,
										["c_max"] = 0,
										["id"] = 390927,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 151198.005467,
							["start_time"] = 1675435560,
							["delay"] = 0,
							["last_event"] = 1675435560,
						}, -- [2]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.001387,
							["serial"] = "Creature-0-3896-2444-650-191629-0005DCB68B",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 4169,
							},
							["pets"] = {
							},
							["damage_from"] = {
								["Allegory"] = true,
							},
							["fight_component"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4169.001387,
							["end_time"] = 1675435567,
							["dps_started"] = false,
							["total"] = 4169.001387,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["nome"] = "Lava Slug",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3089,
										["g_amt"] = 0,
										["n_max"] = 1080,
										["targets"] = {
											["Allegory"] = 4169,
										},
										["n_dmg"] = 1080,
										["n_min"] = 1080,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 4169,
										["c_max"] = 3089,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3089,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["aID"] = "191629",
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675435566,
							["damage_taken"] = 34359.001387,
							["start_time"] = 1675435564,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 140,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 140,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 140,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["actived_at"] = 1675435561,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = -1,
										["id"] = 370898,
										["targets"] = {
										},
										["actived_at"] = 1675435562,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 18,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 5,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435567,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[390927] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185591-00005D09FE",
							["aID"] = "185591",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 140,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396609.008,
				["tempo_start"] = 1675435560,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 734,
				["playing_solo"] = true,
				["totals"] = {
					140982.965254, -- [1]
					-0.004902999999103486, -- [2]
					{
						0, -- [1]
						[0] = -0.008154,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:46:08",
				["hasTimer"] = 7.029999999969732,
				["cleu_timeline"] = {
				},
				["enemy"] = "Lava Slug",
				["TotalElapsedCombatTime"] = 396606.689,
				["CombatEndedAt"] = 396606.689,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:46:00",
				["end_time"] = 396606.689,
				["combat_id"] = 140,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Smith"] = 1,
					["Lava Slug"] = 1,
				},
				["totals_grupo"] = {
					117872, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 117872.005442,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396599.508,
				["contra"] = "Worldbreaker Smith",
				["TimeData"] = {
				},
			}, -- [12]
			{
				{
					["combatId"] = 139,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008704,
							["damage_from"] = {
							},
							["targets"] = {
								["Worldbreaker Smith"] = 129028,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 129028.008704,
							["friendlyfire"] = {
							},
							["end_time"] = 1675435560,
							["dps_started"] = false,
							["total"] = 129028.008704,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12129,
										["targets"] = {
											["Worldbreaker Smith"] = 52169,
										},
										["n_dmg"] = 52169,
										["n_min"] = 8828,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 52169,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[353759] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12027,
										["g_amt"] = 0,
										["n_max"] = 14818,
										["targets"] = {
											["Worldbreaker Smith"] = 56481,
										},
										["n_dmg"] = 44454,
										["n_min"] = 14818,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 56481,
										["c_max"] = 12027,
										["id"] = 353759,
										["r_dmg"] = 0,
										["spellschool"] = 12,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 12027,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20378,
										["targets"] = {
											["Worldbreaker Smith"] = 20378,
										},
										["n_dmg"] = 20378,
										["n_min"] = 20378,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 20378,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.008704,
							["start_time"] = 1675435552,
							["delay"] = 0,
							["last_event"] = 1675435559,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002789,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Dragonarion-Lordaeron"] = 80991,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185591-00005D0E42",
							["damage_from"] = {
								["Mindbender <Dragonarion-Lordaeron>"] = true,
								["Allegory"] = true,
								["Dragonarion-Lordaeron"] = true,
							},
							["aID"] = "185591",
							["raid_targets"] = {
							},
							["total_without_pet"] = 80991.00278899999,
							["fight_component"] = true,
							["end_time"] = 1675435560,
							["dps_started"] = false,
							["total"] = 80991.00278899999,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6379,
										["targets"] = {
											["Dragonarion-Lordaeron"] = 24166,
										},
										["n_dmg"] = 24166,
										["n_min"] = 5558,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 24166,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[390927] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18942,
										["targets"] = {
											["Dragonarion-Lordaeron"] = 56825,
										},
										["n_dmg"] = 56825,
										["n_min"] = 18941,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 56825,
										["c_max"] = 0,
										["id"] = 390927,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 270654.002789,
							["start_time"] = 1675435553,
							["delay"] = 0,
							["last_event"] = 1675435558,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 139,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "EVOKER",
							["totalover"] = 0.001843,
							["total_without_pet"] = 0.001843,
							["total"] = 0.001843,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-580-0A6159F7",
							["totalabsorb"] = 0.001843,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.001843,
							["healing_taken"] = 0.001843,
							["end_time"] = 1675435557,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["start_time"] = 1675435557,
							["spec"] = 1467,
							["custom"] = 0,
							["tipo"] = 2,
							["aID"] = "580-0A6159F7",
							["totaldenied"] = 0.001843,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 139,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 139,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[353759] = {
										["activedamt"] = -1,
										["id"] = 353759,
										["targets"] = {
										},
										["actived_at"] = 1675435553,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 12,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357210] = {
										["activedamt"] = 1,
										["id"] = 357210,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 2,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435557,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[390927] = 3,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185591-00005D09FE",
							["aID"] = "185591",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 139,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396598.389,
				["tempo_start"] = 1675435552,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 733,
				["playing_solo"] = true,
				["totals"] = {
					210018.96686, -- [1]
					-0.001352999999653548, -- [2]
					{
						0, -- [1]
						[0] = -0.007384,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:45:58",
				["hasTimer"] = 5.026000000012573,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Smith",
				["TotalElapsedCombatTime"] = 5.084000000031665,
				["CombatEndedAt"] = 396597.189,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:45:53",
				["end_time"] = 396597.189,
				["combat_id"] = 139,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Smith"] = 1,
				},
				["totals_grupo"] = {
					129028, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Allegory"] = 0.001843,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 105077.008704,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396592.105,
				["contra"] = "Worldbreaker Smith",
				["TimeData"] = {
				},
			}, -- [13]
			{
				{
					["combatId"] = 138,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001896,
							["damage_from"] = {
								["Worldbreaker Cultist"] = true,
							},
							["targets"] = {
								["Worldbreaker Cultist"] = 109129,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 109129.001896,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435536,
							["dps_started"] = false,
							["total"] = 109129.001896,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6960,
										["targets"] = {
											["Worldbreaker Cultist"] = 6960,
										},
										["n_dmg"] = 6960,
										["n_min"] = 6960,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6960,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 23061,
										["targets"] = {
											["Worldbreaker Cultist"] = 35875,
										},
										["n_dmg"] = 35875,
										["n_min"] = 3707,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 35875,
										["c_max"] = 0,
										["id"] = 357209,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 56607,
										["targets"] = {
											["Worldbreaker Cultist"] = 56607,
										},
										["n_dmg"] = 56607,
										["n_min"] = 56607,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 56607,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9687,
										["targets"] = {
											["Worldbreaker Cultist"] = 9687,
										},
										["n_dmg"] = 9687,
										["n_min"] = 9687,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9687,
										["c_max"] = 0,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 19303.001896,
							["start_time"] = 1675435530,
							["delay"] = 0,
							["last_event"] = 1675435535,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003206,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Djaradin Crustshaper"] = 20880,
								["Qalashi Necksnapper"] = 78668,
								["Allegory"] = 19303,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185595-00005D1D39",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185595",
							["raid_targets"] = {
							},
							["total_without_pet"] = 118851.003206,
							["fight_component"] = true,
							["end_time"] = 1675435552,
							["dps_started"] = false,
							["total"] = 118851.003206,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10694,
										["g_amt"] = 0,
										["n_max"] = 5951,
										["targets"] = {
											["Djaradin Crustshaper"] = 20880,
											["Qalashi Necksnapper"] = 78668,
											["Allegory"] = 4648,
										},
										["n_dmg"] = 93502,
										["n_min"] = 4335,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 104196,
										["c_max"] = 10694,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10694,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 18,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387388] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14655,
										["targets"] = {
											["Allegory"] = 14655,
										},
										["n_dmg"] = 14655,
										["n_min"] = 14655,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14655,
										["c_max"] = 0,
										["id"] = 387388,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 5,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 109129.003206,
							["start_time"] = 1675435531,
							["delay"] = 0,
							["last_event"] = 1675435550,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 138,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 138,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 138,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 17,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 5,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[357211] = 1,
								[361469] = 1,
								[362969] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435536,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Cultist",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[387388] = 5,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185595-00005D0AB8",
							["aID"] = "185595",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 138,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["tempo_start"] = 1675435530,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 732,
				["playing_solo"] = true,
				["totals"] = {
					227979.967812, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = -0.004534,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:45:36",
				["hasTimer"] = 5.038000000000466,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Cultist",
				["TotalElapsedCombatTime"] = 396575.399,
				["CombatEndedAt"] = 396575.399,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:45:31",
				["end_time"] = 396575.399,
				["combat_id"] = 138,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Cultist"] = 1,
				},
				["totals_grupo"] = {
					109129, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 109129.001896,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396570.023,
				["contra"] = "Worldbreaker Cultist",
				["TimeData"] = {
				},
			}, -- [14]
			{
				{
					["combatId"] = 137,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005648,
							["damage_from"] = {
							},
							["targets"] = {
								["Worldbreaker Guard"] = 19234,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19234.005648,
							["friendlyfire"] = {
							},
							["end_time"] = 1675435517,
							["dps_started"] = false,
							["total"] = 19234.005648,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19234,
										["targets"] = {
											["Worldbreaker Guard"] = 19234,
										},
										["n_dmg"] = 19234,
										["n_min"] = 19234,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19234,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.005648,
							["start_time"] = 1675435513,
							["delay"] = 0,
							["last_event"] = 1675435513,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005136,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Dragonarion-Lordaeron"] = 12505,
								["Qalashi Necksnapper"] = 64159,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185594-00005D1D9E",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
								["Qalashi Necksnapper"] = true,
							},
							["aID"] = "185594",
							["raid_targets"] = {
							},
							["total_without_pet"] = 76664.00513599999,
							["fight_component"] = true,
							["end_time"] = 1675435530,
							["dps_started"] = false,
							["total"] = 76664.00513599999,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Guard",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6547,
										["targets"] = {
											["Dragonarion-Lordaeron"] = 12505,
											["Qalashi Necksnapper"] = 64159,
										},
										["n_dmg"] = 76664,
										["n_min"] = 4614,
										["g_dmg"] = 0,
										["counter"] = 18,
										["a_dmg"] = 0,
										["total"] = 76664,
										["c_max"] = 0,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["spellschool"] = 1,
										["extra"] = {
										},
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 13,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 232749.005136,
							["start_time"] = 1675435514,
							["delay"] = 0,
							["last_event"] = 1675435529,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 137,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 137,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 137,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = -1,
										["id"] = 370452,
										["targets"] = {
										},
										["actived_at"] = 1675435516,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 13,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 3,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435517,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 137,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396569.238,
				["tempo_start"] = 1675435513,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 731,
				["playing_solo"] = true,
				["totals"] = {
					95897.98111199995, -- [1]
					-0.001492999999754829, -- [2]
					{
						0, -- [1]
						[0] = -0.004206,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:45:18",
				["hasTimer"] = 4.019999999960419,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Guard",
				["TotalElapsedCombatTime"] = 396556.918,
				["CombatEndedAt"] = 396556.918,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:45:13",
				["end_time"] = 396556.918,
				["combat_id"] = 137,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Guard"] = 1,
				},
				["totals_grupo"] = {
					19234, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 19234.005648,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396552.54,
				["contra"] = "Worldbreaker Guard",
				["TimeData"] = {
				},
			}, -- [15]
			{
				{
					["combatId"] = 136,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008587,
							["damage_from"] = {
							},
							["targets"] = {
								["Worldbreaker Brute"] = 177586,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 177586.008587,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435497,
							["dps_started"] = false,
							["total"] = 177586.008587,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 41776,
										["targets"] = {
											["Worldbreaker Brute"] = 69810,
										},
										["n_dmg"] = 69810,
										["e_dmg"] = {
											41776, -- [1]
										},
										["e_lvl"] = {
											1, -- [1]
										},
										["n_min"] = 28034,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 28034,
										},
										["total"] = 69810,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18404,
										["targets"] = {
											["Worldbreaker Brute"] = 27837,
										},
										["n_dmg"] = 27837,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											27837, -- [1]
										},
										["n_min"] = 4646,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 23191,
										},
										["total"] = 27837,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16186,
										["targets"] = {
											["Worldbreaker Brute"] = 16186,
										},
										["n_dmg"] = 16186,
										["n_min"] = 16186,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 16186,
										},
										["total"] = 16186,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 26964,
										["g_amt"] = 0,
										["n_max"] = 12979,
										["targets"] = {
											["Worldbreaker Brute"] = 63753,
										},
										["n_dmg"] = 36789,
										["n_min"] = 11145,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[5] = 63753,
										},
										["total"] = 63753,
										["c_max"] = 26964,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 26964,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.008587,
							["start_time"] = 1675435490,
							["delay"] = 0,
							["last_event"] = 1675435496,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007444,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Dragonarion-Lordaeron"] = 7761,
								["Qalashi Necksnapper"] = 7723,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185589-00005CE913",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
								["Qalashi Necksnapper"] = true,
								["Djaradin Crustshaper"] = true,
							},
							["aID"] = "185589",
							["raid_targets"] = {
							},
							["total_without_pet"] = 15484.007444,
							["fight_component"] = true,
							["end_time"] = 1675435513,
							["dps_started"] = false,
							["total"] = 15484.007444,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7761,
										["targets"] = {
											["Djaradin Crustshaper"] = 0,
											["Qalashi Necksnapper"] = 7723,
											["Dragonarion-Lordaeron"] = 7761,
										},
										["n_dmg"] = 15484,
										["n_min"] = 7723,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 15484,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 310169.007444,
							["start_time"] = 1675435494,
							["delay"] = 0,
							["last_event"] = 1675435512,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 136,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["Allegory"] = 44546,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "EVOKER",
							["totalover"] = 44546.008531,
							["total_without_pet"] = 0.008531,
							["total"] = 0.008531,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-580-0A6159F7",
							["totalabsorb"] = 0.008531,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.008531,
							["healing_taken"] = 0.008531,
							["end_time"] = 1675435497,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[361509] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Allegory"] = 44546,
										},
										["n_max"] = 0,
										["targets"] = {
											["Allegory"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 44546,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 361509,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["n_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["start_time"] = 1675435497,
							["spec"] = 1467,
							["custom"] = 0,
							["tipo"] = 2,
							["aID"] = "580-0A6159F7",
							["totaldenied"] = 0.008531,
							["delay"] = 0,
							["last_event"] = 1675435497,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 136,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 136,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["actived_at"] = 1675435492,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 23,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 11,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[361469] = 1,
								[361509] = 1,
								[370452] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435497,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 136,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396552.031,
				["tempo_start"] = 1675435490,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 730,
				["playing_solo"] = true,
				["totals"] = {
					193069.971208, -- [1]
					-0.001314999999976863, -- [2]
					{
						0, -- [1]
						[0] = -0.007961,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:44:58",
				["hasTimer"] = 7.049999999988359,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Brute",
				["TotalElapsedCombatTime"] = 7.754000000015367,
				["CombatEndedAt"] = 396537.155,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:44:50",
				["end_time"] = 396537.155,
				["combat_id"] = 136,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Brute"] = 1,
				},
				["totals_grupo"] = {
					177586, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Allegory"] = 0.008531,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 177586.008587,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396529.305,
				["contra"] = "Worldbreaker Brute",
				["TimeData"] = {
				},
			}, -- [16]
			{
				{
					["combatId"] = 135,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007385,
							["damage_from"] = {
								["Swooping Snitch"] = true,
							},
							["targets"] = {
								["Swooping Snitch"] = 43109,
								["Worldbreaker Guard"] = 43884,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 86993.007385,
							["friendlyfire"] = {
							},
							["end_time"] = 1675435448,
							["dps_started"] = false,
							["total"] = 86993.007385,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 30044,
										["g_amt"] = 0,
										["n_max"] = 15020,
										["targets"] = {
											["Swooping Snitch"] = 43109,
											["Worldbreaker Guard"] = 15020,
										},
										["n_dmg"] = 28085,
										["n_min"] = 13065,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 28085,
										},
										["total"] = 58129,
										["c_max"] = 30044,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 30044,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 28864,
										["targets"] = {
											["Worldbreaker Guard"] = 28864,
										},
										["n_dmg"] = 28864,
										["n_min"] = 28864,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 28864,
										},
										["total"] = 28864,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 5459.007385,
							["start_time"] = 1675435442,
							["delay"] = 0,
							["last_event"] = 1675435448,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 14528.006597,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Dragonarion-Lordaeron"] = 14528,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185594-00005D1719",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
								["Qalashi Necksnapper"] = true,
							},
							["aID"] = "185594",
							["raid_targets"] = {
							},
							["total_without_pet"] = 14528.006597,
							["fight_component"] = true,
							["end_time"] = 1675435448,
							["dps_started"] = false,
							["total"] = 14528.006597,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Guard",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14528,
										["targets"] = {
											["Dragonarion-Lordaeron"] = 14528,
										},
										["n_dmg"] = 14528,
										["n_min"] = 14528,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14528,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 100792.006597,
							["start_time"] = 1675435443,
							["delay"] = 0,
							["last_event"] = 1675435443,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004034,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 5459,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185592-00005D1D7D",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
							},
							["aID"] = "185592",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5459.004034,
							["fight_component"] = true,
							["end_time"] = 1675435448,
							["dps_started"] = false,
							["total"] = 5459.004034,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Swooping Snitch",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1888,
										["targets"] = {
											["Allegory"] = 5459,
										},
										["n_dmg"] = 5459,
										["n_min"] = 1752,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 5459,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 66617.004034,
							["start_time"] = 1675435441,
							["delay"] = 0,
							["last_event"] = 1675435445,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 135,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 135,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 135,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 39,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 2,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435448,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 135,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["tempo_start"] = 1675435441,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 729,
				["playing_solo"] = true,
				["totals"] = {
					106979.98269, -- [1]
					-0.005730000000767177, -- [2]
					{
						0, -- [1]
						[0] = -0.008708,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:44:09",
				["hasTimer"] = 6.026000000012573,
				["cleu_timeline"] = {
				},
				["enemy"] = "Swooping Snitch",
				["TotalElapsedCombatTime"] = 396488.004,
				["CombatEndedAt"] = 396488.004,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:44:02",
				["end_time"] = 396488.004,
				["combat_id"] = 135,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Swooping Snitch"] = 1,
					["Worldbreaker Guard"] = 1,
				},
				["totals_grupo"] = {
					86993, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 86993.007385,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396481.088,
				["contra"] = "Swooping Snitch",
				["TimeData"] = {
				},
			}, -- [17]
			{
				{
					["combatId"] = 134,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006689,
							["damage_from"] = {
								["Worldbreaker Smith"] = true,
							},
							["targets"] = {
								["Worldbreaker Smith"] = 227946,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 227946.006689,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435429,
							["dps_started"] = false,
							["total"] = 227946.006689,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20734,
										["targets"] = {
											["Worldbreaker Smith"] = 20734,
										},
										["n_dmg"] = 20734,
										["n_min"] = 20734,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 20734,
										},
										["total"] = 20734,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13677,
										["targets"] = {
											["Worldbreaker Smith"] = 13677,
										},
										["n_dmg"] = 13677,
										["n_min"] = 13677,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[5] = 13677,
										},
										["total"] = 13677,
										["c_max"] = 0,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 52688,
										["g_amt"] = 0,
										["n_max"] = 6524,
										["targets"] = {
											["Worldbreaker Smith"] = 65736,
										},
										["n_dmg"] = 13048,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											65736, -- [1]
										},
										["n_min"] = 6524,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 52688,
										},
										["total"] = 65736,
										["c_max"] = 52688,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 52688,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 57066,
										["targets"] = {
											["Worldbreaker Smith"] = 57066,
										},
										["n_dmg"] = 57066,
										["e_dmg"] = {
											57066, -- [1]
										},
										["n_min"] = 57066,
										["g_dmg"] = 0,
										["counter"] = 1,
										["e_lvl"] = {
											1, -- [1]
										},
										["total"] = 57066,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 57671,
										["g_amt"] = 0,
										["n_max"] = 13062,
										["targets"] = {
											["Worldbreaker Smith"] = 70733,
										},
										["n_dmg"] = 13062,
										["n_min"] = 13062,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 70733,
										},
										["total"] = 70733,
										["c_max"] = 29476,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 28195,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 47647.006689,
							["start_time"] = 1675435420,
							["delay"] = 0,
							["last_event"] = 1675435428,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001492,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 47647,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185591-00005D1725",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
							},
							["aID"] = "185591",
							["raid_targets"] = {
							},
							["total_without_pet"] = 47647.001492,
							["fight_component"] = true,
							["end_time"] = 1675435429,
							["dps_started"] = false,
							["total"] = 47647.001492,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5861,
										["targets"] = {
											["Allegory"] = 5861,
										},
										["n_dmg"] = 5861,
										["n_min"] = 5861,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5861,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[390927] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20893,
										["targets"] = {
											["Allegory"] = 41786,
										},
										["n_dmg"] = 41786,
										["n_min"] = 20893,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 41786,
										["c_max"] = 0,
										["id"] = 390927,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 236496.001492,
							["start_time"] = 1675435421,
							["delay"] = 0,
							["last_event"] = 1675435427,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 134,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 134,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 134,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["actived_at"] = 1675435422,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 39,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 14,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[375087] = 1,
								[370452] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435429,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[390927] = 2,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185591-00005D1725",
							["aID"] = "185591",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 134,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396479.488,
				["tempo_start"] = 1675435420,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Dragonarion-Lordaeron"] = {
						["total"] = 3,
						["last"] = 0,
					},
				},
				["combat_counter"] = 728,
				["playing_solo"] = true,
				["totals"] = {
					275592.997658, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = -0.00788,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:43:49",
				["hasTimer"] = 8.024999999965075,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Smith",
				["TotalElapsedCombatTime"] = 8.548999999999069,
				["CombatEndedAt"] = 396468.221,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:43:41",
				["end_time"] = 396468.221,
				["combat_id"] = 134,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Smith"] = 1,
				},
				["totals_grupo"] = {
					227946, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 227946.006689,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396459.672,
				["contra"] = "Worldbreaker Smith",
				["TimeData"] = {
				},
			}, -- [18]
			{
				{
					["combatId"] = 133,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003418,
							["damage_from"] = {
								["Swooping Snitch"] = true,
								["Worldbreaker Guard"] = true,
							},
							["targets"] = {
								["Worldbreaker Guard"] = 138190,
								["Swooping Snitch"] = 99089,
								["Lava Flick"] = 15263,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 252542.003418,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435219,
							["dps_started"] = false,
							["total"] = 252542.003418,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37700,
										["targets"] = {
											["Worldbreaker Guard"] = 37700,
										},
										["n_dmg"] = 37700,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											37700, -- [1]
										},
										["n_min"] = 37700,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 37700,
											[14] = 37700,
										},
										["total"] = 37700,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 27656,
										["g_amt"] = 0,
										["n_max"] = 15478,
										["targets"] = {
											["Worldbreaker Guard"] = 82221,
											["Swooping Snitch"] = 99089,
											["Lava Flick"] = 15263,
										},
										["n_dmg"] = 168917,
										["n_min"] = 9521,
										["g_dmg"] = 0,
										["counter"] = 14,
										["ChartData"] = {
											[8] = 196573,
											[14] = 196573,
											[11] = 196573,
											[5] = 138666,
										},
										["total"] = 196573,
										["c_max"] = 27656,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 27656,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 13,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9280,
										["targets"] = {
											["Worldbreaker Guard"] = 18269,
										},
										["n_dmg"] = 18269,
										["n_min"] = 8989,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 18269,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 44776.003418,
							["start_time"] = 1675435203,
							["delay"] = 0,
							["last_event"] = 1675435219,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004048,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Dragonarion-Lordaeron"] = 15825,
								["Allegory"] = 37845,
								["Qalashi Necksnapper"] = 391945,
								["Blitzlêiter"] = 13470,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185594-00005D1727",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
								["Qalashi Necksnapper"] = true,
								["Blitzlêiter"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 459085.004048,
							["fight_component"] = true,
							["end_time"] = 1675435420,
							["monster"] = true,
							["total"] = 459085.004048,
							["aID"] = "185594",
							["classe"] = "UNKNOW",
							["nome"] = "Worldbreaker Guard",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 31979,
										["g_amt"] = 0,
										["n_max"] = 6880,
										["targets"] = {
											["Dragonarion-Lordaeron"] = 15825,
											["Allegory"] = 25073,
											["Qalashi Necksnapper"] = 391945,
										},
										["n_dmg"] = 400864,
										["n_min"] = 4204,
										["g_dmg"] = 0,
										["counter"] = 85,
										["MISS"] = 1,
										["total"] = 432843,
										["c_max"] = 11520,
										["a_dmg"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["spellschool"] = 1,
										["extra"] = {
										},
										["PARRY"] = 4,
										["c_min"] = 9717,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 74,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377609] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6780,
										["targets"] = {
											["Blitzlêiter"] = 13470,
											["Allegory"] = 12772,
										},
										["n_dmg"] = 26242,
										["n_min"] = 1672,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 26242,
										["c_max"] = 0,
										["id"] = 377609,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["dps_started"] = false,
							["friendlyfire"] = {
							},
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1675435386,
							["damage_taken"] = 1065644.004048,
							["start_time"] = 1675435291,
							["delay"] = 1675435386,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008584,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 6931,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185592-00005D12A9",
							["damage_from"] = {
								["Dragonarion-Lordaeron"] = true,
								["Allegory"] = true,
							},
							["aID"] = "185592",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6931.008584,
							["fight_component"] = true,
							["end_time"] = 1675435219,
							["dps_started"] = false,
							["total"] = 6931.008584,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Swooping Snitch",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1998,
										["targets"] = {
											["Allegory"] = 6931,
										},
										["n_dmg"] = 6931,
										["n_min"] = 1547,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 6931,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 165658.008584,
							["start_time"] = 1675435214,
							["delay"] = 1675435209,
							["last_event"] = 1675435209,
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.00778,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-192137-00005D12C9",
							["pets"] = {
							},
							["aID"] = "192137",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00778,
							["damage_from"] = {
								["Allegory"] = true,
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.00778,
							["end_time"] = 1675435219,
							["friendlyfire"] = {
							},
							["nome"] = "Lava Flick",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 15263.00778,
							["start_time"] = 1675435219,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 133,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 133,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.002086,
							["resource"] = 0.002086,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "EVOKER",
							["totalover"] = 0.002086,
							["total"] = 0.002086,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 1467,
							["aID"] = "580-0A6159F7",
							["flag_original"] = 1300,
							["last_event"] = 0,
							["alternatepower"] = 6.002086,
							["passiveover"] = 0.002086,
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 3,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 133,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 64,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 2,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372470] = {
										["activedamt"] = 1,
										["id"] = 372470,
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 5,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[357211] = 4,
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435219,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Guard",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 2632,
							["spell_cast"] = {
								[377609] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185594-00005D1727",
							["aID"] = "185594",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 133,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["tempo_start"] = 1675435203,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Dragonarion-Lordaeron"] = {
						["total"] = 4,
						["last"] = 4,
					},
					["Allegory"] = {
						["total"] = 6,
						["last"] = 0,
					},
				},
				["combat_counter"] = 727,
				["playing_solo"] = true,
				["totals"] = {
					718557.967551, -- [1]
					-0.00504700000055891, -- [2]
					{
						0, -- [1]
						[0] = -0.001855,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Allegory"] = {
						{
							true, -- [1]
							377609, -- [2]
							1749, -- [3]
							1675435219.979, -- [4]
							194144, -- [5]
							"Worldbreaker Guard", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
							false, -- [11]
							false, -- [12]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:40:20",
				["hasTimer"] = 15.02500000002328,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Guard",
				["TotalElapsedCombatTime"] = 396258.675,
				["CombatEndedAt"] = 396258.675,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:40:04",
				["end_time"] = 396258.675,
				["combat_id"] = 133,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Swooping Snitch"] = 2,
					["Worldbreaker Guard"] = 1,
					["Lava Flick"] = 1,
				},
				["totals_grupo"] = {
					252542, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 252542.003418,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396242.755,
				["contra"] = "Worldbreaker Guard",
				["TimeData"] = {
				},
			}, -- [19]
			{
				{
					["combatId"] = 132,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008051,
							["damage_from"] = {
								["Worldbreaker Smith"] = true,
							},
							["targets"] = {
								["Worldbreaker Smith"] = 250184,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 250184.008051,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435191,
							["dps_started"] = false,
							["total"] = 250184.008051,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26817,
										["targets"] = {
											["Worldbreaker Smith"] = 26817,
										},
										["n_dmg"] = 26817,
										["n_min"] = 26817,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[8] = 26817,
											[11] = 26817,
											[5] = 26817,
										},
										["total"] = 26817,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13065,
										["targets"] = {
											["Worldbreaker Smith"] = 96342,
										},
										["n_dmg"] = 96342,
										["n_min"] = 10937,
										["g_dmg"] = 0,
										["counter"] = 8,
										["ChartData"] = {
											[8] = 96342,
											[11] = 96342,
											[5] = 85405,
										},
										["total"] = 96342,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 8,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[361500] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36790,
										["targets"] = {
											["Worldbreaker Smith"] = 36790,
										},
										["n_dmg"] = 36790,
										["n_min"] = 36790,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 36790,
										},
										["total"] = 36790,
										["c_max"] = 0,
										["id"] = 361500,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18125,
										["targets"] = {
											["Worldbreaker Smith"] = 30084,
										},
										["n_dmg"] = 30084,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											30084, -- [1]
										},
										["n_min"] = 5438,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[8] = 23563,
											[11] = 30084,
										},
										["total"] = 30084,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 46804,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Worldbreaker Smith"] = 46804,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 46804,
										},
										["total"] = 46804,
										["c_max"] = 46804,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 46804,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13347,
										["targets"] = {
											["Worldbreaker Smith"] = 13347,
										},
										["n_dmg"] = 13347,
										["n_min"] = 13347,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[8] = 13347,
											[11] = 13347,
										},
										["total"] = 13347,
										["c_max"] = 0,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 94216.008051,
							["start_time"] = 1675435181,
							["delay"] = 0,
							["last_event"] = 1675435190,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008132,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 94216,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185591-00005D16A9",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185591",
							["raid_targets"] = {
							},
							["total_without_pet"] = 94216.008132,
							["fight_component"] = true,
							["end_time"] = 1675435191,
							["dps_started"] = false,
							["total"] = 94216.008132,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5876,
										["targets"] = {
											["Allegory"] = 10646,
										},
										["n_dmg"] = 10646,
										["n_min"] = 4770,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10646,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[390927] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20893,
										["targets"] = {
											["Allegory"] = 83570,
										},
										["n_dmg"] = 83570,
										["n_min"] = 20892,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 83570,
										["c_max"] = 0,
										["id"] = 390927,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 250184.008132,
							["start_time"] = 1675435179,
							["delay"] = 0,
							["last_event"] = 1675435190,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 132,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 132,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 132,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 33,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375802] = {
										["activedamt"] = 1,
										["id"] = 375802,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["activedamt"] = 1,
										["id"] = 359618,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 2,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375087] = {
										["activedamt"] = 1,
										["id"] = 375087,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 19,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 2,
								[361469] = 1,
								[375087] = 1,
								[370452] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435191,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Smith",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[390927] = 3,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185591-00005D16A9",
							["aID"] = "185591",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 132,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396241.805,
				["tempo_start"] = 1675435179,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 726,
				["playing_solo"] = true,
				["totals"] = {
					344399.99244, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:39:52",
				["hasTimer"] = 12.01699999999255,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Smith",
				["TotalElapsedCombatTime"] = 396230.638,
				["CombatEndedAt"] = 396230.638,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:39:39",
				["end_time"] = 396230.638,
				["combat_id"] = 132,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Smith"] = 1,
				},
				["totals_grupo"] = {
					250184, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 250184.008051,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396218.379,
				["contra"] = "Worldbreaker Smith",
				["TimeData"] = {
				},
			}, -- [20]
			{
				{
					["combatId"] = 131,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002997,
							["damage_from"] = {
								["Worldbreaker Brute"] = true,
							},
							["targets"] = {
								["Worldbreaker Brute"] = 242387,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["friendlyfire"] = {
							},
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 242387.002997,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["end_time"] = 1675435154,
							["dps_started"] = false,
							["total"] = 242387.002997,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 41279,
										["targets"] = {
											["Worldbreaker Brute"] = 66746,
										},
										["n_dmg"] = 66746,
										["e_dmg"] = {
											41279, -- [1]
										},
										["e_lvl"] = {
											1, -- [1]
										},
										["n_min"] = 25467,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[8] = 25467,
											[11] = 25467,
											[5] = 25467,
										},
										["total"] = 66746,
										["c_max"] = 0,
										["e_amt"] = 1,
										["id"] = 359077,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[357209] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 42837,
										["g_amt"] = 0,
										["n_max"] = 4666,
										["targets"] = {
											["Worldbreaker Brute"] = 59711,
										},
										["n_dmg"] = 16874,
										["e_lvl"] = {
											1, -- [1]
										},
										["e_dmg"] = {
											59711, -- [1]
										},
										["n_min"] = 4037,
										["g_dmg"] = 0,
										["counter"] = 5,
										["ChartData"] = {
											[8] = 51008,
											[11] = 59711,
											[5] = 42837,
										},
										["total"] = 59711,
										["c_max"] = 42837,
										["e_amt"] = 1,
										["id"] = 357209,
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 42837,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["e_total"] = 1,
										["r_amt"] = 0,
									},
									[370452] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14857,
										["targets"] = {
											["Worldbreaker Brute"] = 14857,
										},
										["n_dmg"] = 14857,
										["n_min"] = 14857,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[11] = 14857,
										},
										["total"] = 14857,
										["c_max"] = 0,
										["id"] = 370452,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[356995] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 28919,
										["g_amt"] = 0,
										["n_max"] = 13062,
										["targets"] = {
											["Worldbreaker Brute"] = 101073,
										},
										["n_dmg"] = 72154,
										["n_min"] = 10876,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[8] = 101073,
											[11] = 101073,
											[5] = 101073,
										},
										["total"] = 101073,
										["c_max"] = 28919,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 28919,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 35930.002997,
							["start_time"] = 1675435141,
							["delay"] = 0,
							["last_event"] = 1675435154,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005372,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 35930,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185589-00005D1849",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185589",
							["raid_targets"] = {
							},
							["total_without_pet"] = 35930.005372,
							["fight_component"] = true,
							["end_time"] = 1675435154,
							["dps_started"] = false,
							["total"] = 35930.005372,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7002,
										["targets"] = {
											["Allegory"] = 17751,
										},
										["n_dmg"] = 17751,
										["n_min"] = 5357,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 17751,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[387398] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18179,
										["targets"] = {
											["Allegory"] = 18179,
										},
										["n_dmg"] = 18179,
										["n_min"] = 18179,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 18179,
										["c_max"] = 0,
										["id"] = 387398,
										["r_dmg"] = 0,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 242387.005372,
							["start_time"] = 1675435146,
							["delay"] = 0,
							["last_event"] = 1675435153,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 131,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 131,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 131,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370452] = {
										["activedamt"] = 0,
										["id"] = 370452,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[357209] = {
										["activedamt"] = 0,
										["id"] = 357209,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 29,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["activedamt"] = 1,
										["id"] = 375342,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 1,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 31,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 1,
								[370452] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435154,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
						{
							["monster"] = true,
							["nome"] = "Worldbreaker Brute",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["flag_original"] = 68168,
							["spell_cast"] = {
								[387398] = 1,
							},
							["classe"] = "UNKNOW",
							["fight_component"] = true,
							["last_event"] = 0,
							["pets"] = {
							},
							["tipo"] = 4,
							["serial"] = "Creature-0-3896-2444-650-185589-00005D1849",
							["aID"] = "185589",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 131,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396217.089,
				["tempo_start"] = 1675435141,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 725,
				["playing_solo"] = true,
				["totals"] = {
					278316.987203, -- [1]
					-0.001244999999926222, -- [2]
					{
						-0.002150000000000318, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:39:15",
				["hasTimer"] = 13.11700000002747,
				["cleu_timeline"] = {
				},
				["enemy"] = "Worldbreaker Brute",
				["TotalElapsedCombatTime"] = 13.28299999999581,
				["CombatEndedAt"] = 396193.734,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:39:01",
				["end_time"] = 396193.734,
				["combat_id"] = 131,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Worldbreaker Brute"] = 1,
				},
				["totals_grupo"] = {
					242387, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 242387.002997,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396180.451,
				["contra"] = "Worldbreaker Brute",
				["TimeData"] = {
				},
			}, -- [21]
			{
				{
					["combatId"] = 130,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007073,
							["damage_from"] = {
								["Swooping Snitch"] = true,
							},
							["targets"] = {
								["Swooping Snitch"] = 62356,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["aID"] = "580-0A6159F7",
							["raid_targets"] = {
							},
							["total_without_pet"] = 62356.007073,
							["friendlyfire"] = {
							},
							["end_time"] = 1675435087,
							["dps_started"] = false,
							["total"] = 62356.007073,
							["classe"] = "EVOKER",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 51576,
										["g_amt"] = 0,
										["n_max"] = 10780,
										["targets"] = {
											["Swooping Snitch"] = 62356,
										},
										["n_dmg"] = 10780,
										["n_min"] = 10780,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 62356,
										["c_max"] = 30047,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21529,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 11160.007073,
							["start_time"] = 1675435085,
							["delay"] = 0,
							["last_event"] = 1675435087,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001742,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Allegory"] = 11160,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3896-2444-650-185592-00005D118A",
							["damage_from"] = {
								["Allegory"] = true,
							},
							["aID"] = "185592",
							["raid_targets"] = {
							},
							["total_without_pet"] = 11160.001742,
							["fight_component"] = true,
							["end_time"] = 1675435087,
							["dps_started"] = false,
							["total"] = 11160.001742,
							["classe"] = "UNKNOW",
							["monster"] = true,
							["nome"] = "Swooping Snitch",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2122,
										["targets"] = {
											["Allegory"] = 11160,
										},
										["n_dmg"] = 11160,
										["n_min"] = 1456,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 11160,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 62356.001742,
							["start_time"] = 1675435073,
							["delay"] = 0,
							["last_event"] = 1675435086,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 130,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 130,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 130,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[356995] = {
										["activedamt"] = 0,
										["id"] = 356995,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[370898] = {
										["activedamt"] = 0,
										["id"] = 370898,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 42,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[390899] = {
										["activedamt"] = 1,
										["id"] = 390899,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["activedamt"] = 1,
										["id"] = 390936,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[388599] = {
										["activedamt"] = 1,
										["id"] = 388599,
										["targets"] = {
										},
										["actived_at"] = 1675435073,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[387678] = {
										["activedamt"] = 1,
										["id"] = 387678,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[372014] = {
										["activedamt"] = 2,
										["id"] = 372014,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[368901] = {
										["activedamt"] = 1,
										["id"] = 368901,
										["targets"] = {
										},
										["actived_at"] = 1675435073,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[186403] = {
										["activedamt"] = 1,
										["id"] = 186403,
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 4,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675435087,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 130,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["tempo_start"] = 1675435073,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Allegory"] = {
						["total"] = 0,
						["last"] = 0,
					},
				},
				["combat_counter"] = 724,
				["playing_solo"] = true,
				["totals"] = {
					73515.992014, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "15:38:08",
				["hasTimer"] = 14.00800000003073,
				["cleu_timeline"] = {
				},
				["enemy"] = "Swooping Snitch",
				["TotalElapsedCombatTime"] = 396126.734,
				["CombatEndedAt"] = 396126.734,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "15:37:53",
				["end_time"] = 396126.734,
				["combat_id"] = 130,
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Swooping Snitch"] = 1,
				},
				["totals_grupo"] = {
					62356, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["Allegory"] = 62356.007073,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 396112.484,
				["contra"] = "Swooping Snitch",
				["TimeData"] = {
				},
			}, -- [22]
			{
				{
					["tipo"] = 2,
					["combatId"] = 129,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003813,
							["damage_from"] = {
							},
							["targets"] = {
								["Unstable Elemental"] = 86634,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 86634.003813,
							["end_time"] = 1675435073,
							["serial"] = "Player-580-0A6159F7",
							["dps_started"] = false,
							["total"] = 86634.003813,
							["aID"] = "580-0A6159F7",
							["spec"] = 1467,
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 46657,
										["g_amt"] = 0,
										["n_max"] = 14772,
										["targets"] = {
											["Unstable Elemental"] = 86634,
										},
										["n_dmg"] = 39977,
										["n_min"] = 12059,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 86634,
										["c_max"] = 24999,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21658,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["last_event"] = 1675300200,
							["custom"] = 0,
							["tipo"] = 1,
							["last_dps"] = 0,
							["start_time"] = 1675435061,
							["delay"] = 1675300200,
							["damage_taken"] = 0.003813,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.002225,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
								["Allegory"] = true,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002225,
							["serial"] = "Creature-0-3102-2444-1588-194961-00005B0CFB",
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675300191,
							["classe"] = "UNKNOW",
							["aID"] = "194961",
							["nome"] = "Unstable Elemental",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["fight_component"] = true,
							["total"] = 0.002225,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 86634.002225,
							["start_time"] = 1675300191,
							["delay"] = 0,
							["last_dps"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 129,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "EVOKER",
							["totalover"] = 0.006196,
							["total_without_pet"] = 0.006196,
							["total"] = 0.006196,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-580-0A6159F7",
							["totalabsorb"] = 0.006196,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.006196,
							["healing_taken"] = 0.006196,
							["end_time"] = 1675435073,
							["heal_enemy_amt"] = 0,
							["healing_from"] = {
							},
							["nome"] = "Allegory",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["start_time"] = 1675435073,
							["spec"] = 1467,
							["custom"] = 0,
							["tipo"] = 2,
							["aID"] = "580-0A6159F7",
							["totaldenied"] = 0.006196,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 129,
					["_ActorTable"] = {
						{
							["received"] = 0.005653,
							["resource"] = 0.005653,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "EVOKER",
							["totalover"] = 0.005653,
							["total"] = 0.005653,
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["spec"] = 1467,
							["passiveover"] = 0.005653,
							["flag_original"] = 1300,
							["tipo"] = 3,
							["alternatepower"] = 50.005653,
							["last_event"] = 0,
							["serial"] = "Player-580-0A6159F7",
							["aID"] = "580-0A6159F7",
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 129,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[370898] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = 370898,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["actived_at"] = 1675300191,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 7,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 0,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[358267] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 358267,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 2,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1675300191,
							["tipo"] = 4,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 129,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 396110.9,
				["tempo_start"] = 1675300189,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Jizzrag"] = {
						["last"] = 3,
						["total"] = 4,
					},
					["Proterowing"] = {
						["last"] = 0,
						["total"] = 0,
					},
					["Dikê"] = {
						["total"] = 5,
						["last"] = 5,
					},
					["Alandrîa"] = {
						["last"] = 5,
						["total"] = 6,
					},
					["Praedamina"] = {
						["total"] = 6,
						["last"] = 4,
					},
					["Johndogge"] = {
						["total"] = 5,
						["last"] = 5,
					},
					["Twinklebart"] = {
						["total"] = 6,
						["last"] = 4,
					},
					["Corleone-Lordaeron"] = {
						["total"] = 5,
						["last"] = 5,
					},
					["Synthica"] = {
						["total"] = 6,
						["last"] = 5,
					},
					["Netanyahoo"] = {
						["total"] = 3,
						["last"] = 3,
					},
					["Kalaratrii"] = {
						["total"] = 0,
						["last"] = 0,
					},
					["Allegory"] = {
						["total"] = 50,
						["last"] = 6,
					},
					["Swoggi"] = {
						["last"] = 0,
						["total"] = 0,
					},
					["Geckopresi"] = {
						["total"] = 5,
						["last"] = 5,
					},
				},
				["combat_counter"] = 721,
				["playing_solo"] = true,
				["totals"] = {
					86633.64885700011, -- [1]
					-0.4054229999912973, -- [2]
					{
						-0.03450199999998037, -- [1]
						[0] = -0.052941,
						["alternatepower"] = 0,
						[3] = -0.005557000000010248,
						[6] = -0.006072000000017397,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["Allegory"] = {
						{
							false, -- [1]
							243241, -- [2]
							7578, -- [3]
							1675434079.027, -- [4]
							238920, -- [5]
							"Crownedkinq-Blackrock", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [1]
						{
							false, -- [1]
							77489, -- [2]
							472, -- [3]
							1675434082.111, -- [4]
							238920, -- [5]
							"Crownedkinq-Blackrock", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [2]
						{
							false, -- [1]
							77489, -- [2]
							472, -- [3]
							1675434085.094, -- [4]
							238920, -- [5]
							"Crownedkinq-Blackrock", -- [6]
							nil, -- [7]
							0, -- [8]
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 4,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "02:09:52",
				["hasTimer"] = 1.005000000004657,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Unstable Elemental",
				["TotalElapsedCombatTime"] = 0.904999999969732,
				["CombatEndedAt"] = 359787.306,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:09:50",
				["end_time"] = 359777.644,
				["combat_id"] = 129,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					86634, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Allegory"] = 48489.003813,
						}, -- [1]
					},
				},
				["start_time"] = 359776.196,
				["TimeData"] = {
				},
				["frags"] = {
					["Unstable Elemental"] = 1,
				},
			}, -- [23]
			{
				{
					["tipo"] = 2,
					["combatId"] = 128,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001356,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Unstable Elemental"] = 38626,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 38626.001356,
							["damage_taken"] = 0.001356,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675300173,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13146,
										["targets"] = {
											["Unstable Elemental"] = 13146,
										},
										["n_dmg"] = 13146,
										["n_min"] = 13146,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 13146,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 25480,
										["targets"] = {
											["Unstable Elemental"] = 25480,
										},
										["n_dmg"] = 25480,
										["n_min"] = 25480,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 25480,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 38626.001356,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675300173,
							["last_dps"] = 0,
							["start_time"] = 1675300172,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.001607,
							["damage_from"] = {
								["Allegory"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-194961-00005B0D27",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001607,
							["aID"] = "194961",
							["fight_component"] = true,
							["total"] = 0.001607,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Unstable Elemental",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675300173,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 38626.001607,
							["start_time"] = 1675300173,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 128,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 128,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 128,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[370898] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 1,
										["id"] = 370898,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["actived_at"] = 1675300173,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 4,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[358267] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 358267,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 375342,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 0,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1675300173,
							["tipo"] = 4,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 128,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 359776.196,
				["tempo_start"] = 1675300172,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 720,
				["playing_solo"] = true,
				["totals"] = {
					38626, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "02:09:34",
				["hasTimer"] = 1.001000000047498,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Unstable Elemental",
				["TotalElapsedCombatTime"] = 1.35899999999674,
				["CombatEndedAt"] = 359760.197,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:09:33",
				["end_time"] = 359760.197,
				["combat_id"] = 128,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					38626, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Allegory"] = 38626.001356,
						}, -- [1]
					},
				},
				["start_time"] = 359758.838,
				["TimeData"] = {
				},
				["frags"] = {
					["Unstable Elemental"] = 1,
				},
			}, -- [24]
			{
				{
					["tipo"] = 2,
					["combatId"] = 127,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004751,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Unstable Elemental"] = 84141,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 84141.004751,
							["damage_taken"] = 0.004751,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675300172,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13146,
										["targets"] = {
											["Unstable Elemental"] = 58839,
										},
										["n_dmg"] = 58839,
										["n_min"] = 9821,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 58839,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 25302,
										["targets"] = {
											["Unstable Elemental"] = 25302,
										},
										["n_dmg"] = 25302,
										["n_min"] = 25302,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 25302,
										["c_max"] = 0,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 84141.004751,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675300166,
							["last_dps"] = 0,
							["start_time"] = 1675300155,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.005383,
							["damage_from"] = {
								["Allegory"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-194961-00005B0D06",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005383,
							["aID"] = "194961",
							["fight_component"] = true,
							["total"] = 0.005383,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Unstable Elemental",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675300156,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 84141.005383,
							["start_time"] = 1675300156,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 127,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 127,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 127,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[370898] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 1,
										["id"] = 370898,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[356995] = {
										["activedamt"] = -1,
										["id"] = 356995,
										["targets"] = {
										},
										["actived_at"] = 1675300156,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 2,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 0,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1675300156,
							["tipo"] = 4,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 127,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
				},
				["CombatStartedAt"] = 359751.646,
				["tempo_start"] = 1675300155,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Allegory"] = {
						["total"] = 0,
						["last"] = 0,
					},
				},
				["combat_counter"] = 719,
				["playing_solo"] = true,
				["totals"] = {
					84141, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "02:09:17",
				["hasTimer"] = 1.007999999972526,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Unstable Elemental",
				["TotalElapsedCombatTime"] = 2.076000000000931,
				["CombatEndedAt"] = 359753.722,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:09:16",
				["end_time"] = 359742.759,
				["combat_id"] = 127,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					84141, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Allegory"] = 49811.004751,
						}, -- [1]
					},
				},
				["start_time"] = 359741.705,
				["TimeData"] = {
				},
				["frags"] = {
					["Unstable Elemental"] = 1,
				},
			}, -- [25]
			{
				{
					["tipo"] = 2,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003004,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Bisquius"] = 150653,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 150653.003004,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 150653.003004,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298773,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 20321,
										["g_amt"] = 0,
										["n_max"] = 3998,
										["targets"] = {
											["Bisquius"] = 28105,
										},
										["n_dmg"] = 7784,
										["n_min"] = 1801,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 28105,
										["c_max"] = 8101,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 4180,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377079] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3102,
										["g_amt"] = 0,
										["n_max"] = 1551,
										["targets"] = {
											["Bisquius"] = 4653,
										},
										["n_dmg"] = 1551,
										["n_min"] = 1551,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 4653,
										["c_max"] = 3102,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3102,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258922] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1376,
										["targets"] = {
											["Bisquius"] = 4050,
										},
										["n_dmg"] = 4050,
										["n_min"] = 1314,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 4050,
										["c_max"] = 0,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[207771] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 7637,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Bisquius"] = 7637,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7637,
										["c_max"] = 7637,
										["id"] = 207771,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 7637,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258921] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3625,
										["targets"] = {
											["Bisquius"] = 3625,
										},
										["n_dmg"] = 3625,
										["n_min"] = 3625,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3625,
										["c_max"] = 0,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[204021] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 24893,
										["targets"] = {
											["Bisquius"] = 24893,
										},
										["n_dmg"] = 24893,
										["n_min"] = 24893,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 24893,
										["c_max"] = 0,
										["id"] = 204021,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[384117] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11352,
										["targets"] = {
											["Bisquius"] = 11352,
										},
										["n_dmg"] = 11352,
										["n_min"] = 11352,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11352,
										["c_max"] = 0,
										["id"] = 384117,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 22180,
										["g_amt"] = 0,
										["n_max"] = 5547,
										["targets"] = {
											["Bisquius"] = 38438,
										},
										["n_dmg"] = 16258,
										["n_min"] = 5173,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 38438,
										["c_max"] = 11350,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10830,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[228478] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 27900,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Bisquius"] = 27900,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 27900,
										["c_max"] = 27900,
										["id"] = 228478,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 27900,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298772,
							["on_hold"] = false,
							["start_time"] = 1675298765,
							["delay"] = 0,
							["damage_taken"] = 0.003004,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.0039,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Bisquius"] = 90225,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 90225.0039,
							["damage_taken"] = 0.0039,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298773,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 68876,
										["g_amt"] = 0,
										["n_max"] = 11009,
										["targets"] = {
											["Bisquius"] = 90225,
										},
										["n_dmg"] = 21349,
										["n_min"] = 10340,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 90225,
										["c_max"] = 25156,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21479,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 90225.0039,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298772,
							["last_dps"] = 0,
							["start_time"] = 1675298769,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 10779.004604,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Blutgurgel"] = 18016,
								["Grimkrit"] = 10779,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-197557-00005B07C7",
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Flamindragon"] = true,
								["Spirit Wolf <Maplebaomn>"] = true,
								["Ferloc"] = true,
								["Eastpack"] = true,
								["Beast <Ixaru>"] = true,
								["Galldo"] = true,
								["Lucér"] = true,
								["Saturas-Tichondrius"] = true,
								["Wild Imp <Belàkor>"] = true,
								["Zrouge"] = true,
								["Crab"] = true,
								["Niored"] = true,
								["Belàkor"] = true,
								["Blazê"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Heloran-Lordaeron"] = true,
								["Spirit Wolf <Milai>"] = true,
								["Note"] = true,
								["Dztn"] = true,
								["Drakekard"] = true,
								["Dreadstalker <Belàkor>"] = true,
								["Skrulus"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Rottingandy"] = true,
								["Thiril"] = true,
								["Opór"] = true,
								["Tøxicator"] = true,
								["Starcloud"] = true,
								["Rydrasil"] = true,
								["Echse"] = true,
								["Sýlvanà"] = true,
								["Neakî"] = true,
								["Hammerzehrer <Rottingandy>"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["TheBEES"] = true,
								["Xînsu"] = true,
								["Aîphaton"] = true,
								["Scahra"] = true,
								["Esme-Lordaeron"] = true,
								["Risen Skulker"] = true,
								["Tienti-Lordaeron"] = true,
								["Hodeldiedoo"] = true,
								["Herzschinder"] = true,
								["Luitger"] = true,
								["Thrazosh"] = true,
								["Mothman"] = true,
								["Vaikir"] = true,
								["Dædshøt"] = true,
								["Elrondyr"] = true,
								["Shukar"] = true,
								["Liquid Magma Totem <Note>"] = true,
								["Worselchen-Nathrezim"] = true,
								["Makkresh"] = true,
								["Mîlex"] = true,
								["Spârky"] = true,
								["Gahrol"] = true,
								["Milai"] = true,
								["Misha"] = true,
								["Beast <Lotosblüte>"] = true,
								["Allegory"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Cat"] = true,
								["Dqniix"] = true,
								["Melaskula"] = true,
								["Aislina-Frostmourne"] = true,
								["Kaz-tarash"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Grimkrit"] = true,
								["Lilítt"] = true,
								["Midracsky"] = true,
								["Lotosblüte"] = true,
								["Walevo"] = true,
								["Blasphemy <Vaikir>"] = true,
								["Rashael-Lordaeron"] = true,
								["Yourholiness"] = true,
								["Fadruidsko"] = true,
								["Ixaru"] = true,
								["Whish"] = true,
								["Fenryr"] = true,
								["Evionix"] = true,
								["VazeelRike"] = true,
								["Spirit Wolf <Draikuen>"] = true,
								["Blutgurgel"] = true,
								["Ne"] = true,
								["Busswhip"] = true,
								["Draikuen"] = true,
								["Grindling"] = true,
								["Bârzi"] = true,
								["Golgrem"] = true,
								["Bloodworm <Lucér>"] = true,
								["Missgankalot"] = true,
								["Arrmok"] = true,
								["Rezagal"] = true,
								["Eleazara-Arygos"] = true,
								["Flauschi"] = true,
								["Fenryr <Gahrol>"] = true,
								["Kahabrakh"] = true,
								["Geiszt"] = true,
								["Témeraîre"] = true,
							},
							["aID"] = "197557",
							["raid_targets"] = {
							},
							["total_without_pet"] = 28795.004604,
							["classe"] = "UNKNOW",
							["on_hold"] = false,
							["monster"] = true,
							["end_time"] = 1675298773,
							["friendlyfire_total"] = 0,
							["total"] = 28795.004604,
							["nome"] = "Bisquius",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18016,
										["targets"] = {
											["Blutgurgel"] = 18016,
											["Grimkrit"] = 10779,
										},
										["n_dmg"] = 28795,
										["n_min"] = 10779,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 28795,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["fight_component"] = true,
							["custom"] = 0,
							["last_event"] = 1675298770,
							["last_dps"] = 0,
							["start_time"] = 1675298767,
							["delay"] = 0,
							["damage_taken"] = 10282008.004604,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 46035,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 46035.006268,
							["total_without_pet"] = 0.006268,
							["total"] = 0.006268,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.006268,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.006268,
							["healing_taken"] = 0.006268,
							["end_time"] = 1675298773,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 13603,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 13603,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 11015,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 11015,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 20212,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 20212,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 1205,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 1205,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298766,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298772,
							["tipo"] = 2,
							["totaldenied"] = 0.006268,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["received"] = 0.001104,
							["resource"] = 33.001104,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.001104,
							["total"] = 0.001104,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 6.001104,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298776,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.001104,
						}, -- [1]
						{
							["received"] = 0.003636,
							["resource"] = 0.003636,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "EVOKER",
							["totalover"] = 0.003636,
							["total"] = 0.003636,
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["spec"] = 1467,
							["passiveover"] = 0.003636,
							["flag_original"] = 1300,
							["tipo"] = 3,
							["alternatepower"] = 13.003636,
							["last_event"] = 0,
							["serial"] = "Player-580-0A6159F7",
							["aID"] = "580-0A6159F7",
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = 247456,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[207771] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = 207771,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["cooldowns_defensive"] = 1.008116,
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["cooldowns_defensive_targets"] = {
								["Bisquius"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 212988,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 391166,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[203981] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 5,
										["id"] = 203981,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 8,
							["cooldowns_defensive_spells"] = {
								["_ActorTable"] = {
									[204021] = {
										["id"] = 204021,
										["targets"] = {
											["Bisquius"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 7,
								[225919] = 2,
								[204021] = 1,
								[228477] = 1,
								[225921] = 3,
								[258920] = 1,
								[263642] = 2,
								[203720] = 2,
								[204513] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["buff_uptime"] = 40,
							["tipo"] = 4,
							["last_event"] = 1675298773,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = 356995,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 29,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 2,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[356995] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1675298773,
							["tipo"] = 4,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["buff_uptime_targets"] = {
							},
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 123,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 359073.29,
				["tempo_start"] = 1675298765,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Scahra"] = {
						["total"] = 6,
						["last"] = 0,
					},
					["Allegory"] = {
						["total"] = 13,
						["last"] = 0,
					},
					["Fadruidsko"] = {
						["total"] = 6,
						["last"] = 5,
					},
					["Thiril"] = {
						["total"] = 6,
						["last"] = 5,
					},
					["Isary"] = {
						["total"] = 6,
						["last"] = 5,
					},
					["Milai"] = {
						["total"] = 0,
						["last"] = 0,
					},
					["Melaeya"] = {
						["total"] = 6,
						["last"] = 5,
					},
					["Arrmok"] = {
						["total"] = 6,
						["last"] = 0,
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					269672.4996539991, -- [1]
					-0.3985790000013067, -- [2]
					{
						-0.05334199999997402, -- [1]
						[0] = -0.1218439999998369,
						["alternatepower"] = 0,
						[3] = -0.02698900000000037,
						[6] = -0.01595500000001948,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 1,
						["dispell"] = 0,
						["interrupt"] = -0.004947000000000035,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					240878, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 1,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:46:14",
				["hasTimer"] = 7.052000000025146,
				["cleu_timeline"] = {
				},
				["enemy"] = "Bisquius",
				["TotalElapsedCombatTime"] = 6.072999999974854,
				["CombatEndedAt"] = 358359.518,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.006268,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 150653.003004,
							["Allegory"] = 90225.0039,
						}, -- [1]
					},
				},
				["end_time"] = 358359.518,
				["combat_id"] = 123,
				["spells_cast_timeline"] = {
				},
				["contra"] = "Bisquius",
				["frags"] = {
					["Doomguard"] = 1,
					["Bisquius"] = 1,
				},
				["combat_counter"] = 714,
				["data_inicio"] = "01:46:06",
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358351.511,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [26]
			{
				{
					["tipo"] = 2,
					["combatId"] = 122,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008606,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Tough Carp"] = 14255,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 14255.008606,
							["damage_taken"] = 0.008606,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298734,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7703,
										["targets"] = {
											["Tough Carp"] = 14255,
										},
										["n_dmg"] = 14255,
										["n_min"] = 6552,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 14255,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 14255.008606,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298733,
							["last_dps"] = 0,
							["start_time"] = 1675298732,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008038,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Bisquius"] = 8926,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3786,
										["targets"] = {
											["Bisquius"] = 3786,
										},
										["n_dmg"] = 3786,
										["n_min"] = 3786,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3786,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5140,
										["targets"] = {
											["Bisquius"] = 5140,
										},
										["n_dmg"] = 5140,
										["n_min"] = 5140,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5140,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8926.008038,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 8926.008038,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298765,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298765,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298765,
							["delay"] = 0,
							["damage_taken"] = 0.008038,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.004007,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Spârky"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Niored"] = true,
								["Melaskula"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Vaikir"] = true,
								["Note"] = true,
								["Dztn"] = true,
								["Galldo"] = true,
								["Xînsu"] = true,
								["Allegory"] = true,
								["Kitsuneri"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Worselchen-Nathrezim"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["Blutgurgel"] = true,
								["VazeelRike"] = true,
								["Missgankalot"] = true,
								["Sýlvanà"] = true,
								["Misha"] = true,
								["Heloran-Lordaeron"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Geiszt"] = true,
								["Saturas-Tichondrius"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B07AB",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004007,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.004007,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298734,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 425542.004007,
							["start_time"] = 1675298734,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 122,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 122,
					["_ActorTable"] = {
						{
							["received"] = 0.006772,
							["resource"] = 113.006772,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.006772,
							["total"] = 0.006772,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.006772,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298765,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.006772,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 122,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390224] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390224,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 391166,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["last_event"] = 1675298734,
							["nome"] = "Scahra",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime"] = 10,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[362969] = 1,
							},
							["buff_uptime"] = 10,
							["last_event"] = 1675298734,
							["classe"] = "EVOKER",
							["nome"] = "Allegory",
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 122,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Arrmok"] = {
						["total"] = 11,
						["last"] = 0,
					},
					["Belàkor"] = {
						["total"] = 5,
						["last"] = 0,
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					23180.63271900042, -- [1]
					-0.3129710000000001, -- [2]
					{
						-0.06963599999998667, -- [1]
						[0] = -0.08824999999993333,
						["alternatepower"] = 0,
						[3] = -0.01213099999998946,
						[6] = -0.01943300000000114,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					23181, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:45:34",
				["hasTimer"] = 1.01400000002468,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Tough Carp",
				["TotalElapsedCombatTime"] = 358319.573,
				["CombatEndedAt"] = 358319.573,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:45:32",
				["end_time"] = 358320.039,
				["combat_id"] = 122,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Allegory"] = 14255.008606,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1675298732,
				["combat_counter"] = 713,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358318.027,
				["TimeData"] = {
				},
				["frags"] = {
					["Bittershell Hermit"] = 2,
				},
			}, -- [27]
			{
				{
					["tipo"] = 2,
					["combatId"] = 121,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003965,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 136527,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 136527.003965,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 136527.003965,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298723,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[258922] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3112,
										["g_amt"] = 0,
										["n_max"] = 1603,
										["targets"] = {
											["Rubbery Fish Head"] = 8872,
										},
										["n_dmg"] = 5760,
										["n_min"] = 1289,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 8872,
										["c_max"] = 3112,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3112,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[247455] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29672,
										["targets"] = {
											["Rubbery Fish Head"] = 29672,
										},
										["n_dmg"] = 29672,
										["n_min"] = 29672,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 29672,
										["c_max"] = 0,
										["id"] = 247455,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[377079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1551,
										["targets"] = {
											["Rubbery Fish Head"] = 1551,
										},
										["n_dmg"] = 1551,
										["n_min"] = 1551,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1551,
										["c_max"] = 0,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[382090] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 56725,
										["g_amt"] = 0,
										["n_max"] = 15883,
										["targets"] = {
											["Rubbery Fish Head"] = 96432,
										},
										["n_dmg"] = 39707,
										["n_min"] = 11345,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 96432,
										["c_max"] = 29497,
										["id"] = 382090,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 27228,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298721,
							["on_hold"] = false,
							["start_time"] = 1675298716,
							["delay"] = 0,
							["damage_taken"] = 0.003965,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.00704,
							["damage_from"] = {
								["Scahra"] = true,
								["Flamindragon"] = true,
								["Tienti-Lordaeron"] = true,
								["Golgrem"] = true,
								["Rydrasil"] = true,
								["Spârky"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Niored"] = true,
								["Blazê"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Grimkrit"] = true,
								["Wild Imp <Aîphaton>"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Dztn"] = true,
								["Drakekard"] = true,
								["Aîphaton"] = true,
								["Esme-Lordaeron"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Maplebaomn"] = true,
								["Mîlex"] = true,
								["Tøxicator"] = true,
								["Saturas-Tichondrius"] = true,
								["VazeelRike"] = true,
								["Missgankalot"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Galldo"] = true,
								["Dædshøt"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["Lilítt"] = true,
								["Geiszt"] = true,
								["Melaskula"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B079C",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00704,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.00704,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298723,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1824670.00704,
							["start_time"] = 1675298723,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 121,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 10808,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 10808.002333,
							["total_without_pet"] = 0.002333,
							["total"] = 0.002333,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.002333,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.002333,
							["healing_taken"] = 0.002333,
							["end_time"] = 1675298723,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 1157,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 1157,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 9651,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 9651,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298716,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298721,
							["tipo"] = 2,
							["totaldenied"] = 0.002333,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 121,
					["_ActorTable"] = {
						{
							["received"] = 0.001688,
							["resource"] = 19.001688,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.001688,
							["total"] = 0.001688,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.001688,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298720,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.001688,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 121,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["activedamt"] = -1,
										["id"] = 247456,
										["targets"] = {
										},
										["actived_at"] = 1675298722,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[390224] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 4,
										["id"] = 390224,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 391166,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[377453] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 377453,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383756] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 383756,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391172] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 0,
										["id"] = 391172,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 212988,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[377453] = 1,
							},
							["buff_uptime"] = 48,
							["last_event"] = 1675298723,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 28,
							["pets"] = {
							},
							["tipo"] = 4,
							["aID"] = "580-0A6159F7",
							["last_event"] = 1675298723,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-580-0A6159F7",
							["classe"] = "EVOKER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 121,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 358317.938,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 712,
				["totals"] = {
					136526.7625469996, -- [1]
					-0.344067, -- [2]
					{
						-0.03149100000000579, -- [1]
						[0] = -0.038807,
						["alternatepower"] = 0,
						[3] = -0.01951600000000905,
						[6] = -0.008259999999999934,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:45:23",
				["hasTimer"] = 6.024000000033993,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:45:16",
				["end_time"] = 358309.08,
				["combat_id"] = 121,
				["tempo_start"] = 1675298716,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals_grupo"] = {
					136527, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.002333,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 136527.003965,
						}, -- [1]
					},
				},
				["start_time"] = 358302.067,
				["TimeData"] = {
				},
				["frags"] = {
					["Bittershell Hermit"] = 26,
				},
			}, -- [28]
			{
				{
					["tipo"] = 2,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001696,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 25593,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 25593.001696,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 25593.001696,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298716,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5145,
										["targets"] = {
											["Rubbery Fish Head"] = 7789,
										},
										["n_dmg"] = 7789,
										["n_min"] = 2644,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 7789,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[258922] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1725,
										["targets"] = {
											["Rubbery Fish Head"] = 3407,
										},
										["n_dmg"] = 3407,
										["n_min"] = 1682,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3407,
										["c_max"] = 0,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7206,
										["targets"] = {
											["Rubbery Fish Head"] = 14397,
										},
										["n_dmg"] = 14397,
										["n_min"] = 7191,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 14397,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298716,
							["on_hold"] = false,
							["start_time"] = 1675298707,
							["delay"] = 0,
							["damage_taken"] = 0.001696,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.007147,
							["damage_from"] = {
								["Grimkrit"] = true,
								["Scahra"] = true,
								["Infernal <Vaikir>"] = true,
								["Tienti-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Füxli"] = true,
								["Maplebaomn"] = true,
								["Loreley-Tichondrius"] = true,
								["Melaskula"] = true,
								["Rydrasil"] = true,
								["Spârky"] = true,
								["VazeelRike"] = true,
								["Sinfluterrin"] = true,
								["Herzschinder"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Toute"] = true,
								["Saturas-Tichondrius"] = true,
								["Lilítt"] = true,
								["Grindling"] = true,
								["Tøxicator"] = true,
								["Neakî"] = true,
								["Dædshøt"] = true,
								["Missgankalot"] = true,
								["Nêrdnuss"] = true,
								["Galldo"] = true,
								["Aîphaton"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Vaikir"] = true,
								["Angíta-Lordaeron"] = true,
								["Geiszt"] = true,
								["Heloran-Lordaeron"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B0792",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007147,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.007147,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298709,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 527207.0071469999,
							["start_time"] = 1675298709,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 51,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 51.008473,
							["total_without_pet"] = 0.008473,
							["total"] = 0.008473,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.008473,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.008473,
							["healing_taken"] = 0.008473,
							["end_time"] = 1675298709,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 51,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 51,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298707,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298707,
							["tipo"] = 2,
							["totaldenied"] = 0.008473,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["received"] = 0.001915,
							["resource"] = 33.001915,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.001915,
							["total"] = 0.001915,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.001915,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298716,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.001915,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 19,
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[390224] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390224,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203981] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 203981,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 391166,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 212988,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391172] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 391172,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383756] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 383756,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[225919] = 1,
								[263642] = 1,
								[204255] = 2,
								[225921] = 1,
							},
							["nome"] = "Scahra",
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["pets"] = {
							},
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["last_event"] = 1675298709,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 10,
							["pets"] = {
							},
							["tipo"] = 4,
							["aID"] = "580-0A6159F7",
							["last_event"] = 1675298709,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386907] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386907,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-580-0A6159F7",
							["classe"] = "EVOKER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 120,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 711,
				["totals"] = {
					25592.79746099992, -- [1]
					-0.323245, -- [2]
					{
						-0.04831999999999281, -- [1]
						[0] = -0.033733,
						["alternatepower"] = 0,
						[3] = -0.01464100000000505,
						[6] = -0.01027699999999854,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					25593, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:45:09",
				["hasTimer"] = 1.011999999987893,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:45:07",
				["end_time"] = 358295.173,
				["combat_id"] = 120,
				["tempo_start"] = 1675298707,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Bittershell Hermit"] = 2,
					["Frostfin Minnow"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358293.163,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.008473,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 23868.001696,
						}, -- [1]
					},
				},
			}, -- [29]
			{
				{
					["tipo"] = 2,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00377,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 17127,
								["Turnip Punching Bag"] = 54724,
								["Tough Carp"] = 140740,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 21246,
										["g_amt"] = 0,
										["n_max"] = 6426,
										["targets"] = {
											["Turnip Punching Bag"] = 6426,
											["Tough Carp"] = 21246,
										},
										["n_dmg"] = 6426,
										["n_min"] = 6426,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 27672,
										["c_max"] = 10956,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 10290,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377079] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1344,
										["g_amt"] = 0,
										["n_max"] = 1551,
										["targets"] = {
											["Rubbery Fish Head"] = 673,
											["Turnip Punching Bag"] = 1344,
											["Tough Carp"] = 2223,
										},
										["n_dmg"] = 2896,
										["n_min"] = 672,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 4240,
										["c_max"] = 1344,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1344,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258922] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3618,
										["g_amt"] = 0,
										["n_max"] = 1806,
										["targets"] = {
											["Tough Carp"] = 8590,
											["Rubbery Fish Head"] = 3040,
										},
										["n_dmg"] = 8012,
										["n_min"] = 1366,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 11630,
										["c_max"] = 3618,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3618,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[247455] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9747,
										["targets"] = {
											["Rubbery Fish Head"] = 9747,
											["Turnip Punching Bag"] = 9476,
											["Tough Carp"] = 9599,
										},
										["n_dmg"] = 28822,
										["n_min"] = 9476,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 28822,
										["c_max"] = 0,
										["id"] = 247455,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[204021] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 66244,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Tough Carp"] = 66244,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 66244,
										["c_max"] = 66244,
										["id"] = 204021,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 66244,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[204598] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4942,
										["targets"] = {
											["Tough Carp"] = 7456,
										},
										["n_dmg"] = 7456,
										["n_min"] = 2514,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 7456,
										["c_max"] = 0,
										["id"] = 204598,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 47931,
										["g_amt"] = 0,
										["n_max"] = 7474,
										["targets"] = {
											["Turnip Punching Bag"] = 33741,
											["Tough Carp"] = 21664,
										},
										["n_dmg"] = 7474,
										["n_min"] = 7474,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 55405,
										["c_max"] = 17099,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 14190,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258921] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3737,
										["targets"] = {
											["Rubbery Fish Head"] = 3667,
											["Turnip Punching Bag"] = 3737,
											["Tough Carp"] = 3718,
										},
										["n_dmg"] = 11122,
										["n_min"] = 3667,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 11122,
										["c_max"] = 0,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 212591.00377,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 212591.00377,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298707,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298706,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298697,
							["delay"] = 0,
							["damage_taken"] = 0.00377,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.008432,
							["damage_from"] = {
								["Scahra"] = true,
								["Infernal <Vaikir>"] = true,
								["Eleanda-Lordaeron"] = true,
								["Herzschinder"] = true,
								["Golgrem"] = true,
								["Aislina-Frostmourne"] = true,
								["Rydrasil"] = true,
								["Spârky"] = true,
								["Melaskula"] = true,
								["Corfid"] = true,
								["Note"] = true,
								["Walevo"] = true,
								["Gahrol"] = true,
								["Whish"] = true,
								["Esme-Lordaeron"] = true,
								["VazeelRike"] = true,
								["Aîphaton"] = true,
								["Kitsuneri"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Fenryr <Gahrol>"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Lilítt"] = true,
								["Blazê"] = true,
								["Saturas-Tichondrius"] = true,
								["Risen Skulker"] = true,
								["Missgankalot"] = true,
								["Drakekard"] = true,
								["Dædshøt"] = true,
								["Galldo"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Geiszt"] = true,
								["Maplebaomn"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-65310-00005B0787",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008432,
							["aID"] = "65310",
							["fight_component"] = true,
							["total"] = 0.008432,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Turnip Punching Bag",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298705,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 590014.008432,
							["start_time"] = 1675298705,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.004934,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Infernal <Vaikir>"] = true,
								["Dqniix"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Spârky"] = true,
								["Nêrdnuss"] = true,
								["Melaskula"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Grimkrit"] = true,
								["Note"] = true,
								["Wild Imp <Aîphaton>"] = true,
								["Walevo"] = true,
								["Scahra"] = true,
								["Herzschinder"] = true,
								["Dztn"] = true,
								["Blazê"] = true,
								["Neakî"] = true,
								["Drakekard"] = true,
								["Esme-Lordaeron"] = true,
								["Whish"] = true,
								["VazeelRike"] = true,
								["Kitsuneri"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Lilítt"] = true,
								["Missgankalot"] = true,
								["Mîlex"] = true,
								["Tøxicator"] = true,
								["Aislina-Frostmourne"] = true,
								["Dædshøt"] = true,
								["Risen Skulker"] = true,
								["Grindling"] = true,
								["Saturas-Tichondrius"] = true,
								["Aîphaton"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Geiszt"] = true,
								["Galldo"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B0788",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004934,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.004934,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298705,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1946168.004934,
							["start_time"] = 1675298705,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.003587,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Infernal <Vaikir>"] = true,
								["Tienti-Lordaeron"] = true,
								["Herzschinder"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Nêrdnuss"] = true,
								["Niored"] = true,
								["Melaskula"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Blackcàt"] = true,
								["Vaikir"] = true,
								["Drakekard"] = true,
								["Aislina-Frostmourne"] = true,
								["Aîphaton"] = true,
								["VazeelRike"] = true,
								["Kitsuneri"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Lilítt"] = true,
								["Grindling"] = true,
								["Tøxicator"] = true,
								["Blazê"] = true,
								["Scahra"] = true,
								["Risen Skulker"] = true,
								["Missgankalot"] = true,
								["Dædshøt"] = true,
								["Spârky"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["Whish"] = true,
								["Geiszt"] = true,
								["Galldo"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B0788",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003587,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.003587,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298705,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 903913.0035870001,
							["start_time"] = 1675298705,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 81560,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 81560.007877,
							["total_without_pet"] = 0.007877,
							["total"] = 0.007877,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.007877,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.007877,
							["healing_taken"] = 0.007877,
							["end_time"] = 1675298705,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 34006,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 34006,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 21537,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 21537,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 3710,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 14,
										["overheal"] = 3710,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 14,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 22307,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 22307,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298698,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298704,
							["tipo"] = 2,
							["totaldenied"] = 0.007877,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["received"] = 0.00546,
							["resource"] = 48.00546,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.00546,
							["total"] = 0.00546,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.00546,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298707,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.00546,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[204598] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 204598,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[207771] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 207771,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[247456] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 6,
										["id"] = 247456,
										["refreshamt"] = 3,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["cooldowns_defensive"] = 1.00174,
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["cooldowns_defensive_targets"] = {
								["Tough Carp"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[390224] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 390224,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203981] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 8,
										["id"] = 203981,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 8,
										["id"] = 391166,
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383756] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 383756,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[347765] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 347765,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391172] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 391172,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 212988,
										["refreshamt"] = 11,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 11,
							["cooldowns_defensive_spells"] = {
								["_ActorTable"] = {
									[204021] = {
										["id"] = 204021,
										["targets"] = {
											["Tough Carp"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 8,
								[225919] = 1,
								[225921] = 2,
								[204021] = 1,
								[228477] = 1,
								[247454] = 1,
								[258920] = 1,
								[204513] = 1,
								[203720] = 1,
								[263642] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["buff_uptime"] = 72,
							["tipo"] = 4,
							["last_event"] = 1675298705,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386907] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 386907,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[386907] = 1,
							},
							["buff_uptime"] = 37,
							["last_event"] = 1675298705,
							["classe"] = "EVOKER",
							["nome"] = "Allegory",
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 119,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 710,
				["totals"] = {
					212590.7575890003, -- [1]
					-0.3386580000005011, -- [2]
					{
						-0.03228800000000328, -- [1]
						[0] = -0.037713,
						["alternatepower"] = 0,
						[3] = -20.02772,
						[6] = 19.989966,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 1,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					212591, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 1,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:45:05",
				["hasTimer"] = 7.057000000029802,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:44:57",
				["end_time"] = 358291.178,
				["combat_id"] = 119,
				["tempo_start"] = 1675298697,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Bittershell Hermit"] = 4,
					["Healing Stream Totem"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358283.168,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.007877,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 210917.00377,
						}, -- [1]
					},
				},
			}, -- [30]
			{
				{
					["tipo"] = 2,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006905,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 21896,
								["Turnip Punching Bag"] = 12734,
								["Tough Carp"] = 53916,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12734,
										["g_amt"] = 0,
										["n_max"] = 4693,
										["targets"] = {
											["Rubbery Fish Head"] = 11387,
											["Turnip Punching Bag"] = 12734,
											["Tough Carp"] = 6980,
										},
										["n_dmg"] = 18367,
										["n_min"] = 2287,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 31101,
										["c_max"] = 12734,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 12734,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[258922] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 7477,
										["g_amt"] = 0,
										["n_max"] = 1904,
										["targets"] = {
											["Tough Carp"] = 7692,
											["Rubbery Fish Head"] = 8958,
										},
										["n_dmg"] = 9173,
										["n_min"] = 1755,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 16650,
										["c_max"] = 3886,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3591,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[247455] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26196,
										["targets"] = {
											["Tough Carp"] = 26196,
										},
										["n_dmg"] = 26196,
										["n_min"] = 26196,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 26196,
										["c_max"] = 0,
										["id"] = 247455,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[377079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1551,
										["targets"] = {
											["Rubbery Fish Head"] = 1551,
										},
										["n_dmg"] = 1551,
										["n_min"] = 1551,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1551,
										["c_max"] = 0,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6565,
										["targets"] = {
											["Tough Carp"] = 13048,
										},
										["n_dmg"] = 13048,
										["n_min"] = 6483,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 13048,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 88546.006905,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 88546.006905,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298697,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298697,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298686,
							["delay"] = 0,
							["damage_taken"] = 0.006905,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.006707,
							["damage_from"] = {
								["Scahra"] = true,
								["Infernal <Vaikir>"] = true,
								["Tienti-Lordaeron"] = true,
								["Eleanda-Lordaeron"] = true,
								["Herzschinder"] = true,
								["Galldo"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Spârky"] = true,
								["Sinfluterrin"] = true,
								["Niored"] = true,
								["Blazê"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Esme-Lordaeron"] = true,
								["Walevo"] = true,
								["Melaskula"] = true,
								["Dztn"] = true,
								["Wild Imp <Aîphaton>"] = true,
								["Drakekard"] = true,
								["Whish"] = true,
								["Bossyy"] = true,
								["Skysmimi-Lordaeron"] = true,
								["VazeelRike"] = true,
								["Kitsuneri"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Vaikir"] = true,
								["Dædshøt"] = true,
								["Mîlex"] = true,
								["Tøxicator"] = true,
								["Aîphaton"] = true,
								["Aislina-Frostmourne"] = true,
								["Missgankalot"] = true,
								["Golgrem"] = true,
								["Lilítt"] = true,
								["Corfid"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Geiszt"] = true,
								["Maplebaomn"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B077E",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006707,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.006707,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298693,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1437612.006707,
							["start_time"] = 1675298693,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.002639,
							["damage_from"] = {
								["Scahra"] = true,
								["Infernal <Vaikir>"] = true,
								["Eleanda-Lordaeron"] = true,
								["Herzschinder"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Sinfluterrin"] = true,
								["Niored"] = true,
								["Melaskula"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Heloran-Lordaeron"] = true,
								["Esme-Lordaeron"] = true,
								["Drakekard"] = true,
								["Whish"] = true,
								["Geiszt"] = true,
								["Mîlex"] = true,
								["Aîphaton"] = true,
								["Kitsuneri"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Xaani"] = true,
								["Dædshøt"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["VazeelRike"] = true,
								["Mothman"] = true,
								["Missgankalot"] = true,
								["Galldo"] = true,
								["Aislina-Frostmourne"] = true,
								["Maplebaomn"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Bossyy"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Rottingandy"] = true,
								["Corfid"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B0783",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002639,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.002639,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298693,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 977626.0026390001,
							["start_time"] = 1675298693,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 32313,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 32313.004881,
							["total_without_pet"] = 0.004881,
							["total"] = 0.004881,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.004881,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.004881,
							["healing_taken"] = 0.004881,
							["end_time"] = 1675298693,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 27207,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 4,
										["overheal"] = 27207,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 1286,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 8,
										["overheal"] = 1286,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 3820,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 3820,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298687,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298693,
							["tipo"] = 2,
							["totaldenied"] = 0.004881,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["received"] = 0.004599,
							["resource"] = 75.004599,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.004599,
							["total"] = 0.004599,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.004599,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298697,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.004599,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 247456,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[394958] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 394958,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[1490] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 1490,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 4,
										["id"] = 203981,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383756] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 383756,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[347765] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 347765,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391172] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 391172,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 212988,
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 391166,
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 9,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 2,
								[225921] = 1,
								[247454] = 1,
								[203720] = 1,
								[263642] = 1,
								[225919] = 1,
							},
							["buff_uptime"] = 62,
							["last_event"] = 1675298693,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 28,
							["pets"] = {
							},
							["tipo"] = 4,
							["aID"] = "580-0A6159F7",
							["last_event"] = 1675298693,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-580-0A6159F7",
							["classe"] = "EVOKER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 118,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 709,
				["totals"] = {
					88545.72102000019, -- [1]
					-0.3821950000005927, -- [2]
					{
						-0.04009699999999813, -- [1]
						[0] = -0.03189400000000001,
						["alternatepower"] = 0,
						[3] = -0.00859100000000268,
						[6] = -0.01285299999999978,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					88546, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:44:53",
				["hasTimer"] = 6.050000000046566,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Tough Carp",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:44:46",
				["end_time"] = 358279.424,
				["combat_id"] = 118,
				["tempo_start"] = 1675298686,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358272.404,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.004881,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 75812.006905,
						}, -- [1]
					},
				},
			}, -- [31]
			{
				{
					["tipo"] = 2,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006603,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 9396,
								["Tough Carp"] = 3927,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3927,
										["targets"] = {
											["Tough Carp"] = 3927,
										},
										["n_dmg"] = 3927,
										["n_min"] = 3927,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3927,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[258921] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 9396,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Rubbery Fish Head"] = 9396,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9396,
										["c_max"] = 9396,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 9396,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 13323.006603,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 13323.006603,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298686,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298686,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298684,
							["delay"] = 0,
							["damage_taken"] = 0.006603,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.007157,
							["damage_from"] = {
								["Scahra"] = true,
								["Galldo"] = true,
								["Kitsuneri"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B0779",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007157,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.007157,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298685,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 8718.007157,
							["start_time"] = 1675298685,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 44560,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 44560.003086,
							["total_without_pet"] = 0.003086,
							["total"] = 0.003086,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.003086,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.003086,
							["healing_taken"] = 0.003086,
							["end_time"] = 1675298685,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 6801,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 6801,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[210042] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 37444,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 37444,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 210042,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 315,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 315,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298684,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298685,
							["tipo"] = 2,
							["totaldenied"] = 0.003086,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["received"] = 0.006715,
							["resource"] = 17.006715,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.006715,
							["total"] = 0.006715,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.006715,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298686,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.006715,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 8,
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391172] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 391172,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[347765] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 347765,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 1,
										["id"] = 391166,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203981] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 203981,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 212988,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["last_event"] = 1675298685,
							["buff_uptime_targets"] = {
							},
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["pets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 4,
							["pets"] = {
							},
							["tipo"] = 4,
							["aID"] = "580-0A6159F7",
							["last_event"] = 1675298685,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-580-0A6159F7",
							["classe"] = "EVOKER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 117,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 708,
				["totals"] = {
					13322.90604999999, -- [1]
					-0.299017, -- [2]
					{
						-0.01877300000000057, -- [1]
						[0] = -0.008925,
						["alternatepower"] = 0,
						[3] = -0.01441399999999965,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					13323, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:44:45",
				["hasTimer"] = 1.002000000036787,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Tough Carp",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:44:44",
				["end_time"] = 358271.356,
				["combat_id"] = 117,
				["tempo_start"] = 1675298684,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358270.354,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.003086,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 3927.006603,
						}, -- [1]
					},
				},
			}, -- [32]
			{
				{
					["tipo"] = 2,
					["combatId"] = 116,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001862,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 22073,
								["Not-So-Tender Morsel"] = 16605,
								["Tough Carp"] = 108408,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 2,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
								["Felhound"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 2,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3952,
										["g_amt"] = 0,
										["n_max"] = 3798,
										["targets"] = {
											["Tough Carp"] = 11426,
											["Felhound"] = 0,
										},
										["n_dmg"] = 7474,
										["n_min"] = 3676,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 11426,
										["c_max"] = 3952,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3952,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[258922] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 5128,
										["g_amt"] = 0,
										["n_max"] = 1265,
										["targets"] = {
											["Not-So-Tender Morsel"] = 3675,
											["Tough Carp"] = 7631,
										},
										["n_dmg"] = 6178,
										["n_min"] = 1190,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 11306,
										["c_max"] = 2652,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 2476,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[228478] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 20949,
										["g_amt"] = 0,
										["n_max"] = 10584,
										["targets"] = {
											["Not-So-Tender Morsel"] = 10584,
											["Rubbery Fish Head"] = 20949,
										},
										["n_dmg"] = 10584,
										["n_min"] = 10584,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 31533,
										["c_max"] = 20949,
										["id"] = 228478,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 20949,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5325,
										["targets"] = {
											["Tough Carp"] = 10377,
										},
										["n_dmg"] = 10377,
										["n_min"] = 5052,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10377,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258921] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6654,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Tough Carp"] = 6654,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6654,
										["c_max"] = 6654,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 6654,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[377079] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 4886,
										["g_amt"] = 0,
										["n_max"] = 892,
										["targets"] = {
											["Rubbery Fish Head"] = 1124,
											["Not-So-Tender Morsel"] = 2346,
											["Tough Carp"] = 4556,
										},
										["n_dmg"] = 3140,
										["n_min"] = 562,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 8026,
										["c_max"] = 3102,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 1784,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[391058] = {
										["c_amt"] = 7,
										["b_amt"] = 0,
										["c_dmg"] = 18743,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Tough Carp"] = 18743,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 18743,
										["c_max"] = 2678,
										["id"] = 391058,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 2677,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[212105] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 5740,
										["g_amt"] = 0,
										["n_max"] = 2980,
										["targets"] = {
											["Tough Carp"] = 23286,
										},
										["n_dmg"] = 17546,
										["n_min"] = 2883,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 23286,
										["c_max"] = 5740,
										["id"] = 212105,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 5740,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[350631] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 22027,
										["targets"] = {
											["Tough Carp"] = 22027,
										},
										["n_dmg"] = 22027,
										["n_min"] = 22027,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 22027,
										["c_max"] = 0,
										["id"] = 350631,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[204598] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 3708,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Tough Carp"] = 3708,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3708,
										["c_max"] = 3708,
										["id"] = 204598,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3708,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 147086.001862,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 147086.001862,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298677,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298677,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298656,
							["delay"] = 0,
							["damage_taken"] = 0.001862,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003435,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 32543,
								["Not-So-Tender Morsel"] = 42382,
								["Turnip Punching Bag"] = 14182,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 89107.00343499999,
							["damage_taken"] = 0.003435,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298677,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 21609,
										["g_amt"] = 0,
										["n_max"] = 14182,
										["targets"] = {
											["Rubbery Fish Head"] = 32543,
											["Not-So-Tender Morsel"] = 42382,
											["Turnip Punching Bag"] = 14182,
										},
										["n_dmg"] = 67498,
										["n_min"] = 9523,
										["g_dmg"] = 0,
										["counter"] = 7,
										["ChartData"] = {
											[11] = 89107,
											[14] = 89107,
											[17] = 89107,
											[8] = 89107,
										},
										["total"] = 89107,
										["c_max"] = 21609,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21609,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 89107.00343499999,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298665,
							["last_dps"] = 0,
							["start_time"] = 1675298672,
							["delay"] = 1675298665,
							["spec"] = 1467,
						}, -- [2]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.004675,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Tienti-Lordaeron"] = true,
								["Walevo"] = true,
								["Gahrol"] = true,
								["Blackcàt"] = true,
								["Dztn"] = true,
								["VazeelRike"] = true,
								["Eleanda-Lordaeron"] = true,
								["Whish"] = true,
								["Fenryr <Gahrol>"] = true,
								["Blazê"] = true,
								["Allegory"] = true,
								["Galldo"] = true,
								["Loreley-Tichondrius"] = true,
								["Grimkrit"] = true,
								["Saturas-Tichondrius"] = true,
								["Thiril"] = true,
								["Mîlex"] = true,
								["Kizlikad"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Missgankalot"] = true,
								["Risen Skulker"] = true,
								["Nêrdnuss"] = true,
								["Dædshøt"] = true,
								["Lilítt"] = true,
								["Melaskula"] = true,
								["Xaani"] = true,
								["Dqniix"] = true,
								["Geiszt"] = true,
								["Corfid"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-65310-00005B0769",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004675,
							["aID"] = "65310",
							["fight_component"] = true,
							["total"] = 0.004675,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Turnip Punching Bag",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298677,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 575069.004675,
							["start_time"] = 1675298677,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.003699,
							["damage_from"] = {
								["Scahra"] = true,
								["Tienti-Lordaeron"] = true,
								["Ferloc"] = true,
								["Hotsolmyr"] = true,
								["Eleanda-Lordaeron"] = true,
								["Eastpack"] = true,
								["Herzschinder"] = true,
								["Galldo"] = true,
								["Worselchen-Nathrezim"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Niored"] = true,
								["Melaskula"] = true,
								["Vaikir"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Geiszt"] = true,
								["Makkresh"] = true,
								["Wild Imp <Zins>"] = true,
								["Walevo"] = true,
								["Fenryr <Gahrol>"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Dztn"] = true,
								["Golgrem"] = true,
								["Dqniix"] = true,
								["Allegory"] = true,
								["Aîphaton"] = true,
								["Opór"] = true,
								["VazeelRike"] = true,
								["Aislina-Frostmourne"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Kizlikad"] = true,
								["Mîlex"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["Dædshøt"] = true,
								["Zins"] = true,
								["Missgankalot"] = true,
								["Maplebaomn"] = true,
								["Gahrol"] = true,
								["Corfid"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["TheBEES"] = true,
								["Mothman"] = true,
								["Blazê"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195817-00005B075F",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003699,
							["aID"] = "195817",
							["fight_component"] = true,
							["total"] = 0.003699,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Not-So-Tender Morsel",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298677,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2304729.003699,
							["start_time"] = 1675298677,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [4]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.002923,
							["damage_from"] = {
								["Scahra"] = true,
								["Tienti-Lordaeron"] = true,
								["Ferloc"] = true,
								["Hotsolmyr"] = true,
								["Eleanda-Lordaeron"] = true,
								["Elrondyr"] = true,
								["Blackmaria"] = true,
								["Herzschinder"] = true,
								["Galldo"] = true,
								["Worselchen-Nathrezim"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Spârky"] = true,
								["Grimkrit"] = true,
								["Aislina-Frostmourne"] = true,
								["Blutgurgel"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Misha"] = true,
								["Neakî"] = true,
								["Blazê"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Heloran-Lordaeron"] = true,
								["Vaikir"] = true,
								["Esme-Lordaeron"] = true,
								["Opór"] = true,
								["Luitger"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Makkresh"] = true,
								["Dztn"] = true,
								["Risen Skulker"] = true,
								["Whish"] = true,
								["Drakekard"] = true,
								["Fenryr"] = true,
								["Melaskula"] = true,
								["Allegory"] = true,
								["Tøxicator"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Dædshøt"] = true,
								["Thiril"] = true,
								["Lilítt"] = true,
								["Kizlikad"] = true,
								["Mîlex"] = true,
								["VazeelRike"] = true,
								["Missgankalot"] = true,
								["Maplebaomn"] = true,
								["Corfid"] = true,
								["Echse"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["TheBEES"] = true,
								["Note"] = true,
								["Golgrem"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B0764",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002923,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.002923,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298677,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2304013.002923,
							["start_time"] = 1675298677,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [5]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.002837,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Ferloc"] = true,
								["Tienti-Lordaeron"] = true,
								["Saturas-Tichondrius"] = true,
								["TheBEES"] = true,
								["Luitger"] = true,
								["Blutgurgel"] = true,
								["Neakî"] = true,
								["Eleanda-Lordaeron"] = true,
								["Melaskula"] = true,
								["Elrondyr"] = true,
								["Blackmaria"] = true,
								["Dqniix"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Spârky"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Missgankalot"] = true,
								["Blasphemy <Tienti-Lordaeron>"] = true,
								["Herzschinder"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Misha"] = true,
								["Kizlikad"] = true,
								["Blazê"] = true,
								["Ryzsard"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Frogsplash"] = true,
								["Vaikir"] = true,
								["Esme-Lordaeron"] = true,
								["Opór"] = true,
								["Beast <Luitger>"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Worselchen-Nathrezim"] = true,
								["Dztn"] = true,
								["Whish"] = true,
								["Aislina-Frostmourne"] = true,
								["Drakekard"] = true,
								["Fenryr"] = true,
								["Aîphaton"] = true,
								["VazeelRike"] = true,
								["Niored"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Galldo"] = true,
								["Thiril"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["Dædshøt"] = true,
								["Note"] = true,
								["Risen Skulker"] = true,
								["Corfid"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Echse"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Scahra"] = true,
								["Mîlex"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B0769",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002837,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.002837,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298677,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3775218.002837,
							["start_time"] = 1675298677,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [6]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 116,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 231173,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 231173.00756,
							["total_without_pet"] = 12771.00756,
							["total"] = 12771.00756,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.00756,
							["last_hps"] = 0,
							["targets"] = {
								["Scahra"] = 12771,
							},
							["totalover_without_pet"] = 0.00756,
							["healing_taken"] = 12771.00756,
							["fight_component"] = true,
							["end_time"] = 1675298677,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 30606,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 4,
										["overheal"] = 30606,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[143924] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 5831,
										},
										["n_max"] = 2315,
										["targets"] = {
											["Scahra"] = 4209,
										},
										["n_min"] = 227,
										["counter"] = 6,
										["overheal"] = 5831,
										["total"] = 4209,
										["c_max"] = 0,
										["id"] = 143924,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 4209,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 1787,
										},
										["n_max"] = 200,
										["targets"] = {
											["Scahra"] = 401,
										},
										["n_min"] = 0,
										["counter"] = 27,
										["overheal"] = 1787,
										["total"] = 401,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 27,
										["n_curado"] = 401,
										["absorbed"] = 0,
									},
									[212106] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 31186,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 7,
										["overheal"] = 31186,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 212106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 7,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 4447,
										},
										["n_max"] = 143,
										["targets"] = {
											["Scahra"] = 143,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 4447,
										["total"] = 143,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 143,
										["absorbed"] = 0,
									},
									[350631] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 149066,
										},
										["n_max"] = 5514,
										["targets"] = {
											["Scahra"] = 5514,
										},
										["n_min"] = 5514,
										["counter"] = 1,
										["overheal"] = 149066,
										["total"] = 5514,
										["c_max"] = 0,
										["id"] = 350631,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 5514,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 8250,
										},
										["n_max"] = 2504,
										["targets"] = {
											["Scahra"] = 2504,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 8250,
										["total"] = 2504,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 2504,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298656,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298677,
							["tipo"] = 2,
							["totaldenied"] = 0.00756,
							["delay"] = 0,
							["healing_from"] = {
								["Scahra"] = true,
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 116,
					["_ActorTable"] = {
						{
							["received"] = 0.00472,
							["resource"] = 142.00472,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.00472,
							["fight_component"] = true,
							["total"] = 0.00472,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.00472,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298679,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.00472,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 116,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 5,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 15,
										["id"] = 247456,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[1490] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 20,
										["id"] = 1490,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[204598] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 204598,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 18,
										["id"] = 203981,
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[187827] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 187827,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212084] = {
										["activedamt"] = 2,
										["id"] = 212084,
										["targets"] = {
										},
										["actived_at"] = 1675298676,
										["uptime"] = 0,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 19,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391430] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 21,
										["id"] = 391430,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 14,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 10,
										["id"] = 212988,
										["refreshamt"] = 3,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 6,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 391166,
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 37,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[328957] = 1,
								[204255] = 7,
								[225919] = 2,
								[225921] = 2,
								[228477] = 1,
								[212084] = 1,
								[263642] = 2,
								[204513] = 1,
								[258920] = 1,
								[203720] = 2,
							},
							["buff_uptime"] = 155,
							["last_event"] = 1675298677,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 91,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 359618,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[357211] = 4,
								[362969] = 1,
								[358733] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675298677,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
						{
							["fight_component"] = true,
							["classe"] = "UNKNOW",
							["nome"] = "Turnip Punching Bag",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["flag_original"] = 2600,
							["last_event"] = 0,
							["aID"] = "65310",
							["tipo"] = 4,
							["serial"] = "Creature-0-3102-2444-1588-65310-00005B0769",
							["spell_cast"] = {
								[127801] = 1,
							},
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 116,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 358244.475,
				["tempo_start"] = 1675298656,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Spârky"] = {
						["total"] = 0,
						["last"] = 0,
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					236192.6124250007, -- [1]
					12770.64943500002, -- [2]
					{
						-0.04816699999997098, -- [1]
						[0] = -0.07990799999999999,
						["alternatepower"] = 0,
						[3] = -0.01881299999996831,
						[6] = -0.01781900000000292,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					236193, -- [1]
					12771, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:44:38",
				["hasTimer"] = 20.13799999997718,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["TotalElapsedCombatTime"] = 7.48599999997532,
				["CombatEndedAt"] = 358251.961,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 12771.00756,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 147086.001862,
							["Allegory"] = 89107.00343499999,
						}, -- [1]
					},
				},
				["end_time"] = 358263.553,
				["combat_id"] = 116,
				["data_inicio"] = "01:44:17",
				["frags"] = {
					["Ur'zul"] = 1,
					["Felhound"] = 1,
					["Bittershell Hermit"] = 38,
					["Shivarra"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 707,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358242.535,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [33]
			{
				{
					["tipo"] = 2,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006547,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 53194,
								["Not-So-Tender Morsel"] = 37940,
								["Tough Carp"] = 20570,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 111704.006547,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 111704.006547,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298653,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5073,
										["targets"] = {
											["Not-So-Tender Morsel"] = 6884,
											["Rubbery Fish Head"] = 5073,
										},
										["n_dmg"] = 11957,
										["n_min"] = 2172,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 11957,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[204598] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5603,
										["targets"] = {
											["Tough Carp"] = 2737,
											["Rubbery Fish Head"] = 8436,
										},
										["n_dmg"] = 11173,
										["n_min"] = 2737,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 11173,
										["c_max"] = 0,
										["id"] = 204598,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258921] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5297,
										["targets"] = {
											["Rubbery Fish Head"] = 5297,
											["Tough Carp"] = 5260,
										},
										["n_dmg"] = 10557,
										["n_min"] = 5260,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10557,
										["c_max"] = 0,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258922] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1990,
										["targets"] = {
											["Rubbery Fish Head"] = 3955,
										},
										["n_dmg"] = 3955,
										["n_min"] = 1965,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3955,
										["c_max"] = 0,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[228478] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18012,
										["targets"] = {
											["Rubbery Fish Head"] = 18012,
										},
										["n_dmg"] = 18012,
										["n_min"] = 18012,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 18012,
										["c_max"] = 0,
										["id"] = 228478,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12263,
										["g_amt"] = 0,
										["n_max"] = 6066,
										["targets"] = {
											["Not-So-Tender Morsel"] = 18329,
										},
										["n_dmg"] = 6066,
										["n_min"] = 6066,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 18329,
										["c_max"] = 12263,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 12263,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[247455] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12727,
										["targets"] = {
											["Rubbery Fish Head"] = 12421,
											["Not-So-Tender Morsel"] = 12727,
											["Tough Carp"] = 12573,
										},
										["n_dmg"] = 37721,
										["n_min"] = 12421,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 37721,
										["c_max"] = 0,
										["id"] = 247455,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298652,
							["on_hold"] = false,
							["start_time"] = 1675298646,
							["delay"] = 0,
							["damage_taken"] = 0.006547,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004486,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Not-So-Tender Morsel"] = 15566,
								["Rubbery Fish Head"] = 8064,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 23630.004486,
							["damage_taken"] = 0.004486,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298653,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 15566,
										["g_amt"] = 0,
										["n_max"] = 8064,
										["targets"] = {
											["Not-So-Tender Morsel"] = 15566,
											["Rubbery Fish Head"] = 8064,
										},
										["n_dmg"] = 8064,
										["n_min"] = 8064,
										["g_dmg"] = 0,
										["counter"] = 2,
										["ChartData"] = {
											[5] = 23630,
										},
										["total"] = 23630,
										["c_max"] = 15566,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 15566,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 23630.004486,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298647,
							["last_dps"] = 0,
							["start_time"] = 1675298647,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006514,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Fadruidsko"] = true,
								["Tienti-Lordaeron"] = true,
								["Walevo"] = true,
								["Worselchen-Nathrezim"] = true,
								["Ferloc"] = true,
								["Blazê"] = true,
								["Galldo"] = true,
								["Eleanda-Lordaeron"] = true,
								["Drakekard"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Allegory"] = true,
								["Golgrem"] = true,
								["Loreley-Tichondrius"] = true,
								["Rydrasil"] = true,
								["Makkresh"] = true,
								["Grimkrit"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["Fenryr <Gahrol>"] = true,
								["Missgankalot"] = true,
								["Sinfluterrin"] = true,
								["Scahra"] = true,
								["Niored"] = true,
								["Gahrol"] = true,
								["Melaskula"] = true,
								["Xaani"] = true,
								["Aislina-Frostmourne"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195817-00005B0756",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006514,
							["aID"] = "195817",
							["fight_component"] = true,
							["total"] = 0.006514,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Not-So-Tender Morsel",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298653,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 597638.006514,
							["start_time"] = 1675298653,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.004925,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Fadruidsko"] = true,
								["Tienti-Lordaeron"] = true,
								["Ferloc"] = true,
								["Eleanda-Lordaeron"] = true,
								["Dqniix"] = true,
								["Galldo"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Zrouge"] = true,
								["Sinfluterrin"] = true,
								["Pleekz"] = true,
								["Niored"] = true,
								["Melaskula"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Grimkrit"] = true,
								["Note"] = true,
								["Walevo"] = true,
								["Dztn"] = true,
								["Drakekard"] = true,
								["Herzschinder"] = true,
								["Aislina-Frostmourne"] = true,
								["Allegory"] = true,
								["Lilítt"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Fenryr <Gahrol>"] = true,
								["Neakî"] = true,
								["Mîlex"] = true,
								["Tøxicator"] = true,
								["Blackcàt"] = true,
								["Golgrem"] = true,
								["Missgankalot"] = true,
								["Whish"] = true,
								["Gahrol"] = true,
								["Dædshøt"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["TheBEES"] = true,
								["Scahra"] = true,
								["Blazê"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B0756",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004925,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.004925,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298653,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1390873.004925,
							["start_time"] = 1675298653,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [4]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.002574,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Fadruidsko"] = true,
								["Tienti-Lordaeron"] = true,
								["Ferloc"] = true,
								["Eleanda-Lordaeron"] = true,
								["Dqniix"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Sinfluterrin"] = true,
								["Niored"] = true,
								["Blazê"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Corfid"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Walevo"] = true,
								["Whish"] = true,
								["Melaskula"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Gahrol"] = true,
								["Mîlex"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["Fenryr <Gahrol>"] = true,
								["Galldo"] = true,
								["Missgankalot"] = true,
								["Blackcàt"] = true,
								["Scahra"] = true,
								["Drakekard"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["TheBEES"] = true,
								["Mothman"] = true,
								["Dædshøt"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B0756",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002574,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.002574,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298653,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1034808.002574,
							["start_time"] = 1675298653,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 70485,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 70485.001528,
							["total_without_pet"] = 0.001528,
							["total"] = 0.001528,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.001528,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.001528,
							["healing_taken"] = 0.001528,
							["end_time"] = 1675298653,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 34008,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 34008,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 1,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 21746,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 21746,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 1900,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 10,
										["overheal"] = 1900,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 10,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 12831,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 4,
										["overheal"] = 12831,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298648,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298653,
							["tipo"] = 2,
							["totaldenied"] = 0.001528,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["received"] = 0.008553,
							["resource"] = 50.008553,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.008553,
							["total"] = 0.008553,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.008553,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298656,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.008553,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 4,
										["id"] = 247456,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
									[204598] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 3,
										["id"] = 204598,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 4,
										["id"] = 203981,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391430] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 391430,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 391171,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[347765] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 347765,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391172] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 391172,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 212988,
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 7,
										["id"] = 391166,
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 7,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 5,
								[225921] = 1,
								[247454] = 1,
								[228477] = 1,
								[204513] = 1,
								[258920] = 1,
							},
							["buff_uptime"] = 59,
							["last_event"] = 1675298653,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 35,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 7,
										["id"] = 359618,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[362969] = 1,
								[357211] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675298653,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 115,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					135333.7232250003, -- [1]
					-0.3504290000007482, -- [2]
					{
						-0.03849599999999984, -- [1]
						[0] = -0.034878,
						["alternatepower"] = 0,
						[3] = -0.00976699999998785,
						[6] = -0.01785899999999785,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					135334, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:44:14",
				["hasTimer"] = 6.044999999983702,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["TotalElapsedCombatTime"] = 358239.346,
				["CombatEndedAt"] = 358239.346,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:44:07",
				["end_time"] = 358239.837,
				["combat_id"] = 115,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.001528,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 111704.006547,
							["Allegory"] = 23630.004486,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1675298646,
				["combat_counter"] = 706,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358232.83,
				["TimeData"] = {
				},
				["frags"] = {
					["Bittershell Hermit"] = 20,
				},
			}, -- [34]
			{
				{
					["tipo"] = 2,
					["combatId"] = 114,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007505,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Not-So-Tender Morsel"] = 28487,
								["Tough Carp"] = 9191,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 37678.007505,
							["damage_taken"] = 0.007505,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298646,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 21708,
										["g_amt"] = 0,
										["n_max"] = 9191,
										["targets"] = {
											["Not-So-Tender Morsel"] = 28487,
											["Tough Carp"] = 9191,
										},
										["n_dmg"] = 15970,
										["n_min"] = 6779,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 37678,
										["c_max"] = 21708,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21708,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 37678.007505,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298646,
							["last_dps"] = 0,
							["start_time"] = 1675298641,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004938,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Not-So-Tender Morsel"] = 13583,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 13583.004938,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 13583.004938,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298646,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 13583,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Not-So-Tender Morsel"] = 13583,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 13583,
										["c_max"] = 8878,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 4705,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298646,
							["on_hold"] = false,
							["start_time"] = 1675298642,
							["delay"] = 0,
							["damage_taken"] = 0.004938,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.003835,
							["damage_from"] = {
								["Scahra"] = true,
								["Luitger"] = true,
								["Eleanda-Lordaeron"] = true,
								["Herzschinder"] = true,
								["Galldo"] = true,
								["Aislina-Frostmourne"] = true,
								["Rydrasil"] = true,
								["Sinfluterrin"] = true,
								["Misha"] = true,
								["Blazê"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Walevo"] = true,
								["Dztn"] = true,
								["Gahrol"] = true,
								["Allegory"] = true,
								["Maplebaomn"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Blutgurgel"] = true,
								["Dædshøt"] = true,
								["Bârzi"] = true,
								["Xaani"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Missgankalot"] = true,
								["Tøxicator"] = true,
								["Blackcàt"] = true,
								["Golgrem"] = true,
								["Neakî"] = true,
								["Fenryr <Gahrol>"] = true,
								["TheBEES"] = true,
								["Lilítt"] = true,
								["Melaskula"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195817-00005B0750",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003835,
							["aID"] = "195817",
							["fight_component"] = true,
							["total"] = 0.003835,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Not-So-Tender Morsel",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298643,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 633826.003835,
							["start_time"] = 1675298643,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 114,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 114,
					["_ActorTable"] = {
						{
							["received"] = 0.002397,
							["resource"] = 30.002397,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.002397,
							["total"] = 0.002397,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.002397,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298646,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.002397,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 114,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 16,
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 203981,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391430] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 391430,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 1,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 212988,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[347765] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 347765,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 391166,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[203720] = 1,
							},
							["nome"] = "Scahra",
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["pets"] = {
							},
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["last_event"] = 1675298643,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 8,
							["pets"] = {
							},
							["tipo"] = 4,
							["aID"] = "580-0A6159F7",
							["last_event"] = 1675298643,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-580-0A6159F7",
							["classe"] = "EVOKER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 114,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 358232.081,
				["tempo_start"] = 1675298641,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					51260.82025799993, -- [1]
					-0.2816519999992808, -- [2]
					{
						-0.0403190000000011, -- [1]
						[0] = -0.013492,
						["alternatepower"] = 0,
						[3] = -0.02039700000000266,
						[6] = -0.007513000000000325,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					51261, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:44:04",
				["hasTimer"] = 1.010999999998603,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Not-So-Tender Morsel",
				["TotalElapsedCombatTime"] = 358229.08,
				["CombatEndedAt"] = 358229.08,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 4705.004938,
							["Allegory"] = 6779.007505,
						}, -- [1]
					},
				},
				["end_time"] = 358229.853,
				["combat_id"] = 114,
				["data_inicio"] = "01:44:02",
				["frags"] = {
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 705,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358227.847,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [35]
			{
				{
					["tipo"] = 2,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002546,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 23233,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 23233.002546,
							["damage_taken"] = 0.002546,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298641,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7398,
										["targets"] = {
											["Rubbery Fish Head"] = 14030,
										},
										["n_dmg"] = 14030,
										["n_min"] = 6632,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 14030,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9203,
										["targets"] = {
											["Rubbery Fish Head"] = 9203,
										},
										["n_dmg"] = 9203,
										["n_min"] = 9203,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9203,
										["c_max"] = 0,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 23233.002546,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298640,
							["last_dps"] = 0,
							["start_time"] = 1675298637,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004552,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Not-So-Tender Morsel"] = 9022,
								["Rubbery Fish Head"] = 11135,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 9022,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Not-So-Tender Morsel"] = 9022,
											["Rubbery Fish Head"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 9022,
										["c_max"] = 9022,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 9022,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5199,
										["targets"] = {
											["Rubbery Fish Head"] = 5199,
										},
										["n_dmg"] = 5199,
										["n_min"] = 5199,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5199,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[247455] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4385,
										["targets"] = {
											["Rubbery Fish Head"] = 4385,
										},
										["n_dmg"] = 4385,
										["n_min"] = 4385,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 4385,
										["c_max"] = 0,
										["id"] = 247455,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[377079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1551,
										["targets"] = {
											["Rubbery Fish Head"] = 1551,
										},
										["n_dmg"] = 1551,
										["n_min"] = 1551,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1551,
										["c_max"] = 0,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20157.004552,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 20157.004552,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298641,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298641,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298636,
							["delay"] = 0,
							["damage_taken"] = 0.004552,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.008593,
							["damage_from"] = {
								["Scahra"] = true,
								["Tienti-Lordaeron"] = true,
								["Luitger"] = true,
								["Elrondyr"] = true,
								["Herzschinder"] = true,
								["Golgrem"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Nêrdnuss"] = true,
								["Misha"] = true,
								["Blazê"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Grimkrit"] = true,
								["Esme-Lordaeron"] = true,
								["Beast <Luitger>"] = true,
								["Walevo"] = true,
								["Dztn"] = true,
								["Dqniix"] = true,
								["Niored"] = true,
								["Heloran-Lordaeron"] = true,
								["Fenryr <Gahrol>"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Allegory"] = true,
								["Lilítt"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Aislina-Frostmourne"] = true,
								["Dædshøt"] = true,
								["Bârzi"] = true,
								["Gahrol"] = true,
								["Risen Skulker"] = true,
								["Missgankalot"] = true,
								["Blutgurgel"] = true,
								["Tøxicator"] = true,
								["Melaskula"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["Maplebaomn"] = true,
								["Galldo"] = true,
								["Blackcàt"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B074B",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008593,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.008593,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298641,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1242065.008593,
							["start_time"] = 1675298641,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 67835,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 67835.00720600001,
							["total_without_pet"] = 0.007206,
							["total"] = 0.007206,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.007206,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.007206,
							["healing_taken"] = 0.007206,
							["end_time"] = 1675298641,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 13604,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 13604,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 15974,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 15974,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 475,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 475,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 131,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 131,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[210042] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 37651,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 37651,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 210042,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298638,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298640,
							["tipo"] = 2,
							["totaldenied"] = 0.007206,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 113,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 247456,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 5,
										["id"] = 203981,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391430] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 391430,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[347765] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 347765,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 212988,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 391166,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 3,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 3,
								[247454] = 1,
								[228477] = 1,
							},
							["buff_uptime"] = 39,
							["last_event"] = 1675298641,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 26,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 375342,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[362969] = 2,
								[357211] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1675298641,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 113,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 358227.847,
				["tempo_start"] = 1675298636,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					43389.7735299999, -- [1]
					-0.3206070000033254, -- [2]
					{
						-0.03824900000000294, -- [1]
						[0] = -0.0177,
						["alternatepower"] = 0,
						[3] = -0.01712900000001127,
						[6] = -0.004628000000002075,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					43390, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:44:01",
				["hasTimer"] = 3.018999999971129,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["TotalElapsedCombatTime"] = 3.641999999992549,
				["CombatEndedAt"] = 358226.579,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.007206,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 11135.004552,
							["Allegory"] = 23233.002546,
						}, -- [1]
					},
				},
				["end_time"] = 358226.937,
				["combat_id"] = 113,
				["data_inicio"] = "01:43:57",
				["frags"] = {
					["Bittershell Hermit"] = 7,
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 704,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358222.937,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [36]
			{
				{
					["tipo"] = 2,
					["combatId"] = 112,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004077,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Tough Carp"] = 64085,
								["Rubbery Fish Head"] = 76860,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 140945.004077,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 1,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
								["Felhound"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 1,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 140945.004077,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298636,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 7908,
										["g_amt"] = 0,
										["n_max"] = 3689,
										["targets"] = {
											["Tough Carp"] = 9998,
											["Rubbery Fish Head"] = 5645,
										},
										["n_dmg"] = 7735,
										["n_min"] = 1956,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 15643,
										["c_max"] = 7908,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 7908,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 892,
										["targets"] = {
											["Tough Carp"] = 892,
										},
										["n_dmg"] = 892,
										["n_min"] = 892,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 892,
										["c_max"] = 0,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[212105] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 8631,
										["g_amt"] = 0,
										["n_max"] = 2892,
										["targets"] = {
											["Tough Carp"] = 3080,
											["Rubbery Fish Head"] = 36582,
										},
										["n_dmg"] = 31031,
										["n_min"] = 2782,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 39662,
										["c_max"] = 5551,
										["id"] = 212105,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3080,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5118,
										["targets"] = {
											["Rubbery Fish Head"] = 5118,
										},
										["n_dmg"] = 5118,
										["n_min"] = 5118,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5118,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[247455] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5644,
										["targets"] = {
											["Tough Carp"] = 5644,
										},
										["n_dmg"] = 5644,
										["n_min"] = 5644,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5644,
										["c_max"] = 0,
										["id"] = 247455,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258922] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 2693,
										["g_amt"] = 0,
										["n_max"] = 1411,
										["targets"] = {
											["Felhound"] = 0,
											["Rubbery Fish Head"] = 3772,
											["Tough Carp"] = 7919,
										},
										["n_dmg"] = 8998,
										["n_min"] = 1232,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 11691,
										["c_max"] = 2693,
										["id"] = 258922,
										["r_dmg"] = 0,
										["EVADE"] = 1,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 2693,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 7,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[228478] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 14525,
										["targets"] = {
											["Tough Carp"] = 14525,
										},
										["n_dmg"] = 14525,
										["n_min"] = 14525,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 14525,
										["c_max"] = 0,
										["id"] = 228478,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[350631] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 22027,
										["targets"] = {
											["Tough Carp"] = 22027,
										},
										["n_dmg"] = 22027,
										["n_min"] = 22027,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 22027,
										["c_max"] = 0,
										["id"] = 350631,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[391058] = {
										["c_amt"] = 10,
										["b_amt"] = 0,
										["c_dmg"] = 25743,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Rubbery Fish Head"] = 25743,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 25743,
										["c_max"] = 2575,
										["id"] = 391058,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 2574,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298636,
							["on_hold"] = false,
							["start_time"] = 1675298627,
							["delay"] = 0,
							["damage_taken"] = 0.004077,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007642,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Tough Carp"] = 10217,
								["Rubbery Fish Head"] = 31158,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 41375.007642,
							["damage_taken"] = 0.007642,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298635,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[357212] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 21780,
										["g_amt"] = 0,
										["n_max"] = 10217,
										["targets"] = {
											["Tough Carp"] = 10217,
											["Rubbery Fish Head"] = 31158,
										},
										["n_dmg"] = 19595,
										["n_min"] = 9378,
										["g_dmg"] = 0,
										["counter"] = 3,
										["ChartData"] = {
											[5] = 41375,
										},
										["total"] = 41375,
										["c_max"] = 21780,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 21780,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 41375.007642,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298633,
							["last_dps"] = 0,
							["start_time"] = 1675298629,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.00401,
							["damage_from"] = {
								["Gahrol"] = true,
								["Tienti-Lordaeron"] = true,
								["Eleanda-Lordaeron"] = true,
								["Elrondyr"] = true,
								["Dqniix"] = true,
								["Galldo"] = true,
								["Aislina-Frostmourne"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Sinfluterrin"] = true,
								["Nêrdnuss"] = true,
								["Niored"] = true,
								["Blazê"] = true,
								["Ryzsard"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Grimkrit"] = true,
								["Esme-Lordaeron"] = true,
								["Walevo"] = true,
								["Dztn"] = true,
								["Allegory"] = true,
								["Blackcàt"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Tøxicator"] = true,
								["Lilítt"] = true,
								["Bârzi"] = true,
								["Herzschinder"] = true,
								["Fenryr <Gahrol>"] = true,
								["Missgankalot"] = true,
								["Scahra"] = true,
								["Note"] = true,
								["Maplebaomn"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["Golgrem"] = true,
								["Dædshøt"] = true,
								["Melaskula"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B0741",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00401,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.00401,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298635,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1387774.00401,
							["start_time"] = 1675298635,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.002132,
							["damage_from"] = {
								["Scahra"] = true,
								["Esme-Lordaeron"] = true,
								["Luitger"] = true,
								["Beast <Luitger>"] = true,
								["Walevo"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Ferloc"] = true,
								["Dztn"] = true,
								["Herzschinder"] = true,
								["Blutgurgel"] = true,
								["Neakî"] = true,
								["Elrondyr"] = true,
								["Dqniix"] = true,
								["Allegory"] = true,
								["Galldo"] = true,
								["Loreley-Tichondrius"] = true,
								["Toute"] = true,
								["Misha"] = true,
								["Bârzi"] = true,
								["Dædshøt"] = true,
								["Tøxicator"] = true,
								["Lilítt"] = true,
								["Aislina-Frostmourne"] = true,
								["Missgankalot"] = true,
								["Nêrdnuss"] = true,
								["Niored"] = true,
								["Golgrem"] = true,
								["Blazê"] = true,
								["Xaani"] = true,
								["TheBEES"] = true,
								["Corfid"] = true,
								["Maplebaomn"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B0746",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002132,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.002132,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298635,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 768071.0021319999,
							["start_time"] = 1675298635,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 112,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 344402,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 344402.004305,
							["total_without_pet"] = 4814.004305,
							["total"] = 4814.004305,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.004305,
							["last_hps"] = 0,
							["targets"] = {
								["Scahra"] = 4814,
							},
							["totalover_without_pet"] = 0.004305,
							["healing_taken"] = 4814.004305,
							["fight_component"] = true,
							["end_time"] = 1675298635,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 28764,
										},
										["n_max"] = 1845,
										["targets"] = {
											["Scahra"] = 1845,
										},
										["n_min"] = 0,
										["counter"] = 3,
										["overheal"] = 28764,
										["total"] = 1845,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 1845,
										["absorbed"] = 0,
									},
									[143924] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 875,
										["targets"] = {
											["Scahra"] = 875,
										},
										["n_min"] = 875,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 875,
										["c_max"] = 0,
										["id"] = 143924,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 875,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 4810,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 61,
										["overheal"] = 4810,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 61,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[212106] = {
										["c_amt"] = 2,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 63518,
										},
										["n_max"] = 2094,
										["targets"] = {
											["Scahra"] = 2094,
										},
										["n_min"] = 0,
										["counter"] = 13,
										["overheal"] = 63518,
										["total"] = 2094,
										["c_max"] = 0,
										["id"] = 212106,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 11,
										["n_curado"] = 2094,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 10002,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 10002,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[350631] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 231871,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 231871,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 350631,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 5437,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 5437,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298628,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298635,
							["tipo"] = 2,
							["totaldenied"] = 0.004305,
							["delay"] = 0,
							["healing_from"] = {
								["Scahra"] = true,
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 112,
					["_ActorTable"] = {
						{
							["received"] = 0.003726,
							["resource"] = 157.003726,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.003726,
							["fight_component"] = true,
							["total"] = 0.003726,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.003726,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298636,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.003726,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 112,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 247456,
										["refreshamt"] = 3,
										["actived"] = false,
										["counter"] = 0,
									},
									[394958] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 394958,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[1490] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 1490,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 1,
										["id"] = 203981,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212084] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 2,
										["id"] = 212084,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391430] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 391430,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[187827] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 187827,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 6,
										["id"] = 212988,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 7,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 391166,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 11,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[328957] = 1,
								[204255] = 3,
								[225919] = 1,
								[225921] = 1,
								[228477] = 1,
								[212084] = 1,
								[263642] = 1,
								[203720] = 1,
								[247454] = 1,
							},
							["buff_uptime"] = 64,
							["last_event"] = 1675298635,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 375342,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[387678] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 387678,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386907] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 386907,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[357211] = 3,
							},
							["buff_uptime"] = 48,
							["last_event"] = 1675298635,
							["classe"] = "EVOKER",
							["nome"] = "Allegory",
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 112,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 358218.372,
				["tempo_start"] = 1675298627,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					182319.7463360002, -- [1]
					4813.711472999999, -- [2]
					{
						-0.02563400000000576, -- [1]
						[0] = -0.027587,
						["alternatepower"] = 0,
						[3] = -0.02731399999999937,
						[6] = -0.01240799999999354,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					182320, -- [1]
					4814, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:43:56",
				["hasTimer"] = 7.040999999968335,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Tough Carp",
				["TotalElapsedCombatTime"] = 2.48399999999674,
				["CombatEndedAt"] = 358220.856,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 4814.004305,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 135827.004077,
							["Allegory"] = 41375.007642,
						}, -- [1]
					},
				},
				["end_time"] = 358221.601,
				["combat_id"] = 112,
				["data_inicio"] = "01:43:48",
				["frags"] = {
					["Bittershell Hermit"] = 17,
					["Felhound"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 703,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358213.579,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [37]
			{
				{
					["tipo"] = 2,
					["combatId"] = 111,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005676,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Not-So-Tender Morsel"] = 53915,
								["Rubbery Fish Head"] = 6577,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 60492.005676,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 60492.005676,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298627,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 7563,
										["g_amt"] = 0,
										["n_max"] = 4236,
										["targets"] = {
											["Not-So-Tender Morsel"] = 11799,
										},
										["n_dmg"] = 4236,
										["n_min"] = 4236,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 11799,
										["c_max"] = 7563,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 7563,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1552,
										["targets"] = {
											["Not-So-Tender Morsel"] = 1552,
										},
										["n_dmg"] = 1552,
										["n_min"] = 1552,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1552,
										["c_max"] = 0,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[228478] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 28929,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Not-So-Tender Morsel"] = 28929,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 28929,
										["c_max"] = 28929,
										["id"] = 228478,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 28929,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258922] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1235,
										["targets"] = {
											["Not-So-Tender Morsel"] = 1235,
										},
										["n_dmg"] = 1235,
										["n_min"] = 1235,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1235,
										["c_max"] = 0,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[225919] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5209,
										["targets"] = {
											["Not-So-Tender Morsel"] = 10400,
										},
										["n_dmg"] = 10400,
										["n_min"] = 5191,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10400,
										["c_max"] = 0,
										["id"] = 225919,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258921] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6577,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Rubbery Fish Head"] = 6577,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 6577,
										["c_max"] = 6577,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 6577,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298627,
							["on_hold"] = false,
							["start_time"] = 1675298621,
							["delay"] = 0,
							["damage_taken"] = 0.005676,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.008581,
							["damage_from"] = {
								["Scahra"] = true,
								["Esme-Lordaeron"] = true,
								["Tienti-Lordaeron"] = true,
								["Walevo"] = true,
								["Dztn"] = true,
								["Gahrol"] = true,
								["Mothman"] = true,
								["Blazê"] = true,
								["Fenryr <Gahrol>"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Dqniix"] = true,
								["Galldo"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Toute"] = true,
								["Saturas-Tichondrius"] = true,
								["Rydrasil"] = true,
								["Grimkrit"] = true,
								["Tøxicator"] = true,
								["Sinfluterrin"] = true,
								["Corfid"] = true,
								["Missgankalot"] = true,
								["Maplebaomn"] = true,
								["Golgrem"] = true,
								["Synthica"] = true,
								["Neakî"] = true,
								["Xaani"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Frogsplash"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195817-00005B073C",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008581,
							["aID"] = "195817",
							["fight_component"] = true,
							["total"] = 0.008581,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Not-So-Tender Morsel",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298626,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1166758.008581,
							["start_time"] = 1675298626,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 111,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 33267,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 33267.00743,
							["total_without_pet"] = 0.00743,
							["total"] = 0.00743,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.00743,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.00743,
							["healing_taken"] = 0.00743,
							["end_time"] = 1675298626,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 13604,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 13604,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 16385,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 16385,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 37,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 37,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 3241,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 3241,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298621,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298624,
							["tipo"] = 2,
							["totaldenied"] = 0.00743,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 111,
					["_ActorTable"] = {
						{
							["received"] = 0.001774,
							["resource"] = 47.001774,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.001774,
							["total"] = 0.001774,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.001774,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298627,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.001774,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 111,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 247456,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 212988,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203981] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 0,
										["id"] = 203981,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 391166,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 3,
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 2,
								[225921] = 1,
								[228477] = 1,
								[263642] = 1,
								[225919] = 1,
							},
							["buff_uptime"] = 14,
							["last_event"] = 1675298626,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386907] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386907,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[386907] = 1,
							},
							["buff_uptime"] = 27,
							["last_event"] = 1675298626,
							["classe"] = "EVOKER",
							["nome"] = "Allegory",
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 111,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 702,
				["totals"] = {
					60491.81252899978, -- [1]
					-0.2637449999999999, -- [2]
					{
						-0.04139900000000768, -- [1]
						[0] = -0.026851,
						["alternatepower"] = 0,
						[3] = -0.01882100000000073,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					60492, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:43:46",
				["hasTimer"] = 3.017000000050757,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Not-So-Tender Morsel",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:43:42",
				["end_time"] = 358211.943,
				["combat_id"] = 111,
				["tempo_start"] = 1675298621,
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["frags"] = {
					["Bittershell Hermit"] = 11,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358207.931,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.00743,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 53915.005676,
						}, -- [1]
					},
				},
			}, -- [38]
			{
				{
					["tipo"] = 2,
					["combatId"] = 110,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002588,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 13540,
								["Tough Carp"] = 7159,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20699.002588,
							["damage_taken"] = 0.002588,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298612,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7159,
										["targets"] = {
											["Rubbery Fish Head"] = 13540,
											["Tough Carp"] = 7159,
										},
										["n_dmg"] = 20699,
										["n_min"] = 6561,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 20699,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 20699.002588,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298611,
							["last_dps"] = 0,
							["start_time"] = 1675298609,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002655,
							["aID"] = "580-08C239B5",
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Not-So-Tender Morsel"] = 1222,
							},
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									[258922] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1222,
										["targets"] = {
											["Not-So-Tender Morsel"] = 1222,
										},
										["n_dmg"] = 1222,
										["n_min"] = 1222,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1222,
										["c_max"] = 0,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1222.002655,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 1222.002655,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298621,
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["isTank"] = true,
							["last_event"] = 1675298621,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1675298621,
							["delay"] = 0,
							["damage_taken"] = 0.002655,
						}, -- [2]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.0086,
							["damage_from"] = {
								["Grimkrit"] = true,
								["Esme-Lordaeron"] = true,
								["Maplebaomn"] = true,
								["Tienti-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Drakekard"] = true,
								["Ixaru"] = true,
								["Dztn"] = true,
								["VazeelRike"] = true,
								["Eleanda-Lordaeron"] = true,
								["Cat"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Iliilii"] = true,
								["Allegory"] = true,
								["Galldo"] = true,
								["Loreley-Tichondrius"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Corfid"] = true,
								["Dædshøt"] = true,
								["Tøxicator"] = true,
								["Lilítt"] = true,
								["Missgankalot"] = true,
								["Sinfluterrin"] = true,
								["Crab"] = true,
								["Niored"] = true,
								["Dqniix"] = true,
								["Blazê"] = true,
								["Fenryr <Gahrol>"] = true,
								["Dreadstalker <Aîphaton>"] = true,
								["Geiszt"] = true,
								["Gahrol"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B072D",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.0086,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.0086,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298612,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 618207.0086000001,
							["start_time"] = 1675298612,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006264,
							["damage_from"] = {
								["Grimkrit"] = true,
								["Esme-Lordaeron"] = true,
								["Walevo"] = true,
								["Cat"] = true,
								["Iliilii"] = true,
								["Allegory"] = true,
								["Galldo"] = true,
								["Loreley-Tichondrius"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Corfid"] = true,
								["Dædshøt"] = true,
								["Lilítt"] = true,
								["Sinfluterrin"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Missgankalot"] = true,
								["Crab"] = true,
								["Niored"] = true,
								["VazeelRike"] = true,
								["Blazê"] = true,
								["Dqniix"] = true,
								["Blackcàt"] = true,
								["Geiszt"] = true,
								["Drakekard"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B072D",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006264,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.006264,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298612,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 410212.006264,
							["start_time"] = 1675298612,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 110,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 110,
					["_ActorTable"] = {
						{
							["received"] = 0.008845,
							["resource"] = 54.008845,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.008845,
							["total"] = 0.008845,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.008845,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298621,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.008845,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 110,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 15,
							["aID"] = "580-08C239B5",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383756] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 383756,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 391166,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Scahra",
							["spec"] = 581,
							["grupo"] = true,
							["tipo"] = 4,
							["classe"] = "DEMONHUNTER",
							["last_event"] = 1675298612,
							["buff_uptime_targets"] = {
							},
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["pets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[359618] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 359618,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[362969] = 1,
								[357211] = 1,
							},
							["buff_uptime"] = 16,
							["last_event"] = 1675298612,
							["classe"] = "EVOKER",
							["nome"] = "Allegory",
							["serial"] = "Player-580-0A6159F7",
							["tipo"] = 4,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 110,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					21920.826334, -- [1]
					-0.154024, -- [2]
					{
						-0.03773700000001305, -- [1]
						[0] = -0.019238,
						["alternatepower"] = 0,
						[3] = -0.01424700000000198,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					21921, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:43:33",
				["hasTimer"] = 2.016999999992549,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["TotalElapsedCombatTime"] = 358198.667,
				["CombatEndedAt"] = 358198.667,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "01:43:30",
				["end_time"] = 358198.723,
				["combat_id"] = 110,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["Allegory"] = 20699.002588,
						}, -- [1]
					},
				},
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1675298609,
				["combat_counter"] = 701,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358195.713,
				["TimeData"] = {
				},
				["frags"] = {
					["Bittershell Hermit"] = 3,
				},
			}, -- [39]
			{
				{
					["tipo"] = 2,
					["combatId"] = 109,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001866,
							["friendlyfire_total"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 153273,
								["Not-So-Tender Morsel"] = 7595,
								["Tough Carp"] = 13055,
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["damage_from"] = {
							},
							["last_dps"] = 0,
							["aID"] = "580-08C239B5",
							["raid_targets"] = {
							},
							["total_without_pet"] = 173923.001866,
							["avoidance"] = {
								["overall"] = {
									["DODGE"] = 0,
									["FULL_ABSORB_AMT"] = 0,
									["BLOCKED_AMT"] = 0,
									["BLOCKED_HITS"] = 0,
									["FULL_ABSORBED"] = 0,
									["ALL"] = 0,
									["PARTIAL_ABSORBED"] = 0,
									["PARRY"] = 0,
									["PARTIAL_ABSORB_AMT"] = 0,
									["ABSORB"] = 0,
									["ABSORB_AMT"] = 0,
									["FULL_HIT"] = 0,
									["HITS"] = 0,
									["FULL_HIT_AMT"] = 0,
								},
							},
							["classe"] = "DEMONHUNTER",
							["dps_started"] = false,
							["total"] = 173923.001866,
							["serial"] = "Player-580-08C239B5",
							["end_time"] = 1675298596,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 13028,
										["g_amt"] = 0,
										["n_max"] = 4051,
										["targets"] = {
											["Rubbery Fish Head"] = 29945,
										},
										["n_dmg"] = 16917,
										["n_min"] = 2205,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 29945,
										["c_max"] = 9190,
										["id"] = 1,
										["r_dmg"] = 0,
										["MISS"] = 1,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 3838,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									}, -- [1]
									[377079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1551,
										["targets"] = {
											["Tough Carp"] = 1784,
											["Rubbery Fish Head"] = 3335,
										},
										["n_dmg"] = 5119,
										["n_min"] = 892,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 5119,
										["c_max"] = 0,
										["id"] = 377079,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[228478] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16385,
										["targets"] = {
											["Tough Carp"] = 11271,
											["Rubbery Fish Head"] = 60613,
										},
										["n_dmg"] = 71884,
										["n_min"] = 11271,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 71884,
										["c_max"] = 0,
										["id"] = 228478,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258922] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 2549,
										["g_amt"] = 0,
										["n_max"] = 1467,
										["targets"] = {
											["Not-So-Tender Morsel"] = 7595,
											["Rubbery Fish Head"] = 6926,
										},
										["n_dmg"] = 11972,
										["n_min"] = 1222,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 14521,
										["c_max"] = 2549,
										["id"] = 258922,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 2549,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[384117] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 22704,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Rubbery Fish Head"] = 22704,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 22704,
										["c_max"] = 22704,
										["id"] = 384117,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 22704,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[204021] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 26456,
										["targets"] = {
											["Rubbery Fish Head"] = 26456,
										},
										["n_dmg"] = 26456,
										["n_min"] = 26456,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 26456,
										["c_max"] = 0,
										["id"] = 204021,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[258921] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3294,
										["targets"] = {
											["Rubbery Fish Head"] = 3294,
										},
										["n_dmg"] = 3294,
										["n_min"] = 3294,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3294,
										["c_max"] = 0,
										["id"] = 258921,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["isTank"] = true,
							["spec"] = 581,
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298595,
							["on_hold"] = false,
							["start_time"] = 1675298582,
							["delay"] = 0,
							["damage_taken"] = 0.001866,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007548,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
								["Rubbery Fish Head"] = 117226,
								["Not-So-Tender Morsel"] = 20044,
								["Tough Carp"] = 16207,
							},
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["damage_from"] = {
							},
							["classe"] = "EVOKER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 153477.007548,
							["damage_taken"] = 0.007548,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1675298596,
							["friendlyfire_total"] = 0,
							["aID"] = "580-0A6159F7",
							["nome"] = "Allegory",
							["spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8978,
										["targets"] = {
											["Rubbery Fish Head"] = 35911,
										},
										["n_dmg"] = 35911,
										["n_min"] = 8977,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[8] = 35911,
											[11] = 35911,
											[5] = 35911,
										},
										["total"] = 35911,
										["c_max"] = 0,
										["id"] = 356995,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[357212] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10700,
										["targets"] = {
											["Not-So-Tender Morsel"] = 20044,
											["Rubbery Fish Head"] = 20009,
										},
										["n_dmg"] = 40053,
										["n_min"] = 9344,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[8] = 40053,
											[11] = 40053,
											[5] = 30709,
										},
										["total"] = 40053,
										["c_max"] = 0,
										["id"] = 357212,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[362969] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9557,
										["targets"] = {
											["Tough Carp"] = 16207,
											["Rubbery Fish Head"] = 15789,
										},
										["n_dmg"] = 31996,
										["n_min"] = 6650,
										["g_dmg"] = 0,
										["counter"] = 4,
										["ChartData"] = {
											[11] = 31996,
										},
										["total"] = 31996,
										["c_max"] = 0,
										["id"] = 362969,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
									[359077] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 45517,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Rubbery Fish Head"] = 45517,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["ChartData"] = {
											[8] = 45517,
											[11] = 45517,
											[5] = 45517,
										},
										["total"] = 45517,
										["c_max"] = 45517,
										["id"] = 359077,
										["r_dmg"] = 0,
										["spellschool"] = 80,
										["extra"] = {
										},
										["a_dmg"] = 0,
										["c_min"] = 45517,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["total"] = 153477.007548,
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["custom"] = 0,
							["last_event"] = 1675298593,
							["last_dps"] = 0,
							["start_time"] = 1675298583,
							["delay"] = 0,
							["spec"] = 1467,
						}, -- [2]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.008457,
							["damage_from"] = {
								["Maplebaomn"] = true,
								["Tienti-Lordaeron"] = true,
								["Ixaru"] = true,
								["Eleanda-Lordaeron"] = true,
								["Dqniix"] = true,
								["Galldo"] = true,
								["Aislina-Frostmourne"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Heloran-Lordaeron"] = true,
								["Sinfluterrin"] = true,
								["Crab"] = true,
								["Niored"] = true,
								["Esme-Lordaeron"] = true,
								["Blazê"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Frogsplash"] = true,
								["Grimkrit"] = true,
								["Wild Imp <Aîphaton>"] = true,
								["Golgrem"] = true,
								["Xaani"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Neakî"] = true,
								["Dztn"] = true,
								["Missgankalot"] = true,
								["Risen Ghoul <Melaskula>"] = true,
								["Drakekard"] = true,
								["Allegory"] = true,
								["Iliilii"] = true,
								["VazeelRike"] = true,
								["Mîlex"] = true,
								["Loreley-Tichondrius"] = true,
								["Scahra"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Opór"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["Dædshøt"] = true,
								["Aîphaton"] = true,
								["Risen Skulker"] = true,
								["Melaskula"] = true,
								["Blackcàt"] = true,
								["Synthica"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Bossyy"] = true,
								["Herzschinder"] = true,
								["Geiszt"] = true,
								["Makkresh"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195817-00005B0719",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008457,
							["aID"] = "195817",
							["fight_component"] = true,
							["total"] = 0.008457,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Not-So-Tender Morsel",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298596,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2481039.008457,
							["start_time"] = 1675298596,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.006168,
							["damage_from"] = {
								["Gahrol"] = true,
								["Tienti-Lordaeron"] = true,
								["Luitger"] = true,
								["Eleanda-Lordaeron"] = true,
								["Dqniix"] = true,
								["Galldo"] = true,
								["Aislina-Frostmourne"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Sinfluterrin"] = true,
								["Crab"] = true,
								["Niored"] = true,
								["Blazê"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Angíta-Lordaeron"] = true,
								["Corfid"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Esme-Lordaeron"] = true,
								["Golgrem"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Ixaru"] = true,
								["Dztn"] = true,
								["Allegory"] = true,
								["Fenryr <Gahrol>"] = true,
								["Drakekard"] = true,
								["Neakî"] = true,
								["Missgankalot"] = true,
								["Aîphaton"] = true,
								["Blackcàt"] = true,
								["Loreley-Tichondrius"] = true,
								["Misha"] = true,
								["Risen Skulker"] = true,
								["Blutgurgel"] = true,
								["Lilítt"] = true,
								["Tøxicator"] = true,
								["VazeelRike"] = true,
								["Dædshøt"] = true,
								["Iliilii"] = true,
								["Scahra"] = true,
								["Makkresh"] = true,
								["Herzschinder"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["Maplebaomn"] = true,
								["Geiszt"] = true,
								["Melaskula"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195819-00005B071E",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006168,
							["aID"] = "195819",
							["fight_component"] = true,
							["total"] = 0.006168,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Tough Carp",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298596,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2092169.006168,
							["start_time"] = 1675298596,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [4]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.001755,
							["damage_from"] = {
								["Scahra"] = true,
								["Tienti-Lordaeron"] = true,
								["Luitger"] = true,
								["Eleanda-Lordaeron"] = true,
								["Elrondyr"] = true,
								["Ixaru"] = true,
								["Dqniix"] = true,
								["Galldo"] = true,
								["Makkresh"] = true,
								["Rydrasil"] = true,
								["Saturas-Tichondrius"] = true,
								["Bossyy"] = true,
								["Misha"] = true,
								["Fenryr <Gahrol>"] = true,
								["Neakî"] = true,
								["Ryzsard"] = true,
								["Sinfluterrin"] = true,
								["Crab"] = true,
								["Niored"] = true,
								["Blutgurgel"] = true,
								["Risen Ghoul <Melaskula>"] = true,
								["Pæwpæwpæwpæw"] = true,
								["Angíta-Lordaeron"] = true,
								["Blackcàt"] = true,
								["Heloran-Lordaeron"] = true,
								["Grimkrit"] = true,
								["Note"] = true,
								["Gahrol"] = true,
								["Risen Skulker"] = true,
								["Walevo"] = true,
								["Füxli"] = true,
								["Aîphaton"] = true,
								["Dztn"] = true,
								["Blazê"] = true,
								["Lilítt"] = true,
								["Drakekard"] = true,
								["Dædshøt"] = true,
								["Allegory"] = true,
								["VazeelRike"] = true,
								["Corfid"] = true,
								["Loreley-Tichondrius"] = true,
								["Frogsplash"] = true,
								["Spirit Wolf <Frogsplash>"] = true,
								["Aislina-Frostmourne"] = true,
								["Mîlex"] = true,
								["Tøxicator"] = true,
								["Herzschinder"] = true,
								["Maplebaomn"] = true,
								["Missgankalot"] = true,
								["Esme-Lordaeron"] = true,
								["Iliilii"] = true,
								["Synthica"] = true,
								["Skysmimi-Lordaeron"] = true,
								["Xaani"] = true,
								["Melaskula"] = true,
								["Geiszt"] = true,
								["Golgrem"] = true,
							},
							["targets"] = {
							},
							["serial"] = "Creature-0-3102-2444-1588-195808-00005B0715",
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "UNKNOW",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001755,
							["aID"] = "195808",
							["fight_component"] = true,
							["total"] = 0.001755,
							["friendlyfire"] = {
							},
							["last_event"] = 0,
							["nome"] = "Rubbery Fish Head",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1675298596,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3592883.001755,
							["start_time"] = 1675298596,
							["delay"] = 0,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 109,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["Scahra"] = 82892,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 82892.006152,
							["total_without_pet"] = 0.006152,
							["total"] = 0.006152,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["totalabsorb"] = 0.006152,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.006152,
							["healing_taken"] = 0.006152,
							["end_time"] = 1675298596,
							["aID"] = "580-08C239B5",
							["heal_enemy_amt"] = 0,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
									[203794] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 13603,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 13603,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 203794,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[228477] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 33448,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 5,
										["overheal"] = 33448,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 228477,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[213011] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 1325,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 12,
										["overheal"] = 1325,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 213011,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 12,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
									[227255] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["Scahra"] = 34516,
										},
										["n_max"] = 0,
										["targets"] = {
											["Scahra"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 8,
										["overheal"] = 34516,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 227255,
										["targets_absorbs"] = {
										},
										["c_min"] = 0,
										["c_curado"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["start_time"] = 1675298582,
							["spec"] = 581,
							["custom"] = 0,
							["last_event"] = 1675298596,
							["tipo"] = 2,
							["totaldenied"] = 0.006152,
							["delay"] = 0,
							["healing_from"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 109,
					["_ActorTable"] = {
						{
							["received"] = 0.001468,
							["resource"] = 23.001468,
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.001468,
							["total"] = 0.001468,
							["spec"] = 581,
							["resource_type"] = 17,
							["nome"] = "Scahra",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["alternatepower"] = 0.001468,
							["aID"] = "580-08C239B5",
							["last_event"] = 1675298589,
							["tipo"] = 3,
							["flag_original"] = 1298,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["passiveover"] = 0.001468,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 109,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[247456] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 3,
										["uptime"] = 13,
										["id"] = 247456,
										["refreshamt"] = 10,
										["actived"] = false,
										["counter"] = 0,
									},
									[207771] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = 207771,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["cooldowns_defensive"] = 1.008235,
							["pets"] = {
							},
							["aID"] = "580-08C239B5",
							["cooldowns_defensive_targets"] = {
								["Rubbery Fish Head"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[203981] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 203981,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386907] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = 386907,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391171] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = 391171,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[203819] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 13,
										["id"] = 203819,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383169] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 383169,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[391166] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = 391166,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									[212988] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = 212988,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
									[258920] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = 258920,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[383756] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = 383756,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 23,
							["cooldowns_defensive_spells"] = {
								["_ActorTable"] = {
									[204021] = {
										["id"] = 204021,
										["targets"] = {
											["Rubbery Fish Head"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "Scahra",
							["debuff_uptime_targets"] = {
							},
							["spec"] = 581,
							["grupo"] = true,
							["spell_cast"] = {
								[204255] = 1,
								[228477] = 4,
								[203720] = 2,
								[386907] = 1,
								[386933] = 3,
								[204021] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["buff_uptime"] = 83,
							["tipo"] = 4,
							["last_event"] = 1675298596,
							["isTank"] = true,
							["serial"] = "Player-580-08C239B5",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[356995] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = 356995,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["GetSpellContainer"] = nil --[[ skipped inline function ]],
							["buff_uptime"] = 73,
							["aID"] = "580-0A6159F7",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[381748] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 381748,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390899] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 390899,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[390936] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 13,
										["id"] = 390936,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[375342] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = 375342,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[386441] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 386441,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[186403] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = 186403,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 2,
							["nome"] = "Allegory",
							["spec"] = 1467,
							["grupo"] = true,
							["spell_cast"] = {
								[357211] = 2,
								[362969] = 2,
								[356995] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1675298596,
							["tipo"] = 4,
							["classe"] = "EVOKER",
							["pets"] = {
							},
							["serial"] = "Player-580-0A6159F7",
							["buff_uptime_targets"] = {
							},
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 109,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Scahra"] = "Player-580-08C239B5",
					["Allegory"] = "Player-580-0A6159F7",
				},
				["raid_roster_indexed"] = {
					"Allegory", -- [1]
					"Scahra", -- [2]
				},
				["CombatStartedAt"] = 358195.713,
				["tempo_start"] = 1675298582,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
					["Ferloc"] = {
						["total"] = 0,
						["last"] = 0,
					},
					["Isary"] = {
						["total"] = 0,
						["last"] = 0,
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					327399.6982150002, -- [1]
					-0.3005690000001471, -- [2]
					{
						-0.03821600000000558, -- [1]
						[0] = -0.051007,
						["alternatepower"] = 0,
						[3] = -0.02793400000004453,
						[6] = -0.009191999999998757,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 1,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					327400, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 1,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "01:43:17",
				["hasTimer"] = 13.16800000000512,
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Rubbery Fish Head",
				["TotalElapsedCombatTime"] = 3.813999999954831,
				["CombatEndedAt"] = 358182.001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["Scahra"] = 0.006152,
						}, -- [1]
					},
					["damage"] = {
						{
							["Scahra"] = 173923.001866,
							["Allegory"] = 153477.007548,
						}, -- [1]
					},
				},
				["end_time"] = 358182.579,
				["combat_id"] = 109,
				["data_inicio"] = "01:43:03",
				["frags"] = {
					["Liquid Magma Totem"] = 1,
					["Bittershell Hermit"] = 20,
					["Ur'zul"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 700,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 358168.564,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [40]
		},
	},
	["ocd_tracker"] = {
		["enabled"] = false,
		["current_cooldowns"] = {
		},
		["lines_per_column"] = 12,
		["frames"] = {
			["defensive-raid"] = {
			},
			["main"] = {
			},
			["ofensive"] = {
			},
			["defensive-target"] = {
			},
			["utility"] = {
			},
			["defensive-personal"] = {
			},
		},
		["show_options"] = false,
		["own_frame"] = {
			["defensive-raid"] = false,
			["ofensive"] = false,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
		["width"] = 120,
		["height"] = 18,
		["cooldowns"] = {
		},
		["show_conditions"] = {
			["only_inside_instance"] = true,
			["only_in_group"] = true,
		},
		["framme_locked"] = false,
		["filters"] = {
			["defensive-raid"] = false,
			["ofensive"] = true,
			["defensive-target"] = false,
			["utility"] = false,
			["defensive-personal"] = false,
		},
	},
	["last_version"] = "10.0.5 10410",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["coach"] = {
		["enabled"] = false,
		["welcome_panel_pos"] = {
		},
		["last_coach_name"] = false,
	},
	["on_death_menu"] = false,
	["cached_talents"] = {
	},
	["last_instance_id"] = 2520,
	["data_harvest_for_charsts"] = {
		["players"] = {
			{
				["name"] = "Damage of Each Individual Player",
				["playerOnly"] = true,
				["playerKey"] = "total",
				["combatObjectContainer"] = 1,
			}, -- [1]
		},
		["totals"] = {
			{
				["combatObjectSubTableKey"] = 1,
				["name"] = "Damage of All Player Combined",
				["combatObjectSubTableName"] = "totals",
			}, -- [1]
		},
	},
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = false,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["active_profile"] = "Allegory-Blackmoore",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["force_font_outline"] = "",
	["mythic_plus_log"] = {
	},
	["cached_roles"] = {
	},
	["character_data"] = {
		["logons"] = 15,
	},
	["last_encounter"] = "Kurog Grimtotem",
	["last_instance_time"] = 1675299158,
	["nick_tag_cache"] = {
		["nextreset"] = 1676477479,
		["last_version"] = 15,
	},
	["last_day"] = "03",
	["ignore_nicktag"] = false,
	["combat_id"] = 151,
	["savedStyles"] = {
	},
	["data_harvested_for_charts"] = {
	},
	["plugin_database"] = {
		["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
			["enabled"] = true,
			["author"] = "Terciob",
		},
		["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
			["last_boss"] = false,
			["v1"] = true,
			["v2"] = true,
			["captures"] = {
				false, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
			["first_run"] = true,
			["endurance_threshold"] = 3,
			["max_deaths_for_timeline"] = 5,
			["deaths_threshold"] = 10,
			["show_icon"] = 1,
			["max_segments_for_current"] = 2,
			["max_deaths_for_current"] = 20,
			["last_player"] = false,
			["InstalledAt"] = 1673795711,
			["last_encounter_hash"] = false,
			["showing_type"] = 4,
			["timeline_cutoff_time"] = 3,
			["last_segment"] = false,
			["last_combat_id"] = 0,
			["timeline_cutoff_delete_time"] = 3,
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["last_section_selected"] = "main",
			["author"] = "Terciob",
			["window_scale"] = 1,
			["hide_on_combat"] = false,
			["show_icon"] = 5,
			["opened"] = 0,
			["encounter_timers_dbm"] = {
			},
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["use_square_mode"] = false,
			["is_first_run"] = false,
			["grow_direction"] = "right",
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["main_frame_size"] = {
				299.9999389648438, -- [1]
				499.9999084472656, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 125.405064947908,
				["radius"] = 160,
				["hide"] = false,
			},
			["row_height"] = 20,
			["arrow_anchor_x"] = 0,
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["row_texture"] = "Details Serenity",
			["square_grow_direction"] = "right",
			["point"] = "CENTER",
			["main_frame_strata"] = "LOW",
			["square_amount"] = 5,
			["enabled"] = false,
			["arrow_size"] = 10,
			["use_spark"] = true,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["author"] = "Details! Team",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["font_size"] = 10,
			["y"] = -1.52587890625e-05,
			["x"] = -6.103515625e-05,
			["font_face"] = "Friz Quadrata TT",
			["square_size"] = 32,
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = 0,
				["x"] = 0,
				["size"] = 32,
				["update_speed"] = 0.05,
				["attribute_type"] = 1,
			},
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["main_frame_locked"] = false,
			["arrow_anchor_y"] = 0,
		},
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["hide_pull_bar"] = false,
			["author"] = "Terciob",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["usefocus"] = false,
			["updatespeed"] = 1,
			["disable_gouge"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["absolute_mode"] = false,
			["playSound"] = false,
			["playSoundFile"] = "Details Threat Warning Volume 3",
			["useclasscolors"] = false,
		},
		["DETAILS_PLUGIN_TIME_LINE"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_VANGUARD"] = {
			["tank_block_size_height"] = 50,
			["show_power_bar"] = false,
			["first_run"] = false,
			["aura_timer_text_size"] = 14,
			["tank_block_castbar_size_height"] = 16,
			["show_health_bar"] = true,
			["aura_offset_y"] = 0,
			["enabled"] = true,
			["show_cast_bar"] = false,
			["author"] = "Terciob",
			["tank_block_size"] = 150,
			["bar_height"] = 24,
			["tank_block_texture"] = "Details Serenity",
			["tank_block_color"] = {
				0.074509, -- [1]
				0.035294, -- [2]
				0.035294, -- [3]
				0.832845, -- [4]
			},
			["tank_block_height"] = 40,
			["tank_block_powerbar_size_height"] = 10,
			["show_inc_bars"] = true,
		},
		["DETAILS_PLUGIN_EXPLOSIVE_ORBS"] = {
			["enabled"] = true,
			["author"] = "Rhythm",
			["onlyShowHit"] = false,
			["useShortText"] = false,
		},
		["DETAILS_PLUGIN_RAIDCHECK"] = {
			["enabled"] = true,
			["food_tier1"] = true,
			["mythic_1_4"] = true,
			["food_tier2"] = true,
			["author"] = "Terciob",
			["use_report_panel"] = true,
			["pre_pot_healers"] = false,
			["pre_pot_tanks"] = false,
			["food_tier3"] = true,
		},
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.014263,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 58637,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4238-2520-25640-185534-00025B0953",
					["damage_from"] = {
					},
					["aID"] = "185534",
					["raid_targets"] = {
					},
					["total_without_pet"] = 58637.014263,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 58637.014263,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675299502,
					["nome"] = "Bonebolt Hunter",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 21226,
								["targets"] = {
									["Allegory"] = 21226,
								},
								["n_dmg"] = 21226,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 21226,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[382620] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 22523,
								["targets"] = {
									["Allegory"] = 37411,
								},
								["n_dmg"] = 37411,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 37411,
								["c_max"] = 0,
								["id"] = 382620,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 0.014263,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675299491,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [1]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.145086,
					["damage_from"] = {
						["Worldbreaker Cultist"] = true,
						["Lava Snail"] = true,
						["Bonebolt Hunter"] = true,
						["Trickclaw Mystic"] = true,
						["Cygenoth"] = true,
						["Swooping Snitch"] = true,
						["Worldbreaker Bulwark"] = true,
						["Lava Slug"] = true,
						["Worldbreaker Smith"] = true,
						["Claw Fighter"] = true,
						["Qalashi Necksnapper"] = true,
						["Weaponmaster Vordak"] = true,
						["Worldbreaker Brute"] = true,
						["Vicious Hyena"] = true,
						["Cruel Bonecrusher"] = true,
						["Omen"] = true,
						["Worldbreaker Guard"] = true,
					},
					["targets"] = {
						["Turnip Punching Bag"] = 0,
						["Unstable Elemental"] = 136926,
						["Not-So-Tender Morsel"] = 0,
						["Lava Snail"] = 115510,
						["Rubbery Fish Head"] = 0,
						["Trickclaw Mystic"] = 49217,
						["Djaradin Crustshaper"] = 252753,
						["Swooping Snitch"] = 204554,
						["Bisquius"] = 0,
						["Lava Flick"] = 15263,
						["Claw Fighter"] = 159505,
						["Worldbreaker Bulwark"] = 227770,
						["Lava Slug"] = 34359,
						["Minion of Omen"] = 291801,
						["Worldbreaker Smith"] = 666720,
						["Worldbreaker Guard"] = 352941,
						["Cygenoth"] = 1131736,
						["Worldbreaker Cultist"] = 691978,
						["Emberling"] = 17014,
						["Qalashi Necksnapper"] = 277649,
						["Weaponmaster Vordak"] = 648568,
						["Worldbreaker Brute"] = 560119,
						["Bracken Warscourge"] = 81441,
						["Cruel Bonecrusher"] = 81166,
						["Omen"] = 604811,
						["Tough Carp"] = 0,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "580-0A6159F7",
					["raid_targets"] = {
					},
					["total_without_pet"] = 6601801.145085998,
					["serial"] = "Player-580-0A6159F7",
					["end_time"] = 1675299502,
					["dps_started"] = false,
					["total"] = 6601801.145085998,
					["classe"] = "EVOKER",
					["on_hold"] = false,
					["nome"] = "Allegory",
					["spells"] = {
						["_ActorTable"] = {
							[356995] = {
								["c_amt"] = 14,
								["b_amt"] = 0,
								["c_dmg"] = 381576,
								["g_amt"] = 0,
								["n_max"] = 16613,
								["targets"] = {
									["Omen"] = 176550,
									["Minion of Omen"] = 141378,
									["Cygenoth"] = 175866,
									["Unstable Elemental"] = 86144,
									["Worldbreaker Smith"] = 215517,
									["Worldbreaker Guard"] = 33289,
									["Not-So-Tender Morsel"] = 0,
									["Worldbreaker Cultist"] = 131723,
									["Qalashi Necksnapper"] = 67174,
									["Rubbery Fish Head"] = 0,
									["Weaponmaster Vordak"] = 150453,
									["Worldbreaker Brute"] = 224543,
									["Djaradin Crustshaper"] = 97793,
									["Swooping Snitch"] = 105465,
									["Bisquius"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 1224319,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 110,
								["total"] = 1605895,
								["c_max"] = 34553,
								["id"] = 356995,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 96,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[357209] = {
								["c_amt"] = 16,
								["b_amt"] = 0,
								["c_dmg"] = 292001,
								["g_amt"] = 0,
								["n_max"] = 81441,
								["targets"] = {
									["Lava Slug"] = 34359,
									["Bracken Warscourge"] = 81441,
									["Claw Fighter"] = 159505,
									["Worldbreaker Cultist"] = 101580,
									["Lava Snail"] = 75163,
									["Minion of Omen"] = 55257,
									["Qalashi Necksnapper"] = 54351,
									["Weaponmaster Vordak"] = 69519,
									["Worldbreaker Brute"] = 87548,
									["Cygenoth"] = 238887,
									["Cruel Bonecrusher"] = 81166,
									["Omen"] = 177429,
									["Worldbreaker Smith"] = 133007,
								},
								["n_dmg"] = 1057211,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 117,
								["b_dmg"] = 0,
								["total"] = 1349212,
								["c_max"] = 52688,
								["e_amt"] = 13,
								["id"] = 357209,
								["r_dmg"] = 0,
								["e_dmg"] = {
									23024, -- [1]
									[4] = 75163,
								},
								["e_lvl"] = {
									1, -- [1]
									[4] = 1,
								},
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 101,
								["e_total"] = 16,
								["r_amt"] = 0,
							},
							[359077] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 224886,
								["g_amt"] = 0,
								["n_max"] = 57982,
								["targets"] = {
									["Worldbreaker Bulwark"] = 55290,
									["Worldbreaker Brute"] = 136556,
									["Unstable Elemental"] = 50782,
									["Worldbreaker Smith"] = 130363,
									["Worldbreaker Guard"] = 106068,
									["Worldbreaker Cultist"] = 75380,
									["Minion of Omen"] = 70345,
									["Cygenoth"] = 180574,
									["Rubbery Fish Head"] = 0,
									["Weaponmaster Vordak"] = 146063,
									["Trickclaw Mystic"] = 49217,
									["Djaradin Crustshaper"] = 75726,
									["Qalashi Necksnapper"] = 50265,
									["Omen"] = 78479,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 980222,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["b_dmg"] = 0,
								["r_amt"] = 0,
								["c_max"] = 108146,
								["e_amt"] = 11,
								["id"] = 359077,
								["r_dmg"] = 0,
								["e_dmg"] = {
									78479, -- [1]
								},
								["e_lvl"] = {
									1, -- [1]
								},
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 27,
								["e_total"] = 11,
								["total"] = 1205108,
							},
							[361500] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 130700,
								["g_amt"] = 0,
								["n_max"] = 65475,
								["targets"] = {
									["Worldbreaker Bulwark"] = 109503,
									["Worldbreaker Smith"] = 36790,
									["Worldbreaker Cultist"] = 173277,
									["Qalashi Necksnapper"] = 56463,
									["Weaponmaster Vordak"] = 111592,
									["Djaradin Crustshaper"] = 30476,
									["Minion of Omen"] = 24821,
									["Omen"] = 33565,
									["Cygenoth"] = 274665,
								},
								["n_dmg"] = 720452,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 24,
								["total"] = 851152,
								["c_max"] = 66295,
								["id"] = 361500,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 22,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[389839] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 53746,
								["targets"] = {
									["Not-So-Tender Morsel"] = 0,
									["Omen"] = 53746,
								},
								["n_dmg"] = 53746,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 53746,
								["c_max"] = 0,
								["id"] = 389839,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[370452] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 130322,
								["g_amt"] = 0,
								["n_max"] = 20753,
								["targets"] = {
									["Worldbreaker Bulwark"] = 20638,
									["Weaponmaster Vordak"] = 20433,
									["Worldbreaker Brute"] = 31043,
									["Worldbreaker Smith"] = 67538,
									["Worldbreaker Guard"] = 56036,
									["Omen"] = 61249,
									["Cygenoth"] = 55818,
								},
								["n_dmg"] = 182433,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 312755,
								["c_max"] = 46804,
								["id"] = 370452,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 10,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[357212] = {
								["c_amt"] = 11,
								["b_amt"] = 0,
								["c_dmg"] = 307441,
								["g_amt"] = 0,
								["n_max"] = 19122,
								["targets"] = {
									["Turnip Punching Bag"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Lava Snail"] = 40347,
									["Rubbery Fish Head"] = 0,
									["Djaradin Crustshaper"] = 39119,
									["Swooping Snitch"] = 99089,
									["Lava Flick"] = 15263,
									["Worldbreaker Bulwark"] = 34837,
									["Worldbreaker Smith"] = 27024,
									["Worldbreaker Guard"] = 157548,
									["Emberling"] = 17014,
									["Qalashi Necksnapper"] = 49396,
									["Weaponmaster Vordak"] = 91708,
									["Worldbreaker Brute"] = 70495,
									["Cygenoth"] = 89903,
									["Worldbreaker Cultist"] = 148661,
									["Omen"] = 13154,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 586117,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 58,
								["total"] = 893558,
								["c_max"] = 40347,
								["id"] = 357212,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 47,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[353759] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 121683,
								["g_amt"] = 0,
								["n_max"] = 16712,
								["targets"] = {
									["Worldbreaker Smith"] = 56481,
									["Cygenoth"] = 82215,
									["Weaponmaster Vordak"] = 47155,
									["Worldbreaker Cultist"] = 47645,
								},
								["n_dmg"] = 111813,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 233496,
								["c_max"] = 38440,
								["id"] = 353759,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[362969] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 16686,
								["g_amt"] = 0,
								["n_max"] = 11645,
								["targets"] = {
									["Worldbreaker Bulwark"] = 7502,
									["Not-So-Tender Morsel"] = 0,
									["Worldbreaker Cultist"] = 13712,
									["Rubbery Fish Head"] = 0,
									["Weaponmaster Vordak"] = 11645,
									["Worldbreaker Brute"] = 9934,
									["Djaradin Crustshaper"] = 9639,
									["Cygenoth"] = 33808,
									["Omen"] = 10639,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 80193,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 96879,
								["c_max"] = 16686,
								["id"] = 362969,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 9,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["friendlyfire_total"] = 0,
					["spec"] = 1467,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1525055.145086,
					["start_time"] = 1675299165,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.016571,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 94779,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4238-2520-25640-186206-0002DB0955",
					["damage_from"] = {
						["Allegory"] = true,
					},
					["aID"] = "186206",
					["raid_targets"] = {
					},
					["total_without_pet"] = 94779.016571,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 94779.016571,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675299502,
					["nome"] = "Cruel Bonecrusher",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 31897,
								["g_amt"] = 0,
								["n_max"] = 17255,
								["targets"] = {
									["Allegory"] = 94779,
								},
								["n_dmg"] = 62882,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 94779,
								["c_max"] = 31897,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 81166.016571,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675299492,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [3]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.019268,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 247625,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4238-2520-25640-185528-00005B0955",
					["damage_from"] = {
						["Allegory"] = true,
					},
					["aID"] = "185528",
					["raid_targets"] = {
					},
					["total_without_pet"] = 247625.019268,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 247625.019268,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675299502,
					["nome"] = "Trickclaw Mystic",
					["spells"] = {
						["_ActorTable"] = {
							[382249] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 24266,
								["targets"] = {
									["Allegory"] = 247625,
								},
								["n_dmg"] = 247625,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 247625,
								["c_max"] = 0,
								["id"] = 382249,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 12,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 49217.019268,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675299467,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [4]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.018544,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4238-2520-25640-185529-0003DB0953",
					["damage_from"] = {
						["Allegory"] = true,
					},
					["aID"] = "185529",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.018544,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["fight_component"] = true,
					["end_time"] = 1675299502,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Bracken Warscourge",
					["spells"] = {
						["_ActorTable"] = {
							[387796] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 387796,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[382555] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 382555,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["total"] = 0.018544,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 81441.018544,
					["start_time"] = 1675299499,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [5]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.016092,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 105055,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4238-2520-25640-185508-0000DB0953",
					["damage_from"] = {
						["Allegory"] = true,
					},
					["aID"] = "185508",
					["raid_targets"] = {
					},
					["total_without_pet"] = 105055.016092,
					["fight_component"] = true,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 105055.016092,
					["friendlyfire_total"] = 0,
					["end_time"] = 1675299502,
					["nome"] = "Claw Fighter",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 22107,
								["targets"] = {
									["Allegory"] = 105055,
								},
								["n_dmg"] = 105055,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 105055,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["dps_started"] = false,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 159505.016092,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675299498,
					["delay"] = 0,
					["classe"] = "UNKNOW",
				}, -- [6]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.010739,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 15452,
					},
					["pets"] = {
					},
					["serial"] = "Creature-0-4238-2520-25640-185691-00005B0953",
					["damage_from"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 15452.010739,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675299607,
					["aID"] = "185691",
					["fight_component"] = true,
					["nome"] = "Vicious Hyena",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 15452,
								["targets"] = {
									["Allegory"] = 15452,
								},
								["n_dmg"] = 15452,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 15452,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["total"] = 15452.010739,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["damage_taken"] = 0.010739,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675299597,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [7]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.013712,
					["damage_from"] = {
						["Allegory"] = true,
					},
					["targets"] = {
					},
					["serial"] = "Creature-0-3102-2444-1588-194961-00005B0D06",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["aID"] = "194961",
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.013712,
					["dps_started"] = false,
					["fight_component"] = true,
					["total"] = 0.013712,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "Unstable Elemental",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["end_time"] = 1675300157,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 136926.013712,
					["start_time"] = 1675300154,
					["delay"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [8]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.005406,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Rubbery Fish Head"] = 0,
						["Turnip Punching Bag"] = 0,
						["Bisquius"] = 0,
						["Not-So-Tender Morsel"] = 0,
						["Tough Carp"] = 0,
					},
					["end_time"] = 1675367146,
					["pets"] = {
					},
					["damage_from"] = {
					},
					["start_time"] = 1675367143,
					["aID"] = "580-08C239B5",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005406,
					["on_hold"] = false,
					["classe"] = "DEMONHUNTER",
					["dps_started"] = false,
					["total"] = 0.005406,
					["last_dps"] = 0,
					["delay"] = 0,
					["nome"] = "Scahra",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Turnip Punching Bag"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Bisquius"] = 0,
									["Felhound"] = 0,
									["Doomguard"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
							[258922] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Turnip Punching Bag"] = 0,
									["Felhound"] = 0,
									["Bisquius"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 258922,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[258921] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Turnip Punching Bag"] = 0,
									["Bisquius"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 258921,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[228478] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Not-So-Tender Morsel"] = 0,
									["Rubbery Fish Head"] = 0,
									["Bisquius"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 228478,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[213405] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Doomguard"] = 0,
									["Felguard"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 213405,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[350631] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 350631,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[225919] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Turnip Punching Bag"] = 0,
									["Bisquius"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 225919,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[391058] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 391058,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[384117] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Bisquius"] = 0,
									["Not-So-Tender Morsel"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 384117,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[382090] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Not-So-Tender Morsel"] = 0,
									["Rubbery Fish Head"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 382090,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[204598] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 204598,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[377079] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Turnip Punching Bag"] = 0,
									["Bisquius"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 377079,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[207771] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Bisquius"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 207771,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[204021] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Bisquius"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 204021,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[212105] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 212105,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
							[247455] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Turnip Punching Bag"] = 0,
									["Rubbery Fish Head"] = 0,
									["Not-So-Tender Morsel"] = 0,
									["Tough Carp"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 247455,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.005406,
					["spec"] = 581,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["isTank"] = true,
					["serial"] = "Player-580-08C239B5",
					["tipo"] = 1,
				}, -- [9]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.004611,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Blutgurgel"] = 0,
						["Grimkrit"] = 0,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["damage_from"] = {
					},
					["aID"] = "197557",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004611,
					["on_hold"] = false,
					["damage_taken"] = 0.004611,
					["monster"] = true,
					["total"] = 0.004611,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["nome"] = "Bisquius",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Blutgurgel"] = 0,
									["Grimkrit"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["end_time"] = 1675367146,
					["last_dps"] = 0,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675367143,
					["serial"] = "Creature-0-3102-2444-1588-197557-00005B07C7",
					["classe"] = "UNKNOW",
				}, -- [10]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.005408,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005408,
					["total"] = 0.005408,
					["fight_component"] = true,
					["end_time"] = 1675367146,
					["damage_taken"] = 0.005408,
					["tipo"] = 1,
					["nome"] = "Tough Carp",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["aID"] = "195819",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675367143,
					["serial"] = "Creature-0-3102-2444-1588-195819-00005B07AB",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [11]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.00105,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00105,
					["total"] = 0.00105,
					["fight_component"] = true,
					["end_time"] = 1675367146,
					["damage_taken"] = 0.00105,
					["tipo"] = 1,
					["nome"] = "Rubbery Fish Head",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["aID"] = "195808",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675367143,
					["serial"] = "Creature-0-3102-2444-1588-195808-00005B079C",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [12]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.004413,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004413,
					["total"] = 0.004413,
					["fight_component"] = true,
					["end_time"] = 1675367146,
					["damage_taken"] = 0.004413,
					["tipo"] = 1,
					["nome"] = "Turnip Punching Bag",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["aID"] = "65310",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675367143,
					["serial"] = "Creature-0-3102-2444-1588-65310-00005B0787",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [13]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.005836,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["delay"] = 0,
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005836,
					["total"] = 0.005836,
					["fight_component"] = true,
					["end_time"] = 1675367146,
					["damage_taken"] = 0.005836,
					["tipo"] = 1,
					["nome"] = "Not-So-Tender Morsel",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["aID"] = "195817",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1675367143,
					["serial"] = "Creature-0-3102-2444-1588-195817-00005B075F",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
				}, -- [14]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.020499,
					["damage_from"] = {
						["Dragonarion-Lordaeron"] = true,
						["Allegory"] = true,
					},
					["targets"] = {
						["Allegory"] = 23550,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 23550.020499,
					["aID"] = "185592",
					["friendlyfire"] = {
					},
					["monster"] = true,
					["total"] = 23550.020499,
					["classe"] = "UNKNOW",
					["end_time"] = 1675435088,
					["nome"] = "Swooping Snitch",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2122,
								["targets"] = {
									["Allegory"] = 23550,
								},
								["n_dmg"] = 23550,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 23550,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 13,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["dps_started"] = false,
					["fight_component"] = true,
					["serial"] = "Creature-0-3896-2444-650-185592-00005D118A",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435059,
					["delay"] = 0,
					["damage_taken"] = 228062.020499,
				}, -- [15]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.049467,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Dragonarion-Lordaeron"] = 7761,
						["Allegory"] = 46836,
						["Qalashi Necksnapper"] = 487580,
						["Djaradin Crustshaper"] = 229752,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["friendlyfire"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 771929.0494670001,
					["damage_from"] = {
						["Dragonarion-Lordaeron"] = true,
						["Allegory"] = true,
						["Qalashi Necksnapper"] = true,
						["Djaradin Crustshaper"] = true,
					},
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1675435155,
					["friendlyfire_total"] = 0,
					["aID"] = "185589",
					["nome"] = "Worldbreaker Brute",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 70578,
								["g_amt"] = 0,
								["n_max"] = 8473,
								["targets"] = {
									["Dragonarion-Lordaeron"] = 7761,
									["Allegory"] = 28657,
									["Qalashi Necksnapper"] = 487580,
									["Djaradin Crustshaper"] = 229752,
								},
								["n_dmg"] = 683172,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 134,
								["total"] = 753750,
								["c_max"] = 15379,
								["DODGE"] = 3,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 26,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 99,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[387398] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 18179,
								["targets"] = {
									["Djaradin Crustshaper"] = 0,
									["Allegory"] = 18179,
								},
								["n_dmg"] = 18179,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 18179,
								["c_max"] = 0,
								["id"] = 387398,
								["r_dmg"] = 0,
								["MISS"] = 6,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 19,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 771929.0494670001,
					["serial"] = "Creature-0-3896-2444-650-185589-00005D1849",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1155200.049467,
					["start_time"] = 1675435061,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [16]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.03285,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Dragonarion-Lordaeron"] = 93724,
						["Allegory"] = 141863,
						["Xywarri"] = 27344,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_from"] = {
						["Dragonarion-Lordaeron"] = true,
						["Allegory"] = true,
						["Mindbender <Dragonarion-Lordaeron>"] = true,
					},
					["aID"] = "185591",
					["raid_targets"] = {
					},
					["total_without_pet"] = 262931.03285,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["monster"] = true,
					["end_time"] = 1675435155,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Worldbreaker Smith",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6379,
								["targets"] = {
									["Dragonarion-Lordaeron"] = 17957,
									["Allegory"] = 16507,
									["Xywarri"] = 6076,
								},
								["n_dmg"] = 40540,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 40540,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[390927] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 21268,
								["targets"] = {
									["Dragonarion-Lordaeron"] = 75767,
									["Allegory"] = 125356,
									["Xywarri"] = 21268,
								},
								["n_dmg"] = 222391,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 222391,
								["c_max"] = 0,
								["id"] = 390927,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 10,
								["a_amt"] = 0,
								["n_amt"] = 11,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[367974] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 367974,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["total"] = 262931.03285,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-3896-2444-650-185591-00005D1725",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 869527.0328500001,
					["start_time"] = 1675435110,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [17]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 14528.059329,
					["damage_from"] = {
						["Dragonarion-Lordaeron"] = true,
						["Allegory"] = true,
						["Qalashi Necksnapper"] = true,
						["Blitzlêiter"] = true,
					},
					["targets"] = {
						["Dragonarion-Lordaeron"] = 27033,
						["Allegory"] = 47823,
						["Qalashi Necksnapper"] = 510077,
						["Blitzlêiter"] = 8452,
					},
					["pets"] = {
					},
					["total"] = 593385.059329,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["aID"] = "185594",
					["raid_targets"] = {
					},
					["total_without_pet"] = 593385.059329,
					["last_event"] = 0,
					["fight_component"] = true,
					["monster"] = true,
					["end_time"] = 1675435220,
					["classe"] = "UNKNOW",
					["friendlyfire"] = {
					},
					["nome"] = "Worldbreaker Guard",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 31577,
								["g_amt"] = 0,
								["n_max"] = 14528,
								["targets"] = {
									["Dragonarion-Lordaeron"] = 27033,
									["Allegory"] = 36800,
									["Qalashi Necksnapper"] = 510077,
								},
								["n_dmg"] = 542333,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 109,
								["total"] = 573910,
								["c_max"] = 10940,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 5,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 99,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[377609] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6780,
								["targets"] = {
									["Allegory"] = 11023,
									["Blitzlêiter"] = 8452,
								},
								["n_dmg"] = 19475,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 19475,
								["c_max"] = 0,
								["id"] = 377609,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 14,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["serial"] = "Creature-0-3896-2444-650-185594-00005D1727",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435114,
					["delay"] = 0,
					["damage_taken"] = 989008.0593289998,
				}, -- [18]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.011257,
					["damage_from"] = {
						["Allegory"] = true,
					},
					["targets"] = {
					},
					["friendlyfire"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.011257,
					["aID"] = "192137",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dps_started"] = false,
					["total"] = 0.011257,
					["end_time"] = 1675435220,
					["fight_component"] = true,
					["nome"] = "Lava Flick",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-3896-2444-650-192137-00005D12C9",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435217,
					["delay"] = 0,
					["damage_taken"] = 15263.011257,
				}, -- [19]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 4753.064235999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Djaradin Crustshaper"] = 26609,
						["Qalashi Necksnapper"] = 203739,
						["Allegory"] = 144022,
						["Dragonarion-Lordaeron"] = 4753,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 379123.0642360001,
					["damage_from"] = {
						["Dragonarion-Lordaeron"] = true,
						["Allegory"] = true,
						["Ayasanth"] = true,
					},
					["total"] = 379123.0642360001,
					["fight_component"] = true,
					["end_time"] = 1675435220,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["nome"] = "Worldbreaker Cultist",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6601,
								["targets"] = {
									["Djaradin Crustshaper"] = 26609,
									["Qalashi Necksnapper"] = 203739,
									["Allegory"] = 27438,
									["Dragonarion-Lordaeron"] = 4753,
								},
								["n_dmg"] = 262539,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 56,
								["total"] = 262539,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 53,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[387388] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 14885,
								["targets"] = {
									["Allegory"] = 116584,
								},
								["n_dmg"] = 116584,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 116584,
								["c_max"] = 0,
								["id"] = 387388,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 48,
								["a_amt"] = 0,
								["n_amt"] = 8,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["monster"] = true,
					["aID"] = "185595",
					["serial"] = "Creature-0-3896-2444-650-185595-00005D1976",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 702930.064236,
					["start_time"] = 1675435112,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [20]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.045567,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Worldbreaker Guard"] = 468530,
						["Allegory"] = 39943,
						["Worldbreaker Brute"] = 278717,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 787190.045567,
					["damage_from"] = {
						["Allegory"] = true,
						["Worldbreaker Guard"] = true,
						["Worldbreaker Cultist"] = true,
						["Worldbreaker Brute"] = true,
					},
					["total"] = 787190.045567,
					["monster"] = true,
					["end_time"] = 1675435498,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["nome"] = "Qalashi Necksnapper",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 26595,
								["g_amt"] = 0,
								["n_max"] = 9338,
								["targets"] = {
									["Worldbreaker Guard"] = 468530,
									["Allegory"] = 32680,
									["Worldbreaker Brute"] = 278717,
								},
								["n_dmg"] = 753332,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 129,
								["total"] = 779927,
								["c_max"] = 14978,
								["DODGE"] = 5,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 5,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 115,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[369751] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Allegory"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 369751,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[369788] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 369788,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[376472] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7263,
								["targets"] = {
									["Allegory"] = 7263,
								},
								["n_dmg"] = 7263,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 7263,
								["c_max"] = 0,
								["id"] = 376472,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["aID"] = "186109",
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-186109-00005D05CC",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1479045.045567,
					["start_time"] = 1675435401,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [21]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.049912,
					["damage_from"] = {
						["Allegory"] = true,
						["Worldbreaker Cultist"] = true,
						["Worldbreaker Brute"] = true,
					},
					["targets"] = {
						["Worldbreaker Brute"] = 170840,
					},
					["pets"] = {
					},
					["total"] = 170840.049912,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 170840.049912,
					["last_event"] = 0,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1675435518,
					["aID"] = "186110",
					["fight_component"] = true,
					["nome"] = "Djaradin Crustshaper",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 32379,
								["g_amt"] = 0,
								["n_max"] = 6976,
								["targets"] = {
									["Worldbreaker Brute"] = 170840,
								},
								["n_dmg"] = 138461,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 170840,
								["c_max"] = 11495,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 23,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[369055] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 369055,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 26,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[369193] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 369193,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["friendlyfire_total"] = 0,
					["friendlyfire"] = {
					},
					["serial"] = "Creature-0-3896-2444-650-186110-00005D0A36",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435441,
					["delay"] = 0,
					["damage_taken"] = 509114.0499120001,
				}, -- [22]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.009368999999999999,
					["damage_from"] = {
						["Allegory"] = true,
					},
					["targets"] = {
						["Allegory"] = 4169,
					},
					["friendlyfire"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 4169.009369,
					["aID"] = "191629",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dps_started"] = false,
					["total"] = 4169.009369,
					["end_time"] = 1675435568,
					["fight_component"] = true,
					["nome"] = "Lava Slug",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 3089,
								["g_amt"] = 0,
								["n_max"] = 1080,
								["targets"] = {
									["Allegory"] = 4169,
								},
								["n_dmg"] = 1080,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 4169,
								["c_max"] = 3089,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-3896-2444-650-191629-0005DCB68B",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435562,
					["delay"] = 0,
					["damage_taken"] = 34359.009369,
				}, -- [23]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.009326,
					["damage_from"] = {
						["Allegory"] = true,
					},
					["targets"] = {
					},
					["friendlyfire"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.009326,
					["aID"] = "193026",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dps_started"] = false,
					["total"] = 0.009326,
					["end_time"] = 1675435603,
					["fight_component"] = true,
					["nome"] = "Emberling",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Allegory"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-3896-2444-650-193026-00005D1413",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435600,
					["delay"] = 0,
					["damage_taken"] = 17014.009326,
				}, -- [24]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.007000999999999999,
					["damage_from"] = {
						["Allegory"] = true,
					},
					["targets"] = {
						["Allegory"] = 10446,
					},
					["friendlyfire"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 10446.007001,
					["aID"] = "191628",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["dps_started"] = false,
					["total"] = 10446.007001,
					["end_time"] = 1675435603,
					["fight_component"] = true,
					["nome"] = "Lava Snail",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 4114,
								["targets"] = {
									["Allegory"] = 10446,
								},
								["n_dmg"] = 10446,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 10446,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
					},
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-3896-2444-650-191628-00005D054D",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1675435594,
					["delay"] = 0,
					["damage_taken"] = 115510.007001,
				}, -- [25]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.002938,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Ayasanth"] = 25269,
						["Allegory"] = 223059,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["damage_from"] = {
						["Ayasanth"] = true,
						["Allegory"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 248328.002938,
					["aID"] = "186219",
					["end_time"] = 1675435823,
					["monster"] = true,
					["total"] = 248328.002938,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Weaponmaster Vordak",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 10625,
								["targets"] = {
									["Allegory"] = 142170,
								},
								["n_dmg"] = 142170,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 142170,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 16,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[387410] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 26963,
								["targets"] = {
									["Ayasanth"] = 25269,
									["Allegory"] = 80889,
								},
								["n_dmg"] = 106158,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 106158,
								["c_max"] = 0,
								["id"] = 387410,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["dps_started"] = false,
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-186219-00005D1ED4",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 687360.002938,
					["start_time"] = 1675435772,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [26]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.016765,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 25000,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["damage_from"] = {
						["Allegory"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 25000.016765,
					["aID"] = "185596",
					["end_time"] = 1675435856,
					["monster"] = true,
					["total"] = 25000.016765,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Worldbreaker Bulwark",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 8964,
								["g_amt"] = 0,
								["n_max"] = 6255,
								["targets"] = {
									["Allegory"] = 25000,
								},
								["n_dmg"] = 16036,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 25000,
								["c_max"] = 8964,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[387410] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 387410,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["dps_started"] = false,
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-185596-00005D1ED4",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 227770.016765,
					["start_time"] = 1675435839,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [27]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.008943,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Allegory"] = 248033,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["damage_from"] = {
						["Allegory"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 248033.008943,
					["aID"] = "185660",
					["end_time"] = 1675435943,
					["monster"] = true,
					["total"] = 248033.008943,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Cygenoth",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 10262,
								["targets"] = {
									["Allegory"] = 30094,
								},
								["n_dmg"] = 30094,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 30094,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[394267] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 58194,
								["targets"] = {
									["Allegory"] = 58194,
								},
								["n_dmg"] = 58194,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 58194,
								["c_max"] = 0,
								["id"] = 394267,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[394262] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 394262,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[394275] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 22350,
								["targets"] = {
									["Allegory"] = 44373,
								},
								["n_dmg"] = 44373,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 44373,
								["c_max"] = 0,
								["id"] = 394275,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[394167] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9157,
								["targets"] = {
									["Allegory"] = 115372,
								},
								["n_dmg"] = 115372,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 115372,
								["c_max"] = 0,
								["id"] = 394167,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["dps_started"] = false,
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-185660-00005D1ED4",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1131736.008943,
					["start_time"] = 1675435907,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [28]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.015103,
					["damage_from"] = {
						["Allegory"] = true,
						["Vygosa"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.015103,
					["aID"] = "15466",
					["end_time"] = 1675437492,
					["monster"] = true,
					["total"] = 0.015103,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Minion of Omen",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["dps_started"] = false,
					["last_event"] = 0,
					["serial"] = "Creature-0-1469-1-218-15466-00005D258A",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 341704.015103,
					["start_time"] = 1675437489,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [29]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 132175.013441,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
						["Mirror Image <Noctavian-Khaz'goroth>"] = 66741,
						["Vygosa"] = 53459,
						["Ormthang"] = 103993,
						["Infernal <Létizia-Baelgun>"] = 105652,
						["Firmi-Ysera"] = 68394,
						["Guildoran-Thrall"] = 103489,
						["Blasphemy <Létizia-Baelgun>"] = 17103,
						["Forodim-Tichondrius"] = 128407,
						["Morion-Lothar"] = 53707,
						["Jubtip"] = 52954,
						["Esera-Norgannon"] = 32418,
						["Deanisa-DunMorogh"] = 56455,
						["Collectivevx-Blackrock"] = 9978,
						["Allegory"] = 48763,
						["Zurasius"] = 157144,
						["Létizia-Baelgun"] = 51622,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["damage_from"] = {
						["Ormthang"] = true,
						["Noctavian-Khaz'goroth"] = true,
						["Blasphemy <Létizia-Baelgun>"] = true,
						["Esera-Norgannon"] = true,
						["Deanisa-DunMorogh"] = true,
						["Collectivevx-Blackrock"] = true,
						["Allegory"] = true,
						["Zurasius"] = true,
						["Infernal <Létizia-Baelgun>"] = true,
						["Morion-Lothar"] = true,
						["Jubtip"] = true,
						["Forodim-Tichondrius"] = true,
						["Firmi-Ysera"] = true,
						["Létizia-Baelgun"] = true,
						["Vygosa"] = true,
						["Mirror Image <Noctavian-Khaz'goroth>"] = true,
						["Guildoran-Thrall"] = true,
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1110279.013441,
					["aID"] = "15467",
					["end_time"] = 1675437948,
					["monster"] = true,
					["total"] = 1110279.013441,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "Omen",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 2,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 34588,
								["targets"] = {
									["Firmi-Ysera"] = 31090,
									["Zurasius"] = 52600,
									["Forodim-Tichondrius"] = 34588,
								},
								["n_dmg"] = 118278,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 118278,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 45355,
								["extra"] = {
								},
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 4,
								["n_amt"] = 7,
								["b_dmg"] = 13024,
								["r_amt"] = 0,
							}, -- [1]
							[104903] = {
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9369,
								["targets"] = {
									["Infernal <Létizia-Baelgun>"] = 1577,
									["Firmi-Ysera"] = 11498,
									["Zurasius"] = 1088,
								},
								["n_dmg"] = 14163,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 14163,
								["c_max"] = 0,
								["id"] = 104903,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 2129,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["a_amt"] = 1,
								["n_amt"] = 4,
								["b_dmg"] = 2129,
								["r_amt"] = 0,
							},
							[26540] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 19312,
								["targets"] = {
									["Infernal <Létizia-Baelgun>"] = 104075,
									["Esera-Norgannon"] = 32418,
									["Ormthang"] = 103993,
									["Allegory"] = 48763,
									["Vygosa"] = 53459,
									["Guildoran-Thrall"] = 103489,
									["Blasphemy <Létizia-Baelgun>"] = 17103,
									["Mirror Image <Noctavian-Khaz'goroth>"] = 66741,
									["Morion-Lothar"] = 53707,
									["Jubtip"] = 52954,
									["Forodim-Tichondrius"] = 93819,
									["Deanisa-DunMorogh"] = 56455,
									["Collectivevx-Blackrock"] = 9978,
									["Firmi-Ysera"] = 25806,
									["Zurasius"] = 103456,
									["Létizia-Baelgun"] = 51622,
								},
								["n_dmg"] = 977838,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 58,
								["total"] = 977838,
								["c_max"] = 0,
								["id"] = 26540,
								["r_dmg"] = 0,
								["extra"] = {
								},
								["a_dmg"] = 347683,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["a_amt"] = 21,
								["n_amt"] = 58,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
					},
					["dps_started"] = false,
					["last_event"] = 0,
					["serial"] = "Creature-0-1469-1-218-15467-00005D2757",
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 5560814.013441,
					["start_time"] = 1675437918,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [30]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["targets_overheal"] = {
						["Allegory"] = 52395,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "EVOKER",
					["totalover"] = 52395.03758799999,
					["total_without_pet"] = 420457.0375880001,
					["total"] = 420457.0375880001,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-580-0A6159F7",
					["totalabsorb"] = 0.037588,
					["last_hps"] = 0,
					["targets"] = {
						["Allegory"] = 420457,
					},
					["totalover_without_pet"] = 0.037588,
					["healing_taken"] = 420457.0375880001,
					["fight_component"] = true,
					["end_time"] = 1675299607,
					["aID"] = "580-0A6159F7",
					["heal_enemy_amt"] = 0,
					["nome"] = "Allegory",
					["spells"] = {
						["_ActorTable"] = {
							[374349] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Allegory"] = 3590,
								},
								["n_max"] = 3590,
								["targets"] = {
									["Allegory"] = 22052,
								},
								["n_min"] = 0,
								["counter"] = 9,
								["overheal"] = 3590,
								["total"] = 22052,
								["c_max"] = 0,
								["id"] = 374349,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 22052,
								["totaldenied"] = 0,
								["n_amt"] = 9,
								["absorbed"] = 0,
							},
							[387763] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 22378,
								["targets"] = {
									["Allegory"] = 22378,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 22378,
								["c_max"] = 0,
								["id"] = 387763,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 22378,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["absorbed"] = 0,
							},
							[361195] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 27712,
								["targets"] = {
									["Allegory"] = 55209,
								},
								["n_min"] = 0,
								["counter"] = 2,
								["overheal"] = 0,
								["total"] = 55209,
								["c_max"] = 0,
								["id"] = 361195,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 2,
								["n_curado"] = 55209,
								["absorbed"] = 0,
							},
							[390941] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 64644,
								["targets"] = {
									["Allegory"] = 64644,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 64644,
								["c_max"] = 0,
								["id"] = 390941,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_curado"] = 64644,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["absorbed"] = 0,
							},
							[361509] = {
								["c_amt"] = 1,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Allegory"] = 44546,
								},
								["n_max"] = 45330,
								["targets"] = {
									["Allegory"] = 224923,
								},
								["n_min"] = 0,
								["counter"] = 5,
								["overheal"] = 44546,
								["total"] = 224923,
								["c_max"] = 90892,
								["id"] = 361509,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 90892,
								["n_amt"] = 4,
								["n_curado"] = 134031,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[355916] = {
								["c_amt"] = 1,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Allegory"] = 4259,
								},
								["n_max"] = 0,
								["targets"] = {
									["Allegory"] = 31251,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 4259,
								["total"] = 31251,
								["c_max"] = 31251,
								["id"] = 355916,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 31251,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["start_time"] = 1675299570,
					["spec"] = 1467,
					["custom"] = 0,
					["last_event"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.037588,
					["delay"] = 0,
					["healing_from"] = {
						["Allegory"] = true,
					},
				}, -- [1]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
						["Scahra"] = 0,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "DEMONHUNTER",
					["totalover"] = 0.002524,
					["total_without_pet"] = 0.002524,
					["total"] = 0.002524,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["isTank"] = true,
					["serial"] = "Player-580-08C239B5",
					["totalabsorb"] = 0.002524,
					["last_hps"] = 0,
					["targets"] = {
						["Scahra"] = 0,
					},
					["totalover_without_pet"] = 0.002524,
					["healing_taken"] = 0.002524,
					["end_time"] = 1675367146,
					["healing_from"] = {
					},
					["last_event"] = 0,
					["nome"] = "Scahra",
					["spells"] = {
						["_ActorTable"] = {
							[210042] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 210042,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[203794] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 203794,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[228477] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 228477,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[213011] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 213011,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[212106] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 212106,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[227255] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 227255,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[350631] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 350631,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
							[143924] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["Scahra"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["Scahra"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 143924,
								["targets_absorbs"] = {
								},
								["c_min"] = 0,
								["c_curado"] = 0,
								["n_amt"] = 0,
								["n_curado"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["totaldenied"] = 0.002524,
					["aID"] = "580-08C239B5",
					["custom"] = 0,
					["tipo"] = 2,
					["spec"] = 581,
					["start_time"] = 1675367143,
					["delay"] = 0,
					["heal_enemy_amt"] = 0,
				}, -- [2]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 0.004735,
					["resource"] = 0.023313,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["classe"] = "EVOKER",
					["totalover"] = 0.004735,
					["total"] = 0.004735,
					["nome"] = "Allegory",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["spec"] = 1467,
					["alternatepower"] = 0.004735,
					["last_event"] = 0,
					["tipo"] = 3,
					["flag_original"] = 1300,
					["aID"] = "580-0A6159F7",
					["serial"] = "Player-580-0A6159F7",
					["passiveover"] = 0.004735,
				}, -- [1]
				{
					["received"] = 0.00422,
					["resource"] = 3862.282135999999,
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["targets"] = {
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "DEMONHUNTER",
					["totalover"] = 0.00422,
					["resource_type"] = 17,
					["spec"] = 581,
					["passiveover"] = 0.00422,
					["nome"] = "Scahra",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["alternatepower"] = 0.00422,
					["last_event"] = 0,
					["flag_original"] = 1298,
					["tipo"] = 3,
					["aID"] = "580-08C239B5",
					["isTank"] = true,
					["serial"] = "Player-580-08C239B5",
					["total"] = 0.00422,
				}, -- [2]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[370898] = {
								["actived_at"] = 1675435562,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 44,
								["id"] = 370898,
								["uptime"] = 147,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[355689] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 5,
								["id"] = 355689,
								["uptime"] = 24,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[353759] = {
								["refreshamt"] = 0,
								["appliedamt"] = 3,
								["activedamt"] = -1,
								["uptime"] = 2,
								["id"] = 353759,
								["actived_at"] = 1675435553,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[356995] = {
								["refreshamt"] = 4,
								["appliedamt"] = 21,
								["activedamt"] = -10,
								["uptime"] = 106,
								["id"] = 356995,
								["actived_at"] = 10052206995,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[357209] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 18,
								["id"] = 357209,
								["uptime"] = 148,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[370452] = {
								["actived_at"] = 3350871358,
								["refreshamt"] = 0,
								["activedamt"] = -2,
								["appliedamt"] = 11,
								["id"] = 370452,
								["uptime"] = 47,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["cooldowns_defensive"] = 4.010021999999999,
					["buff_uptime"] = 1398,
					["classe"] = "EVOKER",
					["cooldowns_defensive_targets"] = {
						["--x--x--"] = 4,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[386907] = {
								["id"] = 386907,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[390899] = {
								["refreshamt"] = 0,
								["activedamt"] = 27,
								["appliedamt"] = 27,
								["id"] = 390899,
								["uptime"] = 404,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[357210] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 357210,
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[372470] = {
								["refreshamt"] = 0,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = 372470,
								["uptime"] = 86,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[381748] = {
								["id"] = 381748,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[303601] = {
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = 303601,
								["uptime"] = 54,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[374348] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 374348,
								["uptime"] = 8,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[363916] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 363916,
								["uptime"] = 36,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[372014] = {
								["refreshamt"] = 0,
								["activedamt"] = 28,
								["appliedamt"] = 28,
								["id"] = 372014,
								["uptime"] = 22,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[142073] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = 142073,
								["actived_at"] = 1675299488,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[358267] = {
								["refreshamt"] = 1,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = 358267,
								["uptime"] = 17,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[375087] = {
								["refreshamt"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 375087,
								["uptime"] = 93,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[375802] = {
								["refreshamt"] = 1,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = 375802,
								["uptime"] = 22,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[374349] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 374349,
								["uptime"] = 16,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[368901] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = 368901,
								["actived_at"] = 1675435073,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[388599] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = 388599,
								["actived_at"] = 1675435073,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[387678] = {
								["refreshamt"] = 0,
								["activedamt"] = 25,
								["appliedamt"] = 25,
								["id"] = 387678,
								["uptime"] = 27,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[375342] = {
								["refreshamt"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = 375342,
								["uptime"] = 72,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[383813] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 383813,
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[370553] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 370553,
								["uptime"] = 22,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[359618] = {
								["refreshamt"] = 10,
								["activedamt"] = 16,
								["appliedamt"] = 16,
								["id"] = 359618,
								["uptime"] = 41,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[390936] = {
								["refreshamt"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = 390936,
								["uptime"] = 56,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[186403] = {
								["refreshamt"] = 0,
								["activedamt"] = 27,
								["appliedamt"] = 27,
								["id"] = 186403,
								["uptime"] = 404,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[386441] = {
								["id"] = 386441,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[389820] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = 389820,
								["uptime"] = 1,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 474,
					["pets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["spec"] = 1467,
					["grupo"] = true,
					["spell_cast"] = {
						[386907] = 0,
						[26624] = 4,
						[357210] = 2,
						[362969] = 9,
						[357211] = 24,
						[361195] = 2,
						[356995] = 25,
						[363916] = 3,
						[374348] = 1,
						[360995] = 2,
						[368970] = 1,
						[358733] = 0,
						[361469] = 27,
						[26649] = 1,
						[358385] = 1,
						[370452] = 11,
						[370553] = 2,
						[361509] = 5,
						[375087] = 6,
						[355913] = 1,
						[26374] = 5,
						[358267] = 2,
					},
					["aID"] = "580-0A6159F7",
					["buff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["nome"] = "Allegory",
					["tipo"] = 4,
					["serial"] = "Player-580-0A6159F7",
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[363916] = {
								["id"] = 363916,
								["targets"] = {
									["--x--x--"] = 3,
								},
								["counter"] = 3,
							},
							[374348] = {
								["id"] = 374348,
								["targets"] = {
									["--x--x--"] = 1,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 9,
					},
				}, -- [1]
				{
					["fight_component"] = true,
					["nome"] = "Trickclaw Mystic",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["spell_cast"] = {
						[382249] = 12,
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["pets"] = {
					},
					["aID"] = "185528",
					["serial"] = "Creature-0-4238-2520-25640-185528-00005B0955",
					["monster"] = true,
				}, -- [2]
				{
					["monster"] = true,
					["nome"] = "Bracken Warscourge",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[387796] = 1,
						[382555] = 1,
					},
					["classe"] = "UNKNOW",
					["tipo"] = 4,
					["last_event"] = 0,
					["pets"] = {
					},
					["aID"] = "185529",
					["serial"] = "Creature-0-4238-2520-25640-185529-0003DB0953",
					["fight_component"] = true,
				}, -- [3]
				{
					["fight_component"] = true,
					["nome"] = "Bonebolt Hunter",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["spell_cast"] = {
						[382620] = 2,
					},
					["aID"] = "185534",
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-4238-2520-25640-185534-00005B0953",
					["monster"] = true,
				}, -- [4]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[204598] = {
								["id"] = 204598,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[207771] = {
								["id"] = 207771,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1490] = {
								["id"] = 1490,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[394958] = {
								["id"] = 394958,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[247456] = {
								["id"] = 247456,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["cooldowns_defensive"] = 0,
					["pets"] = {
					},
					["aID"] = "580-08C239B5",
					["cooldowns_defensive_targets"] = {
						["Rubbery Fish Head"] = 0,
						["Bisquius"] = 0,
						["Tough Carp"] = 0,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[187827] = {
								["id"] = 187827,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[390224] = {
								["id"] = 390224,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[212988] = {
								["id"] = 212988,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[391171] = {
								["id"] = 391171,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[391172] = {
								["id"] = 391172,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[347765] = {
								["id"] = 347765,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[387678] = {
								["id"] = 387678,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[258920] = {
								["id"] = 258920,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[391430] = {
								["id"] = 391430,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[383169] = {
								["id"] = 383169,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[203981] = {
								["id"] = 203981,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[377453] = {
								["id"] = 377453,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[391166] = {
								["id"] = 391166,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[212084] = {
								["id"] = 212084,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[386441] = {
								["id"] = 386441,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[383756] = {
								["id"] = 383756,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[203819] = {
								["id"] = 203819,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[386907] = {
								["id"] = 386907,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 0,
					["serial"] = "Player-580-08C239B5",
					["classe"] = "DEMONHUNTER",
					["debuff_uptime_targets"] = {
					},
					["spec"] = 581,
					["grupo"] = true,
					["spell_cast"] = {
						[386907] = 0,
						[204513] = 0,
						[204021] = 0,
						[377453] = 0,
						[225919] = 0,
						[228477] = 0,
						[386933] = 0,
						[203720] = 0,
						[204255] = 0,
						[346665] = 0,
						[258920] = 0,
						[247454] = 0,
						[225921] = 0,
						[263642] = 0,
						[212084] = 0,
						[328957] = 0,
						[204157] = 0,
					},
					["buff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["buff_uptime"] = 0,
					["isTank"] = true,
					["cooldowns_defensive_spells"] = {
						["_ActorTable"] = {
							[204021] = {
								["id"] = 204021,
								["targets"] = {
									["Rubbery Fish Head"] = 0,
									["Bisquius"] = 0,
									["Tough Carp"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["nome"] = "Scahra",
				}, -- [5]
				{
					["flag_original"] = 2600,
					["aID"] = "65310",
					["nome"] = "Turnip Punching Bag",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["pets"] = {
					},
					["tipo"] = 4,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["serial"] = "Creature-0-3102-2444-1588-65310-00005B0769",
					["spell_cast"] = {
						[127801] = 0,
					},
				}, -- [6]
				{
					["fight_component"] = true,
					["nome"] = "Worldbreaker Smith",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["flag_original"] = 2632,
					["aID"] = "185591",
					["classe"] = "UNKNOW",
					["spell_cast"] = {
						[390927] = 10,
						[367974] = 1,
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-185591-00005D1725",
					["tipo"] = 4,
				}, -- [7]
				{
					["flag_original"] = 68168,
					["nome"] = "Worldbreaker Brute",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["spell_cast"] = {
						[387398] = 19,
					},
					["last_event"] = 0,
					["fight_component"] = true,
					["tipo"] = 4,
					["pets"] = {
					},
					["aID"] = "185589",
					["serial"] = "Creature-0-3896-2444-650-185589-00005D1849",
					["classe"] = "UNKNOW",
				}, -- [8]
				{
					["flag_original"] = 2632,
					["nome"] = "Worldbreaker Guard",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["spell_cast"] = {
						[377609] = 14,
					},
					["last_event"] = 0,
					["fight_component"] = true,
					["tipo"] = 4,
					["pets"] = {
					},
					["aID"] = "185594",
					["serial"] = "Creature-0-3896-2444-650-185594-00005D1727",
					["classe"] = "UNKNOW",
				}, -- [9]
				{
					["monster"] = true,
					["nome"] = "Djaradin Crustshaper",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["fight_component"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["last_event"] = 0,
					["spell_cast"] = {
						[369055] = 26,
						[369193] = 1,
					},
					["tipo"] = 4,
					["serial"] = "Creature-0-3896-2444-650-186110-00005D059F",
					["aID"] = "186110",
				}, -- [10]
				{
					["monster"] = true,
					["nome"] = "Worldbreaker Cultist",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 2632,
					["pets"] = {
					},
					["fight_component"] = true,
					["last_event"] = 0,
					["tipo"] = 4,
					["spell_cast"] = {
						[387388] = 48,
					},
					["aID"] = "185595",
					["serial"] = "Creature-0-3896-2444-650-185595-00005D0A56",
					["classe"] = "UNKNOW",
				}, -- [11]
				{
					["fight_component"] = true,
					["nome"] = "Qalashi Necksnapper",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["monster"] = true,
					["pets"] = {
					},
					["flag_original"] = 2632,
					["aID"] = "186109",
					["classe"] = "UNKNOW",
					["spell_cast"] = {
						[369788] = 4,
						[369751] = 1,
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-186109-00005D0564",
					["tipo"] = 4,
				}, -- [12]
				{
					["fight_component"] = true,
					["nome"] = "Weaponmaster Vordak",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[387410] = 3,
					},
					["aID"] = "186219",
					["monster"] = true,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-186219-00005D1ED4",
					["tipo"] = 4,
				}, -- [13]
				{
					["fight_component"] = true,
					["nome"] = "Worldbreaker Bulwark",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[387410] = 1,
					},
					["aID"] = "185596",
					["monster"] = true,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-185596-00005D1ED4",
					["tipo"] = 4,
				}, -- [14]
				{
					["fight_component"] = true,
					["nome"] = "Cygenoth",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[394262] = 2,
						[394275] = 2,
						[394167] = 3,
					},
					["aID"] = "185660",
					["monster"] = true,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3896-2444-650-185660-00005D1ED4",
					["tipo"] = 4,
				}, -- [15]
				{
					["fight_component"] = true,
					["nome"] = "Omen",
					["GetSpellContainer"] = nil --[[ skipped inline function ]],
					["flag_original"] = 68168,
					["spell_cast"] = {
						[104903] = 3,
						[26540] = 2,
					},
					["aID"] = "15467",
					["monster"] = true,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-1469-1-218-15467-00005D2757",
					["tipo"] = 4,
				}, -- [16]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["raid_roster_indexed"] = {
		},
		["spells_cast_timeline"] = {
		},
		["tempo_start"] = 1675299158,
		["cleu_timeline"] = {
		},
		["alternate_power"] = {
			["Dragonarion-Lordaeron"] = {
				["total"] = 7,
				["last"] = 0,
			},
			["Allegory"] = {
				["total"] = 0,
				["last"] = 0,
			},
		},
		["combat_counter"] = 715,
		["totals"] = {
			12040506.422233, -- [1]
			420456.9469570001, -- [2]
			{
				-0.06732299999995917, -- [1]
				[0] = 0.03200399999999998,
				["alternatepower"] = 0,
				[3] = -0.003651000000000001,
				[6] = -0.003207000000003291,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 4.008679,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "01:58:08",
		["end_time"] = 398987.441,
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			6601801.138338998, -- [1]
			420457.030006, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 4.008679,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["frags"] = {
		},
		["hasSaved"] = true,
		["segments_added"] = {
			{
				["elapsed"] = 28.74199999996927,
				["type"] = 0,
				["name"] = "Omen",
				["clock"] = "16:25:20",
			}, -- [1]
			{
				["elapsed"] = 20.7839999999851,
				["type"] = 0,
				["name"] = "Minion of Omen",
				["clock"] = "16:21:23",
			}, -- [2]
			{
				["elapsed"] = 4.657999999995809,
				["type"] = 0,
				["name"] = "Minion of Omen",
				["clock"] = "16:18:07",
			}, -- [3]
			{
				["elapsed"] = 61.82399999996414,
				["type"] = 0,
				["name"] = "Cygenoth",
				["clock"] = "15:51:21",
			}, -- [4]
			{
				["elapsed"] = 19.69999999995343,
				["type"] = 0,
				["name"] = "Worldbreaker Bulwark",
				["clock"] = "15:50:36",
			}, -- [5]
			{
				["elapsed"] = 51.75899999996182,
				["type"] = 0,
				["name"] = "Weaponmaster Vordak",
				["clock"] = "15:49:31",
			}, -- [6]
			{
				["elapsed"] = 4.875,
				["type"] = 0,
				["name"] = "Worldbreaker Cultist",
				["clock"] = "15:49:08",
			}, -- [7]
			{
				["elapsed"] = 14.42399999999907,
				["type"] = 0,
				["name"] = "Qalashi Necksnapper",
				["clock"] = "15:47:22",
			}, -- [8]
			{
				["elapsed"] = 24.5,
				["type"] = 0,
				["name"] = "Worldbreaker Cultist",
				["clock"] = "15:46:55",
			}, -- [9]
			{
				["elapsed"] = 21.44099999999162,
				["type"] = 0,
				["name"] = "Worldbreaker Brute",
				["clock"] = "15:46:21",
			}, -- [10]
			{
				["elapsed"] = 5.732999999949243,
				["type"] = 0,
				["name"] = "Worldbreaker Cultist",
				["clock"] = "15:46:10",
			}, -- [11]
			{
				["elapsed"] = 7.180999999982305,
				["type"] = 0,
				["name"] = "Lava Slug",
				["clock"] = "15:46:00",
			}, -- [12]
			{
				["elapsed"] = 5.084000000031665,
				["type"] = 0,
				["name"] = "Worldbreaker Smith",
				["clock"] = "15:45:53",
			}, -- [13]
			{
				["elapsed"] = 5.376000000047498,
				["type"] = 0,
				["name"] = "Worldbreaker Cultist",
				["clock"] = "15:45:31",
			}, -- [14]
			{
				["elapsed"] = 4.377999999967869,
				["type"] = 0,
				["name"] = "Worldbreaker Guard",
				["clock"] = "15:45:13",
			}, -- [15]
			{
				["elapsed"] = 7.850000000034925,
				["type"] = 0,
				["name"] = "Worldbreaker Brute",
				["clock"] = "15:44:50",
			}, -- [16]
			{
				["elapsed"] = 6.916000000026543,
				["type"] = 0,
				["name"] = "Swooping Snitch",
				["clock"] = "15:44:02",
			}, -- [17]
			{
				["elapsed"] = 8.548999999999069,
				["type"] = 0,
				["name"] = "Worldbreaker Smith",
				["clock"] = "15:43:41",
			}, -- [18]
			{
				["elapsed"] = 15.9199999999837,
				["type"] = 0,
				["name"] = "Worldbreaker Guard",
				["clock"] = "15:40:04",
			}, -- [19]
			{
				["elapsed"] = 12.25900000002002,
				["type"] = 0,
				["name"] = "Worldbreaker Smith",
				["clock"] = "15:39:39",
			}, -- [20]
			{
				["elapsed"] = 13.28299999999581,
				["type"] = 0,
				["name"] = "Worldbreaker Brute",
				["clock"] = "15:39:01",
			}, -- [21]
			{
				["elapsed"] = 14.25,
				["type"] = 0,
				["name"] = "Swooping Snitch",
				["clock"] = "15:37:53",
			}, -- [22]
			{
				["elapsed"] = 1.448000000033062,
				["type"] = 0,
				["name"] = "Unstable Elemental",
				["clock"] = "02:09:50",
			}, -- [23]
			{
				["elapsed"] = 1.35899999999674,
				["type"] = 0,
				["name"] = "Unstable Elemental",
				["clock"] = "02:09:33",
			}, -- [24]
			{
				["elapsed"] = 1.054000000003725,
				["type"] = 0,
				["name"] = "Unstable Elemental",
				["clock"] = "02:09:16",
			}, -- [25]
			{
				["elapsed"] = 28.00399999995716,
				["type"] = 5,
				["name"] = "Trash Cleanup",
				["clock"] = "01:59:39",
			}, -- [26]
			{
				["elapsed"] = 14.01999999996042,
				["type"] = 5,
				["name"] = "Trash Cleanup",
				["clock"] = "01:58:08",
			}, -- [27]
		},
		["data_fim"] = "16:25:48",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["start_time"] = 398582.0700000002,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["last_events_tables"] = {
		},
	},
	["local_instances_config"] = {
		{
			["modo"] = 2,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["segment"] = 0,
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -140.5829467773438,
					["x"] = 454.6597900390625,
					["w"] = 230.1668701171875,
					["h"] = 18.85465431213379,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["combat_counter"] = 745,
	["last_realversion"] = 148,
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-580-0A6159F7"] = 1467,
	},
}
