
ElvDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Farfarella - Blackmoore"] = "Default",
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["class"] = {
		["Blackmoore"] = {
			["Taifunari"] = "MAGE",
			["Farfarella"] = "DRUID",
		},
	},
	["profiles"] = {
		["Default"] = {
			["convertPages"] = true,
			["dbConverted"] = 12.21,
			["actionbar"] = {
				["bar6"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 6,
					["buttons"] = 6,
				},
				["microbar"] = {
					["buttons"] = 11,
				},
				["bar5"] = {
					["enabled"] = false,
					["buttonsPerRow"] = 12,
					["buttons"] = 12,
				},
			},
		},
	},
	["gold"] = {
		["Blackmoore"] = {
			["Taifunari"] = 329355,
			["Farfarella"] = 0,
		},
	},
	["global"] = {
		["nameplate"] = {
			["filters"] = {
				["ElvUI_NonTarget"] = {
				},
				["ElvUI_Explosives"] = {
				},
				["ElvUI_Target"] = {
				},
				["ElvUI_Boss"] = {
				},
			},
		},
	},
	["faction"] = {
		["Blackmoore"] = {
			["Taifunari"] = "Alliance",
			["Farfarella"] = "Alliance",
		},
	},
	["serverID"] = {
		[580] = {
			["Blackmoore"] = true,
		},
	},
	["LuaErrorDisabledAddOns"] = {
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Taifunari - Blackmoore",
		["Farfarella - Blackmoore"] = "Farfarella - Blackmoore",
	},
	["profiles"] = {
		["Taifunari - Blackmoore"] = {
		},
		["Farfarella - Blackmoore"] = {
			["install_complete"] = 12.21,
		},
	},
}
