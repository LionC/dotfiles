
PlaterDBChr = {
	["first_run2"] = {
		["Player-580-081A50F9"] = true,
	},
	["buffsBanned"] = {
	},
	["debuffsBanned"] = {
	},
	["spellRangeCheck"] = {
		[269] = "Crackling Jade Lightning",
		[270] = "Crackling Jade Lightning",
		[268] = "Provoke",
	},
}
