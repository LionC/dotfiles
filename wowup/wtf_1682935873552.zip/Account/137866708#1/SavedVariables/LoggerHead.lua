
LoggerHeadDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["log"] = {
				["raid"] = {
					["Vault of the Incarnates"] = {
						[15] = true,
					},
				},
				["party"] = {
					["Halls of Valor"] = {
						[23] = true,
						[8] = true,
					},
					["The Azure Vault"] = {
						[23] = true,
						[8] = true,
					},
					["Temple of the Jade Serpent"] = {
						[23] = true,
						[8] = true,
					},
					["Ruby Life Pools"] = {
						true, -- [1]
						[8] = true,
						[23] = true,
					},
					["The Nokhud Offensive"] = {
						[23] = true,
						[8] = true,
					},
					["Shadowmoon Burial Grounds"] = {
						[23] = true,
						[8] = true,
					},
				},
			},
			["version"] = 3,
			["minimap"] = {
				["minimapPos"] = 224.5102277544436,
			},
		},
	},
}
