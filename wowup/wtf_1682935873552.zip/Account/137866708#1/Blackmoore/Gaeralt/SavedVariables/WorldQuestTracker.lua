
WQTrackerDBChr = {
	["ActiveQuests"] = {
	},
}
