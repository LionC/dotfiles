
MythicDungeonToolsDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Scahra - Blackmoore",
		["Bhrian - Blackmoore"] = "Bhrian - Blackmoore",
		["Zakarum - Blackmoore"] = "Zakarum - Blackmoore",
	},
	["global"] = {
		["anchorTo"] = "BOTTOMLEFT",
		["scale"] = 1.3,
		["minimap"] = {
			["minimapPos"] = 126.4127800539624,
		},
		["MDI"] = {
		},
		["maximized"] = false,
		["presets"] = {
			[3] = {
				{
					["mdiEnabled"] = false,
					["week"] = 6,
					["value"] = {
						["currentPull"] = 1,
						["currentSublevel"] = 1,
						["pulls"] = {
							{
								["color"] = "ff3eff",
							}, -- [1]
						},
						["currentDungeonIdx"] = 3,
						["teeming"] = false,
						["selection"] = {
							1, -- [1]
						},
						["riftOffsets"] = {
							[6] = {
							},
						},
					},
					["difficulty"] = 10,
					["mdi"] = {
						["freeholdJoined"] = false,
						["freehold"] = 1,
						["beguiling"] = 1,
					},
				}, -- [1]
			},
		},
		["currentDungeonIdx"] = 3,
		["version"] = 40125,
		["xoffset"] = -192.8397369384766,
		["colorPaletteInfo"] = {
			["customPaletteValues"] = {
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [1]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [2]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [3]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [4]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [5]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [6]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [7]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [8]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [9]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [10]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [11]
				{
					1, -- [1]
					1, -- [2]
					1, -- [3]
				}, -- [12]
			},
		},
		["anchorFrom"] = "BOTTOMLEFT",
		["yoffset"] = 12.73452758789063,
	},
}
