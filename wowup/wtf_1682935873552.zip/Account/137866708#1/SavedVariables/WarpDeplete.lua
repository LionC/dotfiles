
WarpDepleteDB = {
	["global"] = {
		["mdtAlertShown"] = true,
	},
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Bhrian - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
