
TomCats_Mechagon_Character = {
	["preferences"] = {
		["TomCats-MechagonMinimapButton"] = {
			["position"] = -2.620175493122636,
		},
	},
}
