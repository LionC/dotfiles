
LoggerHeadDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Allegory - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["log"] = {
				["party"] = {
					["Brackenhide Hollow"] = {
						[23] = true,
					},
				},
			},
			["version"] = 3,
			["minimap"] = {
				["minimapPos"] = 53.33029280140884,
			},
		},
	},
}
