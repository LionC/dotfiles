
WarpDepleteDB = {
	["global"] = {
		["mdtAlertShown"] = true,
	},
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Allegory - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
