
XLootADB = {
	["namespaces"] = {
		["Group"] = {
			["profiles"] = {
				["Default"] = {
					["alert_anchor"] = {
						["visible"] = false,
					},
					["roll_anchor"] = {
						["visible"] = false,
					},
				},
			},
		},
		["Frame"] = {
		},
		["Monitor"] = {
			["profiles"] = {
				["Default"] = {
					["anchor"] = {
						["visible"] = false,
					},
				},
			},
		},
		["Master"] = {
		},
	},
	["profileKeys"] = {
		["Lionc - Blackmoore"] = "Default",
		["Xyresia - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
