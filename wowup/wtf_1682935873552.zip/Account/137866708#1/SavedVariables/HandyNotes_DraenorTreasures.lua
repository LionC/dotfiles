
DraenorTreasuresDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Xyresia - Blackmoore"] = "Default",
		["Ämelia - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
		["Lionc - Blackmoore"] = "Default",
		["Jakuup - Blackmoore"] = "Default",
		["Crayona - Blackmoore"] = "Default",
		["Lioncilu - Blackmoore"] = "Default",
		["Laeduin - Blackmoore"] = "Default",
		["Amilanoo - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
