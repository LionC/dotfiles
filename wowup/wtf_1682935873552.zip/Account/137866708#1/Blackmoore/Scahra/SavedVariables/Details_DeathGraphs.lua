
DeathGraphsDBDeaths = {
	["2635-15"] = {
		["hash"] = "2635-15",
		["type"] = "deaths",
		["name"] = "Dathea, Ascended",
		["id"] = "2635-15",
		["player_db"] = {
			["Scahra"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Scahra",
				["class"] = "DEMONHUNTER",
			},
			["Calolsito-Uldum"] = {
				["name"] = "Calolsito-Uldum",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Gorlirn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Gorlirn",
				["class"] = "PRIEST",
			},
			["Mariosnek-Ragnaros"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Mariosnek-Ragnaros",
				["class"] = "ROGUE",
			},
			["Aubry"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Aubry",
				["class"] = "PALADIN",
			},
			["Wolfankiller-Sanguino"] = {
				["name"] = "Wolfankiller-Sanguino",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Morrizane"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Morrizane",
				["class"] = "EVOKER",
			},
			["Capten-Frostwolf"] = {
				["name"] = "Capten-Frostwolf",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Nyashia-Silvermoon"] = {
				["name"] = "Nyashia-Silvermoon",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Astranith"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Astranith",
				["class"] = "DEATHKNIGHT",
			},
			["Bahyla"] = {
				["name"] = "Bahyla",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tetiro-Draenor"] = {
				["name"] = "Tetiro-Draenor",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Happenslol"] = {
				["name"] = "Happenslol",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Шадовхант-Ясеневыйлес"] = {
				["name"] = "Шадовхант-Ясеневыйлес",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Selenerah"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Selenerah",
				["class"] = "DEATHKNIGHT",
			},
			["Hakizu"] = {
				["name"] = "Hakizu",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kendrana"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana",
				["class"] = "PALADIN",
			},
			["Soosai"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Soosai",
				["class"] = "HUNTER",
			},
			["Xeonidas-Blackhand"] = {
				["name"] = "Xeonidas-Blackhand",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Caxivora"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Caxivora",
				["class"] = "DRUID",
			},
			["Auré-Kazzak"] = {
				["name"] = "Auré-Kazzak",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kêrberøs-Arygos"] = {
				["name"] = "Kêrberøs-Arygos",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Acumena"] = {
				["name"] = "Acumena",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Illusiionn-Stormscale"] = {
				["name"] = "Illusiionn-Stormscale",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["diff"] = 15,
	},
	["2587-15"] = {
		["hash"] = "2587-15",
		["type"] = "deaths",
		["name"] = "Eranog",
		["id"] = "2587-15",
		["player_db"] = {
			["Kendrana-Proudmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana-Proudmoore",
				["class"] = "PALADIN",
			},
			["Selenerah"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Selenerah",
				["class"] = "DEATHKNIGHT",
			},
			["Aspenrustle"] = {
				["name"] = "Aspenrustle",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["diff"] = 15,
	},
	["2592-15"] = {
		["hash"] = "2592-15",
		["type"] = "deaths",
		["name"] = "Sennarth, The Cold Breath",
		["id"] = "2592-15",
		["player_db"] = {
			["Scahra"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Scahra",
				["overall"] = {
				},
			},
			["Muffinform-TarrenMill"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Muffinform-TarrenMill",
				["class"] = "DRUID",
			},
			["Gorlirn"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Gorlirn",
				["overall"] = {
				},
			},
			["Soosai"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Soosai",
				["overall"] = {
				},
			},
			["Kendrana-Proudmoore"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Kendrana-Proudmoore",
				["overall"] = {
				},
			},
			["Morrizane"] = {
				["deaths"] = {
				},
				["class"] = "EVOKER",
				["name"] = "Morrizane",
				["overall"] = {
				},
			},
			["Kendrana"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana",
				["class"] = "PALADIN",
			},
			["Astranith"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Astranith",
				["overall"] = {
				},
			},
			["Caxivora"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Caxivora",
				["overall"] = {
				},
			},
			["Selenerah"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Selenerah",
				["overall"] = {
				},
			},
			["Hakizu"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Hakizu",
				["overall"] = {
				},
			},
			["Xeonidas-Blackhand"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Xeonidas-Blackhand",
				["overall"] = {
				},
			},
			["Aubry"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Aubry",
				["class"] = "PALADIN",
			},
		},
		["diff"] = 15,
	},
	["2614-14"] = {
		["hash"] = "2614-14",
		["type"] = "deaths",
		["name"] = "Broodkeeper Diurna",
		["id"] = "2614-14",
		["player_db"] = {
		},
		["diff"] = 14,
	},
	["2607-15"] = {
		["hash"] = "2607-15",
		["type"] = "deaths",
		["name"] = "Raszageth the Storm-Eater",
		["id"] = "2607-15",
		["player_db"] = {
			["Scahra"] = {
				["name"] = "Scahra",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Bahyla"] = {
				["name"] = "Bahyla",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Gorlirn"] = {
				["name"] = "Gorlirn",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Aubry"] = {
				["name"] = "Aubry",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Morrizane"] = {
				["name"] = "Morrizane",
				["class"] = "EVOKER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Selenerah"] = {
				["name"] = "Selenerah",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Xeonidas-Blackhand"] = {
				["name"] = "Xeonidas-Blackhand",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hakizu"] = {
				["name"] = "Hakizu",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Astranith"] = {
				["name"] = "Astranith",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Acumena"] = {
				["name"] = "Acumena",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Happenslol"] = {
				["name"] = "Happenslol",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["diff"] = 15,
	},
	["2587-14"] = {
		["hash"] = "2587-14",
		["type"] = "deaths",
		["name"] = "Eranog",
		["id"] = "2587-14",
		["player_db"] = {
			["Kendrana-Proudmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana-Proudmoore",
				["class"] = "PALADIN",
			},
			["Lüddl"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Lüddl",
				["class"] = "HUNTER",
			},
		},
		["diff"] = 14,
	},
	["2639-15"] = {
		["hash"] = "2639-15",
		["type"] = "deaths",
		["name"] = "Terros",
		["id"] = "2639-15",
		["player_db"] = {
			["Scahra"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Scahra",
				["class"] = "DEMONHUNTER",
			},
			["Muffinform-TarrenMill"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Muffinform-TarrenMill",
				["class"] = "DRUID",
			},
			["Gorlirn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Gorlirn",
				["class"] = "PRIEST",
			},
			["Aubry"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Aubry",
				["class"] = "PALADIN",
			},
			["Morrizane"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Morrizane",
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Astranith",
				["class"] = "DEATHKNIGHT",
			},
			["Aspenrustle"] = {
				["name"] = "Aspenrustle",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Lüddl"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Lüddl",
				["class"] = "HUNTER",
			},
			["Xeonidas-Blackhand"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Xeonidas-Blackhand",
				["class"] = "WARRIOR",
			},
			["Kendrana-Proudmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana-Proudmoore",
				["class"] = "PALADIN",
			},
			["Zimby-TwistingNether"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Zimby-TwistingNether",
				["class"] = "PRIEST",
			},
			["Trooell-Hyjal"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Trooell-Hyjal",
				["overall"] = {
				},
			},
			["Caxivora"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Caxivora",
				["class"] = "DRUID",
			},
			["Kendrana"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana",
				["class"] = "PALADIN",
			},
			["Selenerah"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Selenerah",
				["class"] = "DEATHKNIGHT",
			},
			["Hakizu"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Hakizu",
				["class"] = "MAGE",
			},
			["Soosai"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Soosai",
				["class"] = "HUNTER",
			},
		},
		["diff"] = 15,
	},
	["2590-15"] = {
		["hash"] = "2590-15",
		["type"] = "deaths",
		["name"] = "The Primal Council",
		["id"] = "2590-15",
		["player_db"] = {
			["Scahra"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Scahra",
				["class"] = "DEMONHUNTER",
			},
			["Muffinform-TarrenMill"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Muffinform-TarrenMill",
				["class"] = "DRUID",
			},
			["Bahyla"] = {
				["name"] = "Bahyla",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Gorlirn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Gorlirn",
				["class"] = "PRIEST",
			},
			["Aubry"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Aubry",
				["class"] = "PALADIN",
			},
			["Happenslol"] = {
				["name"] = "Happenslol",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Xeonidas-Blackhand"] = {
				["name"] = "Xeonidas-Blackhand",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Morrizane"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Morrizane",
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Astranith",
				["class"] = "DEATHKNIGHT",
			},
			["Selenerah"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Selenerah",
				["class"] = "DEATHKNIGHT",
			},
			["Caxivora"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Caxivora",
				["class"] = "DRUID",
			},
			["Kendrana"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana",
				["class"] = "PALADIN",
			},
			["Hakizu"] = {
				["name"] = "Hakizu",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Acumena"] = {
				["name"] = "Acumena",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Soosai"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Soosai",
				["class"] = "HUNTER",
			},
		},
		["diff"] = 15,
	},
	["2605-15"] = {
		["hash"] = "2605-15",
		["type"] = "deaths",
		["name"] = "Kurog Grimtotem",
		["id"] = "2605-15",
		["player_db"] = {
			["Scahra"] = {
				["name"] = "Scahra",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Bahyla"] = {
				["name"] = "Bahyla",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Gorlirn"] = {
				["name"] = "Gorlirn",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Aubry"] = {
				["name"] = "Aubry",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Morrizane"] = {
				["name"] = "Morrizane",
				["class"] = "EVOKER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Xeonidas-Blackhand"] = {
				["name"] = "Xeonidas-Blackhand",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hakizu"] = {
				["name"] = "Hakizu",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Acumena"] = {
				["name"] = "Acumena",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Happenslol"] = {
				["name"] = "Happenslol",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["diff"] = 15,
	},
	["2614-15"] = {
		["hash"] = "2614-15",
		["type"] = "deaths",
		["name"] = "Broodkeeper Diurna",
		["id"] = "2614-15",
		["player_db"] = {
			["Scahra"] = {
				["name"] = "Scahra",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Bahyla"] = {
				["name"] = "Bahyla",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Gorlirn"] = {
				["name"] = "Gorlirn",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Xeonidas-Blackhand"] = {
				["name"] = "Xeonidas-Blackhand",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Morrizane"] = {
				["name"] = "Morrizane",
				["class"] = "EVOKER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Aubry"] = {
				["name"] = "Aubry",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Happensbzzt"] = {
				["name"] = "Happensbzzt",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hakizu"] = {
				["name"] = "Hakizu",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Astranith"] = {
				["name"] = "Astranith",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Acumena"] = {
				["name"] = "Acumena",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Selenerah"] = {
				["name"] = "Selenerah",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["diff"] = 15,
	},
	["2607-14"] = {
		["hash"] = "2607-14",
		["type"] = "deaths",
		["name"] = "Raszageth the Storm-Eater",
		["id"] = "2607-14",
		["player_db"] = {
			["Kendrana-Proudmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kendrana-Proudmoore",
				["class"] = "PALADIN",
			},
			["Lüddl"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Lüddl",
				["class"] = "HUNTER",
			},
		},
		["diff"] = 14,
	},
}
DeathGraphsDBEndurance = {
	["2635-15"] = {
		["hash"] = "2635-15",
		["type"] = "endurance",
		["name"] = "Dathea, Ascended",
		["id"] = "2635-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 19,
				["points"] = 1860,
				["deaths"] = {
					{
						2, -- [1]
						203.8349999999991, -- [2]
						"Zephyr Slam |cFFFF3333330,120|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						192.2810000000009, -- [2]
						"Conductive Mark |cFFFF33338,072|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						127.5479999999989, -- [2]
						"Zephyr Slam |cFFFF3333364,419|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						128.6180000000004, -- [2]
						"Zephyr Slam |cFFFF3333356,570|r", -- [3]
					}, -- [4]
				},
				["class"] = "DEMONHUNTER",
			},
			["Kêrberøs-Arygos"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						6, -- [1]
						213.4189999999944, -- [2]
						"Raging Winds |cFFFF33332,131|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Gorlirn"] = {
				["encounters"] = 19,
				["points"] = 1830,
				["deaths"] = {
					{
						1, -- [1]
						112.5, -- [2]
						"Conductive Mark |cFFFF333366,525|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						134.3999999999996, -- [2]
						"Conductive Mark |cFFFF333310,257|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						122.1329999999998, -- [2]
						"Environment (Falling) |cFFFF3333161,707|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						186.7839999999997, -- [2]
						"Conductive Mark |cFFFF333331,523|r", -- [3]
					}, -- [4]
					{
						1, -- [1]
						113.6300000000047, -- [2]
						"Storm Bolt |cFFFF333320,122|r", -- [3]
					}, -- [5]
					{
						2, -- [1]
						212.3529999999737, -- [2]
						"Conductive Mark |cFFFF333314,188|r", -- [3]
					}, -- [6]
					{
						3, -- [1]
						120.9490000000224, -- [2]
						"Storm Bolt |cFFFF333312,638|r", -- [3]
					}, -- [7]
				},
				["class"] = "PRIEST",
			},
			["Mariosnek-Ragnaros"] = {
				["encounters"] = 11,
				["points"] = 1090,
				["deaths"] = {
					{
						9, -- [1]
						141.4089999999997, -- [2]
						"Conductive Mark |cFFFF333320,858|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Aubry"] = {
				["encounters"] = 19,
				["points"] = 1880,
				["deaths"] = {
					{
						1, -- [1]
						118.3130000000001, -- [2]
						"Cyclone |cFFFF333321,935|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						177.6729999999807, -- [2]
						"Storm Bolt |cFFFF333316,487|r", -- [3]
					}, -- [2]
				},
				["class"] = "PALADIN",
			},
			["Wolfankiller-Sanguino"] = {
				["encounters"] = 5,
				["points"] = 480,
				["deaths"] = {
					{
						7, -- [1]
						132.4260000000068, -- [2]
						"Conductive Mark |cFFFF333322,118|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						196.8789999999863, -- [2]
						"Cyclone |cFFFF33333,974|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Morrizane"] = {
				["encounters"] = 19,
				["points"] = 1860,
				["deaths"] = {
					{
						5, -- [1]
						188.7740000000013, -- [2]
						"Conductive Mark |cFFFF333339,483|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						140.5519999999997, -- [2]
						"Raging Tempest |cFFFF3333124,801|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						115.0770000000193, -- [2]
						"Conductive Mark |cFFFF333326,175|r", -- [3]
					}, -- [3]
					{
						3, -- [1]
						119.3180000000284, -- [2]
						"Conductive Mark |cFFFF333321,568|r", -- [3]
					}, -- [4]
				},
				["class"] = "EVOKER",
			},
			["Capten-Frostwolf"] = {
				["encounters"] = 5,
				["points"] = 480,
				["deaths"] = {
					{
						4, -- [1]
						116.9070000000065, -- [2]
						"Conductive Mark |cFFFF33338,430|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						217.6209999999846, -- [2]
						"Thunderbolt |cFFFF333324,678|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Kaéldrin-TwistingNether"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Nyashia-Silvermoon"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Astranith"] = {
				["encounters"] = 19,
				["points"] = 1820,
				["deaths"] = {
					{
						2, -- [1]
						204.8310000000001, -- [2]
						"Environment (Falling) |cFFFF3333218,375|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						138.1100000000006, -- [2]
						"Thunderbolt |cFFFF333314,896|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						129.5439999999999, -- [2]
						"Melee |cFFFF3333242,836|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						132.3340000000007, -- [2]
						"Conductive Mark |cFFFF333321,979|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						126.6570000000011, -- [2]
						"Melee |cFFFF3333181,034|r", -- [3]
					}, -- [5]
					{
						11, -- [1]
						258.7309999999998, -- [2]
						"Conductive Mark |cFFFF333320,141|r", -- [3]
					}, -- [6]
					{
						2, -- [1]
						216.4139999999898, -- [2]
						"Conductive Mark |cFFFF33336,651|r", -- [3]
					}, -- [7]
					{
						7, -- [1]
						136.7609999999986, -- [2]
						"Thunderbolt |cFFFF333347,814|r", -- [3]
					}, -- [8]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Illusiionn-Stormscale"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Alamo-Doomhammer"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Hakizu"] = {
				["encounters"] = 8,
				["points"] = 780,
				["deaths"] = {
					{
						5, -- [1]
						259.4160000000265, -- [2]
						"Raging Winds |cFFFF33331,815|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						134.3319999999949, -- [2]
						"Raging Winds |cFFFF3333483|r", -- [3]
					}, -- [2]
				},
				["class"] = "MAGE",
			},
			["Bahyla"] = {
				["encounters"] = 6,
				["points"] = 560,
				["deaths"] = {
					{
						2, -- [1]
						193.8609999999753, -- [2]
						"Cyclone |cFFFF33332,342|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						118.2670000000217, -- [2]
						"Cyclone |cFFFF33336,438|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						105.8969999999972, -- [2]
						"Conductive Mark |cFFFF33335,157|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						219.1259999999893, -- [2]
						"Thunderbolt |cFFFF333356,144|r", -- [3]
					}, -- [4]
				},
				["class"] = "HUNTER",
			},
			["Soosai"] = {
				["encounters"] = 11,
				["points"] = 1060,
				["deaths"] = {
					{
						1, -- [1]
						115.514000000001, -- [2]
						"Conductive Mark |cFFFF333363,973|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						120.9480000000003, -- [2]
						"Cyclone |cFFFF33339,009|r", -- [3]
					}, -- [2]
					{
						10, -- [1]
						215.4840000000004, -- [2]
						"Conductive Mark |cFFFF333318,581|r", -- [3]
					}, -- [3]
					{
						11, -- [1]
						195.0609999999979, -- [2]
						"Thunderbolt |cFFFF333340,350|r", -- [3]
					}, -- [4]
				},
				["class"] = "HUNTER",
			},
			["Kendrana"] = {
				["encounters"] = 12,
				["points"] = 1130,
				["deaths"] = {
					{
						3, -- [1]
						136.125, -- [2]
						"Thunderbolt |cFFFF333338,579|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						136.7150000000002, -- [2]
						"Unstable Gusts |cFFFF333372,669|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						140.9549999999999, -- [2]
						"Thunderbolt |cFFFF333342,985|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						184.4140000000007, -- [2]
						"Conductive Mark |cFFFF333319,929|r", -- [3]
					}, -- [4]
					{
						8, -- [1]
						105.5930000000008, -- [2]
						"Raging Tempest |cFFFF3333150,672|r", -- [3]
					}, -- [5]
					{
						10, -- [1]
						135.2009999999973, -- [2]
						"Raging Winds |cFFFF33331,945|r", -- [3]
					}, -- [6]
				},
				["class"] = "PALADIN",
			},
			["Шадовхант-Ясеневыйлес"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						5, -- [1]
						224.9590000000026, -- [2]
						"Raging Winds |cFFFF33331,261|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Selenerah"] = {
				["encounters"] = 11,
				["points"] = 1080,
				["deaths"] = {
					{
						2, -- [1]
						125.8760000000002, -- [2]
						"Melee |cFFFF3333168,365|r", -- [3]
					}, -- [1]
					{
						10, -- [1]
						184.5709999999999, -- [2]
						"Conductive Mark |cFFFF333317,855|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Tetiro-Draenor"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Happenslol"] = {
				["encounters"] = 8,
				["points"] = 790,
				["deaths"] = {
					{
						1, -- [1]
						118.0900000000256, -- [2]
						"Conductive Mark |cFFFF33334,098|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 8,
				["points"] = 780,
				["deaths"] = {
					{
						4, -- [1]
						185.2280000000028, -- [2]
						"Melee |cFFFF3333217,869|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						190.9629999999888, -- [2]
						"Unstable Gusts |cFFFF333336,999|r", -- [3]
					}, -- [2]
				},
				["class"] = "WARRIOR",
			},
			["Peloum-TwistingNether"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Caxivora"] = {
				["encounters"] = 11,
				["points"] = 1070,
				["deaths"] = {
					{
						4, -- [1]
						185.2120000000014, -- [2]
						"Raging Winds |cFFFF33332,006|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						203.8940000000002, -- [2]
						"Zephyr Slam |cFFFF3333185,988|r", -- [3]
					}, -- [2]
					{
						11, -- [1]
						180.0629999999983, -- [2]
						"Raging Winds |cFFFF33331,562|r", -- [3]
					}, -- [3]
				},
				["class"] = "DRUID",
			},
			["Auré-Kazzak"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Calolsito-Uldum"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						5, -- [1]
						125.8210000000254, -- [2]
						"Unstable Gusts |cFFFF333339,249|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Acumena"] = {
				["encounters"] = 7,
				["points"] = 700,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Coodlown-Kazzak"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
		},
		["diff"] = 15,
	},
	["2587-15"] = {
		["hash"] = "2587-15",
		["type"] = "endurance",
		["name"] = "Eranog",
		["id"] = "2587-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Muffinform-TarrenMill"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Gorlirn"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Soosai"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Morrizane"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Aspenrustle"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						172.9510000000009, -- [2]
						"Lava Flow (DoT) |cFFFF333316,136|r", -- [3]
					}, -- [1]
				},
				["class"] = "MONK",
			},
			["Lüddl"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Bahyla"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Hakizu"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Happenslol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Kendrana-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						2, -- [1]
						177.9449999999488, -- [2]
						"Incinerating Roar |cFFFF33335,644|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Zimby-TwistingNether"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Selenerah"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						121.6629999999996, -- [2]
						"Incinerate |cFFFF3333414,036|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Caxivora"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Aubry"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Kendrana"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Acumena"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Happensbzzt"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
		},
		["diff"] = 15,
	},
	["2592-15"] = {
		["hash"] = "2592-15",
		["type"] = "endurance",
		["name"] = "Sennarth, The Cold Breath",
		["id"] = "2592-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						281.6640000000007, -- [2]
						"Environment (Falling) |cFFFF3333520,246|r", -- [3]
					}, -- [1]
				},
			},
			["Muffinform-TarrenMill"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						142.0590000000011, -- [2]
						"Gossamer Burst |cFFFF333354,096|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Bahyla"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Gorlirn"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						80.39199999999255, -- [2]
						"Gossamer Burst |cFFFF3333130,823|r", -- [3]
					}, -- [1]
				},
			},
			["Aubry"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Happenslol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Astranith"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Morrizane"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "EVOKER",
				["deaths"] = {
				},
			},
			["Kendrana-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						1, -- [1]
						149.6160000000382, -- [2]
						"Icy Ground (DoT) |cFFFF333310,692|r", -- [3]
					}, -- [1]
				},
			},
			["Caxivora"] = {
				["encounters"] = 4,
				["points"] = 380,
				["class"] = "DRUID",
				["deaths"] = {
					{
						1, -- [1]
						147.6929999999993, -- [2]
						"Icy Ground (DoT) |cFFFF33338,587|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						268.2620000000006, -- [2]
						"Web Blast |cFFFF3333345,689|r", -- [3]
					}, -- [2]
				},
			},
			["Kendrana"] = {
				["encounters"] = 3,
				["points"] = 280,
				["deaths"] = {
					{
						1, -- [1]
						186.6190000000006, -- [2]
						"Gossamer Burst |cFFFF333398,002|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						125.7430000000004, -- [2]
						"Chilling Blast |cFFFF33338,035|r", -- [3]
					}, -- [2]
				},
				["class"] = "PALADIN",
			},
			["Selenerah"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						2, -- [1]
						125.7830000000013, -- [2]
						"Enveloping Webs |cFFFF333313,858|r", -- [3]
					}, -- [1]
				},
			},
			["Hakizu"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "MAGE",
				["deaths"] = {
					{
						1, -- [1]
						128.2519999999786, -- [2]
						"Chilling Blast |cFFFF33335,377|r", -- [3]
					}, -- [1]
				},
			},
			["Acumena"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Soosai"] = {
				["encounters"] = 4,
				["points"] = 380,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						1, -- [1]
						126.7469999999739, -- [2]
						"Enveloping Webs |cFFFF333314,035|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						222.5779999999995, -- [2]
						"Chilling Blast |cFFFF333310,832|r", -- [3]
					}, -- [2]
				},
			},
		},
		["diff"] = 15,
	},
	["2614-14"] = {
		["hash"] = "2614-14",
		["type"] = "endurance",
		["name"] = "Broodkeeper Diurna",
		["id"] = "2614-14",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Lüddl"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Selenerah"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Kendrana-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Happenslol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Astranith"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Caxivora"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Hakizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Paladiem-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Soosai"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Morrizane"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "EVOKER",
			},
		},
		["diff"] = 14,
	},
	["2607-15"] = {
		["hash"] = "2607-15",
		["type"] = "endurance",
		["name"] = "Raszageth the Storm-Eater",
		["id"] = "2607-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 17,
				["points"] = 1670,
				["deaths"] = {
					{
						3, -- [1]
						56.10000000003493, -- [2]
						"Electrified Jaws |cFFFF3333365,851|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						94.31099999998696, -- [2]
						"Melee |cFFFF3333216,306|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						293.185999999987, -- [2]
						"Electrified Jaws |cFFFF333379,299|r", -- [3]
					}, -- [3]
				},
				["class"] = "DEMONHUNTER",
			},
			["Bahyla"] = {
				["encounters"] = 17,
				["points"] = 1610,
				["deaths"] = {
					{
						3, -- [1]
						69.56300000002375, -- [2]
						"Lightning Strike |cFFFF333352,735|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						26.35800000000745, -- [2]
						"Lightning Breath |cFFFF333391,172|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						66.78200000000652, -- [2]
						"Lightning Breath |cFFFF333356,678|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						58.03099999995902, -- [2]
						"Electric Scales |cFFFF333310,042|r", -- [3]
					}, -- [4]
					{
						10, -- [1]
						170.6319999999832, -- [2]
						"Lightning Devastation |cFFFF3333163,527|r", -- [3]
					}, -- [5]
					{
						11, -- [1]
						366.4519999999902, -- [2]
						"Electric Lash (DoT) |cFFFF33338,190|r", -- [3]
					}, -- [6]
					{
						12, -- [1]
						95.07299999997485, -- [2]
						"Static Charge |cFFFF333370,667|r", -- [3]
					}, -- [7]
					{
						14, -- [1]
						65.80200000002515, -- [2]
						"Lightning Breath |cFFFF333315,692|r", -- [3]
					}, -- [8]
					{
						15, -- [1]
						241.7189999999828, -- [2]
						"Stormsurge |cFFFF333367,775|r", -- [3]
					}, -- [9]
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 17,
				["points"] = 1660,
				["deaths"] = {
					{
						3, -- [1]
						57.875, -- [2]
						"Electric Lash (DoT) |cFFFF33338,835|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						94.54200000001583, -- [2]
						"Static Charge |cFFFF333322,853|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						312.2540000000154, -- [2]
						"Electric Scales |cFFFF333313,457|r", -- [3]
					}, -- [3]
					{
						14, -- [1]
						86.08400000003166, -- [2]
						"Lightning Strike |cFFFF333328,128|r", -- [3]
					}, -- [4]
				},
				["class"] = "PRIEST",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 17,
				["points"] = 1680,
				["deaths"] = {
					{
						4, -- [1]
						155.9419999999809, -- [2]
						"Localized Storm |cFFFF333397,038|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						130.5480000000098, -- [2]
						"Localized Storm |cFFFF333382,565|r", -- [3]
					}, -- [2]
				},
				["class"] = "WARRIOR",
			},
			["Morrizane"] = {
				["encounters"] = 17,
				["points"] = 1630,
				["deaths"] = {
					{
						1, -- [1]
						84.73700000002282, -- [2]
						"Volatile Current |cFFFF333358,261|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						268.6379999999772, -- [2]
						"Stormsurge |cFFFF333330,124|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						165.4510000000009, -- [2]
						"Lightning Devastation |cFFFF3333197,055|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						176.1399999999558, -- [2]
						"Lightning Devastation |cFFFF3333186,926|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						169.9629999999888, -- [2]
						"Lightning Devastation |cFFFF3333212,204|r", -- [3]
					}, -- [5]
					{
						10, -- [1]
						269.5250000000233, -- [2]
						"Stormsurge |cFFFF333363,867|r", -- [3]
					}, -- [6]
					{
						17, -- [1]
						129.234999999986, -- [2]
						"", -- [3]
					}, -- [7]
				},
				["class"] = "EVOKER",
			},
			["Aubry"] = {
				["encounters"] = 17,
				["points"] = 1640,
				["deaths"] = {
					{
						1, -- [1]
						81.39200000005076, -- [2]
						"Electric Scales |cFFFF333311,261|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						95.0449999999837, -- [2]
						"Static Charge |cFFFF333321,895|r", -- [3]
					}, -- [2]
					{
						10, -- [1]
						268.880999999994, -- [2]
						"Scattered Charge |cFFFF333325,232|r", -- [3]
					}, -- [3]
					{
						11, -- [1]
						95.02799999999115, -- [2]
						"Static Charge |cFFFF333331,070|r", -- [3]
					}, -- [4]
					{
						12, -- [1]
						95.07299999997485, -- [2]
						"Static Charge |cFFFF33337,875|r", -- [3]
					}, -- [5]
					{
						17, -- [1]
						116.2229999999981, -- [2]
						"Electric Scales |cFFFF333311,435|r", -- [3]
					}, -- [6]
				},
				["class"] = "PALADIN",
			},
			["Selenerah"] = {
				["encounters"] = 17,
				["points"] = 1630,
				["deaths"] = {
					{
						6, -- [1]
						178.1730000000098, -- [2]
						"Storm Bolt |cFFFF333352,928|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						94.89399999997113, -- [2]
						"Static Charge |cFFFF333376,898|r", -- [3]
					}, -- [2]
					{
						11, -- [1]
						95.02799999999115, -- [2]
						"Static Charge |cFFFF333344,404|r", -- [3]
					}, -- [3]
					{
						14, -- [1]
						197.9029999999912, -- [2]
						"Lightning Devastation |cFFFF3333298,366|r", -- [3]
					}, -- [4]
					{
						15, -- [1]
						281.2939999999944, -- [2]
						"Electric Scales |cFFFF33336,954|r", -- [3]
					}, -- [5]
					{
						16, -- [1]
						164.0769999999902, -- [2]
						"Lightning Devastation |cFFFF3333209,498|r", -- [3]
					}, -- [6]
					{
						18, -- [1]
						65.67599999997765, -- [2]
						"Lightning Breath |cFFFF333358,114|r", -- [3]
					}, -- [7]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Hakizu"] = {
				["encounters"] = 17,
				["points"] = 1630,
				["deaths"] = {
					{
						1, -- [1]
						26.71900000004098, -- [2]
						"Lightning Breath |cFFFF333372,160|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						151.2229999999981, -- [2]
						"Surge |cFFFF333316,532|r", -- [3]
					}, -- [2]
					{
						8, -- [1]
						238.6149999999907, -- [2]
						"Lightning Devastation |cFFFF3333357,774|r", -- [3]
					}, -- [3]
					{
						9, -- [1]
						94.89399999997113, -- [2]
						"Static Charge |cFFFF333331,535|r", -- [3]
					}, -- [4]
					{
						15, -- [1]
						327.7069999999949, -- [2]
						"Stormsurge |cFFFF333387,402|r", -- [3]
					}, -- [5]
					{
						17, -- [1]
						27.06199999997625, -- [2]
						"Lightning Breath |cFFFF333350,050|r", -- [3]
					}, -- [6]
					{
						18, -- [1]
						94.9319999999716, -- [2]
						"Static Charge |cFFFF333395,782|r", -- [3]
					}, -- [7]
				},
				["class"] = "MAGE",
			},
			["Astranith"] = {
				["encounters"] = 17,
				["points"] = 1680,
				["deaths"] = {
					{
						8, -- [1]
						224.9500000000116, -- [2]
						"Lightning Devastation |cFFFF3333343,850|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						132.0879999999888, -- [2]
						"Localized Storm |cFFFF333327,229|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Acumena"] = {
				["encounters"] = 17,
				["points"] = 1670,
				["deaths"] = {
					{
						5, -- [1]
						84.45199999999022, -- [2]
						"Stagger |cFFFF33335,430|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						117.3339999999735, -- [2]
						"Stagger |cFFFF33335,106|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						86.53499999997439, -- [2]
						"Electrified Jaws |cFFFF3333132,483|r", -- [3]
					}, -- [3]
				},
				["class"] = "MONK",
			},
			["Happenslol"] = {
				["encounters"] = 17,
				["points"] = 1690,
				["deaths"] = {
					{
						18, -- [1]
						180.2129999999888, -- [2]
						"Lightning Devastation |cFFFF3333272,785|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
		},
		["diff"] = 15,
	},
	["2587-14"] = {
		["hash"] = "2587-14",
		["type"] = "endurance",
		["name"] = "Eranog",
		["id"] = "2587-14",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Lüddl"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						119.5520000000252, -- [2]
						"Incinerate |cFFFF3333171,675|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Selenerah"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Kendrana-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						102.6369999999879, -- [2]
						"Incinerate |cFFFF3333226,422|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Morrizane"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Caxivora"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Happenslol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Hakizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Paladiem-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Soosai"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
		},
		["diff"] = 14,
	},
	["2639-15"] = {
		["hash"] = "2639-15",
		["type"] = "endurance",
		["name"] = "Terros",
		["id"] = "2639-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						1, -- [1]
						118.8299999999999, -- [2]
						"Melee |cFFFF3333258,911|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						219.7259999999951, -- [2]
						"Melee |cFFFF3333167,845|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEMONHUNTER",
			},
			["Muffinform-TarrenMill"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Gorlirn"] = {
				["encounters"] = 10,
				["points"] = 990,
				["deaths"] = {
					{
						7, -- [1]
						170.9760000000242, -- [2]
						"Fractured Rubble |cFFFF3333163,875|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Soosai"] = {
				["encounters"] = 9,
				["points"] = 870,
				["deaths"] = {
					{
						3, -- [1]
						156.8190000000177, -- [2]
						"Seismic Assault |cFFFF333321,000|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						23.42299999995157, -- [2]
						"Seismic Assault |cFFFF333321,337|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						211.3209999999963, -- [2]
						"Seismic Assault |cFFFF333310,783|r", -- [3]
					}, -- [3]
				},
				["class"] = "HUNTER",
			},
			["Morrizane"] = {
				["encounters"] = 10,
				["points"] = 940,
				["deaths"] = {
					{
						1, -- [1]
						32, -- [2]
						"Fractured Rubble |cFFFF3333112,197|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						53.77199999999721, -- [2]
						"Rock Blast |cFFFF3333308,403|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						171.4120000000112, -- [2]
						"Fractured Rubble |cFFFF3333123,183|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						74.94599999999627, -- [2]
						"Fractured Rubble |cFFFF3333123,311|r", -- [3]
					}, -- [4]
					{
						1, -- [1]
						114.8159999999998, -- [2]
						"Concussive Slam |cFFFF3333139,130|r", -- [3]
					}, -- [5]
					{
						2, -- [1]
						116.1220000000003, -- [2]
						"Awakened Earth |cFFFF333315,962|r", -- [3]
					}, -- [6]
				},
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["encounters"] = 10,
				["points"] = 1000,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Aspenrustle"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						3, -- [1]
						72.55900000000838, -- [2]
						"Shattering Impact |cFFFF3333187,699|r", -- [3]
					}, -- [1]
				},
				["class"] = "MONK",
			},
			["Lüddl"] = {
				["encounters"] = 5,
				["points"] = 450,
				["deaths"] = {
					{
						1, -- [1]
						62.64599999994971, -- [2]
						"Seismic Assault (DoT) |cFFFF333310,909|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						19.30400000000373, -- [2]
						"Seismic Assault (DoT) |cFFFF333320,123|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						32.71799999999348, -- [2]
						"Fractured Rubble |cFFFF3333115,618|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						62.38799999991898, -- [2]
						"Seismic Assault (DoT) |cFFFF333311,437|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						15.83900000003632, -- [2]
						"Awakened Earth |cFFFF333318,383|r", -- [3]
					}, -- [5]
				},
				["class"] = "HUNTER",
			},
			["Bahyla"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Trooell-Hyjal"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DRUID",
				["deaths"] = {
					{
						7, -- [1]
						255.3379999999888, -- [2]
						"Seismic Assault |cFFFF333311,819|r", -- [3]
					}, -- [1]
				},
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 7,
				["points"] = 700,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Selenerah"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						5, -- [1]
						246.6219999999739, -- [2]
						"Rock Blast |cFFFF3333302,751|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Kendrana-Proudmoore"] = {
				["encounters"] = 6,
				["points"] = 590,
				["deaths"] = {
					{
						1, -- [1]
						52.90000000002328, -- [2]
						"Rock Blast |cFFFF3333220,523|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Zimby-TwistingNether"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						4, -- [1]
						11.80600000009872, -- [2]
						"Rock Blast |cFFFF3333286,799|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Aubry"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Kendrana"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						30.20700000000034, -- [2]
						"Shattering Impact |cFFFF3333211,833|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Hakizu"] = {
				["encounters"] = 7,
				["points"] = 680,
				["deaths"] = {
					{
						3, -- [1]
						114.8000000000466, -- [2]
						"Seismic Assault |cFFFF333311,582|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						69.54300000000512, -- [2]
						"Seismic Assault (DoT) |cFFFF333312,294|r", -- [3]
					}, -- [2]
				},
				["class"] = "MAGE",
			},
			["Caxivora"] = {
				["encounters"] = 9,
				["points"] = 880,
				["deaths"] = {
					{
						1, -- [1]
						122.8379999999997, -- [2]
						"Melee |cFFFF3333138,533|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						118.7380000000003, -- [2]
						"Melee |cFFFF3333114,977|r", -- [3]
					}, -- [2]
				},
				["class"] = "DRUID",
			},
			["Acumena"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Happenslol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
		},
		["diff"] = 15,
	},
	["2590-15"] = {
		["hash"] = "2590-15",
		["type"] = "endurance",
		["name"] = "The Primal Council",
		["id"] = "2590-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Muffinform-TarrenMill"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						96.49599999999919, -- [2]
						"Frost Spike |cFFFF333317,673|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Bahyla"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						83.96199999999953, -- [2]
						"Conductive Mark |cFFFF33333,171|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Soosai"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						3, -- [1]
						202.4560000000001, -- [2]
						"Meteor Axe |cFFFF3333253,679|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Happenslol"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Morrizane"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						2, -- [1]
						120.4549999999999, -- [2]
						"Conductive Mark |cFFFF333322,687|r", -- [3]
					}, -- [1]
				},
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						1, -- [1]
						161.2019999999902, -- [2]
						"Conductive Mark |cFFFF33335,579|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Selenerah"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Caxivora"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Kendrana"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						96.70800000000054, -- [2]
						"Slashing Blaze |cFFFF3333135,456|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Hakizu"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						1, -- [1]
						36.66300000000047, -- [2]
						"Meteor Axe |cFFFF3333256,039|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						94.56400000001304, -- [2]
						"Meteor Axe |cFFFF3333110,695|r", -- [3]
					}, -- [2]
				},
				["class"] = "MAGE",
			},
			["Acumena"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Aubry"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
		},
		["diff"] = 15,
	},
	["2605-15"] = {
		["hash"] = "2605-15",
		["type"] = "endurance",
		["name"] = "Kurog Grimtotem",
		["id"] = "2605-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Bahyla"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						1, -- [1]
						66.36600000000908, -- [2]
						"Flame Dominance |cFFFF333315,081|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						53.07699999999022, -- [2]
						"Absolute Zero |cFFFF3333141,516|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						1, -- [1]
						52.99900000001071, -- [2]
						"Absolute Zero |cFFFF3333214,830|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						53.67699999999604, -- [2]
						"Frost Dominance |cFFFF333354,380|r", -- [3]
					}, -- [2]
				},
				["class"] = "PRIEST",
			},
			["Aubry"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						251.0229999999865, -- [2]
						"Lightning Crash |cFFFF333311,533|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Morrizane"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						52.99900000001071, -- [2]
						"Absolute Zero |cFFFF3333282,936|r", -- [3]
					}, -- [1]
				},
				["class"] = "EVOKER",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Hakizu"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Astranith"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Acumena"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Happenslol"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
		},
		["diff"] = 15,
	},
	["2614-15"] = {
		["hash"] = "2614-15",
		["type"] = "endurance",
		["name"] = "Broodkeeper Diurna",
		["id"] = "2614-15",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						68.18499999999767, -- [2]
						"Greatstaff of the Broodkeeper |cFFFF33333,410|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Bahyla"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						66.36700000002747, -- [2]
						"Wildfire |cFFFF33336,494|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						328.2899999999791, -- [2]
						"Empowered Greatstaff's Wrath |cFFFF333358,291|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Aubry"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						247.265000000014, -- [2]
						"Clutchwatcher's Rage |cFFFF333353,453|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Morrizane"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "EVOKER",
			},
			["Hakizu"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						247.265000000014, -- [2]
						"Clutchwatcher's Rage |cFFFF333370,084|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Selenerah"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						4, -- [1]
						330.0829999999842, -- [2]
						"Empowered Greatstaff's Wrath |cFFFF333320,494|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Happensbzzt"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Astranith"] = {
				["encounters"] = 4,
				["points"] = 370,
				["deaths"] = {
					{
						4, -- [1]
						123.0839999999735, -- [2]
						"Greatstaff's Wrath |cFFFF333328,314|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						329.0420000000158, -- [2]
						"Empowered Greatstaff's Wrath |cFFFF333310,821|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Acumena"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						60.38400000002002, -- [2]
						"Wildfire |cFFFF33338,066|r", -- [3]
					}, -- [1]
				},
				["class"] = "MONK",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
		},
		["diff"] = 15,
	},
	["2607-14"] = {
		["hash"] = "2607-14",
		["type"] = "endurance",
		["name"] = "Raszageth the Storm-Eater",
		["id"] = "2607-14",
		["player_db"] = {
			["Scahra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Lüddl"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						97.80900000000838, -- [2]
						"Static Charge |cFFFF333317,008|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Gorlirn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Happenslol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Selenerah"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Kendrana-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						81.22299999999814, -- [2]
						"Electric Scales |cFFFF33335,997|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Paladiem-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Hakizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Caxivora"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Morrizane"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "EVOKER",
			},
			["Astranith"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Soosai"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Xeonidas-Blackhand"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
		},
		["diff"] = 14,
	},
}
DeathGraphsDBCurrent = {
	{
		["deaths"] = {
			{
				["maxhealth"] = 330080,
				["timeofdeath"] = 65.67599999997765,
				["name"] = "Selenerah",
				["events"] = {
					{
						2, -- [1]
						391054, -- [2]
						1, -- [3]
						1676581077.909, -- [4]
						0, -- [5]
						"Aubry", -- [6]
					}, -- [1]
					{
						false, -- [1]
						53365, -- [2]
						22876, -- [3]
						1676581031.956, -- [4]
						346600, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						207203, -- [2]
						903, -- [3]
						1676581032.231, -- [4]
						346600, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						48707, -- [2]
						9173, -- [3]
						1676581032.231, -- [4]
						346600, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						true, -- [1]
						381251, -- [2]
						10076, -- [3]
						1676581032.231, -- [4]
						346600, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						48707, -- [2]
						62306, -- [3]
						1676581032.557, -- [4]
						346600, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						true, -- [1]
						381613, -- [2]
						62306, -- [3]
						1676581032.557, -- [4]
						346600, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						48707, -- [2]
						52809, -- [3]
						1676581032.557, -- [4]
						346600, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						true, -- [1]
						381613, -- [2]
						52809, -- [3]
						1676581032.557, -- [4]
						346600, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						48707, -- [2]
						28153, -- [3]
						1676581032.574, -- [4]
						346600, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						true, -- [1]
						381613, -- [2]
						78340, -- [3]
						1676581032.574, -- [4]
						296413, -- [5]
						"Raszageth", -- [6]
						28153, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						true, -- [1]
						381250, -- [2]
						13434, -- [3]
						1676581032.727, -- [4]
						282979, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						true, -- [1]
						381251, -- [2]
						10076, -- [3]
						1676581032.74, -- [4]
						272903, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						355941, -- [2]
						19685, -- [3]
						1676581032.91, -- [4]
						292588, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						207203, -- [2]
						3774, -- [3]
						1676581033.237, -- [4]
						292588, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						381251, -- [2]
						10076, -- [3]
						1676581033.237, -- [4]
						286286, -- [5]
						"Raszageth", -- [6]
						3774, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						5541, -- [3]
						1676581033.394, -- [4]
						291827, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						4792, -- [3]
						1676581034.609, -- [4]
						296619, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						207203, -- [2]
						3753, -- [3]
						1676581034.738, -- [4]
						296619, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						true, -- [1]
						381250, -- [2]
						13434, -- [3]
						1676581034.738, -- [4]
						286938, -- [5]
						"Raszageth", -- [6]
						3753, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						2686, -- [3]
						1676581035.813, -- [4]
						289624, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						207203, -- [2]
						3865, -- [3]
						1676581036.735, -- [4]
						289624, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						true, -- [1]
						381250, -- [2]
						13433, -- [3]
						1676581036.735, -- [4]
						280056, -- [5]
						"Raszageth", -- [6]
						3865, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						4882, -- [3]
						1676581037.029, -- [4]
						284938, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						2088, -- [3]
						1676581038.248, -- [4]
						287026, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						207203, -- [2]
						5860, -- [3]
						1676581038.739, -- [4]
						287026, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						true, -- [1]
						381250, -- [2]
						13434, -- [3]
						1676581038.739, -- [4]
						279452, -- [5]
						"Raszageth", -- [6]
						5860, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						6, -- [1]
						377594, -- [2]
						1, -- [3]
						1676581039.569, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [28]
					{
						false, -- [1]
						143924, -- [2]
						2815, -- [3]
						1676581039.475, -- [4]
						282267, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						207203, -- [2]
						5720, -- [3]
						1676581039.835, -- [4]
						282267, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						true, -- [1]
						377597, -- [2]
						123618, -- [3]
						1676581039.835, -- [4]
						164369, -- [5]
						"Raszageth", -- [6]
						5720, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						377597, -- [2]
						123619, -- [3]
						1676581040.081, -- [4]
						40750, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						374606, -- [2]
						17365, -- [3]
						1676581040.115, -- [4]
						58115, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						true, -- [1]
						377597, -- [2]
						58114, -- [3]
						1676581040.334, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						65505, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						3, -- [1]
						48707, -- [2]
						0, -- [3]
						1676581030.989, -- [4]
						0, -- [5]
						"Selenerah", -- [6]
					}, -- [35]
				},
				["class"] = "DEATHKNIGHT",
				["timestring"] = "1m 5s",
				["time"] = 1676581040.347,
			}, -- [1]
			{
				["maxhealth"] = 281800,
				["timeofdeath"] = 94.9319999999716,
				["name"] = "Hakizu",
				["events"] = {
					{
						4, -- [1]
						381251, -- [2]
						1, -- [3]
						1676581065.299, -- [4]
						228181, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						382272, -- [2]
						504, -- [3]
						1676581065.558, -- [4]
						228685, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						11426, -- [2]
						5037, -- [3]
						1676581065.558, -- [4]
						228685, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						true, -- [1]
						381958, -- [2]
						5037, -- [3]
						1676581065.558, -- [4]
						228685, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						382272, -- [2]
						885, -- [3]
						1676581065.818, -- [4]
						229570, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						11426, -- [2]
						8848, -- [3]
						1676581065.818, -- [4]
						229570, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						true, -- [1]
						381251, -- [2]
						8848, -- [3]
						1676581065.818, -- [4]
						229570, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						382272, -- [2]
						884, -- [3]
						1676581066.3, -- [4]
						230454, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						11426, -- [2]
						8848, -- [3]
						1676581066.3, -- [4]
						230454, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						true, -- [1]
						381251, -- [2]
						8848, -- [3]
						1676581066.3, -- [4]
						230454, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						382272, -- [2]
						504, -- [3]
						1676581066.558, -- [4]
						230958, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						11426, -- [2]
						5037, -- [3]
						1676581066.558, -- [4]
						230958, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						true, -- [1]
						381958, -- [2]
						5037, -- [3]
						1676581066.558, -- [4]
						230958, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						382272, -- [2]
						885, -- [3]
						1676581066.821, -- [4]
						231843, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						11426, -- [2]
						8848, -- [3]
						1676581066.821, -- [4]
						231843, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						381251, -- [2]
						8848, -- [3]
						1676581066.821, -- [4]
						231843, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						382272, -- [2]
						415, -- [3]
						1676581066.871, -- [4]
						232258, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						11426, -- [2]
						4147, -- [3]
						1676581066.871, -- [4]
						232258, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						true, -- [1]
						381250, -- [2]
						11796, -- [3]
						1676581066.871, -- [4]
						224609, -- [5]
						"Raszageth", -- [6]
						4147, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						143924, -- [2]
						234, -- [3]
						1676581066.954, -- [4]
						224843, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						325983, -- [2]
						7889, -- [3]
						1676581067.104, -- [4]
						232732, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						381251, -- [2]
						8848, -- [3]
						1676581067.313, -- [4]
						223884, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						true, -- [1]
						381958, -- [2]
						5038, -- [3]
						1676581067.563, -- [4]
						218846, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						true, -- [1]
						381251, -- [2]
						8848, -- [3]
						1676581067.813, -- [4]
						209998, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						true, -- [1]
						381251, -- [2]
						8847, -- [3]
						1676581068.298, -- [4]
						201151, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						true, -- [1]
						381958, -- [2]
						5037, -- [3]
						1676581068.546, -- [4]
						196114, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						308, -- [3]
						1676581068.575, -- [4]
						196422, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						true, -- [1]
						381250, -- [2]
						11796, -- [3]
						1676581068.866, -- [4]
						184626, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						true, -- [1]
						381613, -- [2]
						38706, -- [3]
						1676581069.559, -- [4]
						145920, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						true, -- [1]
						381613, -- [2]
						45099, -- [3]
						1676581069.573, -- [4]
						100821, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						true, -- [1]
						381958, -- [2]
						5038, -- [3]
						1676581069.573, -- [4]
						95783, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						381613, -- [2]
						95782, -- [3]
						1676581069.573, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						12352, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Hakizu", -- [6]
					}, -- [33]
				},
				["class"] = "MAGE",
				["timestring"] = "1m 34s",
				["time"] = 1676581069.603,
			}, -- [2]
			{
				["maxhealth"] = 318200,
				["timeofdeath"] = 180.2129999999888,
				["name"] = "Happenslol",
				["events"] = {
					{
						false, -- [1]
						366155, -- [2]
						13667, -- [3]
						1676581142.609, -- [4]
						321468, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						367364, -- [2]
						4198, -- [3]
						1676581144.063, -- [4]
						325666, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						366155, -- [2]
						6346, -- [3]
						1676581144.463, -- [4]
						332012, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						true, -- [1]
						382541, -- [2]
						8504, -- [3]
						1676581144.638, -- [4]
						323508, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						true, -- [1]
						382541, -- [2]
						8503, -- [3]
						1676581144.638, -- [4]
						315005, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						367364, -- [2]
						4206, -- [3]
						1676581145.913, -- [4]
						319211, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						366155, -- [2]
						6357, -- [3]
						1676581146.297, -- [4]
						325568, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						1, -- [1]
						1856, -- [2]
						1, -- [3]
						1676581146.938, -- [4]
						325568, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581147.615, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [9]
					{
						true, -- [1]
						382541, -- [2]
						8503, -- [3]
						1676581147.629, -- [4]
						317065, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						367364, -- [2]
						1953, -- [3]
						1676581147.755, -- [4]
						319018, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						366155, -- [2]
						12691, -- [3]
						1676581148.138, -- [4]
						331709, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						1596, -- [3]
						1676581148.277, -- [4]
						333305, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						355941, -- [2]
						13935, -- [3]
						1676581148.523, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						367364, -- [2]
						3905, -- [3]
						1676581149.573, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						366155, -- [2]
						6357, -- [3]
						1676581149.949, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						355941, -- [2]
						6979, -- [3]
						1676581150.336, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						6, -- [1]
						385553, -- [2]
						3, -- [3]
						1676581150.759, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [18]
					{
						true, -- [1]
						396035, -- [2]
						12372, -- [3]
						1676581150.634, -- [4]
						321728, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						true, -- [1]
						382541, -- [2]
						17006, -- [3]
						1676581150.634, -- [4]
						304722, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						8956, -- [3]
						1676581150.696, -- [4]
						313678, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						1, -- [2]
						81415, -- [3]
						1676581150.788, -- [4]
						313678, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						367364, -- [2]
						1956, -- [3]
						1676581151.392, -- [4]
						234219, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						366155, -- [2]
						12713, -- [3]
						1676581151.763, -- [4]
						246932, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						5624, -- [3]
						1676581151.92, -- [4]
						252556, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						355941, -- [2]
						6967, -- [3]
						1676581152.164, -- [4]
						259523, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581153.274, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						7788, -- [3]
						1676581153.12, -- [4]
						267311, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						367364, -- [2]
						3906, -- [3]
						1676581153.183, -- [4]
						271217, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						366155, -- [2]
						12692, -- [3]
						1676581153.574, -- [4]
						283909, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						true, -- [1]
						396035, -- [2]
						12556, -- [3]
						1676581153.626, -- [4]
						271353, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						382541, -- [2]
						17260, -- [3]
						1676581153.626, -- [4]
						254093, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						355941, -- [2]
						6967, -- [3]
						1676581153.96, -- [4]
						261060, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						false, -- [1]
						143924, -- [2]
						11726, -- [3]
						1676581154.358, -- [4]
						272786, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						true, -- [1]
						388115, -- [2]
						272785, -- [3]
						1676581154.853, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						250410, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [35]
					{
						3, -- [1]
						1856, -- [2]
						0, -- [3]
						1676581146.938, -- [4]
						0, -- [5]
						"Happenslol", -- [6]
					}, -- [36]
				},
				["class"] = "ROGUE",
				["timestring"] = "3m 0s",
				["time"] = 1676581154.884,
			}, -- [3]
			{
				["maxhealth"] = 579905,
				["timeofdeath"] = 229.0329999999958,
				["name"] = "Scahra",
				["events"] = {
					{
						false, -- [1]
						227255, -- [2]
						35333, -- [3]
						1676581200.565, -- [4]
						482371, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						367364, -- [2]
						3905, -- [3]
						1676581200.902, -- [4]
						438226, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						true, -- [1]
						396035, -- [2]
						7287, -- [3]
						1676581201.028, -- [4]
						430939, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						true, -- [1]
						361029, -- [2]
						24635, -- [3]
						1676581201.052, -- [4]
						406304, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						1, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						394457, -- [2]
						2983, -- [3]
						1676581201.135, -- [4]
						409287, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						370971, -- [2]
						2494, -- [3]
						1676581201.135, -- [4]
						411781, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581201.367, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						9195, -- [3]
						1676581201.29, -- [4]
						420976, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [9]
					{
						false, -- [1]
						227255, -- [2]
						18961, -- [3]
						1676581201.559, -- [4]
						439937, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581201.844, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [11]
					{
						false, -- [1]
						366155, -- [2]
						6357, -- [3]
						1676581201.889, -- [4]
						446294, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						370971, -- [2]
						335, -- [3]
						1676581202.021, -- [4]
						446629, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						true, -- [1]
						361029, -- [2]
						24635, -- [3]
						1676581202.066, -- [4]
						421994, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						1, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						394457, -- [2]
						2984, -- [3]
						1676581202.124, -- [4]
						424978, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						385553, -- [2]
						43719, -- [3]
						1676581202.422, -- [4]
						381259, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						213011, -- [2]
						95, -- [3]
						1676581202.467, -- [4]
						381354, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						213011, -- [2]
						47, -- [3]
						1676581202.467, -- [4]
						381401, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						213011, -- [2]
						47, -- [3]
						1676581202.467, -- [4]
						381448, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						213011, -- [2]
						92, -- [3]
						1676581202.467, -- [4]
						381540, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						4659, -- [3]
						1676581202.512, -- [4]
						386199, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						370971, -- [2]
						2495, -- [3]
						1676581202.525, -- [4]
						388694, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						true, -- [1]
						1, -- [2]
						52014, -- [3]
						1676581202.525, -- [4]
						388694, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						227255, -- [2]
						8276, -- [3]
						1676581202.56, -- [4]
						396970, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						true, -- [1]
						1, -- [2]
						50121, -- [3]
						1676581202.582, -- [4]
						396970, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						213011, -- [2]
						1008, -- [3]
						1676581202.649, -- [4]
						397978, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						370971, -- [2]
						6724, -- [3]
						1676581202.649, -- [4]
						404702, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						367364, -- [2]
						1956, -- [3]
						1676581202.727, -- [4]
						406658, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						true, -- [1]
						361029, -- [2]
						24635, -- [3]
						1676581203.081, -- [4]
						279888, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						1, -- [8]
						true, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						394457, -- [2]
						2984, -- [3]
						1676581203.121, -- [4]
						282872, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						370971, -- [2]
						1836, -- [3]
						1676581203.357, -- [4]
						284708, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						54719, -- [3]
						1676581203.412, -- [4]
						284708, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						227255, -- [2]
						26459, -- [3]
						1676581203.559, -- [4]
						256448, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						false, -- [1]
						370971, -- [2]
						1073, -- [3]
						1676581203.619, -- [4]
						257521, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						true, -- [1]
						388115, -- [2]
						257520, -- [3]
						1676581203.682, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						121988, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [35]
					{
						3, -- [1]
						187827, -- [2]
						0, -- [3]
						1676581163.773, -- [4]
						0, -- [5]
						"Scahra", -- [6]
					}, -- [36]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "3m 49s",
				["time"] = 1676581203.704,
			}, -- [4]
			{
				["maxhealth"] = 381860,
				["timeofdeath"] = 232.4070000000065,
				["name"] = "Astranith",
				["events"] = {
					{
						false, -- [1]
						377129, -- [2]
						997, -- [3]
						1676581175.628, -- [4]
						395805, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581176.779, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						15070, -- [3]
						1676581176.603, -- [4]
						400940, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						377129, -- [2]
						1829, -- [3]
						1676581176.619, -- [4]
						400940, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581177.536, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [5]
					{
						false, -- [1]
						377129, -- [2]
						1829, -- [3]
						1676581177.618, -- [4]
						400940, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						true, -- [1]
						396035, -- [2]
						13149, -- [3]
						1676581177.706, -- [4]
						387791, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581178.01, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						8481, -- [3]
						1676581177.819, -- [4]
						396272, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						377129, -- [2]
						933, -- [3]
						1676581178.612, -- [4]
						397205, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581179.233, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [11]
					{
						false, -- [1]
						143924, -- [2]
						14074, -- [3]
						1676581179.039, -- [4]
						400940, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						377129, -- [2]
						933, -- [3]
						1676581179.618, -- [4]
						400940, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						377129, -- [2]
						1876, -- [3]
						1676581180.622, -- [4]
						400940, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						true, -- [1]
						396035, -- [2]
						13150, -- [3]
						1676581180.705, -- [4]
						387790, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						6, -- [1]
						385553, -- [2]
						1, -- [3]
						1676581181.651, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						11485, -- [3]
						1676581181.466, -- [4]
						399275, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581182.86, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [18]
					{
						false, -- [1]
						143924, -- [2]
						11718, -- [3]
						1676581182.67, -- [4]
						400940, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						373462, -- [2]
						9377, -- [3]
						1676581186.64, -- [4]
						400940, -- [5]
						"Gorlirn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						373462, -- [2]
						8861, -- [3]
						1676581197.817, -- [4]
						400940, -- [5]
						"Gorlirn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [22]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581201.844, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [23]
					{
						1, -- [1]
						48707, -- [2]
						1, -- [3]
						1676581201.716, -- [4]
						400940, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						17, -- [2]
						37080, -- [3]
						1676581203.682, -- [4]
						400940, -- [5]
						"Gorlirn", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						48707, -- [2]
						201778, -- [3]
						1676581203.682, -- [4]
						400940, -- [5]
						"Astranith", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						true, -- [1]
						388115, -- [2]
						564857, -- [3]
						1676581203.682, -- [4]
						74941, -- [5]
						"Raszageth", -- [6]
						238858, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						374606, -- [2]
						11357, -- [3]
						1676581203.736, -- [4]
						86298, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						374606, -- [2]
						11357, -- [3]
						1676581203.736, -- [4]
						97655, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						374606, -- [2]
						11357, -- [3]
						1676581203.736, -- [4]
						109012, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						374606, -- [2]
						11357, -- [3]
						1676581203.736, -- [4]
						120369, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						374606, -- [2]
						11357, -- [3]
						1676581203.736, -- [4]
						131726, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						374606, -- [2]
						113, -- [3]
						1676581203.736, -- [4]
						131839, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						false, -- [1]
						143924, -- [2]
						99, -- [3]
						1676581203.736, -- [4]
						131938, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						true, -- [1]
						396035, -- [2]
						13556, -- [3]
						1676581204.052, -- [4]
						118382, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [35]
					{
						false, -- [1]
						143924, -- [2]
						5379, -- [3]
						1676581204.939, -- [4]
						123761, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [36]
					{
						true, -- [1]
						385553, -- [2]
						55903, -- [3]
						1676581206.006, -- [4]
						67858, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [37]
					{
						true, -- [1]
						385553, -- [2]
						55904, -- [3]
						1676581206.039, -- [4]
						11954, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [38]
					{
						false, -- [1]
						143924, -- [2]
						858, -- [3]
						1676581206.147, -- [4]
						12812, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [39]
					{
						true, -- [1]
						396035, -- [2]
						12811, -- [3]
						1676581207.042, -- [4]
						1, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						339, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [40]
					{
						3, -- [1]
						48707, -- [2]
						0, -- [3]
						1676581201.716, -- [4]
						0, -- [5]
						"Astranith", -- [6]
					}, -- [41]
				},
				["class"] = "DEATHKNIGHT",
				["timestring"] = "3m 52s",
				["time"] = 1676581207.078,
			}, -- [5]
			{
				["maxhealth"] = 330080,
				["timeofdeath"] = 233.1130000000121,
				["name"] = "Selenerah",
				["events"] = {
					{
						false, -- [1]
						143924, -- [2]
						9488, -- [3]
						1676581195.616, -- [4]
						255567, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						143924, -- [2]
						10613, -- [3]
						1676581196.848, -- [4]
						266180, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						367364, -- [2]
						3556, -- [3]
						1676581197.274, -- [4]
						269736, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						207203, -- [2]
						5006, -- [3]
						1676581197.817, -- [4]
						269736, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						48707, -- [2]
						49251, -- [3]
						1676581197.817, -- [4]
						269736, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						true, -- [1]
						385553, -- [2]
						54257, -- [3]
						1676581197.817, -- [4]
						269736, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						48707, -- [2]
						54257, -- [3]
						1676581197.844, -- [4]
						269736, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						385553, -- [2]
						54257, -- [3]
						1676581197.844, -- [4]
						269736, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						48707, -- [2]
						3992, -- [3]
						1676581198.026, -- [4]
						269736, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						true, -- [1]
						396035, -- [2]
						13564, -- [3]
						1676581198.026, -- [4]
						260164, -- [5]
						"Surging Ruiner", -- [6]
						3992, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						143924, -- [2]
						5178, -- [3]
						1676581198.067, -- [4]
						265342, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						367364, -- [2]
						3556, -- [3]
						1676581199.075, -- [4]
						268898, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						4800, -- [3]
						1676581199.278, -- [4]
						273698, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						5143, -- [3]
						1676581200.501, -- [4]
						278841, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						367364, -- [2]
						3550, -- [3]
						1676581200.889, -- [4]
						282391, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						396035, -- [2]
						13563, -- [3]
						1676581201.028, -- [4]
						268828, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [17]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581201.844, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [18]
					{
						false, -- [1]
						143924, -- [2]
						2338, -- [3]
						1676581201.693, -- [4]
						271166, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						367364, -- [2]
						3557, -- [3]
						1676581202.717, -- [4]
						274723, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						243, -- [3]
						1676581202.919, -- [4]
						274966, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						396035, -- [2]
						13564, -- [3]
						1676581204.052, -- [4]
						261402, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						367364, -- [2]
						3817, -- [3]
						1676581204.521, -- [4]
						265219, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						2081, -- [3]
						1676581204.532, -- [4]
						267300, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						242, -- [3]
						1676581205.75, -- [4]
						267542, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						367364, -- [2]
						1775, -- [3]
						1676581206.346, -- [4]
						269317, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						true, -- [1]
						396035, -- [2]
						13564, -- [3]
						1676581207.042, -- [4]
						255753, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						true, -- [1]
						1, -- [2]
						73365, -- [3]
						1676581207.367, -- [4]
						255753, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						true, -- [1]
						1, -- [2]
						71646, -- [3]
						1676581207.367, -- [4]
						255753, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						true, -- [1]
						1, -- [2]
						73554, -- [3]
						1676581207.367, -- [4]
						255753, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						1874, -- [3]
						1676581207.367, -- [4]
						39062, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [31]
					{
						false, -- [1]
						53365, -- [2]
						21785, -- [3]
						1676581207.402, -- [4]
						60847, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [32]
					{
						true, -- [1]
						1, -- [2]
						64790, -- [3]
						1676581207.768, -- [4]
						60847, -- [5]
						"Surging Ruiner", -- [6]
						3944, -- [7]
						1, -- [8]
						false, -- [9]
						7505, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						false, -- [1]
						207203, -- [2]
						3944, -- [3]
						1676581207.768, -- [4]
						60847, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						3, -- [1]
						48707, -- [2]
						0, -- [3]
						1676581193.395, -- [4]
						0, -- [5]
						"Selenerah", -- [6]
					}, -- [35]
				},
				["class"] = "DEATHKNIGHT",
				["timestring"] = "3m 53s",
				["time"] = 1676581207.784,
			}, -- [6]
			{
				["maxhealth"] = 295460,
				["timeofdeath"] = 235.6410000000033,
				["name"] = "Morrizane",
				["events"] = {
					{
						false, -- [1]
						394457, -- [2]
						3102, -- [3]
						1676581201.135, -- [4]
						265924, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581201.367, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						2157, -- [3]
						1676581201.29, -- [4]
						268081, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [4]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581201.844, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [5]
					{
						4, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						268081, -- [5]
						"Surging Ruiner", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						394457, -- [2]
						3103, -- [3]
						1676581202.124, -- [4]
						271184, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						385553, -- [2]
						52821, -- [3]
						1676581202.246, -- [4]
						218363, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						1567, -- [3]
						1676581202.512, -- [4]
						219930, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						366155, -- [2]
						6611, -- [3]
						1676581202.687, -- [4]
						226541, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						367364, -- [2]
						2975, -- [3]
						1676581202.707, -- [4]
						229516, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						394457, -- [2]
						3103, -- [3]
						1676581203.121, -- [4]
						232619, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						389, -- [3]
						1676581203.736, -- [4]
						233008, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						366155, -- [2]
						8539, -- [3]
						1676581203.766, -- [4]
						241547, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						367364, -- [2]
						1779, -- [3]
						1676581203.789, -- [4]
						243326, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						396035, -- [2]
						10228, -- [3]
						1676581204.052, -- [4]
						233098, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581205.022, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						13242, -- [3]
						1676581204.939, -- [4]
						246340, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						366155, -- [2]
						6585, -- [3]
						1676581205.587, -- [4]
						252925, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						367364, -- [2]
						2970, -- [3]
						1676581205.597, -- [4]
						255895, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						81, -- [3]
						1676581206.567, -- [4]
						255976, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						396035, -- [2]
						9930, -- [3]
						1676581207.042, -- [4]
						246046, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						366155, -- [2]
						12899, -- [3]
						1676581207.402, -- [4]
						258945, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						true, -- [1]
						396038, -- [2]
						82759, -- [3]
						1676581207.709, -- [4]
						176186, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						378213, -- [2]
						15438, -- [3]
						1676581208.011, -- [4]
						191624, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						378213, -- [2]
						15438, -- [3]
						1676581208.025, -- [4]
						207062, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						6, -- [1]
						385553, -- [2]
						3, -- [3]
						1676581208.651, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [27]
					{
						false, -- [1]
						25914, -- [2]
						23329, -- [3]
						1676581208.684, -- [4]
						230391, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						366155, -- [2]
						6825, -- [3]
						1676581209.221, -- [4]
						237216, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						385375, -- [2]
						16730, -- [3]
						1676581209.478, -- [4]
						253946, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						367364, -- [2]
						7131, -- [3]
						1676581209.85, -- [4]
						261077, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						396035, -- [2]
						12413, -- [3]
						1676581210.045, -- [4]
						248664, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						143924, -- [2]
						5865, -- [3]
						1676581210.205, -- [4]
						254529, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						true, -- [1]
						1, -- [2]
						65659, -- [3]
						1676581210.284, -- [4]
						254529, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						true, -- [1]
						1, -- [2]
						65397, -- [3]
						1676581210.284, -- [4]
						254529, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [35]
					{
						true, -- [1]
						1, -- [2]
						66523, -- [3]
						1676581210.284, -- [4]
						254529, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [36]
					{
						true, -- [1]
						1, -- [2]
						66046, -- [3]
						1676581210.284, -- [4]
						254529, -- [5]
						"Oathsworn Vanguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [37]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Morrizane", -- [6]
					}, -- [38]
				},
				["class"] = "EVOKER",
				["timestring"] = "3m 55s",
				["time"] = 1676581210.312,
			}, -- [7]
			{
				["maxhealth"] = 311240,
				["timeofdeath"] = 237.8649999999907,
				["name"] = "Aubry",
				["events"] = {
					{
						false, -- [1]
						143924, -- [2]
						5738, -- [3]
						1676581180.665, -- [4]
						280857, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						true, -- [1]
						396035, -- [2]
						11610, -- [3]
						1676581180.705, -- [4]
						269247, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						6, -- [1]
						385553, -- [2]
						2, -- [3]
						1676581182.053, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [3]
					{
						false, -- [1]
						143924, -- [2]
						15518, -- [3]
						1676581181.863, -- [4]
						284765, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						6, -- [1]
						385553, -- [2]
						1, -- [3]
						1676581183.265, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						1330, -- [3]
						1676581183.086, -- [4]
						286095, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						6, -- [1]
						385553, -- [2]
						1, -- [3]
						1676581185.289, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						2016, -- [3]
						1676581185.091, -- [4]
						288111, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						5628, -- [3]
						1676581186.291, -- [4]
						293739, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						385582, -- [2]
						10576, -- [3]
						1676581190.362, -- [4]
						304315, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						143924, -- [2]
						2700, -- [3]
						1676581193.98, -- [4]
						307015, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						143924, -- [2]
						1459, -- [3]
						1676581195.207, -- [4]
						308474, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						4168, -- [3]
						1676581198.457, -- [4]
						312642, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [14]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581201.844, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [15]
					{
						4, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581201.693, -- [4]
						312642, -- [5]
						"Surging Ruiner", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						true, -- [1]
						396035, -- [2]
						12280, -- [3]
						1676581207.042, -- [4]
						300362, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						true, -- [1]
						396038, -- [2]
						81869, -- [3]
						1676581207.709, -- [4]
						218493, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						143924, -- [2]
						697, -- [3]
						1676581208.176, -- [4]
						219190, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						6, -- [1]
						385553, -- [2]
						3, -- [3]
						1676581208.651, -- [4]
						0, -- [5]
						"Stormseeker Acolyte", -- [6]
					}, -- [20]
					{
						true, -- [1]
						385553, -- [2]
						50388, -- [3]
						1676581208.74, -- [4]
						168802, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						385553, -- [2]
						50388, -- [3]
						1676581208.787, -- [4]
						118414, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						true, -- [1]
						385553, -- [2]
						50389, -- [3]
						1676581208.823, -- [4]
						68025, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						2627, -- [3]
						1676581209.392, -- [4]
						70652, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						361195, -- [2]
						125401, -- [3]
						1676581209.85, -- [4]
						196053, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						373268, -- [2]
						2853, -- [3]
						1676581209.85, -- [4]
						198906, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						183811, -- [2]
						608, -- [3]
						1676581209.865, -- [4]
						199514, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						true, -- [1]
						396035, -- [2]
						12280, -- [3]
						1676581210.045, -- [4]
						187234, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						true, -- [1]
						1, -- [2]
						57102, -- [3]
						1676581210.192, -- [4]
						187234, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						979, -- [3]
						1676581210.588, -- [4]
						131111, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						138, -- [3]
						1676581211.801, -- [4]
						131249, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						112819, -- [3]
						1676581212.186, -- [4]
						131249, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						true, -- [11]
						false, -- [12]
					}, -- [32]
					{
						true, -- [1]
						381442, -- [2]
						18429, -- [3]
						1676581212.536, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						49113, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Aubry", -- [6]
					}, -- [34]
				},
				["class"] = "PALADIN",
				["timestring"] = "3m 57s",
				["time"] = 1676581212.536,
			}, -- [8]
			{
				["maxhealth"] = 287261,
				["timeofdeath"] = 267.280999999959,
				["name"] = "Bahyla",
				["events"] = {
					{
						true, -- [1]
						396035, -- [2]
						12481, -- [3]
						1676581210.045, -- [4]
						289142, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						183811, -- [2]
						600, -- [3]
						1676581210.588, -- [4]
						289742, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						183811, -- [2]
						1186, -- [3]
						1676581211.47, -- [4]
						290928, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						true, -- [1]
						396035, -- [2]
						12106, -- [3]
						1676581213.058, -- [4]
						278805, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						6, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581213.823, -- [4]
						0, -- [5]
						"Surging Ruiner", -- [6]
					}, -- [5]
					{
						6, -- [1]
						385065, -- [2]
						1, -- [3]
						1676581213.986, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [6]
					{
						4, -- [1]
						396037, -- [2]
						1, -- [3]
						1676581213.823, -- [4]
						278805, -- [5]
						"Surging Ruiner", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						385553, -- [2]
						53952, -- [3]
						1676581215.018, -- [4]
						224835, -- [5]
						"Stormseeker Acolyte", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						true, -- [1]
						396035, -- [2]
						12106, -- [3]
						1676581216.063, -- [4]
						212729, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						true, -- [1]
						396035, -- [2]
						12106, -- [3]
						1676581219.054, -- [4]
						200614, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						true, -- [1]
						396038, -- [2]
						80708, -- [3]
						1676581219.846, -- [4]
						119906, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						true, -- [1]
						396035, -- [2]
						12106, -- [3]
						1676581222.062, -- [4]
						107783, -- [5]
						"Surging Ruiner", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						true, -- [1]
						381442, -- [2]
						68643, -- [3]
						1676581232.104, -- [4]
						39130, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						4, -- [1]
						381442, -- [2]
						1, -- [3]
						1676581232.104, -- [4]
						39130, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						true, -- [1]
						381250, -- [2]
						12480, -- [3]
						1676581232.396, -- [4]
						26650, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						4, -- [1]
						381251, -- [2]
						1, -- [3]
						1676581234.379, -- [4]
						26650, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						true, -- [1]
						381250, -- [2]
						12106, -- [3]
						1676581234.404, -- [4]
						14544, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						109304, -- [2]
						90487, -- [3]
						1676581234.672, -- [4]
						105014, -- [5]
						"Bahyla", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						1, -- [1]
						109304, -- [2]
						1, -- [3]
						1676581234.672, -- [4]
						105014, -- [5]
						"Bahyla", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						true, -- [1]
						381251, -- [2]
						9080, -- [3]
						1676581234.888, -- [4]
						95934, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						true, -- [1]
						381251, -- [2]
						9080, -- [3]
						1676581235.379, -- [4]
						86854, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						381251, -- [2]
						9080, -- [3]
						1676581235.885, -- [4]
						77774, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						true, -- [1]
						381251, -- [2]
						9080, -- [3]
						1676581236.385, -- [4]
						68694, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						true, -- [1]
						381250, -- [2]
						12106, -- [3]
						1676581236.419, -- [4]
						56588, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						6, -- [1]
						181089, -- [2]
						1, -- [3]
						1676581236.852, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [25]
					{
						true, -- [1]
						381251, -- [2]
						9080, -- [3]
						1676581236.885, -- [4]
						47508, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						true, -- [1]
						381251, -- [2]
						9080, -- [3]
						1676581237.385, -- [4]
						38428, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						true, -- [1]
						381250, -- [2]
						12106, -- [3]
						1676581238.419, -- [4]
						26322, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						6, -- [1]
						387261, -- [2]
						1, -- [3]
						1676581239.919, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [29]
					{
						true, -- [1]
						387333, -- [2]
						2320, -- [3]
						1676581239.919, -- [4]
						24002, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						true, -- [1]
						381250, -- [2]
						12105, -- [3]
						1676581240.419, -- [4]
						11897, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						387333, -- [2]
						6962, -- [3]
						1676581240.919, -- [4]
						4935, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						true, -- [1]
						387333, -- [2]
						4908, -- [3]
						1676581241.919, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						6695, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						3, -- [1]
						109304, -- [2]
						0, -- [3]
						1676581234.672, -- [4]
						0, -- [5]
						"Bahyla", -- [6]
					}, -- [34]
				},
				["class"] = "HUNTER",
				["timestring"] = "4m 27s",
				["time"] = 1676581241.952,
			}, -- [9]
			{
				["maxhealth"] = 305520,
				["timeofdeath"] = 271.780999999959,
				["name"] = "Xeonidas-Blackhand",
				["events"] = {
					{
						true, -- [1]
						381251, -- [2]
						8859, -- [3]
						1676581236.619, -- [4]
						77959, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						true, -- [1]
						381251, -- [2]
						8860, -- [3]
						1676581237.119, -- [4]
						69099, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						6089, -- [3]
						1676581237.252, -- [4]
						75188, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						1, -- [1]
						184364, -- [2]
						1, -- [3]
						1676581237.885, -- [4]
						75188, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						true, -- [1]
						381250, -- [2]
						8268, -- [3]
						1676581238.419, -- [4]
						66920, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						289, -- [3]
						1676581238.485, -- [4]
						67209, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						4, -- [1]
						381251, -- [2]
						1, -- [3]
						1676581238.885, -- [4]
						67209, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						381251, -- [2]
						6201, -- [3]
						1676581239.385, -- [4]
						61008, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						202166, -- [2]
						96234, -- [3]
						1676581239.452, -- [4]
						157242, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						3284, -- [3]
						1676581239.685, -- [4]
						160526, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						6, -- [1]
						387261, -- [2]
						1, -- [3]
						1676581239.919, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [11]
					{
						true, -- [1]
						381251, -- [2]
						6201, -- [3]
						1676581239.919, -- [4]
						154325, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						true, -- [1]
						387333, -- [2]
						1585, -- [3]
						1676581239.919, -- [4]
						152740, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						true, -- [1]
						381251, -- [2]
						6201, -- [3]
						1676581240.385, -- [4]
						146539, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						true, -- [1]
						381250, -- [2]
						8268, -- [3]
						1676581240.419, -- [4]
						138271, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						381251, -- [2]
						6202, -- [3]
						1676581240.919, -- [4]
						132069, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						true, -- [1]
						387333, -- [2]
						4755, -- [3]
						1676581240.919, -- [4]
						127314, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						true, -- [1]
						381251, -- [2]
						6201, -- [3]
						1676581241.419, -- [4]
						121113, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						true, -- [1]
						381251, -- [2]
						6202, -- [3]
						1676581241.885, -- [4]
						114911, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						true, -- [1]
						387333, -- [2]
						7924, -- [3]
						1676581241.919, -- [4]
						106987, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						true, -- [1]
						381250, -- [2]
						8268, -- [3]
						1676581242.419, -- [4]
						98719, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						387333, -- [2]
						11094, -- [3]
						1676581242.919, -- [4]
						87625, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						true, -- [1]
						387333, -- [2]
						14264, -- [3]
						1676581243.919, -- [4]
						73361, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						4, -- [1]
						381251, -- [2]
						1, -- [3]
						1676581243.952, -- [4]
						73361, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						true, -- [1]
						381250, -- [2]
						8268, -- [3]
						1676581244.452, -- [4]
						65093, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						true, -- [1]
						381251, -- [2]
						6201, -- [3]
						1676581244.452, -- [4]
						58892, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						true, -- [1]
						387333, -- [2]
						17433, -- [3]
						1676581244.919, -- [4]
						41459, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						true, -- [1]
						381251, -- [2]
						6201, -- [3]
						1676581244.952, -- [4]
						35258, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						15290, -- [2]
						10485, -- [3]
						1676581245.085, -- [4]
						45743, -- [5]
						"Gorlirn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						true, -- [1]
						381251, -- [2]
						6202, -- [3]
						1676581245.452, -- [4]
						39541, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						true, -- [1]
						387333, -- [2]
						30344, -- [3]
						1676581245.919, -- [4]
						9197, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						381251, -- [2]
						9134, -- [3]
						1676581245.952, -- [4]
						63, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						true, -- [1]
						381250, -- [2]
						62, -- [3]
						1676581246.452, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						12115, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						3, -- [1]
						184364, -- [2]
						0, -- [3]
						1676581237.885, -- [4]
						0, -- [5]
						"Xeonidas-Blackhand", -- [6]
					}, -- [34]
				},
				["class"] = "WARRIOR",
				["timestring"] = "4m 31s",
				["time"] = 1676581246.452,
			}, -- [10]
		},
		["bossname"] = "Raszageth the Storm-Eater",
		["bossicon"] = {
			0, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
			4757698, -- [5]
		},
		["date"] = 512569.447,
		["timeelapsed"] = 289.8209999999963,
	}, -- [1]
	{
		["deaths"] = {
			{
				["maxhealth"] = 281800,
				["timeofdeath"] = 27.06199999997625,
				["name"] = "Hakizu",
				["events"] = {
					{
						2, -- [1]
						391054, -- [2]
						1, -- [3]
						1676580853.822, -- [4]
						0, -- [5]
						"Aubry", -- [6]
					}, -- [1]
					{
						true, -- [1]
						381250, -- [2]
						11796, -- [3]
						1676580768.601, -- [4]
						295880, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						382272, -- [2]
						885, -- [3]
						1676580768.828, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						11426, -- [2]
						8848, -- [3]
						1676580768.828, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [4]
					{
						true, -- [1]
						381251, -- [2]
						8848, -- [3]
						1676580768.828, -- [4]
						295880, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						382272, -- [2]
						354, -- [3]
						1676580769.341, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						11426, -- [2]
						3539, -- [3]
						1676580769.341, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						381251, -- [2]
						3539, -- [3]
						1676580769.341, -- [4]
						295880, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						382272, -- [2]
						201, -- [3]
						1676580769.558, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						11426, -- [2]
						2015, -- [3]
						1676580769.558, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [10]
					{
						true, -- [1]
						381958, -- [2]
						2015, -- [3]
						1676580769.558, -- [4]
						295880, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						382272, -- [2]
						3435, -- [3]
						1676580769.558, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						11426, -- [2]
						34348, -- [3]
						1676580769.558, -- [4]
						295880, -- [5]
						"Hakizu", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						true, -- [1]
						381613, -- [2]
						43254, -- [3]
						1676580769.558, -- [4]
						286974, -- [5]
						"Raszageth", -- [6]
						34348, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						true, -- [1]
						381613, -- [2]
						11797, -- [3]
						1676580769.58, -- [4]
						275177, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						381613, -- [2]
						35623, -- [3]
						1676580769.58, -- [4]
						239554, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						true, -- [1]
						381251, -- [2]
						3539, -- [3]
						1676580769.823, -- [4]
						236015, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						true, -- [1]
						381251, -- [2]
						3539, -- [3]
						1676580770.337, -- [4]
						232476, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						true, -- [1]
						381250, -- [2]
						4718, -- [3]
						1676580770.606, -- [4]
						227758, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						true, -- [1]
						381251, -- [2]
						3539, -- [3]
						1676580770.836, -- [4]
						224219, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						361195, -- [2]
						16070, -- [3]
						1676580771.198, -- [4]
						240289, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						484, -- [3]
						1676580771.512, -- [4]
						240773, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						373268, -- [2]
						439, -- [3]
						1676580772.135, -- [4]
						241212, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						373268, -- [2]
						30953, -- [3]
						1676580772.281, -- [4]
						272165, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						325983, -- [2]
						10829, -- [3]
						1676580772.342, -- [4]
						282994, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						6, -- [1]
						377594, -- [2]
						1, -- [3]
						1676580772.567, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [26]
					{
						true, -- [1]
						381250, -- [2]
						4718, -- [3]
						1676580772.611, -- [4]
						278276, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						896, -- [3]
						1676580772.723, -- [4]
						279172, -- [5]
						"Hakizu", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						true, -- [1]
						377597, -- [2]
						43419, -- [3]
						1676580772.823, -- [4]
						235753, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						373268, -- [2]
						30953, -- [3]
						1676580772.987, -- [4]
						266706, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [30]
					{
						true, -- [1]
						377597, -- [2]
						108547, -- [3]
						1676580773.072, -- [4]
						158159, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						373268, -- [2]
						439, -- [3]
						1676580773.139, -- [4]
						158598, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						true, -- [1]
						377597, -- [2]
						108547, -- [3]
						1676580773.315, -- [4]
						50051, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						true, -- [1]
						377597, -- [2]
						50050, -- [3]
						1676580773.586, -- [4]
						1, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						58497, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Hakizu", -- [6]
					}, -- [35]
				},
				["class"] = "MAGE",
				["timestring"] = "0m 27s",
				["time"] = 1676580773.614,
			}, -- [1]
			{
				["maxhealth"] = 311240,
				["timeofdeath"] = 116.2229999999981,
				["name"] = "Aubry",
				["events"] = {
					{
						false, -- [1]
						325983, -- [2]
						13635, -- [3]
						1676580850.333, -- [4]
						243898, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						true, -- [1]
						381250, -- [2]
						11435, -- [3]
						1676580850.841, -- [4]
						232463, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						6, -- [1]
						377658, -- [2]
						1, -- [3]
						1676580851.054, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [3]
					{
						false, -- [1]
						366155, -- [2]
						11538, -- [3]
						1676580850.892, -- [4]
						244001, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						6798, -- [3]
						1676580851.23, -- [4]
						250799, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						366155, -- [2]
						5769, -- [3]
						1676580852.721, -- [4]
						256568, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						true, -- [1]
						381250, -- [2]
						11435, -- [3]
						1676580852.82, -- [4]
						245133, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						366155, -- [2]
						3035, -- [3]
						1676580853.66, -- [4]
						248168, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						390971, -- [2]
						15478, -- [3]
						1676580854.198, -- [4]
						263646, -- [5]
						"Gorlirn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						194, -- [3]
						1676580854.482, -- [4]
						263840, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						25914, -- [2]
						24192, -- [3]
						1676580854.653, -- [4]
						288032, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						true, -- [1]
						381250, -- [2]
						11435, -- [3]
						1676580854.834, -- [4]
						276597, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						325983, -- [2]
						14595, -- [3]
						1676580854.951, -- [4]
						291192, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						366155, -- [2]
						6231, -- [3]
						1676580855.484, -- [4]
						297423, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						143924, -- [2]
						2026, -- [3]
						1676580855.683, -- [4]
						299449, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						true, -- [1]
						381250, -- [2]
						11435, -- [3]
						1676580856.837, -- [4]
						288014, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						610, -- [3]
						1676580856.902, -- [4]
						288624, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						225311, -- [2]
						21739, -- [3]
						1676580856.925, -- [4]
						310363, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						6, -- [1]
						377612, -- [2]
						1, -- [3]
						1676580857.55, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [19]
					{
						true, -- [1]
						377612, -- [2]
						66713, -- [3]
						1676580857.55, -- [4]
						243650, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						4, -- [1]
						377612, -- [2]
						1, -- [3]
						1676580857.55, -- [4]
						243650, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						377612, -- [2]
						7624, -- [3]
						1676580858.067, -- [4]
						236026, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						143924, -- [2]
						5516, -- [3]
						1676580858.119, -- [4]
						241542, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						true, -- [1]
						377612, -- [2]
						7623, -- [3]
						1676580858.563, -- [4]
						233919, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						4, -- [1]
						377662, -- [2]
						1, -- [3]
						1676580858.625, -- [4]
						233919, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						true, -- [1]
						381250, -- [2]
						11435, -- [3]
						1676580858.829, -- [4]
						222484, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						true, -- [1]
						377612, -- [2]
						7624, -- [3]
						1676580859.059, -- [4]
						214860, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						true, -- [1]
						377612, -- [2]
						7623, -- [3]
						1676580859.563, -- [4]
						207237, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						143924, -- [2]
						786, -- [3]
						1676580859.747, -- [4]
						208023, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						true, -- [1]
						377612, -- [2]
						7624, -- [3]
						1676580860.063, -- [4]
						200399, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						true, -- [1]
						377612, -- [2]
						7623, -- [3]
						1676580860.564, -- [4]
						192776, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						true, -- [1]
						381250, -- [2]
						11435, -- [3]
						1676580860.838, -- [4]
						181341, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						143924, -- [2]
						94, -- [3]
						1676580860.962, -- [4]
						181435, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						false, -- [1]
						143924, -- [2]
						529, -- [3]
						1676580862.169, -- [4]
						181964, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [34]
					{
						3, -- [1]
						642, -- [2]
						0, -- [3]
						1676580839.853, -- [4]
						0, -- [5]
						"Aubry", -- [6]
					}, -- [35]
				},
				["class"] = "PALADIN",
				["timestring"] = "1m 56s",
				["time"] = 1676580862.775,
			}, -- [2]
			{
				["maxhealth"] = 295460,
				["timeofdeath"] = 129.234999999986,
				["name"] = "Morrizane",
				["events"] = {
					{
						false, -- [1]
						373268, -- [2]
						3348, -- [3]
						1676580866.747, -- [4]
						181541, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						373268, -- [2]
						1167, -- [3]
						1676580866.747, -- [4]
						182708, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						367364, -- [2]
						2919, -- [3]
						1676580866.747, -- [4]
						185627, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						373268, -- [2]
						1511, -- [3]
						1676580866.747, -- [4]
						187138, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580867.134, -- [4]
						188356, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						394457, -- [2]
						3046, -- [3]
						1676580867.134, -- [4]
						191402, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						373268, -- [2]
						5492, -- [3]
						1676580867.22, -- [4]
						196894, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						373268, -- [2]
						43272, -- [3]
						1676580867.422, -- [4]
						240166, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						367230, -- [2]
						108181, -- [3]
						1676580867.422, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						373268, -- [2]
						1123, -- [3]
						1676580867.48, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						373268, -- [2]
						1236, -- [3]
						1676580867.48, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						373268, -- [2]
						2247, -- [3]
						1676580867.67, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						373268, -- [2]
						1219, -- [3]
						1676580868.12, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						394457, -- [2]
						3046, -- [3]
						1676580868.12, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						373268, -- [2]
						5480, -- [3]
						1676580868.546, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						373268, -- [2]
						2337, -- [3]
						1676580868.556, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						367364, -- [2]
						5841, -- [3]
						1676580868.556, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						373268, -- [2]
						1356, -- [3]
						1676580868.556, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						373268, -- [2]
						1233, -- [3]
						1676580868.556, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						373268, -- [2]
						5492, -- [3]
						1676580869.021, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						373268, -- [2]
						1219, -- [3]
						1676580869.121, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						394457, -- [2]
						3046, -- [3]
						1676580869.121, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						373268, -- [2]
						2471, -- [3]
						1676580869.287, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						394457, -- [2]
						1306, -- [3]
						1676580870.138, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						367364, -- [2]
						5842, -- [3]
						1676580870.387, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						394457, -- [2]
						1304, -- [3]
						1676580871.126, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						394457, -- [2]
						1207, -- [3]
						1676580872.12, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						367364, -- [2]
						5399, -- [3]
						1676580872.197, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						394457, -- [2]
						1207, -- [3]
						1676580873.117, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						367364, -- [2]
						5400, -- [3]
						1676580874.038, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						394457, -- [2]
						1207, -- [3]
						1676580874.129, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						394457, -- [2]
						1207, -- [3]
						1676580875.129, -- [4]
						310220, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Morrizane", -- [6]
					}, -- [33]
				},
				["class"] = "EVOKER",
				["timestring"] = "2m 9s",
				["time"] = 1676580875.787,
			}, -- [3]
			{
				["maxhealth"] = 381860,
				["timeofdeath"] = 129.8520000000135,
				["name"] = "Astranith",
				["events"] = {
					{
						true, -- [1]
						377612, -- [2]
						7228, -- [3]
						1676580859.059, -- [4]
						319933, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						143924, -- [2]
						1231, -- [3]
						1676580859.338, -- [4]
						321164, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						true, -- [1]
						377612, -- [2]
						7229, -- [3]
						1676580859.563, -- [4]
						313935, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						true, -- [1]
						377612, -- [2]
						7228, -- [3]
						1676580860.063, -- [4]
						306707, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						367364, -- [2]
						2804, -- [3]
						1676580860.223, -- [4]
						309511, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						355941, -- [2]
						12092, -- [3]
						1676580860.438, -- [4]
						321603, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						183811, -- [2]
						532, -- [3]
						1676580860.524, -- [4]
						322135, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						2824, -- [3]
						1676580860.564, -- [4]
						324959, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						true, -- [1]
						377612, -- [2]
						7228, -- [3]
						1676580860.564, -- [4]
						317731, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						true, -- [1]
						381250, -- [2]
						10842, -- [3]
						1676580860.838, -- [4]
						306889, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						143924, -- [2]
						442, -- [3]
						1676580861.774, -- [4]
						307331, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						183811, -- [2]
						531, -- [3]
						1676580861.803, -- [4]
						307862, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						367364, -- [2]
						5607, -- [3]
						1676580862.031, -- [4]
						313469, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						true, -- [1]
						381250, -- [2]
						10841, -- [3]
						1676580862.843, -- [4]
						302628, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						143924, -- [2]
						2415, -- [3]
						1676580862.989, -- [4]
						305043, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						367364, -- [2]
						5607, -- [3]
						1676580863.85, -- [4]
						310650, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						1585, -- [3]
						1676580864.214, -- [4]
						312235, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						25, -- [3]
						1676580865.428, -- [4]
						312260, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						367364, -- [2]
						5607, -- [3]
						1676580865.672, -- [4]
						317867, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						143924, -- [2]
						6, -- [3]
						1676580866.635, -- [4]
						317873, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						367364, -- [2]
						5617, -- [3]
						1676580867.492, -- [4]
						323490, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						4, -- [3]
						1676580867.859, -- [4]
						323494, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						143924, -- [2]
						8, -- [3]
						1676580869.072, -- [4]
						323502, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						367364, -- [2]
						2809, -- [3]
						1676580869.313, -- [4]
						326311, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						8, -- [3]
						1676580870.313, -- [4]
						326319, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						367364, -- [2]
						5608, -- [3]
						1676580871.114, -- [4]
						331927, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						6, -- [3]
						1676580871.52, -- [4]
						331933, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						4, -- [3]
						1676580872.737, -- [4]
						331937, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						367364, -- [2]
						5608, -- [3]
						1676580872.955, -- [4]
						337545, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						2, -- [3]
						1676580873.954, -- [4]
						337547, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						367364, -- [2]
						2596, -- [3]
						1676580874.804, -- [4]
						340143, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						143924, -- [2]
						3, -- [3]
						1676580875.154, -- [4]
						340146, -- [5]
						"Astranith", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						48707, -- [2]
						0, -- [3]
						1676580802.493, -- [4]
						0, -- [5]
						"Astranith", -- [6]
					}, -- [33]
				},
				["class"] = "DEATHKNIGHT",
				["timestring"] = "2m 9s",
				["time"] = 1676580876.404,
			}, -- [4]
			{
				["maxhealth"] = 281800,
				["timeofdeath"] = 130.1520000000019,
				["name"] = "Hakizu",
				["events"] = {
					{
						false, -- [1]
						373862, -- [2]
						12161, -- [3]
						1676580862.843, -- [4]
						169079, -- [5]
						"Morrizane", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [1]
					{
						true, -- [1]
						381250, -- [2]
						12161, -- [3]
						1676580862.843, -- [4]
						169079, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						361195, -- [2]
						32139, -- [3]
						1676580864.437, -- [4]
						201218, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						false, -- [1]
						373268, -- [2]
						1431, -- [3]
						1676580864.941, -- [4]
						202649, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						false, -- [1]
						373268, -- [2]
						521, -- [3]
						1676580865.13, -- [4]
						203170, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						373268, -- [2]
						1216, -- [3]
						1676580866.129, -- [4]
						204386, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						373268, -- [2]
						1167, -- [3]
						1676580866.747, -- [4]
						205553, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						373268, -- [2]
						1219, -- [3]
						1676580867.134, -- [4]
						206772, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						373268, -- [2]
						43273, -- [3]
						1676580867.447, -- [4]
						250045, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580868.12, -- [4]
						251263, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [10]
					{
						false, -- [1]
						373268, -- [2]
						2337, -- [3]
						1676580868.556, -- [4]
						253600, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [11]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580869.121, -- [4]
						254818, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Hakizu", -- [6]
					}, -- [13]
				},
				["class"] = "MAGE",
				["timestring"] = "2m 10s",
				["time"] = 1676580876.704,
			}, -- [5]
			{
				["maxhealth"] = 305520,
				["timeofdeath"] = 130.350999999966,
				["name"] = "Xeonidas-Blackhand",
				["events"] = {
					{
						false, -- [1]
						183811, -- [2]
						530, -- [3]
						1676580861.376, -- [4]
						102337, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						183811, -- [2]
						521, -- [3]
						1676580861.427, -- [4]
						102858, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						366155, -- [2]
						6854, -- [3]
						1676580862.02, -- [4]
						109712, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						367364, -- [2]
						3084, -- [3]
						1676580862.031, -- [4]
						112796, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						3043, -- [3]
						1676580862.588, -- [4]
						115839, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						373862, -- [2]
						11811, -- [3]
						1676580862.843, -- [4]
						115839, -- [5]
						"Morrizane", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						true, -- [1]
						381250, -- [2]
						11811, -- [3]
						1676580862.843, -- [4]
						115839, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						4558, -- [3]
						1676580863.802, -- [4]
						120397, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						366155, -- [2]
						6853, -- [3]
						1676580863.826, -- [4]
						127250, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						367364, -- [2]
						3084, -- [3]
						1676580863.838, -- [4]
						130334, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						361195, -- [2]
						21000, -- [3]
						1676580864.437, -- [4]
						151334, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						373268, -- [2]
						1430, -- [3]
						1676580864.941, -- [4]
						152764, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						18, -- [3]
						1676580865.028, -- [4]
						152782, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						373268, -- [2]
						521, -- [3]
						1676580865.13, -- [4]
						153303, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						366155, -- [2]
						6854, -- [3]
						1676580865.634, -- [4]
						160157, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						367364, -- [2]
						3084, -- [3]
						1676580865.646, -- [4]
						163241, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						373268, -- [2]
						1216, -- [3]
						1676580866.129, -- [4]
						164457, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						17, -- [3]
						1676580866.236, -- [4]
						164474, -- [5]
						"Xeonidas-Blackhand", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						366155, -- [2]
						8370, -- [3]
						1676580866.747, -- [4]
						172844, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						367364, -- [2]
						3777, -- [3]
						1676580866.747, -- [4]
						176621, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						373268, -- [2]
						1167, -- [3]
						1676580866.747, -- [4]
						177788, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580867.134, -- [4]
						179006, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						373268, -- [2]
						43273, -- [3]
						1676580867.435, -- [4]
						222279, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580868.12, -- [4]
						223497, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						366155, -- [2]
						13700, -- [3]
						1676580868.546, -- [4]
						237197, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						373268, -- [2]
						2336, -- [3]
						1676580868.556, -- [4]
						239533, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						367364, -- [2]
						3084, -- [3]
						1676580868.556, -- [4]
						242617, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580869.121, -- [4]
						243835, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						366155, -- [2]
						6850, -- [3]
						1676580870.371, -- [4]
						250685, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						367364, -- [2]
						3089, -- [3]
						1676580870.387, -- [4]
						253774, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						366155, -- [2]
						11538, -- [3]
						1676580872.171, -- [4]
						265312, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						366155, -- [2]
						5769, -- [3]
						1676580874.013, -- [4]
						271081, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						184364, -- [2]
						0, -- [3]
						1676580840.064, -- [4]
						0, -- [5]
						"Xeonidas-Blackhand", -- [6]
					}, -- [33]
				},
				["class"] = "WARRIOR",
				["timestring"] = "2m 10s",
				["time"] = 1676580876.903,
			}, -- [6]
			{
				["maxhealth"] = 330080,
				["timeofdeath"] = 131.5519999999669,
				["name"] = "Selenerah",
				["events"] = {
					{
						true, -- [1]
						377612, -- [2]
						8771, -- [3]
						1676580860.564, -- [4]
						233196, -- [5]
						"Raszageth", -- [6]
						1552, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						true, -- [1]
						381250, -- [2]
						13157, -- [3]
						1676580860.838, -- [4]
						220039, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						183811, -- [2]
						536, -- [3]
						1676580861.327, -- [4]
						220575, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						143924, -- [2]
						1388, -- [3]
						1676580861.365, -- [4]
						221963, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						183811, -- [2]
						535, -- [3]
						1676580861.566, -- [4]
						222498, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						183811, -- [2]
						524, -- [3]
						1676580861.596, -- [4]
						223022, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						4, -- [1]
						381251, -- [2]
						1, -- [3]
						1676580861.916, -- [4]
						223022, -- [5]
						"Raszageth", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						381251, -- [2]
						9868, -- [3]
						1676580862.433, -- [4]
						213154, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						3495, -- [3]
						1676580862.588, -- [4]
						216649, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						207203, -- [2]
						788, -- [3]
						1676580862.843, -- [4]
						216649, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						true, -- [1]
						381250, -- [2]
						13157, -- [3]
						1676580862.843, -- [4]
						204280, -- [5]
						"Raszageth", -- [6]
						788, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						true, -- [1]
						381251, -- [2]
						9869, -- [3]
						1676580862.927, -- [4]
						194411, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						6, -- [1]
						396734, -- [2]
						1, -- [3]
						1676580863.394, -- [4]
						0, -- [5]
						"Raszageth", -- [6]
					}, -- [13]
					{
						false, -- [1]
						373862, -- [2]
						9868, -- [3]
						1676580863.427, -- [4]
						194411, -- [5]
						"Morrizane", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						true, -- [1]
						381251, -- [2]
						9868, -- [3]
						1676580863.427, -- [4]
						194411, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						143924, -- [2]
						1052, -- [3]
						1676580863.802, -- [4]
						195463, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						207203, -- [2]
						15, -- [3]
						1676580863.919, -- [4]
						195463, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						373862, -- [2]
						277, -- [3]
						1676580863.919, -- [4]
						195463, -- [5]
						"Morrizane", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						true, -- [1]
						381251, -- [2]
						9868, -- [3]
						1676580863.919, -- [4]
						185887, -- [5]
						"Raszageth", -- [6]
						292, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						true, -- [1]
						381251, -- [2]
						9868, -- [3]
						1676580864.423, -- [4]
						176019, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						207203, -- [2]
						7, -- [3]
						1676580864.927, -- [4]
						176019, -- [5]
						"Selenerah", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						true, -- [1]
						381251, -- [2]
						9869, -- [3]
						1676580864.927, -- [4]
						166157, -- [5]
						"Raszageth", -- [6]
						7, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						143924, -- [2]
						24, -- [3]
						1676580865.028, -- [4]
						166181, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						26, -- [3]
						1676580866.236, -- [4]
						166207, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						22, -- [3]
						1676580867.447, -- [4]
						166229, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						143924, -- [2]
						2, -- [3]
						1676580868.67, -- [4]
						166231, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						1, -- [3]
						1676580869.896, -- [4]
						166232, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						2, -- [3]
						1676580871.114, -- [4]
						166234, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						143924, -- [2]
						1, -- [3]
						1676580872.348, -- [4]
						166235, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						4, -- [3]
						1676580874.338, -- [4]
						166239, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						1, -- [3]
						1676580875.554, -- [4]
						166240, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						143924, -- [2]
						1, -- [3]
						1676580876.779, -- [4]
						166241, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						false, -- [1]
						143924, -- [2]
						5, -- [3]
						1676580878.004, -- [4]
						166246, -- [5]
						"Selenerah", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [33]
					{
						3, -- [1]
						48707, -- [2]
						0, -- [3]
						1676580802.562, -- [4]
						0, -- [5]
						"Selenerah", -- [6]
					}, -- [34]
				},
				["class"] = "DEATHKNIGHT",
				["timestring"] = "2m 11s",
				["time"] = 1676580878.104,
			}, -- [7]
			{
				["maxhealth"] = 579905,
				["timeofdeath"] = 131.5929999999935,
				["name"] = "Scahra",
				["events"] = {
					{
						false, -- [1]
						370971, -- [2]
						4, -- [3]
						1676580867.786, -- [4]
						607384, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						394457, -- [2]
						2663, -- [3]
						1676580868.12, -- [4]
						608906, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						370971, -- [2]
						33, -- [3]
						1676580868.284, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						227255, -- [2]
						96, -- [3]
						1676580868.496, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						213011, -- [2]
						3, -- [3]
						1676580868.957, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						370971, -- [2]
						23, -- [3]
						1676580868.957, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						394457, -- [2]
						2663, -- [3]
						1676580869.121, -- [4]
						608906, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						1, -- [2]
						1540, -- [3]
						1676580869.237, -- [4]
						608906, -- [5]
						"Wrathguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						370971, -- [2]
						5, -- [3]
						1676580869.273, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						2326, -- [3]
						1676580869.487, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						227255, -- [2]
						49, -- [3]
						1676580869.498, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						370971, -- [2]
						4, -- [3]
						1676580869.747, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						394457, -- [2]
						1141, -- [3]
						1676580870.138, -- [4]
						608906, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						true, -- [1]
						1, -- [2]
						3883, -- [3]
						1676580870.237, -- [4]
						608906, -- [5]
						"Wrathguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						370971, -- [2]
						6, -- [3]
						1676580870.273, -- [4]
						608906, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						227255, -- [2]
						10, -- [3]
						1676580870.496, -- [4]
						605039, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						561, -- [3]
						1676580870.713, -- [4]
						605600, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						213011, -- [2]
						3, -- [3]
						1676580870.964, -- [4]
						605603, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						370971, -- [2]
						18, -- [3]
						1676580870.964, -- [4]
						605621, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						394457, -- [2]
						1055, -- [3]
						1676580871.126, -- [4]
						606676, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						370971, -- [2]
						5, -- [3]
						1676580871.271, -- [4]
						606681, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						227255, -- [2]
						17, -- [3]
						1676580871.496, -- [4]
						606698, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						143924, -- [2]
						335, -- [3]
						1676580871.929, -- [4]
						607033, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						394457, -- [2]
						1055, -- [3]
						1676580872.137, -- [4]
						608088, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						true, -- [1]
						1, -- [2]
						3965, -- [3]
						1676580872.249, -- [4]
						608088, -- [5]
						"Wrathguard", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						370971, -- [2]
						5, -- [3]
						1676580872.274, -- [4]
						608093, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						394457, -- [2]
						1055, -- [3]
						1676580873.117, -- [4]
						605183, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						1889, -- [3]
						1676580873.145, -- [4]
						607072, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						394457, -- [2]
						1055, -- [3]
						1676580874.129, -- [4]
						608127, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						646, -- [3]
						1676580874.338, -- [4]
						608773, -- [5]
						"Scahra", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						394457, -- [2]
						1055, -- [3]
						1676580875.129, -- [4]
						608906, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						394457, -- [2]
						1055, -- [3]
						1676580876.13, -- [4]
						608906, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						187827, -- [2]
						0, -- [3]
						1676580749.505, -- [4]
						0, -- [5]
						"Scahra", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "2m 11s",
				["time"] = 1676580878.145,
			}, -- [8]
			{
				["maxhealth"] = 318200,
				["timeofdeath"] = 133.5939999999828,
				["name"] = "Happenslol",
				["events"] = {
					{
						false, -- [1]
						361195, -- [2]
						19091, -- [3]
						1676580864.437, -- [4]
						217547, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						143924, -- [2]
						11, -- [3]
						1676580864.614, -- [4]
						217558, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						false, -- [1]
						373268, -- [2]
						1431, -- [3]
						1676580864.941, -- [4]
						218989, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						false, -- [1]
						373268, -- [2]
						521, -- [3]
						1676580865.13, -- [4]
						219510, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						367364, -- [2]
						5608, -- [3]
						1676580865.659, -- [4]
						225118, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						3, -- [3]
						1676580865.829, -- [4]
						225121, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						373268, -- [2]
						1217, -- [3]
						1676580866.129, -- [4]
						226338, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						false, -- [1]
						373268, -- [2]
						1168, -- [3]
						1676580866.747, -- [4]
						227506, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						5, -- [3]
						1676580867.047, -- [4]
						227511, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						373268, -- [2]
						1219, -- [3]
						1676580867.134, -- [4]
						228730, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						373268, -- [2]
						43273, -- [3]
						1676580867.435, -- [4]
						272003, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						367364, -- [2]
						2809, -- [3]
						1676580867.48, -- [4]
						274812, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						false, -- [1]
						185311, -- [2]
						16705, -- [3]
						1676580868.096, -- [4]
						291517, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						259760, -- [2]
						835, -- [3]
						1676580868.096, -- [4]
						292352, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580868.12, -- [4]
						293570, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						143924, -- [2]
						9, -- [3]
						1676580868.274, -- [4]
						293579, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						367364, -- [2]
						3390, -- [3]
						1676580868.556, -- [4]
						296969, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						373268, -- [2]
						2337, -- [3]
						1676580868.556, -- [4]
						299306, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						185311, -- [2]
						16705, -- [3]
						1676580869.083, -- [4]
						316011, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						259760, -- [2]
						835, -- [3]
						1676580869.083, -- [4]
						316846, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580869.121, -- [4]
						318064, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						1, -- [3]
						1676580869.487, -- [4]
						318065, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						185311, -- [2]
						16705, -- [3]
						1676580870.087, -- [4]
						334100, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						259760, -- [2]
						835, -- [3]
						1676580870.087, -- [4]
						334100, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						367364, -- [2]
						5192, -- [3]
						1676580870.387, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						185311, -- [2]
						16705, -- [3]
						1676580871.089, -- [4]
						334100, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						259760, -- [2]
						835, -- [3]
						1676580871.089, -- [4]
						334100, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						367364, -- [2]
						5085, -- [3]
						1676580872.237, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						388081, -- [2]
						4405, -- [3]
						1676580872.748, -- [4]
						334100, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						259760, -- [2]
						221, -- [3]
						1676580872.762, -- [4]
						334100, -- [5]
						"Happenslol", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						367364, -- [2]
						2491, -- [3]
						1676580874.079, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						false, -- [1]
						367364, -- [2]
						2472, -- [3]
						1676580875.846, -- [4]
						334100, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						31224, -- [2]
						0, -- [3]
						1676580837.281, -- [4]
						0, -- [5]
						"Happenslol", -- [6]
					}, -- [33]
				},
				["class"] = "ROGUE",
				["timestring"] = "2m 13s",
				["time"] = 1676580880.146,
			}, -- [9]
			{
				["maxhealth"] = 267220,
				["timeofdeath"] = 134.9679999999935,
				["name"] = "Bahyla",
				["events"] = {
					{
						true, -- [1]
						377612, -- [2]
						7829, -- [3]
						1676580859.563, -- [4]
						78233, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [1]
					{
						false, -- [1]
						183811, -- [2]
						524, -- [3]
						1676580859.563, -- [4]
						78757, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [2]
					{
						true, -- [1]
						377612, -- [2]
						7829, -- [3]
						1676580860.063, -- [4]
						70928, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [3]
					{
						true, -- [1]
						377662, -- [2]
						10903, -- [3]
						1676580860.223, -- [4]
						60025, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [4]
					{
						false, -- [1]
						367364, -- [2]
						5607, -- [3]
						1676580860.413, -- [4]
						65632, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [5]
					{
						true, -- [1]
						377612, -- [2]
						7829, -- [3]
						1676580860.564, -- [4]
						57803, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [6]
					{
						false, -- [1]
						370511, -- [2]
						148412, -- [3]
						1676580860.805, -- [4]
						206215, -- [5]
						"Bahyla", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [7]
					{
						true, -- [1]
						381250, -- [2]
						11743, -- [3]
						1676580860.838, -- [4]
						194472, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [8]
					{
						true, -- [1]
						377662, -- [2]
						16354, -- [3]
						1676580861.216, -- [4]
						178118, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [9]
					{
						false, -- [1]
						183811, -- [2]
						517, -- [3]
						1676580861.615, -- [4]
						178626, -- [5]
						"Aubry", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [10]
					{
						false, -- [1]
						367364, -- [2]
						5607, -- [3]
						1676580862.233, -- [4]
						184233, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [11]
					{
						false, -- [1]
						373862, -- [2]
						11742, -- [3]
						1676580862.843, -- [4]
						184233, -- [5]
						"Morrizane", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [12]
					{
						true, -- [1]
						381250, -- [2]
						11742, -- [3]
						1676580862.843, -- [4]
						184233, -- [5]
						"Raszageth", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [13]
					{
						false, -- [1]
						367364, -- [2]
						2804, -- [3]
						1676580864.059, -- [4]
						187037, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [14]
					{
						false, -- [1]
						361195, -- [2]
						19091, -- [3]
						1676580864.437, -- [4]
						206128, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [15]
					{
						false, -- [1]
						373268, -- [2]
						1430, -- [3]
						1676580864.941, -- [4]
						207558, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [16]
					{
						false, -- [1]
						373268, -- [2]
						522, -- [3]
						1676580865.13, -- [4]
						208080, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [17]
					{
						false, -- [1]
						367364, -- [2]
						2803, -- [3]
						1676580865.853, -- [4]
						210883, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [18]
					{
						false, -- [1]
						373268, -- [2]
						1216, -- [3]
						1676580866.129, -- [4]
						212099, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [19]
					{
						false, -- [1]
						373268, -- [2]
						1167, -- [3]
						1676580866.747, -- [4]
						213266, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [20]
					{
						false, -- [1]
						373268, -- [2]
						1218, -- [3]
						1676580867.134, -- [4]
						214476, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [21]
					{
						false, -- [1]
						373268, -- [2]
						43272, -- [3]
						1676580867.435, -- [4]
						257730, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [22]
					{
						false, -- [1]
						367364, -- [2]
						5617, -- [3]
						1676580867.67, -- [4]
						263347, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [23]
					{
						false, -- [1]
						373268, -- [2]
						1219, -- [3]
						1676580868.12, -- [4]
						264566, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [24]
					{
						false, -- [1]
						373268, -- [2]
						2337, -- [3]
						1676580868.556, -- [4]
						266886, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [25]
					{
						false, -- [1]
						373268, -- [2]
						1219, -- [3]
						1676580869.121, -- [4]
						268105, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [26]
					{
						false, -- [1]
						367364, -- [2]
						5200, -- [3]
						1676580869.487, -- [4]
						273305, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [27]
					{
						false, -- [1]
						367364, -- [2]
						5192, -- [3]
						1676580871.296, -- [4]
						278497, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [28]
					{
						false, -- [1]
						367364, -- [2]
						5192, -- [3]
						1676580873.135, -- [4]
						283689, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [29]
					{
						false, -- [1]
						367364, -- [2]
						2596, -- [3]
						1676580874.989, -- [4]
						286277, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [30]
					{
						false, -- [1]
						367364, -- [2]
						2473, -- [3]
						1676580876.829, -- [4]
						288750, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [31]
					{
						false, -- [1]
						367364, -- [2]
						1356, -- [3]
						1676580877.829, -- [4]
						290106, -- [5]
						"Morrizane", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
						false, -- [11]
						false, -- [12]
					}, -- [32]
					{
						3, -- [1]
						109304, -- [2]
						0, -- [3]
						1676580844.002, -- [4]
						0, -- [5]
						"Bahyla", -- [6]
					}, -- [33]
				},
				["class"] = "HUNTER",
				["timestring"] = "2m 14s",
				["time"] = 1676580881.52,
			}, -- [10]
		},
		["bossname"] = "Raszageth the Storm-Eater",
		["bossicon"] = {
			0, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
			4757698, -- [5]
		},
		["date"] = 512197.654,
		["timeelapsed"] = 146.00900000002,
	}, -- [2]
}
DeathGraphsDBGraph = {
	["2635-15"] = {
		["deaths"] = {
			[210] = {
				1674159391, -- [1]
			},
			[122] = {
				1674160508, -- [1]
				1674764468, -- [2]
			},
			[148] = {
				1674162085, -- [1]
			},
			[180] = {
				1674162875, -- [1]
			},
			[212] = {
				1674764100, -- [1]
			},
			[213] = {
				1674766911, -- [1]
			},
			[298] = {
				1674766513, -- [1]
			},
			[125] = {
				1674159391, -- [1]
				1674766513, -- [2]
			},
			[215] = {
				1674162495, -- [1]
			},
			[184] = {
				1674161232, -- [1]
				1674162495, -- [2]
			},
			[153] = {
				1674161739, -- [1]
			},
			[185] = {
				1674160508, -- [1]
				1674160508, -- [2]
				1674765906, -- [3]
			},
			[217] = {
				1674766911, -- [1]
			},
			[186] = {
				1674160508, -- [1]
				1674160869, -- [2]
			},
			[218] = {
				1674765906, -- [1]
				1674765906, -- [2]
			},
			[126] = {
				1674162085, -- [1]
				1674764468, -- [2]
			},
			[219] = {
				1674159391, -- [1]
				1674766911, -- [2]
				1674766911, -- [3]
			},
			[188] = {
				1674160869, -- [1]
			},
			[220] = {
				1674766911, -- [1]
			},
			[127] = {
				1674161490, -- [1]
			},
			[221] = {
				1674162495, -- [1]
			},
			[190] = {
				1674768208, -- [1]
			},
			[112] = {
				1674158981, -- [1]
			},
			[128] = {
				1674161739, -- [1]
			},
			[129] = {
				1674161490, -- [1]
			},
			[192] = {
				1674160869, -- [1]
				1674160869, -- [2]
				1674160869, -- [3]
			},
			[113] = {
				1674763702, -- [1]
			},
			[193] = {
				1674764100, -- [1]
			},
			[257] = {
				1674768208, -- [1]
			},
			[258] = {
				1674162875, -- [1]
			},
			[259] = {
				1674766513, -- [1]
			},
			[195] = {
				1674159763, -- [1]
				1674162875, -- [2]
			},
			[227] = {
				1674764100, -- [1]
				1674764100, -- [2]
			},
			[196] = {
				1674768208, -- [1]
			},
			[115] = {
				1674158981, -- [1]
				1674763702, -- [2]
			},
			[134] = {
				1674159763, -- [1]
				1674767297, -- [2]
			},
			[265] = {
				1674766513, -- [1]
			},
			[135] = {
				1674162495, -- [1]
				1674763702, -- [2]
			},
			[116] = {
				1674765906, -- [1]
			},
			[136] = {
				1674159763, -- [1]
				1674160508, -- [2]
				1674767297, -- [3]
				1674767297, -- [4]
			},
			[270] = {
				1674162875, -- [1]
			},
			[137] = {
				1674763702, -- [1]
				1674767297, -- [2]
			},
			[271] = {
				1674162875, -- [1]
			},
			[138] = {
				1674159763, -- [1]
				1674159763, -- [2]
			},
			[203] = {
				1674159391, -- [1]
				1674161232, -- [2]
				1674768208, -- [3]
			},
			[145] = {
				1674161490, -- [1]
			},
			[118] = {
				1674158981, -- [1]
				1674158981, -- [2]
				1674763702, -- [3]
				1674764468, -- [4]
			},
			[140] = {
				1674161232, -- [1]
				1674161490, -- [2]
			},
			[132] = {
				1674161739, -- [1]
				1674767297, -- [2]
			},
			[204] = {
				1674159391, -- [1]
			},
			[119] = {
				1674158981, -- [1]
				1674764468, -- [2]
			},
			[142] = {
				1674161739, -- [1]
			},
			[205] = {
				1674161232, -- [1]
			},
			[206] = {
				1674161232, -- [1]
			},
			[120] = {
				1674162085, -- [1]
				1674764468, -- [2]
			},
			[144] = {
				1674161490, -- [1]
				1674162085, -- [2]
			},
			[141] = {
				1674162085, -- [1]
			},
			[105] = {
				1674161739, -- [1]
				1674765906, -- [2]
			},
			[177] = {
				1674768208, -- [1]
			},
			[216] = {
				1674764100, -- [1]
			},
			[262] = {
				1674162495, -- [1]
			},
			[224] = {
				1674766513, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2587-15"] = {
		["deaths"] = {
			[121] = {
				1674152696, -- [1]
			},
			[172] = {
				1674757230, -- [1]
			},
			[177] = {
				1673552168, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2592-15"] = {
		["deaths"] = {
			[229] = {
				1673557268, -- [1]
			},
			[147] = {
				1674155121, -- [1]
			},
			[126] = {
				1673557268, -- [1]
			},
			[222] = {
				1674155121, -- [1]
			},
			[125] = {
				1674155748, -- [1]
				1674155748, -- [2]
			},
			[143] = {
				1674155748, -- [1]
			},
			[186] = {
				1674155121, -- [1]
			},
			[149] = {
				1673557268, -- [1]
			},
			[142] = {
				1674155748, -- [1]
				1674155748, -- [2]
			},
			[226] = {
				1674155121, -- [1]
			},
			[128] = {
				1673557268, -- [1]
			},
			[181] = {
				1673557268, -- [1]
			},
			[268] = {
				1674156231, -- [1]
			},
			[80] = {
				1674759194, -- [1]
			},
			[281] = {
				1674156231, -- [1]
			},
			[246] = {
				1674155121, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2607-15"] = {
		["deaths"] = {
			[27] = {
				1676580893, -- [1]
			},
			[75] = {
				1676575005, -- [1]
			},
			[293] = {
				1676579328, -- [1]
			},
			[212] = {
				1676579651, -- [1]
			},
			[182] = {
				1676577520, -- [1]
			},
			[151] = {
				1676574605, -- [1]
			},
			[185] = {
				1676577520, -- [1]
			},
			[232] = {
				1676581264, -- [1]
			},
			[94] = {
				1676574165, -- [1]
				1676574165, -- [2]
				1676575767, -- [3]
				1676576823, -- [4]
				1676577520, -- [5]
				1676577520, -- [6]
				1676581264, -- [7]
			},
			[155] = {
				1676575397, -- [1]
			},
			[229] = {
				1676581264, -- [1]
			},
			[180] = {
				1676581264, -- [1]
			},
			[95] = {
				1676574605, -- [1]
				1676578548, -- [2]
				1676578548, -- [3]
				1676578835, -- [4]
				1676578835, -- [5]
			},
			[56] = {
				1676575005, -- [1]
			},
			[252] = {
				1676575397, -- [1]
			},
			[312] = {
				1676579328, -- [1]
			},
			[327] = {
				1676580156, -- [1]
				1676580156, -- [2]
				1676580156, -- [3]
			},
			[241] = {
				1676580156, -- [1]
			},
			[65] = {
				1676579651, -- [1]
				1676581264, -- [2]
			},
			[81] = {
				1676574165, -- [1]
			},
			[129] = {
				1676580893, -- [1]
				1676580893, -- [2]
			},
			[57] = {
				1676575005, -- [1]
			},
			[66] = {
				1676575767, -- [1]
			},
			[225] = {
				1676576269, -- [1]
			},
			[132] = {
				1676580626, -- [1]
			},
			[226] = {
				1676576269, -- [1]
			},
			[386] = {
				1676578548, -- [1]
			},
			[164] = {
				1676580626, -- [1]
			},
			[385] = {
				1676578548, -- [1]
			},
			[165] = {
				1676575397, -- [1]
			},
			[197] = {
				1676579651, -- [1]
			},
			[84] = {
				1676574165, -- [1]
				1676575767, -- [2]
			},
			[198] = {
				1676579651, -- [1]
			},
			[116] = {
				1676580893, -- [1]
			},
			[268] = {
				1676574605, -- [1]
				1676578015, -- [2]
			},
			[269] = {
				1676578015, -- [1]
			},
			[270] = {
				1676574605, -- [1]
				1676578015, -- [2]
			},
			[271] = {
				1676574605, -- [1]
				1676575397, -- [2]
			},
			[272] = {
				1676578015, -- [1]
			},
			[170] = {
				1676578015, -- [1]
			},
			[102] = {
				1676575767, -- [1]
				1676575767, -- [2]
			},
			[328] = {
				1676579328, -- [1]
			},
			[326] = {
				1676579328, -- [1]
			},
			[86] = {
				1676579328, -- [1]
				1676579651, -- [2]
			},
			[130] = {
				1676578835, -- [1]
				1676578835, -- [2]
				1676580626, -- [3]
				1676580893, -- [4]
			},
			[117] = {
				1676578835, -- [1]
			},
			[72] = {
				1676575005, -- [1]
			},
			[281] = {
				1676580156, -- [1]
			},
			[366] = {
				1676578548, -- [1]
			},
			[238] = {
				1676576823, -- [1]
				1676576823, -- [2]
				1676576823, -- [3]
			},
			[58] = {
				1676576269, -- [1]
			},
			[176] = {
				1676576269, -- [1]
				1676580626, -- [2]
			},
			[26] = {
				1676574165, -- [1]
				1676575397, -- [2]
			},
			[169] = {
				1676577520, -- [1]
			},
			[224] = {
				1676576823, -- [1]
				1676580626, -- [2]
			},
			[178] = {
				1676576269, -- [1]
			},
			[69] = {
				1676575005, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2587-14"] = {
		["deaths"] = {
			[102] = {
				1673547977, -- [1]
			},
			[119] = {
				1673547977, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2639-15"] = {
		["deaths"] = {
			[122] = {
				1674153389, -- [1]
			},
			[211] = {
				1673556421, -- [1]
			},
			[62] = {
				1673553165, -- [1]
				1673554603, -- [2]
			},
			[246] = {
				1673554603, -- [1]
				1673554603, -- [2]
			},
			[307] = {
				1673555907, -- [1]
			},
			[156] = {
				1673553866, -- [1]
				1673553866, -- [2]
				1674153750, -- [3]
			},
			[96] = {
				1673555907, -- [1]
			},
			[255] = {
				1673556421, -- [1]
			},
			[257] = {
				1673554603, -- [1]
			},
			[114] = {
				1673553866, -- [1]
				1674153389, -- [2]
			},
			[132] = {
				1674153389, -- [1]
			},
			[116] = {
				1674153750, -- [1]
			},
			[69] = {
				1674758407, -- [1]
			},
			[11] = {
				1673554115, -- [1]
			},
			[15] = {
				1673555907, -- [1]
			},
			[170] = {
				1673556421, -- [1]
			},
			[118] = {
				1674153389, -- [1]
				1674153750, -- [2]
			},
			[30] = {
				1674153750, -- [1]
			},
			[204] = {
				1673553866, -- [1]
			},
			[19] = {
				1673553866, -- [1]
			},
			[103] = {
				1673553165, -- [1]
			},
			[60] = {
				1673554115, -- [1]
			},
			[72] = {
				1674758407, -- [1]
			},
			[52] = {
				1673553165, -- [1]
			},
			[171] = {
				1673554603, -- [1]
			},
			[129] = {
				1674153750, -- [1]
			},
			[73] = {
				1673553165, -- [1]
			},
			[32] = {
				1673553165, -- [1]
				1673554115, -- [2]
			},
			[53] = {
				1673554115, -- [1]
				1673554115, -- [2]
			},
			[126] = {
				1674153389, -- [1]
			},
			[74] = {
				1673555907, -- [1]
			},
			[23] = {
				1673555907, -- [1]
			},
			[219] = {
				1674758407, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2590-15"] = {
		["deaths"] = {
			[161] = {
				1674760914, -- [1]
			},
			[96] = {
				1674157519, -- [1]
				1674157519, -- [2]
			},
			[200] = {
				1674760914, -- [1]
			},
			[156] = {
				1674157519, -- [1]
			},
			[202] = {
				1674157932, -- [1]
			},
			[94] = {
				1674761254, -- [1]
			},
			[83] = {
				1674760914, -- [1]
			},
			[121] = {
				1674157519, -- [1]
			},
			[36] = {
				1674760914, -- [1]
			},
			[120] = {
				1674157519, -- [1]
			},
			[184] = {
				1674760914, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2605-15"] = {
		["deaths"] = {
			[53] = {
				1674762368, -- [1]
				1674762368, -- [2]
			},
			[66] = {
				1674761724, -- [1]
			},
			[52] = {
				1674761724, -- [1]
				1674761724, -- [2]
			},
			[503] = {
				1674762368, -- [1]
			},
			[251] = {
				1674762368, -- [1]
			},
			[67] = {
				1674761724, -- [1]
			},
			[271] = {
				1674762368, -- [1]
			},
			[70] = {
				1674761724, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2614-15"] = {
		["deaths"] = {
			[66] = {
				1676572363, -- [1]
			},
			[354] = {
				1676572992, -- [1]
			},
			[123] = {
				1676572992, -- [1]
			},
			[328] = {
				1676572110, -- [1]
			},
			[60] = {
				1676572363, -- [1]
			},
			[247] = {
				1676572110, -- [1]
				1676572110, -- [2]
			},
			[419] = {
				1676572992, -- [1]
			},
			[345] = {
				1676572110, -- [1]
			},
			[72] = {
				1676572363, -- [1]
				1676572363, -- [2]
			},
			[347] = {
				1676572110, -- [1]
			},
			[68] = {
				1676572363, -- [1]
			},
			[330] = {
				1676572992, -- [1]
			},
			[329] = {
				1676572992, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["2607-14"] = {
		["deaths"] = {
			[81] = {
				1673550254, -- [1]
			},
			[97] = {
				1673550254, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
}
