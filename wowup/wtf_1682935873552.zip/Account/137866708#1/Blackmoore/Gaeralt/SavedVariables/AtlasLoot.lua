
AtlasLootCharDB = {
	["__addonrevision"] = 4772,
	["GUI"] = {
		["selected"] = {
			[5] = 0,
		},
	},
}
