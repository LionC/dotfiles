
TomTomDB = {
	["profileKeys"] = {
		["Lionc - Blackmoore"] = "Default",
		["Xyresia - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
	["profileKeys"] = {
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
		["Xyresia - Blackmoore"] = "Xyresia - Blackmoore",
	},
	["profiles"] = {
		["Lionc - Blackmoore"] = {
		},
		["Xyresia - Blackmoore"] = {
		},
	},
}
