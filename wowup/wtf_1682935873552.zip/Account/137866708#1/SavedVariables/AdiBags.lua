
AdiBagsDB = {
	["namespaces"] = {
		["ItemLevel"] = {
		},
		["FilterOverride"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 3,
				},
			},
		},
		["ItemCategory"] = {
		},
		["NewItem"] = {
		},
		["AdiBags_TooltipInfo"] = {
		},
		["MoneyFrame"] = {
		},
		["ItemSets"] = {
		},
		["CurrencyFrame"] = {
		},
		["DataSource"] = {
		},
		["Junk"] = {
		},
		["Equipment"] = {
		},
	},
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["positions"] = {
				["Backpack"] = {
					["xOffset"] = -3.6650390625,
					["yOffset"] = -95.98405456542969,
				},
			},
		},
	},
}
