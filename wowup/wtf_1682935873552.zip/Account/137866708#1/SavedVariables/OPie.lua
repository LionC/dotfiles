
OneRing_Config = {
	["CharProfiles"] = {
		["Blackmoore-Lionc"] = "default",
	},
	["_GameVersion"] = "9.1.0",
	["_OPieVersion"] = "Xe 6 (3.106)",
	["ProfileStorage"] = {
		["default"] = {
			["RingAtMouse"] = true,
			["Bindings"] = {
				["Pots"] = "ALT-G",
				["onsumables"] = "ALT-C",
			},
		},
	},
	["PersistentStorage"] = {
		["RingKeeper"] = {
			["Pots"] = {
				{
					"item", -- [1]
					171267, -- [2]
					["sliceToken"] = "ABuek/Q5K5f",
				}, -- [1]
				{
					"item", -- [1]
					152550, -- [2]
					["sliceToken"] = "ABuek/Q5K5d",
				}, -- [2]
				{
					"item", -- [1]
					171263, -- [2]
					["sliceToken"] = "ABuek/Q5K53",
				}, -- [3]
				{
					"item", -- [1]
					171266, -- [2]
					["sliceToken"] = "ABuek/Q5K5s",
				}, -- [4]
				{
					"item", -- [1]
					152503, -- [2]
					["sliceToken"] = "ABuek/Q5K5a",
				}, -- [5]
				["name"] = "Pots",
				["save"] = true,
			},
			["OPieFlagStore"] = {
				["StoreVersion"] = 2,
			},
			["onsumables"] = {
				{
					"item", -- [1]
					168651, -- [2]
					["sliceToken"] = "ABuek/Q5K5A",
				}, -- [1]
				{
					"item", -- [1]
					172042, -- [2]
					["sliceToken"] = "ABuekMomOVf",
				}, -- [2]
				{
					"item", -- [1]
					172062, -- [2]
					["sliceToken"] = "ABuek/Q5K5P",
				}, -- [3]
				{
					"item", -- [1]
					172045, -- [2]
					["sliceToken"] = "ABuek/Q5K5O",
				}, -- [4]
				{
					"item", -- [1]
					172049, -- [2]
					["sliceToken"] = "ABuek/Q5K5I",
				}, -- [5]
				{
					"item", -- [1]
					172051, -- [2]
					["sliceToken"] = "ABuek/Q5K58",
				}, -- [6]
				{
					"item", -- [1]
					171285, -- [2]
					["sliceToken"] = "ABuek/Q5K5U",
				}, -- [7]
				{
					"item", -- [1]
					171276, -- [2]
					["sliceToken"] = "ABuekMomOVd",
				}, -- [8]
				{
					"item", -- [1]
					178715, -- [2]
					["sliceToken"] = "ABuek/Q5K5Y",
				}, -- [9]
				{
					"item", -- [1]
					172347, -- [2]
					["sliceToken"] = "ABuekMomOV3",
				}, -- [10]
				["limit"] = "Lionc-Blackmoore",
				["save"] = true,
				["name"] = "Consumables",
			},
		},
	},
	["_GameLocale"] = "enUS",
}
OPie_SavedData = nil
