
TomCats_Mechagon_Character = {
	["preferences"] = {
		["TomCats-MechagonMinimapButton"] = {
			["position"] = -2.664687407673003,
		},
	},
}
