
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[70] = 30,
		[65] = 40,
		[66] = 30,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-580-0916F7F1"] = true,
	},
	["resources_on_target"] = false,
	["minimap"] = {
	},
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[70] = 30,
		[65] = 40,
		[66] = 30,
	},
}
