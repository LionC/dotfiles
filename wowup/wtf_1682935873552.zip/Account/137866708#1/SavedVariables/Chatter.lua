
ChatterDB = {
	["namespaces"] = {
		["PlayerNames"] = {
		},
		["AltLinks"] = {
		},
		["Scrollback"] = {
		},
		["Invite Links"] = {
			["profiles"] = {
				["Default"] = {
					["words"] = {
						["inv"] = "inv",
						["invite"] = "invite",
					},
				},
			},
		},
		["ChannelColors"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["Party Leader"] = {
							["b"] = 1,
							["g"] = 0.784313797950745,
							["r"] = 0.462745130062103,
						},
						["Instance Leader"] = {
							["b"] = 0.0352941192686558,
							["g"] = 0.282352954149246,
							["r"] = 1,
						},
						["Instance"] = {
							["b"] = 0,
							["g"] = 0.498039245605469,
							["r"] = 1,
						},
						["Raid Leader"] = {
							["b"] = 0.0352941192686558,
							["g"] = 0.282352954149246,
							["r"] = 1,
						},
						["Yell"] = {
							["b"] = 0.250980406999588,
							["g"] = 0.250980406999588,
							["r"] = 1,
						},
						["Raid Warning"] = {
							["b"] = 0,
							["g"] = 0.282352954149246,
							["r"] = 1,
						},
						["Party"] = {
							["b"] = 1,
							["g"] = 0.666666686534882,
							["r"] = 0.666666686534882,
						},
						["Whisper"] = {
							["b"] = 1,
							["g"] = 0.501960813999176,
							["r"] = 1,
						},
						["Say"] = {
							["b"] = 1,
							["g"] = 1,
							["r"] = 1,
						},
						["Real ID Whisper"] = {
							["b"] = 0.964705944061279,
							["g"] = 1,
							["r"] = 0,
						},
						["Raid"] = {
							["b"] = 0,
							["g"] = 0.498039245605469,
							["r"] = 1,
						},
						["Guild"] = {
							["b"] = 0.250980406999588,
							["g"] = 1,
							["r"] = 0.250980406999588,
						},
						["Officer"] = {
							["b"] = 0.250980406999588,
							["g"] = 0.752941250801086,
							["r"] = 0.250980406999588,
						},
					},
				},
			},
		},
		["StickyChannels"] = {
		},
		["ChatFrameBorders"] = {
		},
		["Buttons"] = {
		},
		["Server Positioning"] = {
		},
		["JustifyText"] = {
		},
		["Timestamps"] = {
		},
		["EditBox"] = {
		},
		["Highlight"] = {
		},
		["ChatTabs"] = {
		},
		["ChannelNames"] = {
		},
		["CopyChat"] = {
		},
		["UrlCopy"] = {
		},
		["Editbox History"] = {
			["realm"] = {
				["Blackmoore"] = {
					["history"] = {
						"/p is anyone premade with the heal?", -- [1]
						"/p nice", -- [2]
						"/p ok so...its over?", -- [3]
						"/p it is", -- [4]
						"/p yey we have a rogue", -- [5]
						"/p so  we can shroud the caster group  and open all  locks", -- [6]
						"/p lets open all locks before the werewolf please, makes it a lot smoother", -- [7]
						"/p before the caster group", -- [8]
						"/p ill tell you", -- [9]
						"/p that was a lot of stacks :3", -- [10]
						"/p drones make it really hard to get off", -- [11]
						"/p sec", -- [12]
						"/p rep", -- [13]
						"/p ims o sorry", -- [14]
						"/p autopilot forgot the rogue route", -- [15]
						"/p open cages", -- [16]
						"/p yes", -- [17]
						"/p ski[ here", -- [18]
						"/p shroud", -- [19]
						"/p or not..", -- [20]
						"/p shroud?", -- [21]
						"/p ..", -- [22]
						"/p dont caryr it out", -- [23]
						"/p no", -- [24]
						"/p caryr it into one corner", -- [25]
						"/p and tank in the other", -- [26]
						"/p he instantly respawsn when yo carry them put", -- [27]
						"/p tanking here, remove all barrels in fight that are near this corner", -- [28]
						"/p ignore the rest", -- [29]
						"/g hola", -- [30]
						"/cw Dalaxor was willsten  für den", -- [31]
						"/cw Dalaxor ok das ist eine andere größenordnung als ich für pets ausgebe^^ danke trotzdem!", -- [32]
					},
				},
			},
		},
		["ChatFont"] = {
		},
		["Mousewheel Scroll"] = {
		},
	},
	["profileKeys"] = {
		["Lionc - Blackmoore"] = "Default",
		["Xyresia - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["welcomeMessaged"] = true,
		},
	},
}
