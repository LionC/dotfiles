
DetailsTimeLineDB = {
	["max_segments"] = 4,
	["combat_data"] = {
	},
	["hide_on_combat"] = false,
	["IndividualSpells"] = {
		{
			[381517] = {
				{
					17.37900000000082, -- [1]
					"Erkhart Stormvein", -- [2]
					381517, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					35.57100000000355, -- [1]
					"Erkhart Stormvein", -- [2]
					381517, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[381512] = {
				{
					5.946000000003551, -- [1]
					"Erkhart Stormvein", -- [2]
					381512, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					22.95400000000518, -- [1]
					"Erkhart Stormvein", -- [2]
					381512, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
				{
					41.15400000000227, -- [1]
					"Erkhart Stormvein", -- [2]
					381512, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [3]
			},
			[381605] = {
				{
					39.72100000000501, -- [1]
					"Kyrakka", -- [2]
					381605, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					55.49599999999919, -- [1]
					"Kyrakka", -- [2]
					381605, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					73.71300000000338, -- [1]
					"Kyrakka", -- [2]
					381605, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[381525] = {
				{
					4.692000000002736, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					24.55400000000373, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					46.7960000000021, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					65.01299999999901, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[392398] = {
				{
					16.17199999999866, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					17.37900000000082, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					18.59100000000035, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					19.81200000000536, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[381602] = {
				{
					18.2960000000021, -- [1]
					"Kyrakka", -- [2]
					381602, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Syreht-Nazjatar", -- [5]
				}, -- [1]
			},
			[385558] = {
				{
					11.6050000000032, -- [1]
					"Erkhart Stormvein", -- [2]
					385558, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					29.80500000000029, -- [1]
					"Erkhart Stormvein", -- [2]
					385558, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
		}, -- [1]
		{
			[372858] = {
				{
					21.6160000000018, -- [1]
					"Kokia Blazehoof", -- [2]
					372858, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
			},
			[384823] = {
				{
					17.09399999999732, -- [1]
					"Blazebound Firestorm", -- [2]
					384823, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[372107] = {
				{
					16.8269999999975, -- [1]
					"Kokia Blazehoof", -- [2]
					372107, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					33.81899999999587, -- [1]
					"Kokia Blazehoof", -- [2]
					372107, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[373087] = {
				{
					31.63300000000163, -- [1]
					"Blazebound Firestorm", -- [2]
					373087, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[373017] = {
				{
					20.98399999999674, -- [1]
					"Blazebound Firestorm", -- [2]
					373017, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					24.61899999999878, -- [1]
					"Blazebound Firestorm", -- [2]
					373017, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
			},
			[372863] = {
				{
					11.0769999999975, -- [1]
					"Kokia Blazehoof", -- [2]
					372863, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					45.05999999999767, -- [1]
					"Kokia Blazehoof", -- [2]
					372863, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
		}, -- [2]
		{
			[372851] = {
				{
					16.25800000000163, -- [1]
					"Melidrussa Chillworn", -- [2]
					372851, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Allegory", -- [5]
				}, -- [1]
				{
					59.93499999999767, -- [1]
					"Melidrussa Chillworn", -- [2]
					372851, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Aniiema-Antonidas", -- [5]
				}, -- [2]
			},
			[396044] = {
				{
					6.282999999995809, -- [1]
					"Melidrussa Chillworn", -- [2]
					396044, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					49.94200000000274, -- [1]
					"Melidrussa Chillworn", -- [2]
					396044, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[372808] = {
				{
					0.5769999999974971, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					3.00800000000163, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
				{
					9.059000000001106, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [3]
				{
					11.08400000000256, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [4]
				{
					29.26900000000023, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [5]
				{
					31.70900000000256, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [6]
				{
					41.44200000000274, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [7]
				{
					43.85899999999674, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [8]
				{
					46.26699999999983, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [9]
				{
					53.56700000000274, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [10]
				{
					55.97899999999936, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [11]
			},
			[371489] = {
				{
					2.657999999995809, -- [1]
					"Flashfrost Chillweaver", -- [2]
					371489, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[373803] = {
				{
					32.54200000000128, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					37.39299999999639, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
				{
					44.69200000000274, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Wollmieger-Sen'jin", -- [5]
				}, -- [3]
				{
					46.79299999999785, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [4]
				{
					49.54200000000128, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [5]
				{
					51.94200000000274, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [6]
				{
					54.39400000000023, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [7]
			},
			[373046] = {
				{
					26.46699999999692, -- [1]
					"Melidrussa Chillworn", -- [2]
					373046, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					38.59300000000076, -- [1]
					"Melidrussa Chillworn", -- [2]
					373046, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
		}, -- [3]
		{
			[373678] = {
				{
					63.49799999999959, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					71.99199999999837, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					88.98799999999756, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					109.6499999999978, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					118.1529999999984, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
			},
			[375825] = {
				{
					127.6840000000011, -- [1]
					"Frozen Destroyer", -- [2]
					375825, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374779] = {
				{
					125.755000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					319.9860000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374485] = {
				{
					127.6840000000011, -- [1]
					"Blazing Fiend", -- [2]
					374485, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374430] = {
				{
					345.9609999999993, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					379.9520000000011, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[397341] = {
				{
					265.8479999999981, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					274.364999999998, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					291.3410000000004, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					312.0040000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					422.4969999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					430.987000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					448.005000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
			},
			[372456] = {
				{
					95.08899999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					372456, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[397338] = {
				{
					332.482, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					363.0149999999994, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					393.3529999999992, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374022] = {
				{
					48.9419999999991, -- [1]
					"Kurog Grimtotem", -- [2]
					374022, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375828] = {
				{
					127.6840000000011, -- [1]
					"Blazing Fiend", -- [2]
					375828, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[382563] = {
				{
					15.90499999999884, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					24.40699999999924, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					41.37299999999959, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					465.1159999999982, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					473.6229999999996, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
			},
			[395816] = {
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					395816, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Qalashi Wallcrasher", -- [5]
				}, -- [1]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					395816, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Qalashi Wallcrasher", -- [5]
				}, -- [2]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					395816, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Qalashi Wallcrasher", -- [5]
				}, -- [3]
			},
			[374705] = {
				{
					252.1820000000007, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					252.5770000000011, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374215] = {
				{
					299.4069999999992, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					456.0570000000007, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[359996] = {
				{
					477.3980000000011, -- [1]
					"Worldcarver Wurmling", -- [2]
					359996, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[390548] = {
				{
					10.10699999999997, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [1]
				{
					35.60900000000038, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [2]
				{
					56.23300000000018, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [3]
				{
					81.72799999999916, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [4]
				{
					102.3809999999976, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [5]
				{
					203.1699999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [6]
				{
					228.6800000000003, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [7]
				{
					256.5740000000005, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [8]
				{
					282.0639999999985, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [9]
				{
					302.7109999999993, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [10]
				{
					413.2039999999979, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [11]
				{
					438.7010000000009, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [12]
				{
					459.3389999999999, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [13]
			},
			[374427] = {
				{
					327.4759999999988, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					357.9969999999994, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					388.3339999999989, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374621] = {
				{
					330.0849999999991, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					350.7180000000008, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					371.3260000000009, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374691] = {
				{
					251.2649999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					374691, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[390920] = {
				{
					260.8420000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					269.3600000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					286.3420000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					307.0010000000002, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					315.5149999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					417.4789999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					425.9860000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
				{
					442.9939999999988, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [8]
			},
			[375792] = {
				{
					321.9779999999992, -- [1]
					"Thundering Ravager", -- [2]
					375792, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374622] = {
				{
					331.5760000000009, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Schrottbot-Aman'thul", -- [5]
				}, -- [1]
				{
					352.2170000000006, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Schrottbot-Aman'thul", -- [5]
				}, -- [2]
				{
					372.8349999999991, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Sanmara-KultderVerdammten", -- [5]
				}, -- [3]
			},
			[370212] = {
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					370212, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					370212, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374624] = {
				{
					162.6889999999985, -- [1]
					"Frozen Destroyer", -- [2]
					374624, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375824] = {
				{
					321.9779999999992, -- [1]
					"Tectonic Crusher", -- [2]
					375824, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[395893] = {
				{
					210.4739999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					235.9369999999981, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
		}, -- [4]
		{
			[373678] = {
				{
					292.244999999999, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					312.913999999997, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					321.3979999999974, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[375825] = {
				{
					327.2379999999976, -- [1]
					"Frozen Destroyer", -- [2]
					375825, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374779] = {
				{
					126.1790000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					325.232, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374485] = {
				{
					128.1289999999972, -- [1]
					"Blazing Fiend", -- [2]
					374485, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374881] = {
				{
					440.5, -- [1]
					"Kurog Grimtotem", -- [2]
					374881, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374918] = {
				{
					440.5, -- [1]
					"Kurog Grimtotem", -- [2]
					374918, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[397341] = {
				{
					73.24599999999919, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					90.2619999999988, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					110.895999999997, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					119.3809999999976, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[372456] = {
				{
					298.3149999999987, -- [1]
					"Kurog Grimtotem", -- [2]
					372456, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[397338] = {
				{
					337.9589999999989, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					368.2959999999985, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					398.6079999999965, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					428.9409999999989, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374022] = {
				{
					48.20099999999729, -- [1]
					"Kurog Grimtotem", -- [2]
					374022, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375828] = {
				{
					128.1289999999972, -- [1]
					"Blazing Fiend", -- [2]
					375828, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[382563] = {
				{
					15.05299999999988, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					23.56899999999951, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					40.59999999999855, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					61.22499999999855, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374215] = {
				{
					98.32099999999991, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374705] = {
				{
					254.7569999999978, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					255.2689999999966, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374430] = {
				{
					351.2789999999986, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					385.2349999999969, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					419.2039999999979, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[390548] = {
				{
					9.2599999999984, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [1]
				{
					34.79999999999927, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [2]
				{
					55.45999999999913, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [3]
				{
					80.97899999999936, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [4]
				{
					101.5789999999979, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [5]
				{
					206.0579999999973, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [6]
				{
					231.5639999999985, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [7]
				{
					259.4979999999996, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [8]
				{
					284.9519999999975, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [9]
				{
					305.6129999999976, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [10]
			},
			[390920] = {
				{
					68.25199999999677, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					85.25399999999718, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					105.887999999999, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					114.3789999999972, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374427] = {
				{
					332.9509999999973, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					363.2899999999972, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					393.601999999999, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					423.9449999999997, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374621] = {
				{
					136.2539999999972, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					156.8839999999982, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374691] = {
				{
					254.2179999999971, -- [1]
					"Kurog Grimtotem", -- [2]
					374691, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374916] = {
				{
					440.5, -- [1]
					"Kurog Grimtotem", -- [2]
					374916, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375792] = {
				{
					128.1289999999972, -- [1]
					"Thundering Ravager", -- [2]
					375792, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374622] = {
				{
					137.7539999999972, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Schrottbot-Aman'thul", -- [5]
				}, -- [1]
				{
					158.3889999999992, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Raknash-Malfurion", -- [5]
				}, -- [2]
			},
			[395893] = {
				{
					213.3629999999976, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					238.8459999999977, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					266.757999999998, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374917] = {
				{
					440.5, -- [1]
					"Kurog Grimtotem", -- [2]
					374917, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375824] = {
				{
					327.2379999999976, -- [1]
					"Tectonic Crusher", -- [2]
					375824, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374624] = {
				{
					362.2459999999992, -- [1]
					"Frozen Destroyer", -- [2]
					374624, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
		}, -- [5]
		{
			[373678] = {
				{
					71.95600000000195, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					88.94900000000052, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					109.6200000000026, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					118.1180000000022, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[375825] = {
				{
					127.604000000003, -- [1]
					"Frozen Destroyer", -- [2]
					375825, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374779] = {
				{
					125.6480000000011, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					326.0330000000031, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374485] = {
				{
					127.604000000003, -- [1]
					"Blazing Fiend", -- [2]
					374485, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374918] = {
				{
					549.8129999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					374918, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374881] = {
				{
					549.8129999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					374881, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[397338] = {
				{
					338.4250000000029, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					369.4200000000019, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					400.6330000000016, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					430.9500000000007, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374215] = {
				{
					305.492000000002, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					491.2460000000028, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[372456] = {
				{
					95.03800000000047, -- [1]
					"Kurog Grimtotem", -- [2]
					372456, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[396241] = {
				{
					532.7790000000023, -- [1]
					"Kurog Grimtotem", -- [2]
					396241, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374022] = {
				{
					48.89300000000003, -- [1]
					"Kurog Grimtotem", -- [2]
					374022, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375828] = {
				{
					127.604000000003, -- [1]
					"Blazing Fiend", -- [2]
					375828, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[382563] = {
				{
					15.80199999999968, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					24.34100000000035, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					41.33200000000215, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					61.95700000000215, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374624] = {
				{
					162.6599999999999, -- [1]
					"Frozen Destroyer", -- [2]
					374624, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374705] = {
				{
					258.2750000000015, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					258.5260000000017, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[374430] = {
				{
					352.3840000000018, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					387.1840000000011, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					421.2170000000006, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[375792] = {
				{
					328.0159999999996, -- [1]
					"Thundering Ravager", -- [2]
					375792, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[390548] = {
				{
					11.21700000000055, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [1]
				{
					36.74500000000262, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [2]
				{
					56.20300000000134, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [3]
				{
					81.65400000000227, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [4]
				{
					102.3470000000016, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [5]
				{
					209.2580000000016, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [6]
				{
					234.7080000000024, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [7]
				{
					262.6270000000004, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [8]
				{
					288.1500000000015, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [9]
				{
					308.7750000000015, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [10]
				{
					448.375, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [11]
				{
					473.8790000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [12]
				{
					494.4960000000028, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [13]
				{
					519.979000000003, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [14]
				{
					540.6380000000026, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Konval-Aegwynn", -- [5]
				}, -- [15]
			},
			[374427] = {
				{
					333.367000000002, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					364.4130000000005, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					395.6130000000012, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					425.9510000000009, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			[374621] = {
				{
					336.0750000000007, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					357.117000000002, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					377.3590000000004, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374691] = {
				{
					257.3500000000022, -- [1]
					"Kurog Grimtotem", -- [2]
					374691, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374916] = {
				{
					549.8129999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					374916, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[390920] = {
				{
					292.4160000000011, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					313.0330000000031, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					321.5330000000031, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					452.3250000000007, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					461.1630000000005, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					478.1540000000023, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					498.7620000000024, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
				{
					507.2620000000024, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [8]
				{
					524.2630000000026, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [9]
				{
					544.9370000000017, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [10]
			},
			[374622] = {
				{
					337.5840000000026, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Raknash-Malfurion", -- [5]
				}, -- [1]
				{
					358.6180000000022, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Öllfä-Alleria", -- [5]
				}, -- [2]
				{
					378.867000000002, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Öllfä-Alleria", -- [5]
				}, -- [3]
			},
			[395893] = {
				{
					216.5250000000015, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					242.0090000000018, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					269.9180000000015, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374917] = {
				{
					549.8129999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					374917, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375824] = {
				{
					328.0159999999996, -- [1]
					"Tectonic Crusher", -- [2]
					375824, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[397341] = {
				{
					297.4250000000029, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					318.0420000000013, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					457.3250000000007, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					466.1870000000017, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					483.1710000000021, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					503.7710000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					512.2630000000026, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
				{
					529.2630000000026, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [8]
			},
		}, -- [6]
		{
			[374485] = {
				{
					127.7810000000027, -- [1]
					"Blazing Fiend", -- [2]
					374485, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[382563] = {
				{
					87.59900000000198, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					108.2170000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					116.6929999999993, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374917] = {
				{
					153.0040000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					374917, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375825] = {
				{
					127.7810000000027, -- [1]
					"Frozen Destroyer", -- [2]
					375825, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374779] = {
				{
					125.75, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[390548] = {
				{
					10.12199999999939, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Maxchen", -- [5]
				}, -- [1]
				{
					35.66700000000128, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [2]
				{
					56.28000000000247, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Maxchen", -- [5]
				}, -- [3]
				{
					81.79400000000169, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Maxchen", -- [5]
				}, -- [4]
				{
					102.4420000000027, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [5]
			},
			[374022] = {
				{
					95.16600000000108, -- [1]
					"Kurog Grimtotem", -- [2]
					374022, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374881] = {
				{
					153.0040000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					374881, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374918] = {
				{
					153.0040000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					374918, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374916] = {
				{
					153.0040000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					374916, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[373678] = {
				{
					17.37900000000082, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					25.91300000000047, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					42.9429999999993, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					63.56899999999951, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					72.08100000000195, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
			},
			[374623] = {
				{
					138.380000000001, -- [1]
					"Frozen Destroyer", -- [2]
					374623, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					148.1130000000012, -- [1]
					"Frozen Destroyer", -- [2]
					374623, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			[372456] = {
				{
					48.99200000000201, -- [1]
					"Kurog Grimtotem", -- [2]
					372456, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[375828] = {
				{
					127.7810000000027, -- [1]
					"Blazing Fiend", -- [2]
					375828, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
		}, -- [7]
		{
			[374881] = {
				{
					57.88799999999901, -- [1]
					"Kurog Grimtotem", -- [2]
					374881, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374022] = {
				{
					48.74600000000282, -- [1]
					"Kurog Grimtotem", -- [2]
					374022, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374918] = {
				{
					57.88799999999901, -- [1]
					"Kurog Grimtotem", -- [2]
					374918, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[390548] = {
				{
					11.14400000000023, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Udras-Antonidas", -- [5]
				}, -- [1]
				{
					36.56200000000172, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [2]
				{
					57.24500000000262, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Isigoingde", -- [5]
				}, -- [3]
			},
			[382563] = {
				{
					15.71199999999953, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					24.17000000000189, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					41.17000000000189, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
			},
			[374917] = {
				{
					57.88799999999901, -- [1]
					"Kurog Grimtotem", -- [2]
					374917, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			[374916] = {
				{
					57.88799999999901, -- [1]
					"Kurog Grimtotem", -- [2]
					374916, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
		}, -- [8]
	},
	["useicons"] = true,
	["cooldowns_timeline"] = {
	},
	["backdrop_color"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		0.4, -- [4]
	},
	["deaths_data"] = {
	},
	["debuff_timeline"] = {
	},
	["window_scale"] = 1,
	["BossSpellCast"] = {
		{
			["Erkhart Stormvein"] = {
				{
					5.946000000003551, -- [1]
					"Erkhart Stormvein", -- [2]
					381512, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					11.6050000000032, -- [1]
					"Erkhart Stormvein", -- [2]
					385558, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					17.37900000000082, -- [1]
					"Erkhart Stormvein", -- [2]
					381517, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					22.95400000000518, -- [1]
					"Erkhart Stormvein", -- [2]
					381512, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [4]
				{
					29.80500000000029, -- [1]
					"Erkhart Stormvein", -- [2]
					385558, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					35.57100000000355, -- [1]
					"Erkhart Stormvein", -- [2]
					381517, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					41.15400000000227, -- [1]
					"Erkhart Stormvein", -- [2]
					381512, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [7]
			},
			["Primal Thundercloud"] = {
				{
					16.17199999999866, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					17.37900000000082, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					18.59100000000035, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					19.81200000000536, -- [1]
					"Primal Thundercloud", -- [2]
					392398, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			["Kyrakka"] = {
				{
					4.692000000002736, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					18.2960000000021, -- [1]
					"Kyrakka", -- [2]
					381602, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Syreht-Nazjatar", -- [5]
				}, -- [2]
				{
					24.55400000000373, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					39.72100000000501, -- [1]
					"Kyrakka", -- [2]
					381605, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					46.7960000000021, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					55.49599999999919, -- [1]
					"Kyrakka", -- [2]
					381605, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					65.01299999999901, -- [1]
					"Kyrakka", -- [2]
					381525, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
				{
					73.71300000000338, -- [1]
					"Kyrakka", -- [2]
					381605, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [8]
			},
		}, -- [1]
		{
			["Blazebound Firestorm"] = {
				{
					17.09399999999732, -- [1]
					"Blazebound Firestorm", -- [2]
					384823, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					20.98399999999674, -- [1]
					"Blazebound Firestorm", -- [2]
					373017, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
				{
					24.61899999999878, -- [1]
					"Blazebound Firestorm", -- [2]
					373017, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [3]
				{
					31.63300000000163, -- [1]
					"Blazebound Firestorm", -- [2]
					373087, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
			},
			["Kokia Blazehoof"] = {
				{
					11.0769999999975, -- [1]
					"Kokia Blazehoof", -- [2]
					372863, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					16.8269999999975, -- [1]
					"Kokia Blazehoof", -- [2]
					372107, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					21.6160000000018, -- [1]
					"Kokia Blazehoof", -- [2]
					372858, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [3]
				{
					33.81899999999587, -- [1]
					"Kokia Blazehoof", -- [2]
					372107, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					45.05999999999767, -- [1]
					"Kokia Blazehoof", -- [2]
					372863, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
			},
		}, -- [2]
		{
			["Infused Whelp"] = {
				{
					32.54200000000128, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					37.39299999999639, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
				{
					44.69200000000274, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Wollmieger-Sen'jin", -- [5]
				}, -- [3]
				{
					46.79299999999785, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [4]
				{
					49.54200000000128, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [5]
				{
					51.94200000000274, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [6]
				{
					54.39400000000023, -- [1]
					"Infused Whelp", -- [2]
					373803, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [7]
			},
			["Flashfrost Chillweaver"] = {
				{
					2.657999999995809, -- [1]
					"Flashfrost Chillweaver", -- [2]
					371489, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			["Melidrussa Chillworn"] = {
				{
					0.5769999999974971, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [1]
				{
					3.00800000000163, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [2]
				{
					6.282999999995809, -- [1]
					"Melidrussa Chillworn", -- [2]
					396044, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					9.059000000001106, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [4]
				{
					11.08400000000256, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [5]
				{
					16.25800000000163, -- [1]
					"Melidrussa Chillworn", -- [2]
					372851, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Allegory", -- [5]
				}, -- [6]
				{
					26.46699999999692, -- [1]
					"Melidrussa Chillworn", -- [2]
					373046, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
				{
					29.26900000000023, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [8]
				{
					31.70900000000256, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [9]
				{
					38.59300000000076, -- [1]
					"Melidrussa Chillworn", -- [2]
					373046, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [10]
				{
					41.44200000000274, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [11]
				{
					43.85899999999674, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [12]
				{
					46.26699999999983, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [13]
				{
					49.94200000000274, -- [1]
					"Melidrussa Chillworn", -- [2]
					396044, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [14]
				{
					53.56700000000274, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [15]
				{
					55.97899999999936, -- [1]
					"Melidrussa Chillworn", -- [2]
					372808, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Soîfon-Antonidas", -- [5]
				}, -- [16]
				{
					59.93499999999767, -- [1]
					"Melidrussa Chillworn", -- [2]
					372851, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Aniiema-Antonidas", -- [5]
				}, -- [17]
			},
		}, -- [3]
		{
			["Qalashi Wallcrasher"] = {
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					395816, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Qalashi Wallcrasher", -- [5]
				}, -- [1]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					370212, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					395816, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Qalashi Wallcrasher", -- [5]
				}, -- [3]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					395816, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Qalashi Wallcrasher", -- [5]
				}, -- [4]
				{
					477.3980000000011, -- [1]
					"Qalashi Wallcrasher", -- [2]
					370212, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
			},
			["Kurog Grimtotem"] = {
				{
					10.10699999999997, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [1]
				{
					15.90499999999884, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					24.40699999999924, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					35.60900000000038, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [4]
				{
					41.37299999999959, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					48.9419999999991, -- [1]
					"Kurog Grimtotem", -- [2]
					374022, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					56.23300000000018, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [7]
				{
					63.49799999999959, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [8]
				{
					71.99199999999837, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [9]
				{
					81.72799999999916, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [10]
				{
					88.98799999999756, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [11]
				{
					95.08899999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					372456, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [12]
				{
					102.3809999999976, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [13]
				{
					109.6499999999978, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [14]
				{
					118.1529999999984, -- [1]
					"Kurog Grimtotem", -- [2]
					373678, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [15]
				{
					125.755000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [16]
				{
					203.1699999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [17]
				{
					210.4739999999983, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [18]
				{
					228.6800000000003, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [19]
				{
					235.9369999999981, -- [1]
					"Kurog Grimtotem", -- [2]
					395893, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [20]
				{
					251.2649999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					374691, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [21]
				{
					256.5740000000005, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [22]
				{
					260.8420000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [23]
				{
					265.8479999999981, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [24]
				{
					269.3600000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [25]
				{
					274.364999999998, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [26]
				{
					282.0639999999985, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [27]
				{
					286.3420000000006, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [28]
				{
					291.3410000000004, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [29]
				{
					299.4069999999992, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [30]
				{
					302.7109999999993, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [31]
				{
					307.0010000000002, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [32]
				{
					312.0040000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [33]
				{
					315.5149999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [34]
				{
					319.9860000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					374779, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [35]
				{
					413.2039999999979, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Nadjane-Malygos", -- [5]
				}, -- [36]
				{
					417.4789999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [37]
				{
					422.4969999999994, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [38]
				{
					425.9860000000008, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [39]
				{
					430.987000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [40]
				{
					438.7010000000009, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [41]
				{
					442.9939999999988, -- [1]
					"Kurog Grimtotem", -- [2]
					390920, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [42]
				{
					448.005000000001, -- [1]
					"Kurog Grimtotem", -- [2]
					397341, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [43]
				{
					456.0570000000007, -- [1]
					"Kurog Grimtotem", -- [2]
					374215, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [44]
				{
					459.3389999999999, -- [1]
					"Kurog Grimtotem", -- [2]
					390548, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Zwarag", -- [5]
				}, -- [45]
				{
					465.1159999999982, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [46]
				{
					473.6229999999996, -- [1]
					"Kurog Grimtotem", -- [2]
					382563, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [47]
			},
			["Earth Breaker"] = {
				{
					252.1820000000007, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					252.5770000000011, -- [1]
					"Earth Breaker", -- [2]
					374705, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			["Worldcarver Wurmling"] = {
				{
					477.3980000000011, -- [1]
					"Worldcarver Wurmling", -- [2]
					359996, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
			},
			["Thundering Ravager"] = {
				{
					321.9779999999992, -- [1]
					"Thundering Ravager", -- [2]
					375792, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					330.0849999999991, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					331.5760000000009, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Schrottbot-Aman'thul", -- [5]
				}, -- [3]
				{
					350.7180000000008, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					352.2170000000006, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Schrottbot-Aman'thul", -- [5]
				}, -- [5]
				{
					371.3260000000009, -- [1]
					"Thundering Ravager", -- [2]
					374621, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					372.8349999999991, -- [1]
					"Thundering Ravager", -- [2]
					374622, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
					"Sanmara-KultderVerdammten", -- [5]
				}, -- [7]
			},
			["Blazing Fiend"] = {
				{
					127.6840000000011, -- [1]
					"Blazing Fiend", -- [2]
					374485, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					127.6840000000011, -- [1]
					"Blazing Fiend", -- [2]
					375828, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			["Frozen Destroyer"] = {
				{
					127.6840000000011, -- [1]
					"Frozen Destroyer", -- [2]
					375825, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					162.6889999999985, -- [1]
					"Frozen Destroyer", -- [2]
					374624, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
			},
			["Tectonic Crusher"] = {
				{
					321.9779999999992, -- [1]
					"Tectonic Crusher", -- [2]
					375824, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [1]
				{
					327.4759999999988, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [2]
				{
					332.482, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [3]
				{
					345.9609999999993, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [4]
				{
					357.9969999999994, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [5]
				{
					363.0149999999994, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [6]
				{
					379.9520000000011, -- [1]
					"Tectonic Crusher", -- [2]
					374430, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [7]
				{
					388.3339999999989, -- [1]
					"Tectonic Crusher", -- [2]
					374427, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [8]
				{
					393.3529999999992, -- [1]
					"Tectonic Crusher", -- [2]
					397338, -- [3]
					"SPELL_CAST_SUCCESS", -- [4]
				}, -- [9]
			},
		}, -- [4]
	},
}
