
g_professionsSpecsSelectedTabs = {
	[2834] = 403,
	[2830] = 377,
}
g_professionsSpecsSelectedPaths = {
	[403] = 34687,
	[348] = 28437,
	[405] = 34758,
	[376] = 31143,
	[377] = 31184,
}
