
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"nullopt\" loginPortal=\"EU.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"[IBN_Login] Attempting logonhost=\"EU.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\" (314)\" localizedMessage=\"We couldn't verify your account with that information.\" debugMessage=\"JSON error: Status has no name. (14400) token: 2\")\"", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"nullopt\" loginPortal=\"EU.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"[IBN_Login] Attempting logonhost=\"EU.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"[IBN_Login] Joining realmsubRegion=\"3-4-89\" realmAddress=\"3-4-34\"", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"2\"", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"2\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"[WowEntitlements] [BNetAccount-0-0000060DBF52] [WowAccount-0-000001187FEB] Initialized with 12 entitlements.", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Proficiency in item class 2 set to 0x0000008000", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Proficiency in item class 2 set to 0x000000c000", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Proficiency in item class 2 set to 0x000000c400", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Proficiency in item class 2 set to 0x000010c400", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Proficiency in item class 2 set to 0x000010c480", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Time set to 2/2/2023 (Thu) 16:11", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"GameTimeSync: skipping forwards 2 game minutes, (current = 2/2/2023 (Thu) 16:23, newtime = 2/2/2023 (Thu) 16:25)", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 118.", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Skill 126 increased from 320 to 325", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Skill 183 increased from 320 to 325", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Skill 904 increased from 320 to 325", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Skill 228 increased from 320 to 325", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"GameTimeSync: delta=0, differential=1, HoursAndMinutes=1037", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"Skill 197 increased from 51 to 52", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Skill 2831 increased from 51 to 52", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Skill 197 increased from 52 to 53", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Skill 2831 increased from 52 to 53", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Skill 197 increased from 53 to 54", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Skill 2831 increased from 53 to 54", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Skill 197 increased from 54 to 55", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Skill 2831 increased from 54 to 55", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Skill 197 increased from 55 to 56", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Skill 2831 increased from 55 to 56", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Skill 197 increased from 56 to 57", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Skill 2831 increased from 56 to 57", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Skill 197 increased from 57 to 58", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Skill 2831 increased from 57 to 58", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Weather changed to 1, intensity 0.141478\n", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Weather changed to 1, intensity 0.147398\n", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Spell Clutter disabled", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Render scale changed to 0.65", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"CVar 'vrsWorldGeo' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"CVar 'vrsParticles' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"[IBN_Login] Attempting logonhost=\"eu.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"[GlueLogin] Reconnect token saved; creationTime=\"1675363416\" expirationTime=\"1675377816\"", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"[IBN_Login] Joining realmsubRegion=\"3-4-89\" realmAddress=\"3-4-34\"", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"[WowEntitlements] [BNetAccount-0-0000060DBF52] [WowAccount-0-000001187FEB] Initialized with 12 entitlements.", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Proficiency in item class 2 set to 0x0000008000", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Proficiency in item class 2 set to 0x000000c000", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Proficiency in item class 2 set to 0x000000c400", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Proficiency in item class 2 set to 0x000010c400", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Proficiency in item class 2 set to 0x000010c480", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Time set to 2/2/2023 (Thu) 19:43", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 118.", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Weather changed to 3, intensity 0.308809\n", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Skill 126 increased from 325 to 330", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Skill 183 increased from 325 to 330", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Skill 904 increased from 325 to 330", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Skill 228 increased from 325 to 330", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Weather changed to 3, intensity 0.308809\n", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Weather changed to 3, intensity 0.829982\n", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Weather changed to 3, intensity 0.308809\n", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Proficiency in item class 2 set to 0x0000000100", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Proficiency in item class 2 set to 0x0000000101", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Proficiency in item class 2 set to 0x0000008101", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Proficiency in item class 2 set to 0x000000c101", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Proficiency in item class 2 set to 0x000000c103", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Proficiency in item class 2 set to 0x000000c503", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Proficiency in item class 2 set to 0x000000c523", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Proficiency in item class 2 set to 0x000000e523", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Proficiency in item class 2 set to 0x000010e523", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Proficiency in item class 2 set to 0x000010e533", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Proficiency in item class 2 set to 0x000010e5b3", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Proficiency in item class 2 set to 0x000010e5b3", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Time set to 2/2/2023 (Thu) 20:45", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"Proficiency in item class 2 set to 0x0000008000", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Proficiency in item class 2 set to 0x000000c000", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Proficiency in item class 2 set to 0x000000c400", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Proficiency in item class 2 set to 0x000010c400", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Proficiency in item class 2 set to 0x000010c480", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"Time set to 2/2/2023 (Thu) 20:49", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"Spell Clutter disabled", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Render scale changed to 0.65", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"CVar 'vrsWorldGeo' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"CVar 'vrsParticles' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"[IBN_Login] Attempting logonhost=\"eu.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"[GlueLogin] Reconnect token saved; creationTime=\"1675432942\" expirationTime=\"1675447342\"", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"[IBN_Login] Joining realmsubRegion=\"3-4-89\" realmAddress=\"3-4-34\"", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"[WowEntitlements] [BNetAccount-0-0000060DBF52] [WowAccount-0-000001187FEB] Initialized with 12 entitlements.", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Proficiency in item class 2 set to 0x0000000100", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Proficiency in item class 2 set to 0x0000000101", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Proficiency in item class 2 set to 0x0000008101", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Proficiency in item class 2 set to 0x000000c101", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Proficiency in item class 2 set to 0x000000c103", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Proficiency in item class 2 set to 0x000000c503", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Proficiency in item class 2 set to 0x000000c523", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Proficiency in item class 2 set to 0x000000e523", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Proficiency in item class 2 set to 0x000010e523", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Proficiency in item class 2 set to 0x000010e533", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Proficiency in item class 2 set to 0x000010e5b3", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Proficiency in item class 2 set to 0x000010e5b3", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Time set to 2/3/2023 (Fri) 15:02", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Skill 2558 increased from 0 to 1", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Spell Clutter disabled", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Render scale changed to 0.65", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"CVar 'vrsWorldGeo' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"CVar 'vrsParticles' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"[IBN_Login] Attempting logonhost=\"eu.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"[GlueLogin] Reconnect token saved; creationTime=\"1676235873\" expirationTime=\"1676250273\"", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"[IBN_Login] Joining realmsubRegion=\"3-4-89\" realmAddress=\"3-4-34\"", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"[WowEntitlements] [BNetAccount-0-00000837ADD4] [WowAccount-0-00000548995D] Initialized with 50 entitlements.", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Proficiency in item class 2 set to 0x0000004001", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Proficiency in item class 2 set to 0x0000006001", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Proficiency in item class 2 set to 0x0000106001", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Proficiency in item class 2 set to 0x0000106081", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Time set to 2/12/2023 (Sun) 22:05", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Proficiency in item class 2 set to 0x0000000100", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Proficiency in item class 2 set to 0x0000000101", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Proficiency in item class 2 set to 0x0000000141", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Proficiency in item class 2 set to 0x0000004141", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Proficiency in item class 2 set to 0x0000004143", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Proficiency in item class 4 set to 0x0000000061", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Proficiency in item class 4 set to 0x0000000069", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Proficiency in item class 4 set to 0x000000006d", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Proficiency in item class 2 set to 0x0000004163", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Proficiency in item class 4 set to 0x000000007d", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Proficiency in item class 2 set to 0x0000104163", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Proficiency in item class 2 set to 0x0000104173", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Proficiency in item class 2 set to 0x00001041f3", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Time set to 2/12/2023 (Sun) 22:05", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [644]
		{
			"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [645]
		{
			"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [646]
		{
			"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [647]
		{
			"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [648]
		{
			"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [649]
		{
			"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [650]
		{
			"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [651]
		{
			"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [652]
		{
			"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [653]
		{
			"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [654]
		{
			"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [655]
		{
			"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [656]
		{
			"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [657]
		{
			"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [658]
		{
			"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [659]
		{
			"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [660]
		{
			"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [661]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Weather changed to 1, intensity 0.101152\n", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Weather changed to 2, intensity 0.217562\n", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"[GlueLogin] Explicitly disconnecting from realm server", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Disconnecting for reason 14", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"false\"", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"Spell Clutter disabled", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Render scale changed to 0.65", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"CVar 'vrsWorldGeo' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"CVar 'vrsParticles' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"[IBN_Login] Attempting logonhost=\"eu.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"[GlueLogin] Reconnect token saved; creationTime=\"1676495421\" expirationTime=\"1676509821\"", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"[IBN_Login] Joining realmsubRegion=\"3-4-89\" realmAddress=\"3-4-34\"", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"[WowEntitlements] [BNetAccount-0-00000837ADD4] [WowAccount-0-00000548995D] Initialized with 50 entitlements.", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Proficiency in item class 2 set to 0x0000004001", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"Proficiency in item class 2 set to 0x0000006001", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Proficiency in item class 2 set to 0x0000106001", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Proficiency in item class 2 set to 0x0000106081", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Time set to 2/15/2023 (Wed) 22:11", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Spell Clutter disabled", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Render scale changed to 0.65", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"CVar 'vrsWorldGeo' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"CVar 'vrsParticles' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"[IBN_Login] Attempting logonhost=\"eu.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"[GlueLogin] Reconnect token saved; creationTime=\"1676569993\" expirationTime=\"1676584393\"", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"[IBN_Login] Joining realmsubRegion=\"3-4-89\" realmAddress=\"3-4-34\"", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"[WowEntitlements] [BNetAccount-0-00000837ADD4] [WowAccount-0-00000548995D] Initialized with 50 entitlements.", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Proficiency in item class 2 set to 0x0000004001", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Proficiency in item class 2 set to 0x0000006001", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Proficiency in item class 2 set to 0x0000106001", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Proficiency in item class 2 set to 0x0000106081", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Time set to 2/16/2023 (Thu) 18:52", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Weather changed to 1, intensity 0.120718\n", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Weather changed to 1, intensity 0.120718\n", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [927]
		{
			"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [928]
		{
			"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [929]
		{
			"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [930]
		{
			"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [931]
		{
			"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [932]
		{
			"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [933]
		{
			"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [934]
		{
			"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [935]
		{
			"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [936]
		{
			"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [937]
		{
			"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [938]
		{
			"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [939]
		{
			"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [940]
		{
			"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [941]
		{
			"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [942]
		{
			"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [943]
		{
			"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.", -- [1]
			3, -- [2]
		}, -- [944]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"GameTimeSync: skipping forwards 2 game minutes, (current = 2/16/2023 (Thu) 19:55, newtime = 2/16/2023 (Thu) 19:57)", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"CVar 'nameplatePlayerMaxDistance' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Completed challenge mode mapID 1176, level 20, time 2223643", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Completed challenge mode mapID 2516, level 16, time 1795227", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Disconnecting for reason 1", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [1002]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [1003]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"true\"", -- [1]
			0, -- [2]
		}, -- [1004]
	},
	["height"] = 299.9999694824219,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
