
AtlasLootCharDB = {
	["__addonrevision"] = 4772,
	["GUI"] = {
		["selected"] = {
			[4] = 1,
			[5] = 0,
		},
	},
}
