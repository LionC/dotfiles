
HandyNotes_BattleForAzerothTreasuresDB = {
	["profileKeys"] = {
		["Xyresia - Blackmoore"] = "Xyresia - Blackmoore",
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
	},
	["profiles"] = {
		["Xyresia - Blackmoore"] = {
		},
		["Lionc - Blackmoore"] = {
		},
	},
}
