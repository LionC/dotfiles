
HandyNotesDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Taifunari - Blackmoore",
		["Farfarella - Blackmoore"] = "Farfarella - Blackmoore",
	},
	["profiles"] = {
		["Taifunari - Blackmoore"] = {
		},
		["Farfarella - Blackmoore"] = {
		},
	},
}
HandyNotes_HandyNotesDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Taifunari - Blackmoore",
		["Farfarella - Blackmoore"] = "Farfarella - Blackmoore",
	},
	["profiles"] = {
		["Taifunari - Blackmoore"] = {
		},
		["Farfarella - Blackmoore"] = {
		},
	},
}
