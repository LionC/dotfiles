
Bagnon_Sets = {
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["glowAlpha"] = 0.5,
	["engineerColor"] = {
	},
	["refrigeColor"] = {
	},
	["profiles"] = {
	},
	["mineColor"] = {
	},
	["inscribeColor"] = {
	},
	["global"] = {
		["inventory"] = {
			["rules"] = {
				"all", -- [1]
				"all/all", -- [2]
				"all/normal", -- [3]
				"all/trade", -- [4]
				"all/reagent", -- [5]
				"equip", -- [6]
				"equip/all", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/all", -- [12]
				"use/consume", -- [13]
				"use/enhance", -- [14]
				"trade", -- [15]
				"trade/all", -- [16]
				"trade/goods", -- [17]
				"trade/gem", -- [18]
				"trade/glyph", -- [19]
				"trade/recipe", -- [20]
				"quest", -- [21]
				"misc", -- [22]
				"quest/all", -- [23]
				"contain/all", -- [24]
				"misc/all", -- [25]
			},
			["point"] = "BOTTOMRIGHT",
			["hiddenBags"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				[0] = false,
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["y"] = 0,
			["x"] = 0,
			["bagFrame"] = true,
			["borderColor"] = {
			},
			["alpha"] = 1,
			["scale"] = 1,
			["itemScale"] = 1,
			["brokerObject"] = "BagnonLauncher",
		},
		["vault"] = {
			["y"] = 0,
			["rules"] = {
				"all", -- [1]
				"all/all", -- [2]
				"all/normal", -- [3]
				"all/trade", -- [4]
				"all/reagent", -- [5]
				"equip", -- [6]
				"equip/all", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/all", -- [12]
				"use/consume", -- [13]
				"use/enhance", -- [14]
				"trade", -- [15]
				"trade/all", -- [16]
				"trade/goods", -- [17]
				"trade/gem", -- [18]
				"trade/glyph", -- [19]
				"trade/recipe", -- [20]
				"quest", -- [21]
				"misc", -- [22]
				"quest/all", -- [23]
				"contain/all", -- [24]
				"misc/all", -- [25]
			},
			["point"] = "BOTTOMLEFT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["borderColor"] = {
			},
			["hiddenRules"] = {
			},
			["x"] = 178.301605224609,
		},
		["guild"] = {
			["y"] = 242.166687011719,
			["rules"] = {
				"all", -- [1]
				"all/all", -- [2]
				"all/normal", -- [3]
				"all/trade", -- [4]
				"all/reagent", -- [5]
				"equip", -- [6]
				"equip/all", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/all", -- [12]
				"use/consume", -- [13]
				"use/enhance", -- [14]
				"trade", -- [15]
				"trade/all", -- [16]
				"trade/goods", -- [17]
				"trade/gem", -- [18]
				"trade/glyph", -- [19]
				"trade/recipe", -- [20]
				"quest", -- [21]
				"misc", -- [22]
				"quest/all", -- [23]
				"contain/all", -- [24]
				"misc/all", -- [25]
			},
			["point"] = "BOTTOMRIGHT",
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenBags"] = {
			},
			["hiddenRules"] = {
			},
			["x"] = -402.666687011719,
		},
		["bank"] = {
			["rules"] = {
				"all", -- [1]
				"all/all", -- [2]
				"all/normal", -- [3]
				"all/trade", -- [4]
				"all/reagent", -- [5]
				"equip", -- [6]
				"equip/all", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/all", -- [12]
				"use/consume", -- [13]
				"use/enhance", -- [14]
				"trade", -- [15]
				"trade/all", -- [16]
				"trade/goods", -- [17]
				"trade/gem", -- [18]
				"trade/glyph", -- [19]
				"trade/recipe", -- [20]
				"quest", -- [21]
				"misc", -- [22]
				"quest/all", -- [23]
				"contain/all", -- [24]
				"misc/all", -- [25]
			},
			["point"] = "TOPLEFT",
			["hiddenBags"] = {
				[6] = true,
				[7] = true,
				[8] = false,
				[10] = true,
				[5] = true,
				[-3] = false,
				[9] = true,
				[-1] = false,
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["y"] = 0,
			["x"] = 97.0317306518555,
			["alpha"] = 1,
			["showBags"] = true,
			["scale"] = 1,
			["itemScale"] = 1,
			["brokerObject"] = "BagnonLauncher",
			["borderColor"] = {
			},
		},
	},
	["normalColor"] = {
	},
	["herbColor"] = {
	},
	["tackleColor"] = {
	},
	["leatherColor"] = {
	},
}
