
NameplateSCTDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Xyresia - Blackmoore"] = "Default",
		["Ämelia - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
		["Gaeralt - Blackmoore"] = "Default",
		["Crayona - Blackmoore"] = "Default",
		["Lionc - Blackmoore"] = "Default",
		["Jakuup - Blackmoore"] = "Default",
		["Nißa - Blackmoore"] = "Default",
		["Lioncilu - Blackmoore"] = "Default",
		["Laeduin - Blackmoore"] = "Default",
		["Bhrian - Blackmoore"] = "Default",
		["Amilanoo - Blackmoore"] = "Default",
	},
	["global"] = {
		["damageColor"] = false,
	},
}
