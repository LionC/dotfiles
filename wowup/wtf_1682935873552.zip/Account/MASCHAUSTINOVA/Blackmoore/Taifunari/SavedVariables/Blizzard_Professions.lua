
g_professionsSpecsSelectedTabs = {
	[2831] = 448,
}
g_professionsSpecsSelectedPaths = {
	[445] = 40038,
	[448] = 40217,
}
