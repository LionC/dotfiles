
HandyNotes_ShadowlandsDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Farfarella - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
