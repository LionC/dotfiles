
AstralKeys = {
	{
		["source"] = "guild",
		["weekly_best"] = 19,
		["class"] = "PRIEST",
		["key_level"] = 17,
		["unit"] = "Nilandra-Blackmoore",
		["dungeon_id"] = 2,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 204357,
	}, -- [1]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "DEATHKNIGHT",
		["key_level"] = 21,
		["unit"] = "Astranith-Blackmoore",
		["dungeon_id"] = 2,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 58197,
	}, -- [2]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "PALADIN",
		["key_level"] = 8,
		["unit"] = "Kendrana-Blackmoore",
		["dungeon_id"] = 210,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 4,
	}, -- [3]
	{
		["source"] = "guild",
		["weekly_best"] = 4,
		["class"] = "HUNTER",
		["key_level"] = 10,
		["unit"] = "Bahyla-Blackmoore",
		["dungeon_id"] = 401,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 49087,
	}, -- [4]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "ROGUE",
		["key_level"] = 19,
		["unit"] = "Happenslol-Blackmoore",
		["dungeon_id"] = 401,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 58681,
	}, -- [5]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "DEMONHUNTER",
		["key_level"] = 21,
		["unit"] = "Scahra-Blackmoore",
		["dungeon_id"] = 399,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 132455,
		["btag"] = "LionC#2680",
	}, -- [6]
	{
		["source"] = "guild",
		["weekly_best"] = 4,
		["class"] = "MONK",
		["key_level"] = 10,
		["unit"] = "Acumena-Blackmoore",
		["dungeon_id"] = 402,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 52270,
	}, -- [7]
	{
		["source"] = "guild",
		["weekly_best"] = 9,
		["class"] = "DRUID",
		["key_level"] = 8,
		["unit"] = "Caxivora-Blackmoore",
		["dungeon_id"] = 2,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 55191,
	}, -- [8]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "PALADIN",
		["key_level"] = 19,
		["unit"] = "Aubry-Blackmoore",
		["dungeon_id"] = 399,
		["week"] = 289,
		["faction"] = 0,
		["time_stamp"] = 132475,
	}, -- [9]
}
AstralCharacters = {
	{
		["weekly_best"] = 0,
		["class"] = "EVOKER",
		["unit"] = "Allegory-Blackmoore",
		["faction"] = 0,
	}, -- [1]
}
AstralKeysSettings = {
	["wipedOldTables"] = true,
	["general"] = {
		["show_minimap_button"] = {
			["isEnabled"] = true,
		},
		["init_time"] = 1675839600,
		["expanded_tooltip"] = {
			["isEnabled"] = true,
		},
		["report_on_message"] = {
			["no_key"] = false,
			["party"] = true,
			["guild"] = false,
			["raid"] = false,
		},
		["show_tooltip_key"] = {
			["isEnabled"] = true,
		},
		["announce_party"] = {
			["isEnabled"] = true,
		},
		["announce_guild"] = {
			["isEnabled"] = false,
		},
	},
	["frame"] = {
		["rank_filter"] = {
			true, -- [1]
			true, -- [2]
			true, -- [3]
			true, -- [4]
			true, -- [5]
			true, -- [6]
			true, -- [7]
			true, -- [8]
			true, -- [9]
			true, -- [10]
		},
		["show_offline"] = {
			["isEnabled"] = true,
		},
		["isCollapsed"] = {
			["isEnabled"] = false,
		},
		["orientation"] = 1,
		["mingle_offline"] = {
			["isEnabled"] = false,
		},
		["sorth_method"] = "character_name",
		["current_list"] = "GUILD",
	},
	["friendOptions"] = {
		["friend_sync"] = {
			["isEnabled"] = true,
		},
		["show_other_faction"] = {
			["isEnabled"] = true,
		},
	},
	["new_settings_config"] = true,
}
AstralMinimap = {
	["profileKeys"] = {
		["Allegory - Blackmoore"] = "Allegory - Blackmoore",
		["Natinne - Blackmoore"] = "Natinne - Blackmoore",
		["Farfarella - Blackmoore"] = "Farfarella - Blackmoore",
	},
	["profiles"] = {
		["Allegory - Blackmoore"] = {
			["minimap"] = {
				["minimapPos"] = 41.40568717562186,
			},
		},
		["Natinne - Blackmoore"] = {
		},
		["Farfarella - Blackmoore"] = {
		},
	},
}
AstralAffixes = {
	["rotation"] = {
	},
	["season_start_week"] = 284,
	["season_affix"] = 132,
}
AstralLists = {
	{
		["name"] = "GUILD",
		["units"] = {
			["Scahra-Blackmoore"] = "LionC#2680",
			["Moiyra-Blackmoore"] = true,
			["Acumena-Blackmoore"] = true,
			["Aubry-Blackmoore"] = true,
			["Bahyla-Blackmoore"] = true,
			["Prîmecut-Blackmoore"] = true,
			["Allegory-Blackmoore"] = true,
			["Malomedies-Blackmoore"] = true,
			["Miotas-Blackmoore"] = true,
			["Carêless-Blackmoore"] = true,
			["Soosai-Blackmoore"] = true,
			["Dyrell-Blackmoore"] = true,
			["Diablerie-Blackmoore"] = true,
			["Kalzifer-Blackmoore"] = true,
			["Quendolyn-Blackmoore"] = true,
			["Selenerah-Blackmoore"] = true,
			["Nilandra-Blackmoore"] = true,
			["Happenslol-Blackmoore"] = true,
			["Gorlirn-Blackmoore"] = true,
			["Nascha-Blackmoore"] = true,
			["Caxivora-Blackmoore"] = true,
			["Astranith-Blackmoore"] = true,
			["Nazki-Blackmoore"] = true,
			["Morrizane-Blackmoore"] = true,
			["Hakizu-Blackmoore"] = true,
			["Kendrana-Blackmoore"] = true,
			["Selendrenah-Blackmoore"] = true,
			["Sooseia-Blackmoore"] = true,
		},
	}, -- [1]
	{
		["name"] = "FRIENDS",
		["units"] = {
			["Gorlirn-Blackmoore"] = true,
			["Scahra-Blackmoore"] = "LionC#2680",
		},
	}, -- [2]
}
AstralUnits = nil
