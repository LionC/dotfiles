
TomCats_Mechagon_Character = {
	["preferences"] = {
		["TomCats-MechagonMinimapButton"] = {
			["position"] = -2.664687343811317,
		},
	},
}
