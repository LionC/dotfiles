
ClassicFCTCharConfig = nil
ClassicFCTCharVars = nil
ClassicFCTCharTables = nil
