
HandyNotes_LegionTreasuresDB = {
	["profileKeys"] = {
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
		["Xyresia - Blackmoore"] = "Xyresia - Blackmoore",
	},
	["profiles"] = {
		["Lionc - Blackmoore"] = {
		},
		["Xyresia - Blackmoore"] = {
		},
	},
}
