
OmniCDDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Lionc - Blackmoore"] = "Default",
		["Bhrian - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
		["BattleRes"] = {
		},
	},
	["cooldowns"] = {
	},
	["version"] = 3,
	["profiles"] = {
		["Default"] = {
			["Party"] = {
				["party"] = {
					["extraBars"] = {
						["raidBar0"] = {
							["manualPos"] = {
								["raidBar0"] = {
									["y"] = 224.3024308866279,
									["x"] = 333.9648379547107,
								},
							},
						},
					},
					["spells"] = {
						["59752"] = false,
						["221562"] = true,
						["47482"] = false,
						["50334"] = true,
						["102543"] = true,
						["152279"] = true,
						["228260"] = true,
						["391109"] = true,
						["264735"] = true,
						["49576"] = true,
						["236776"] = true,
						["383269"] = true,
						["207167"] = true,
					},
					["position"] = {
						["attach"] = "TOPLEFT",
						["preset"] = "TOPLEFT",
						["anchor"] = "TOPRIGHT",
					},
					["priority"] = {
						["offensive"] = 20,
					},
				},
				["arena"] = {
					["spells"] = {
						["221562"] = true,
						["207167"] = true,
						["49576"] = true,
						["383269"] = true,
					},
					["position"] = {
						["attach"] = "TOPLEFT",
						["preset"] = "TOPLEFT",
						["anchor"] = "TOPRIGHT",
					},
				},
			},
		},
	},
}
