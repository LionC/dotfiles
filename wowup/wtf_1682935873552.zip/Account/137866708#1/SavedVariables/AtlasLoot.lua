
AtlasLootDB = {
}
