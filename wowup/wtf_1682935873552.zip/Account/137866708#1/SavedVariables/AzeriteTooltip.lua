
AzeriteTooltipDB = {
	["OnlySpec"] = false,
	["Compact"] = false,
	["Bags"] = true,
	["Flyout"] = true,
	["RemoveBlizzard"] = true,
}
