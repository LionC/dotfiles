
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["editor_tab_spaces"] = 4,
	["login_squelch_time"] = 10,
	["lastArchiveClear"] = 1613312819,
	["minimap"] = {
		["minimapPos"] = 25.19289986112062,
		["hide"] = false,
	},
	["lastUpgrade"] = 1675181491,
	["dbVersion"] = 64,
	["displays"] = {
		["Inscription"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Inscription one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "TINS",
					["useDesc"] = true,
					["name"] = "Track Inscription",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Inscription Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				1, -- [1]
				1, -- [2]
				0.60000002384186, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "N8L8DKipCyr",
			["displayIcon"] = "4620676",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Isc Module",
			["barColor2"] = {
				0, -- [1]
				0.4627451300621, -- [2]
				0.69803923368454, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620676,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TINS then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 45357,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Inscription",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				1, -- [1]
				1, -- [2]
				0.60000002384186, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["TINS"] = true,
				["Utt"] = true,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Inscription",
						["zone"] = 5,
						["hiddenQuestId"] = "74105",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 64.3,
						["X"] = 40.2,
						["name"] = "Profession master Lydiara Whisperfeather",
						["zone"] = 3,
						["hiddenQuestId"] = "70254",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [2]
					{
						["Y"] = 57.96,
						["X"] = 67.87,
						["name"] = "Pulsing Earth Rune",
						["zone"] = 1,
						["hiddenQuestId"] = "70306",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 25.2,
						["X"] = 85.7,
						["name"] = "Sign Language Reference Sheet",
						["zone"] = 2,
						["hiddenQuestId"] = "70307",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 23.9,
						["X"] = 46.2,
						["name"] = "Dusty Darkmoon Card",
						["zone"] = 3,
						["hiddenQuestId"] = "70297",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 30.9,
						["X"] = 43.7,
						["name"] = "Frosted Parchment",
						["zone"] = 3,
						["hiddenQuestId"] = "70293",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 63.68,
						["X"] = 13.2,
						["name"] = "How to Train Your Whelpling",
						["zone"] = 5,
						["hiddenQuestId"] = "70281",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 41.2,
						["X"] = 56.3,
						["name"] = "Forgetful Apprentice's Tome",
						["zone"] = 4,
						["hiddenQuestId"] = "70264",
						["drops"] = "198659",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 40.1,
						["X"] = 47.1,
						["name"] = "Forgetful Apprentice's Tome",
						["zone"] = 4,
						["hiddenQuestId"] = "70248",
						["drops"] = "198654",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [9]
					{
						["Y"] = 40.9,
						["X"] = 56.1,
						["name"] = "Counterfeit Darkmoon Deck",
						["zone"] = 4,
						["hiddenQuestId"] = "70287",
						["drops"] = "201015",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [10]
				},
				["hideCompleted"] = true,
				["onlyElites"] = false,
			},
		},
		["sp1"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 7,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "-- Default Locale --\naura_env.defaultLocale = 'enUS'\n-- User Locale Var--\naura_env.userLocale = GetLocale()\n-- Get Text sinppet --\naura_env.get_text_snippet = function(name)\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.userLocale] then\n    return aura_env.textSnippets[name][aura_env.userLocale]\n  end\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.defaultLocale] then\n    return aura_env.textSnippets[name][aura_env.defaultLocale]\n  end\n  return name\nend\n-- World quest Availibility --\naura_env.is_world_quest_available = function(quest)\n  if not C_TaskQuest.GetQuestTimeLeftSeconds(quest) then\n    return true\n  end\n  return false\nend\n-- Quest Completion check --\naura_env.is_quest_completed = function(quest)\n  if C_QuestLog.IsQuestFlaggedCompleted(quest) then\n    return true\n  end\n  return false\nend\n-- Enlightened Faction --\naura_env.factionID = 2478\n-- Title items --\n--Norah#21256 thank you for French Tranlations\n--Beatrice#2650 & Podwiznaia#2373 thank you both for help with the Russian Translations\n--Shokuhou (Orillion), Lars, phoi thank you all for your japanese Translations\n--Shokuhou (Orillion) thank you for your Dutch Translations\n--Zamy thank you for your Koreran Translations\n--三皈依#3388 thank you for your Translations\n--hohunide thank you for your Translations\n--N3cro#92 thank you for your German Translations\naura_env.textSnippets = {\n  overviewHeadline = { enUS = ' Todo list:',\n    deDE = 'Aufgabenliste:',\n    zhTW = '的任務列表: ', \n    zhCN = ' 任务列表:', \n    ruRU = 'Список дел ' ,\n    frFR = 'Liste de choses à faire :' ,\n    jaJP = 'タマのやること帳・ ',\n    koKR = '숙제 리스트 ',\n  },\n  \n  worldBoss = { \n    enUS = 'World Boss: ',\n    deDE = 'Weltboss: ',\n    zhTW = '世界首領', \n    zhCN = '世界BOSS: ',\n    ruRU = 'Мировой босс:',\n    frFR = 'Boss mondial: ',\n    nlNL = 'Wereld Baas',\n    jaJP = 'ワールドボス',\n    koKR = '필드보스',\n  },\n  \n  worldQuests = {\n    enUS = 'World Quests: ',\n    deDE = 'Welt-Quests: ',\n    zhTW = '世界任務', \n    zhCN = '世界任务: ',\n    ruRU = 'МЛокальные задания:',\n    frFR = 'Quêtes mondiales: ',\n    nlNL = 'World Quests',\n    jaJP = 'アコードを手伝う',\n    koKR = '전역 퀘스트',\n  },\n  \n  weeklyQuest = {\n    enUS = 'Aiding the Accord: ',\n    deDE = 'Unterstützung des Abkommens ',\n    zhTW = '支援協調者：', \n    zhCN = '协助援军： ',\n    ruRU = 'Содействие Соглашению: ',\n    frFR = 'Aider le concordat: ',\n    nlNL = 'Accord Assistentie',\n    jaJP='アコードを手伝う',\n    koKR = '협의회 지원',\n  },\n  \n  CommunityFeast = {\n    enUS = 'Community Feast: ',\n    deDE = 'Gemeinschaftsfest: ',\n    zhTW = '集體盛宴：', \n    zhCN = '社区盛宴： ',\n    ruRU = 'Большое пиршество: ',\n    frFR = 'Festin tribal:  ',\n    nlNL = 'Gemeenschap`s Feestmaal',\n    jaJP = 'コミュニティの宴会',\n    koKR = '공동체 잔치',\n  },\n  \n  elements = {\n    enUS = 'Trial of Elements: ',\n    deDE = 'Prüfung der Elemente:',\n    zhTW = '元素的試煉: ', \n    zhCN = '元素审判:  ',\n    ruRU = 'Испытание элементов: ',\n    frFR = 'L’épreuve des éléments: ',\n    nlNL = 'Test van de Elementen',\n    jaJP = '五大の試し',\n    koKR = '원소의 시험',\n  },\n  \n  flood = {\n    enUS = 'Trial of Flood: ',\n    deDE = 'Prüfung der Flut:',\n    zhTW = '洪流的試煉: ', \n    zhCN = '洪水的审判： ',\n    ruRU = 'Испытание наводнения: ', \n    frFR = 'L’épreuve du déluge:  ',\n    nlNL = 'Test van de Overstroming',\n    jaJP = '洪水の試し',\n    koKR = '홍수의 시험',\n  },\n  \n  SoDK = {\n    enUS = 'Siege of Dragonscale Keep: ',\n    deDE = 'Belagerung der Drachenschuppenburg: ',\n    zhTW = '攻打龍禍要塞： ', \n    zhCN = '围攻灭龙要塞: ',\n    ruRU = 'Осада драконьей погибели: ',\n    frFR = 'Siege du Fleau-des-dragons: ',\n    nlNL = 'Belegering van Fort Dragonscale',\n    jaJP =' ドラゴンスケール天守の包囲',\n    koKR = '용의 파멸 성채 공성전',\n  },\n  \n  Hunt = {\n    enUS = 'Grand Hunts: ',\n    deDE = 'GroBe Jagden: ',\n    zhTW = '大狩獵: ', \n    zhCN = '洪荒狩猎: ',\n    ruRU = 'Великая охота: ',\n    frFR = 'Grandes Chasses: ',\n    nlNL = 'Grootse Jachten',\n    jaJP = '盛大狩り',\n    koKR = '사냥의 제전',\n  },\n}\n-- TODO - Items --\naura_env.todoList = {\n  {name = \"weeklyQuest\", maximum = 1,\n    quests = {\n      {questId = 70750,},--Aiding the Accord-- \n    },\n  },\n  \n  {name = \"CommunityFeast\",maximum = 1,\n    quests = {\n      {questId = 70893,},-- Hidden quest ID 70893--\n    },\n  },\n  \n  {name = \"SoDK\",maximum = 1,\n    quests = {\n      {questId = 70866,},-- confirm this Hidden ID72025 0r 70866--\n    },\n  },\n  \n  {name = \"Hunt\",maximum = 1,\n    quests = {\n      {questId = 70906,},-- WS 25.44,92.29-- Epic\n      -- {questId = 69998,},-- WS 25.44,92.29--\n      -- {questId = 69999,},-- WS 40.98,84.46--\n      -- {questId = 70000,},-- WS 25.44,92.29--\n    },\n  },\n  {name = \"flood\",maximum = 1,\n    quests = {\n      {questId = 71033,}, --Raging Torrent mobID 197221 hidden ID 71033 --\n    },\n  },\n  {name = \"elements\",maximum = 1,\n    quests = {\n      {questId = 71995,}, --Therrocite mob id 197749--\n    },\n  },\n  \n  { name = \"worldBoss\",  maximum = 1,\n    quests = {\n      {questId = 65234,}, -- Bazual mobID 193532, hidden ID####--\n      {questId = 65262,},-- Liskanoth  mobID 193533, hidden ID####--\n      {questId = 65231,},-- Strunraan mobID 193534, hidden ID####--\n      {questId = 65115,},-- Basrikron mobID 193535, hidden ID####--\n      \n    },\n  },\n  \n}\n\n--Output Varible--\naura_env.text = '';\n--Output Main function--\naura_env.update_overview_display = function()\n  local text = ''\n  -----------------------------------------------------Todo list Prep--------------------------------------------------------------------------- \n  for _, todoEntry in ipairs(aura_env.todoList) do\n    -- PINK --\n    local entry, color, completed, maximum = '', 'ffff00ff', 0, #todoEntry.quests\n    if \n    --set up the items to display\n    -- todoEntry.name == 'worldQuests' and aura_env.config['includeWorldQuest'] or -- < not need in this version \n    todoEntry.name == 'worldBoss' and aura_env.config['includeWorldBoss'] or -- world boss\n    todoEntry.name == 'CommunityFeast' and aura_env.config['includeCommunityFeast'] or-- Tuskarr Community Feast--\n    todoEntry.name == 'elements' and aura_env.config['includeelements'] or--Trial of Elements --\n    todoEntry.name == 'flood' and aura_env.config['includeFlood'] or--Trial of Floods --\n    todoEntry.name == 'SoDK' and aura_env.config['includeSoDK'] or--Siege of Dragonscale Keep --\n    todoEntry.name == 'Hunt' and aura_env.config['includeHunt'] or--Grand Hunts --\n    todoEntry.name == 'weeklyQuest' and aura_env.config['includeWeeklyQuest'] then--Aiding the Accord--\n      if todoEntry.maximum then\n        maximum = todoEntry.maximum\n      end\n      for _, todoQuest in ipairs(todoEntry.quests) do\n        if todoEntry.name == 'worldBoss' then\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n          end\n        else\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n          end\n        end\n      end\n      if (maximum > 1) and (completed >= (maximum / 2)) then\n        -- Burnt Orange --\n        color = 'ffff7801'\n      end \n      if completed >= maximum then\n        -- JADE--\n        color = 'FF00ff96'\n      end\n      \n      if completed >= maximum then\n        if\n        --check if the use wants to hide the line after complete\n        -- todoEntry.name == 'worldQuests' and not aura_env.config['hideWorldQuestsIfCompleted'] or\n        todoEntry.name == 'worldBoss' and not aura_env.config['hideWorldBossIfCompleted'] or\n        todoEntry.name == 'CommunityFeast' and not aura_env.config['hideCommunityFeastIfCompleted'] or -- Tuskarr Community Feast--\n        todoEntry.name == 'elements' and not aura_env.config['hideelementsIfCompleted'] or --Trial of Elements --\n        todoEntry.name == 'flood' and not aura_env.config['hideFloodIfCompleted'] or --Trial of Floods --\n        todoEntry.name == 'SoDK' and not aura_env.config['hideSoDKIfCompleted'] or--Siege of Dragonscale Keep --\n        todoEntry.name == 'Hunt' and not aura_env.config['hideHuntIfCompleted'] or --Grand Hunts --\n        todoEntry.name == 'weeklyQuest' and not aura_env.config['hideWeeklyQuestIfCompleted'] then --Aiding the Accord--\n          entry ='    ' ..  aura_env.get_text_snippet(todoEntry.name) .. ': ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n        end\n      else\n        entry ='    ' .. aura_env.get_text_snippet(todoEntry.name) .. ': ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n      end\n      \n      text = text .. entry\n    end\n  end\n  \n  return text\nend\n\n--Update output varible--\naura_env.update_display = function()\n  local text = ''\n  ---todo list items update---\n  if aura_env.config['showOverview'] then -- cheack if use want to show\n    text ='  ' .. text .. WrapTextInColorCode(aura_env.get_text_snippet('overviewHeadline'), 'ff00ff96') .. '\\r\\n'--apped header\n    text = text .. aura_env.update_overview_display() .. '\\r' --append todo list items\n  end \n  return text\nend\naura_env.text = aura_env.update_display()",
				},
				["finish"] = {
				},
			},
			["selfPoint"] = "TOPLEFT",
			["desaturate"] = true,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["useAdjustededMin"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["compress"] = false,
			["alpha"] = 1,
			["uid"] = "maqhXWF)VdO",
			["backgroundOffset"] = 2,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Todo list Pack",
			["customText"] = "function()\n  aura_env.text = aura_env.update_display()\n  \n  return aura_env.text \nend",
			["desaturateBackground"] = false,
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["useAdjustededMax"] = false,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:todo list",
			["anchorPoint"] = "BOTTOMLEFT",
			["fontSize"] = 12,
			["xOffset"] = 0,
			["conditions"] = {
			},
			["backgroundColor"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.5, -- [4]
			},
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["semver"] = "4.99.2",
			["config"] = {
			},
			["id"] = "sp1",
			["crop_y"] = 0.41,
			["frameStrata"] = 1,
			["width"] = 280.00006103516,
			["anchorFrameType"] = "SELECTFRAME",
			["startAngle"] = 0,
			["inverse"] = false,
			["tocversion"] = 100002,
			["orientation"] = "VERTICAL",
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["auraRotation"] = 0,
		},
		["Dragonbane Keep timer bar"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0.082352943718433, -- [2]
				0.082352943718433, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["texture"] = "WorldState Score",
			["cooldownTextDisabled"] = true,
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["uid"] = "wsxLVnTupQ1",
			["displayIcon"] = 236469,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Reps Pack",
			["cooldownSwipe"] = false,
			["sparkRotationMode"] = "AUTO",
			["cooldownEdge"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["use_alwaystrue"] = true,
						["use_absorbMode"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["use_absorbHealMode"] = true,
						["custom_type"] = "stateupdate",
						["event"] = "Conditions",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["events"] = "DRAGONFLIGHT_EVENT_TRACKER,START",
						["custom"] = "function(allstates, event, id)\n  \n  \n  if not aura_env.config.Siege then \n    return false \n  end\n  if aura_env.config.hideComplete and aura_env.isComplete() then \n    return    false \n  end\n  \n  if event == \"DRAGONFLIGHT_EVENT_TRACKER\" and id == aura_env.id or event == \"STATUS\" or event == \"OPTIONS\" then\n    local regionTimers = {\n      [1] = 1670338860, -- NA\n      [2] = 1670698860, -- KR\n      [3] = 1670342460, -- EU\n      [4] = 1670698860, -- TW\n      [5] = 1670677260} -- CN \n    \n    local settime1 = regionTimers[GetCurrentRegion()]\n    \n    local resettimer = 120 --aura_env.config.fbre -- need to finish adding this varibles in custom  options\n    local Rtime = resettimer * 60 -- multiply mins by secs and assign total secs\n    local interval = Rtime\n    \n    local ActiveDrutation = 15 --aura_env.config.sdur  -- need to finish adding this varibles in custom  options\n    local Atime = ActiveDrutation *60 -- multiply mins by secs and assign total secs\n    local duration = Atime\n    \n    \n    local Offsetmins = aura_env.config.Offsetammout -- get off set amount in mins\n    local Otime = Offsetmins * 60-- multiply mins by secs and assign total secs\n    local offset = Otime\n    \n    settime1 = aura_env.config.Siegeoffset and settime1+offset or settime1\n    \n    local TtNK = interval - ((GetServerTime() - settime1) % interval)\n    \n    local active = interval - TtNK < duration\n    local remaining = duration - (interval - TtNK)\n    \n    allstates[\"\"] = {\n      changed = true,\n      show = true,\n      progressType = \"timed\",\n      autoHide = true,\n      duration = active and duration or interval-duration,\n      expirationTime = GetTime() + (active and remaining or TtNK),\n      icon = 236469,\n      active = active\n    }\n    return true\n  end\nend",
						["spellIds"] = {
						},
						["check"] = "event",
						["use_unit"] = true,
						["unit"] = "player",
						["customVariables"] = "{\n  active = {\n    display = \"Siege Active\", \n    type = \"bool\",\n  },\n  \n  expirationTime = true,\n}",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["custom"] = "function()\n    if aura_env.config.Siege then\n        return true\n    end \nend",
						["events"] = "START",
						["subeventPrefix"] = "SPELL",
						["check"] = "event",
						["custom_type"] = "status",
						["spellIds"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subforeground",
				}, -- [1]
				{
					["type"] = "subbackground",
				}, -- [2]
				{
					["text_text_format_p_time_format"] = 2,
					["text_text"] = "%p",
					["text_text_format_p_gcd_cast"] = false,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_1.formattedTime_format"] = "none",
					["rotateText"] = "NONE",
					["text_text_format_p_decimal_precision"] = 1,
					["text_text_format_p_gcd_gcd"] = true,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_text_format_p_gcd_channel"] = false,
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_p_gcd_hide_zero"] = false,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_mod_rate"] = true,
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["type"] = "subtext",
					["text_anchorXOffset"] = -10,
					["text_font"] = "Expressway",
					["text_anchorYOffset"] = 0,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_text_format_p_big_number_format"] = "AbbreviateNumbers",
					["text_text_format_p_format"] = "timed",
					["text_shadowXOffset"] = 1,
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "Siege timer",
					["text_text_format_p_time_mod_rate"] = true,
					["text_text_format_p_time_precision"] = 1,
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_1.active_format"] = "none",
					["text_text_format_p_format"] = "timed",
					["anchorYOffset"] = 0,
					["type"] = "subtext",
					["text_anchorXOffset"] = 0,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowXOffset"] = 1,
					["text_shadowYOffset"] = -1,
					["text_visible"] = true,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_anchorYOffset"] = 0,
					["text_text_format_p_time_format"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
				}, -- [4]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "Active",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_1.active_format"] = "none",
					["type"] = "subtext",
					["text_color"] = {
						0, -- [1]
						1, -- [2]
						0.086274512112141, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = false,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_1.display_format"] = "none",
					["text_fontType"] = "None",
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [5]
			},
			["height"] = 17,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["source"] = "import",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["barColor2"] = {
				1, -- [1]
				0, -- [2]
				0.68235296010971, -- [3]
				1, -- [4]
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["icon_side"] = "LEFT",
			["zoom"] = 0.3,
			["information"] = {
			},
			["sparkHeight"] = 30,
			["backgroundColor"] = {
				1, -- [1]
				0.58431375026703, -- [2]
				0.58431375026703, -- [3]
				0.75, -- [4]
			},
			["desc"] = "code sampled and edited from the original WA by putro https://wago.io/fTuRJ__jk\n\n",
			["config"] = {
				["Siege"] = true,
				["hideComplete"] = false,
				["Offsetammout"] = 1,
				["Siegeoffset"] = false,
			},
			["semver"] = "4.99.2",
			["width"] = 280,
			["id"] = "Dragonbane Keep timer bar",
			["useCooldownModRate"] = true,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["sparkHidden"] = "NEVER",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Event timer",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will display  the Dragonbane keep siege timer|n(default: |cFF02ff00enabled|r)",
					["key"] = "Siege",
					["useDesc"] = true,
					["name"] = "|cFFff0000siege timer|r",
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "If enabled, will hide siege if marked as completed |n(default: |cFF02ff00enabled|r)",
					["key"] = "hideComplete",
					["useDesc"] = true,
					["name"] = "|cFFff0000Hide Complete|r",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "If enabled, will use the off setto assist in correcting the time|n(default: |cFFff0000disabled|r)",
					["key"] = "Siegeoffset",
					["useDesc"] = true,
					["name"] = "|cFFaa0000Use off-set|r",
					["width"] = 1,
				}, -- [4]
				{
					["softMin"] = 1,
					["type"] = "range",
					["bigStep"] = 1,
					["max"] = 720,
					["step"] = 0.5,
					["width"] = 1,
					["min"] = 1,
					["key"] = "Offsetammout",
					["desc"] = "Off set ammount in Minutes",
					["softMax"] = 720,
					["useDesc"] = true,
					["name"] = "|cFFaa0000Set Event Offset (in minutes)|r",
					["default"] = 1,
				}, -- [5]
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "-- Default Locale --\naura_env.defaultLocale = 'enUS'\n-- User Locale Var--\naura_env.userLocale = GetLocale()\n-- Get Text sinppet --\naura_env.get_text_snippet = function(name)\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.userLocale] then\n    return aura_env.textSnippets[name][aura_env.userLocale]\n  end\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.defaultLocale] then\n    return aura_env.textSnippets[name][aura_env.defaultLocale]\n  end\n  return name\nend\n\nfunction aura_env.isComplete()\n  if C_QuestLog.IsQuestFlaggedCompleted(70866) then\n    return true\n  end\n  \n  return false\nend",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "C_Timer.After(0, function() WeakAuras.ScanEvents(\"DRAGONFLIGHT_EVENT_TRACKER\", aura_env.id) end)",
					["do_custom"] = true,
				},
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["variable"] = "active",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
						{
							["property"] = "sub.4.text_visible",
						}, -- [2]
						{
							["value"] = true,
							["property"] = "sub.5.text_visible",
						}, -- [3]
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.5.text_color",
						}, -- [4]
					},
				}, -- [1]
			},
			["cooldown"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
		},
		["LW Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Leatherworking", -- [1]
				"LWAB 5", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620678,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "ZWWM6NLeQJV",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:JC Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "LW Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["LWAB 5"] = false,
				["Leatherworking"] = false,
			},
		},
		["Todo list Pack"] = {
			["controlledChildren"] = {
				"header", -- [1]
				"BGtd", -- [2]
				"todo list", -- [3]
				"sp1", -- [4]
			},
			["borderBackdrop"] = "Solid",
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 38.518608940972,
			["anchorPoint"] = "TOPLEFT",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 80,
			["subRegions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 1,
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps Pack",
			["regionType"] = "group",
			["borderSize"] = 2,
			["uid"] = "dNgzs9xJOlD",
			["groupIcon"] = 134329,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Todo list Pack",
			["parent"] = "Weekly/Daily Module",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = -134.32095898522,
			["config"] = {
			},
			["borderInset"] = 1,
			["borderEdge"] = "1 Pixel",
			["conditions"] = {
			},
			["information"] = {
			},
			["selfPoint"] = "CENTER",
		},
		["BGtd"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "-- Default Locale --\naura_env.defaultLocale = 'enUS'\n-- User Locale Var--\naura_env.userLocale = GetLocale()\n-- Get Text sinppet --\naura_env.get_text_snippet = function(name)\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.userLocale] then\n    return aura_env.textSnippets[name][aura_env.userLocale]\n  end\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.defaultLocale] then\n    return aura_env.textSnippets[name][aura_env.defaultLocale]\n  end\n  return name\nend\n-- World quest Availibility --\naura_env.is_world_quest_available = function(quest)\n  if not C_TaskQuest.GetQuestTimeLeftSeconds(quest) then\n    return true\n  end\n  return false\nend\n-- Quest Completion check --\naura_env.is_quest_completed = function(quest)\n  if C_QuestLog.IsQuestFlaggedCompleted(quest) then\n    return true\n  end\n  return false\nend\n-- Enlightened Faction --\naura_env.factionID = 2478\n-- Title items --\n--Norah#21256 thank you for French Tranlations\n--Beatrice#2650 & Podwiznaia#2373 thank you both for help with the Russian Translations\n--Shokuhou (Orillion), Lars, phoi thank you all for your japanese Translations\n--Shokuhou (Orillion) thank you for your Dutch Translations\n--Zamy thank you for your Koreran Translations\n--三皈依#3388 thank you for your Translations\n--hohunide thank you for your Translations\n--N3cro#92 thank you for your German Translations\naura_env.textSnippets = {\n  overviewHeadline = { enUS = ' Todo list:',\n    deDE = 'Aufgabenliste:',\n    zhTW = '的任務列表: ', \n    zhCN = ' 任务列表:', \n    ruRU = 'Список дел ' ,\n    frFR = 'Liste de choses à faire :' ,\n    jaJP = 'タマのやること帳・ ',\n    koKR = '숙제 리스트 ',\n  },\n  \n  worldBoss = { \n    enUS = 'World Boss: ',\n    deDE = 'Weltboss: ',\n    zhTW = '世界首領', \n    zhCN = '世界BOSS: ',\n    ruRU = 'Мировой босс:',\n    frFR = 'Boss mondial: ',\n    nlNL = 'Wereld Baas',\n    jaJP = 'ワールドボス',\n    koKR = '필드보스',\n  },\n  \n  worldQuests = {\n    enUS = 'World Quests: ',\n    deDE = 'Welt-Quests: ',\n    zhTW = '世界任務', \n    zhCN = '世界任务: ',\n    ruRU = 'МЛокальные задания:',\n    frFR = 'Quêtes mondiales: ',\n    nlNL = 'World Quests',\n    jaJP = 'アコードを手伝う',\n    koKR = '전역 퀘스트',\n  },\n  \n  weeklyQuest = {\n    enUS = 'Aiding the Accord: ',\n    deDE = 'Unterstützung des Abkommens ',\n    zhTW = '支援協調者：', \n    zhCN = '协助援军： ',\n    ruRU = 'Содействие Соглашению: ',\n    frFR = 'Aider le concordat: ',\n    nlNL = 'Accord Assistentie',\n    jaJP='アコードを手伝う',\n    koKR = '협의회 지원',\n  },\n  \n  CommunityFeast = {\n    enUS = 'Community Feast: ',\n    deDE = 'Gemeinschaftsfest: ',\n    zhTW = '集體盛宴：', \n    zhCN = '社区盛宴： ',\n    ruRU = 'Большое пиршество: ',\n    frFR = 'Festin tribal:  ',\n    nlNL = 'Gemeenschap`s Feestmaal',\n    jaJP = 'コミュニティの宴会',\n    koKR = '공동체 잔치',\n  },\n  \n  elements = {\n    enUS = 'Trial of Elements: ',\n    deDE = 'Prüfung der Elemente:',\n    zhTW = '元素的試煉: ', \n    zhCN = '元素审判:  ',\n    ruRU = 'Испытание элементов: ',\n    frFR = 'L’épreuve des éléments: ',\n    nlNL = 'Test van de Elementen',\n    jaJP = '五大の試し',\n    koKR = '원소의 시험',\n  },\n  \n  flood = {\n    enUS = 'Trial of Flood: ',\n    deDE = 'Prüfung der Flut:',\n    zhTW = '洪流的試煉: ', \n    zhCN = '洪水的审判： ',\n    ruRU = 'Испытание наводнения: ', \n    frFR = 'L’épreuve du déluge:  ',\n    nlNL = 'Test van de Overstroming',\n    jaJP = '洪水の試し',\n    koKR = '홍수의 시험',\n  },\n  \n  SoDK = {\n    enUS = 'Siege of Dragonscale Keep: ',\n    deDE = 'Belagerung der Drachenschuppenburg: ',\n    zhTW = '攻打龍禍要塞： ', \n    zhCN = '围攻灭龙要塞: ',\n    ruRU = 'Осада драконьей погибели: ',\n    frFR = 'Siege du Fleau-des-dragons: ',\n    nlNL = 'Belegering van Fort Dragonscale',\n    jaJP =' ドラゴンスケール天守の包囲',\n    koKR = '용의 파멸 성채 공성전',\n  },\n  \n  Hunt = {\n    enUS = 'Grand Hunts: ',\n    deDE = 'GroBe Jagden: ',\n    zhTW = '大狩獵: ', \n    zhCN = '洪荒狩猎: ',\n    ruRU = 'Великая охота: ',\n    frFR = 'Grandes Chasses: ',\n    nlNL = 'Grootse Jachten',\n    jaJP = '盛大狩り',\n    koKR = '사냥의 제전',\n  },\n}\n-- TODO - Items --\naura_env.todoList = {\n  {name = \"weeklyQuest\", maximum = 1,\n    quests = {\n      {questId = 70750,},--Aiding the Accord-- \n    },\n  },\n  \n  {name = \"CommunityFeast\",maximum = 1,\n    quests = {\n      {questId = 70893,},-- Hidden quest ID 70893--\n    },\n  },\n  \n  {name = \"SoDK\",maximum = 1,\n    quests = {\n      {questId = 70866,},-- confirm this Hidden ID72025 0r 70866--\n    },\n  },\n  \n  {name = \"Hunt\",maximum = 1,\n    quests = {\n      {questId = 70906,},-- WS 25.44,92.29-- Epic\n      -- {questId = 69998,},-- WS 25.44,92.29--\n      -- {questId = 69999,},-- WS 40.98,84.46--\n      -- {questId = 70000,},-- WS 25.44,92.29--\n    },\n  },\n  {name = \"flood\",maximum = 1,\n    quests = {\n      {questId = 71033,}, --Raging Torrent mobID 197221 hidden ID 71033 --\n    },\n  },\n  {name = \"elements\",maximum = 1,\n    quests = {\n      {questId = 71995,}, --Therrocite mob id 197749--\n    },\n  },\n  \n  { name = \"worldBoss\",  maximum = 1,\n    quests = {\n      {questId = 65234,}, -- Bazual mobID 193532, hidden ID####--\n      {questId = 65262,},-- Liskanoth  mobID 193533, hidden ID####--\n      {questId = 65231,},-- Strunraan mobID 193534, hidden ID####--\n      {questId = 65115,},-- Basrikron mobID 193535, hidden ID####--\n      \n    },\n  },\n  \n}\n\n--Output Varible--\naura_env.text = '';\n--Output Main function--\naura_env.update_overview_display = function()\n  local text = ''\n  -----------------------------------------------------Todo list Prep--------------------------------------------------------------------------- \n  for _, todoEntry in ipairs(aura_env.todoList) do\n    -- PINK --\n    local entry, color, completed, maximum = '', 'ffff00ff', 0, #todoEntry.quests\n    if \n    --set up the items to display\n    -- todoEntry.name == 'worldQuests' and aura_env.config['includeWorldQuest'] or -- < not need in this version \n    todoEntry.name == 'worldBoss' and aura_env.config['includeWorldBoss'] or -- world boss\n    todoEntry.name == 'CommunityFeast' and aura_env.config['includeCommunityFeast'] or-- Tuskarr Community Feast--\n    todoEntry.name == 'elements' and aura_env.config['includeelements'] or--Trial of Elements --\n    todoEntry.name == 'flood' and aura_env.config['includeFlood'] or--Trial of Floods --\n    todoEntry.name == 'SoDK' and aura_env.config['includeSoDK'] or--Siege of Dragonscale Keep --\n    todoEntry.name == 'Hunt' and aura_env.config['includeHunt'] or--Grand Hunts --\n    todoEntry.name == 'weeklyQuest' and aura_env.config['includeWeeklyQuest'] then--Aiding the Accord--\n      if todoEntry.maximum then\n        maximum = todoEntry.maximum\n      end\n      for _, todoQuest in ipairs(todoEntry.quests) do\n        if todoEntry.name == 'worldBoss' then\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n          end\n        else\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n          end\n        end\n      end\n      if (maximum > 1) and (completed >= (maximum / 2)) then\n        -- Burnt Orange --\n        color = 'ffff7801'\n      end \n      if completed >= maximum then\n        -- JADE--\n        color = 'FF00ff96'\n      end\n      \n      if completed >= maximum then\n        if\n        --check if the use wants to hide the line after complete\n        -- todoEntry.name == 'worldQuests' and not aura_env.config['hideWorldQuestsIfCompleted'] or\n        todoEntry.name == 'worldBoss' and not aura_env.config['hideWorldBossIfCompleted'] or\n        todoEntry.name == 'CommunityFeast' and not aura_env.config['hideCommunityFeastIfCompleted'] or -- Tuskarr Community Feast--\n        todoEntry.name == 'elements' and not aura_env.config['hideelementsIfCompleted'] or --Trial of Elements --\n        todoEntry.name == 'flood' and not aura_env.config['hideFloodIfCompleted'] or --Trial of Floods --\n        todoEntry.name == 'SoDK' and not aura_env.config['hideSoDKIfCompleted'] or--Siege of Dragonscale Keep --\n        todoEntry.name == 'Hunt' and not aura_env.config['hideHuntIfCompleted'] or --Grand Hunts --\n        todoEntry.name == 'weeklyQuest' and not aura_env.config['hideWeeklyQuestIfCompleted'] then --Aiding the Accord--\n          entry ='    ' ..  aura_env.get_text_snippet(todoEntry.name) .. ': ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n        end\n      else\n        entry ='    ' .. aura_env.get_text_snippet(todoEntry.name) .. ': ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n      end\n      \n      text = text .. entry\n    end\n  end\n  \n  return text\nend\n\n--Update output varible--\naura_env.update_display = function()\n  local text = ''\n  ---todo list items update---\n  if aura_env.config['showOverview'] then -- cheack if use want to show\n    text ='  ' .. text .. WrapTextInColorCode(aura_env.get_text_snippet('overviewHeadline'), 'ff00ff96') .. '\\r\\n'--apped header\n    text = text .. aura_env.update_overview_display() .. '\\r' --append todo list items\n  end \n  return text\nend\naura_env.text = aura_env.update_display()",
				},
				["finish"] = {
				},
			},
			["selfPoint"] = "TOPLEFT",
			["desaturate"] = true,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["useAdjustededMin"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["compress"] = false,
			["alpha"] = 1,
			["uid"] = "o21ekKjaSvs",
			["backgroundOffset"] = 2,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Todo list Pack",
			["customText"] = "function()\n  aura_env.text = aura_env.update_display()\n  \n  return aura_env.text \nend",
			["desaturateBackground"] = false,
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 16,
			["rotate"] = false,
			["useAdjustededMax"] = false,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:todo list",
			["anchorPoint"] = "TOPLEFT",
			["fontSize"] = 12,
			["xOffset"] = 0,
			["conditions"] = {
			},
			["backgroundColor"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.5, -- [4]
			},
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.23938930034637, -- [4]
			},
			["semver"] = "4.99.2",
			["config"] = {
			},
			["id"] = "BGtd",
			["crop_y"] = 0.41,
			["frameStrata"] = 1,
			["width"] = 280,
			["anchorFrameType"] = "SCREEN",
			["startAngle"] = 0,
			["inverse"] = false,
			["tocversion"] = 100002,
			["orientation"] = "VERTICAL",
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["auraRotation"] = 0,
		},
		["Maruuk Centaur"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Reps Pack",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["factionID"] = 2503,
						["use_unit"] = true,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.MCSH then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["iconSource"] = -1,
			["barColor"] = {
				1, -- [1]
				0.58431375026703, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 4687627,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 110,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["gradientOrientation"] = "HORIZONTAL",
			["internalVersion"] = 64,
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["selfPoint"] = "CENTER",
			["source"] = "import",
			["uid"] = "bD2xgMYw(gA",
			["config"] = {
				["Rep"] = {
					["MCSH"] = false,
				},
			},
			["xOffset"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["alpha"] = 1,
			["height"] = 16,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["spark"] = false,
			["zoom"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Maruuk Centaur",
			["backgroundColor"] = {
				1, -- [1]
				0.26666668057442, -- [2]
				0, -- [3]
				0.75, -- [4]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["version"] = 80,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFF02ff00enabled|r)",
							["key"] = "MCSH",
							["useDesc"] = true,
							["name"] = "|cFFff9500Maruuk Centaur Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.MCSH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
		},
		["EncCAB"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "EncCAB",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "8YYktHYX345",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Enc Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["PBG"] = {
			["user_y"] = 0,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Crafting Module",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "description",
					["text"] = "Treatise of (profession name) is the item that you can buy from your friendly inscriptors or via work order.\n\nThey give one point per week per profession",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "toggle end able crafting module",
					["key"] = "CMT",
					["useDesc"] = true,
					["name"] = "Enable Crafting module",
					["width"] = 2,
				}, -- [3]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 1,
				}, -- [4]
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOP",
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "-- Default Locale --\naura_env.defaultLocale = 'enUS'\n-- User Locale Var--\naura_env.userLocale = GetLocale()\n-- Get Text sinppet --\naura_env.get_text_snippet = function(name)\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.userLocale] then\n    return aura_env.textSnippets[name][aura_env.userLocale]\n  end\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.defaultLocale] then\n    return aura_env.textSnippets[name][aura_env.defaultLocale]\n  end\n  return name\nend\n-- World quest Availibility --\naura_env.is_world_quest_available = function(quest)\n  if not C_TaskQuest.GetQuestTimeLeftSeconds(quest) then\n    return true\n  end\n  return false\nend\n-- Quest Completion check --\naura_env.is_quest_completed = function(quest)\n  if C_QuestLog.IsQuestFlaggedCompleted(quest) then\n    return true\n  end\n  return false\nend\n-- Enlightened Faction --\naura_env.factionID = 2478\n-- Title items --\n--Norah#21256 thank you for French Tranlations--\n--Beatrice#2650 & Podwiznaia#2373 thank you both for help with the Russian Translations--\n--Shokuhou (Orillion) thank you for your japanese Translations--\n--Shokuhou (Orillion) thank you for your Dutch Translations--\n--Zamy thank you for your Koreran Translations--\naura_env.textSnippets = {\n  overviewHeadline = { \n    enUS = 'Tama`s Todo list',\n    deDE = 'Tama`s Aufgabenliste',\n    zhTW = 'Tama`s 任務列表', \n    zhCN = 'Tama`s 任务列表', \n    ruRU = 'Список дел Tama' ,\n    frFR = 'Tama`s Liste de choses à faire',\n    koKR = 'Tama의 숙제 리스트',\n  },\n  worldBoss = { \n    enUS = 'World Boss',\n    deDE = 'Weltboss',\n    zhTW = '世界首領', \n    zhCN = '世界老板',\n    ruRU = 'Мировой босс',\n    frFR = 'Boss mondial',\n    nlNL = 'Wereld Baas',\n    jaJP = '世界ボス',\n    koKR = '필드보스',\n  },\n  worldQuests = {\n    enUS = 'World Quests',\n    deDE = 'Welt-Quests',\n    zhTW = '世界任務', \n    zhCN = '世界任务',\n    ruRU = 'МЛокальные задания',\n    frFR = 'Quêtes mondiales',\n    nlNL = 'World Quests',\n    jaJP = 'World Quests',\n    koKR = '전역 퀘스트',\n  },\n  weeklyQuest = {\n    enUS = 'Aiding the Accord',\n    deDE = 'Unterst\\195\\188tzung des Abkommens',\n    zhTW = '协助协议', \n    zhCN = '协助协议',\n    ruRU = 'Содействие Соглашению',\n    frFR = 'Aider le concordat',\n    nlNL = 'Accord Assistentie',\n    jaJP = 'アコードを応援します',\n    koKR = '협의회 지원',\n  },\n  CommunityFeast = {\n    enUS = 'Community Feast',\n    deDE = 'Gemeinschaftsfestmahl',\n    zhTW = '社区盛宴', \n    zhCN = '社区盛宴',\n    ruRU = 'Большое пиршество',\n    frFR = 'Festin tribal',\n    nlNL = 'Gemeenschap`s Feestmaal',\n    jaJP = ' 五大の裁判',\n    koKR = '공동체 잔치',\n  },\n  elements = {\n    enUS = 'Trial of Elements',\n    deDE = 'Pr\\195\\188fung der Elemente',\n    zhTW = '元素审判', \n    zhCN = '元素审判',\n    ruRU = 'Испытание элементов',\n    frFR = 'L’épreuve des éléments',\n    nlNL = 'Test van de Elementen',        \n    jaJP = '宴会',\n    koKR = '원소의 시험',\n  },\n  flood = {\n    enUS = 'Trial of Flood',\n    deDE = 'Pr\\195\\188fung der Flut',\n    zhTW = '洪水的审判', \n    zhCN = '洪水的审判',\n    ruRU = 'Испытание наводнения', \n    frFR = 'L’épreuve du déluge',\n    nlNL = 'Test van de Overstroming',\n    jaJP = '大水の裁判',\n    koKR = '홍수의 시험',\n  },\n  SoDK = {\n    enUS = 'Siege of Dragonscale Keep',\n    deDE = 'Belagerung der Drachenfluchfestung',\n    zhTW = '龙鳞要塞之围', \n    zhCN = '龙鳞要塞之围',\n    ruRU = 'Осада драконьей погибели',\n    frFR = 'Siege du Fleau-des-dragons',\n    nlNL = 'Belegering van Fort Dragonscale',\n    jaJP = 'ドラゴンスケールケープの包囲',\n    koKR = '용의 파멸 성채 공성전',\n  },\n  Hunt = {\n    enUS = 'Grand Hunts',\n    deDE = 'Gro\\195\\159e Jagd',\n    zhTW = '大狩猎', \n    zhCN = '大狩猎',\n    ruRU = 'Великая охота',\n    frFR = 'Grandes Chasses',\n    nlNL = 'Grootse Jachten',\n    jaJP = 'ごランドハント',\n    koKR = '사냥의 제전',\n  },\n}\n-- TODO - Items --\naura_env.todoList = {\n  {name = \"weeklyQuest\", maximum = 1,\n    quests = {\n      {questId = 70750,},--Aiding the Accord-- \n    },\n  },\n  \n  {name = \"CommunityFeast\",maximum = 1,\n    quests = {\n      {questId = 70893,},-- Hidden quest ID 70893--\n    },\n  },\n  \n  {name = \"SoDK\",maximum = 1,\n    quests = {\n      {questId = 70866,},-- confirm this Hidden ID72025 0r 70866--\n    },\n  },\n  \n  {name = \"Hunt\",maximum = 1,\n    quests = {\n      {questId = 70906,},-- WS 25.44,92.29-- Epic\n      --{questId = 69998,},-- WS 25.44,92.29--\n      --{questId = 69999,},-- WS 40.98,84.46--\n      --{questId = 70000,},-- WS 25.44,92.29--\n    },\n  },\n  {name = \"flood\",maximum = 1,\n    quests = {\n      {questId = 71033,}, --Raging Torrent mobID 197221 hidden ID 71033 --\n    },\n  },\n  {name = \"elements\",maximum = 1,\n    quests = {\n      {questId = 71995,}, --Therrocite 197749--\n    },\n  },\n  \n  { name = \"worldBoss\",  maximum = 1,\n    quests = {\n      {questId = 65234,}, -- Bazual mobID 193532, hidden ID####--\n      {questId = 65262,},-- Liskanoth  mobID 193533, hidden ID####--\n      {questId = 65231,},-- Strunraan mobID 193534, hidden ID####--\n      {questId = 65115,},-- Basrikron mobID 193535, hidden ID####--\n      \n    },\n  },\n  \n}\n\n--Output Varible--\naura_env.text = '';\n--Output Main function--\naura_env.update_overview_display = function()\n  local text = ''\n  -----------------------------------------------------Todo list Prep--------------------------------------------------------------------------- \n  for _, todoEntry in ipairs(aura_env.todoList) do\n    -- PINK --\n    local entry, color, completed, maximum = '', 'ffff00ff', 0, #todoEntry.quests\n    if \n    -- todoEntry.name == 'worldQuests' or\n    todoEntry.name == 'worldBoss' and aura_env.config['TD.includeWorldBoss'] or\n    todoEntry.name == 'CommunityFeast' and aura_env.config['TD.includeCommunityFeast'] or-- Tuskarr Community Feast--\n    todoEntry.name == 'elements' and aura_env.config['TD.includeelements'] or--Trial of Elements --\n    todoEntry.name == 'flood' and aura_env.config['TD.includeFlood'] or--Trial of Floods --\n    todoEntry.name == 'SoDK' and aura_env.config['TD.includeSoDK'] or--Siege of Dragonscale Keep --\n    todoEntry.name == 'Hunt' and aura_env.config['TD.includeHunt'] or--Grand Hunts --\n    todoEntry.name == 'weeklyQuest' and aura_env.config['TD.includeWeeklyQuest'] then--Aiding the Accord--\n      if todoEntry.maximum then\n        maximum = todoEntry.maximum\n      end\n      for _, todoQuest in ipairs(todoEntry.quests) do\n        if todoEntry.name == 'worldBoss' then\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n          end\n        else\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n          end\n        end\n      end\n      if (maximum > 1) and (completed >= (maximum / 2)) then\n        -- Burnt Orange --\n        color = 'ffff7801'\n      end \n      if completed >= maximum then\n        -- JADE--\n        color = 'FF00ff96'\n      end\n      \n      if completed >= maximum then\n        if\n        -- todoEntry.name == 'worldQuests' and not aura_env.config['hideWorldQuestsIfCompleted'] or\n        todoEntry.name == 'worldBoss' and not aura_env.config['TD.hideWorldBossIfCompleted'] or\n        todoEntry.name == 'CommunityFeast' and not aura_env.config['TD.hideCommunityFeastIfCompleted'] or -- Tuskarr Community Feast--\n        todoEntry.name == 'elements' and not aura_env.config['TD.hideelementsIfCompleted'] or --Trial of Elements --\n        todoEntry.name == 'flood' and not aura_env.config['TD.hideFloodIfCompleted'] or --Trial of Floods --\n        todoEntry.name == 'SoDK' and not aura_env.config['TD.hideSoDKIfCompleted'] or--Siege of Dragonscale Keep --\n        todoEntry.name == 'Hunt' and not aura_env.config['TD.hideHuntIfCompleted'] or --Grand Hunts --\n        todoEntry.name == 'weeklyQuest' and not aura_env.config['TD.hideWeeklyQuestIfCompleted'] then --Aiding the Accord--\n          entry = '    '..aura_env.get_text_snippet(todoEntry.name) .. ': ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n        end\n      else\n        entry = '    '..  aura_env.get_text_snippet(todoEntry.name) .. ': ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n      end\n      \n      text = text .. entry\n    end\n  end\n  \n  return text\nend\n\n--Update Display--\naura_env.update_display = function()\n  local text = ''\n  ---todo---\n  if aura_env.config['showOverview'] then\n    text = text .. '    '..WrapTextInColorCode(aura_env.get_text_snippet('overviewHeadline'), 'ff00ff96') .. '\\r\\n'\n    --text = text .. '   '\n    text = text .. aura_env.update_overview_display() .. '  \\r'\n    \n  end \n  return text\nend\naura_env.text = aura_env.update_display()",
				},
				["finish"] = {
				},
			},
			["selfPoint"] = "BOTTOM",
			["desaturate"] = true,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["startAngle"] = 0,
			["useAdjustededMin"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["tocversion"] = 100002,
			["alpha"] = 1,
			["uid"] = "kwMvPcxvWXT",
			["backgroundOffset"] = 2,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["customText"] = "function()\n    aura_env.text = aura_env.update_display()\n    \n    return aura_env.text \nend",
			["desaturateBackground"] = false,
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
						["matchesShowOn"] = "showAlways",
						["event"] = "Health",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["events"] = "START",
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.CMT then\n        return true\n    end \nend",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["mirror"] = false,
			["config"] = {
				["CMT"] = true,
			},
			["xOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["anchorFrameParent"] = false,
			["crop_x"] = 0.41,
			["backgroundColor"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.5, -- [4]
			},
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["id"] = "PBG",
			["crop_y"] = 0.41,
			["frameStrata"] = 1,
			["width"] = 250,
			["anchorFrameType"] = "UNITFRAME",
			["auraRotation"] = 0,
			["inverse"] = false,
			["compress"] = false,
			["orientation"] = "VERTICAL",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
		},
		["Knowledge workshop"] = {
			["outline"] = "OUTLINE",
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
				{
					["useName"] = false,
					["type"] = "header",
					["text"] = "",
					["noMerge"] = true,
					["width"] = 2,
				}, -- [1]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Will automatically hide unlearned professions. Custom options can still disable known professions when enabled. If disabled custom options will determine which professions are shown.",
					["key"] = "Show",
					["useDesc"] = true,
					["name"] = "Show profession Todo list",
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "If Enabled will display more details of how to obtain the items |n(default: |cFFff0000disabled|r) |nWarning this isnt formatted text its much wider and doesn look pretty it there just to help if you CBa going to wow head :p",
					["key"] = "Extra",
					["useDesc"] = true,
					["name"] = "extra details",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will automatically hide unlearned professions. |n(default: |cFF02ff00enabled|r)",
					["key"] = "automaticDetection",
					["useDesc"] = true,
					["name"] = "Automatically Detect Professions",
					["width"] = 1,
				}, -- [4]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Todo list over ride",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "alchemy",
					["useDesc"] = true,
					["name"] = "|cffc300ffAlchemy|r",
					["width"] = 1,
				}, -- [6]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "blacksmithing",
					["useDesc"] = true,
					["name"] = "|cffc98e64Blacksmithing|r",
					["width"] = 1,
				}, -- [7]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "enchanting",
					["useDesc"] = true,
					["name"] = "|cff3000ffEnchanting|r",
					["width"] = 1,
				}, -- [8]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "engineering",
					["useDesc"] = true,
					["name"] = "|cff30aaffEngineering|r",
					["width"] = 1,
				}, -- [9]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "herbalism",
					["useDesc"] = true,
					["name"] = "|cff00ff59Herbalism|r",
					["width"] = 1,
				}, -- [10]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "inscription",
					["useDesc"] = true,
					["name"] = "|cffffff99Inscription|r",
					["width"] = 1,
				}, -- [11]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "jewelcrafting",
					["useDesc"] = true,
					["name"] = "|cffff0066Jewelcrafting|r",
					["width"] = 1,
				}, -- [12]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "leatherworking",
					["useDesc"] = true,
					["name"] = "|cffffaa00Leatherworking|r",
					["width"] = 1,
				}, -- [13]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "mining",
					["useDesc"] = true,
					["name"] = "|cffff6633Mining|r",
					["width"] = 1,
				}, -- [14]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "skinning",
					["useDesc"] = true,
					["name"] = "|cff884422Skinning|r",
					["width"] = 1,
				}, -- [15]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will track this profession|n(default: |cFF02ff00enabled|r)",
					["key"] = "tailoring",
					["useDesc"] = true,
					["name"] = "|cffffff00Tailoring|r",
					["width"] = 1,
				}, -- [16]
			},
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["customText"] = "function()\n  if not aura_env.last or aura_env.last < GetTime() - 1 then\n    aura_env.last = GetTime()\n    aura_env.update_display()\n  end\n  return aura_env.text\nend",
			["shadowYOffset"] = -1,
			["anchorPoint"] = "TOPLEFT",
			["displayText_format_p_time_format"] = 0,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "local objectives = {\n  -- Pack/dirt\n  -- treatise\n  -- gather /kill drop items\n  \n  \n  --Alchemy\n  {name=\"Dirt/Pack\", quests={66373, 66374}, optionKey=\"alchemy\", skillID=171,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 1,\n    short = \"|cffc300ff(Alc)|r\",\n    long = \"|cffc300ffAlchemy -|r\"\n  },\n  {name=\"Elementious Splinter\", quests={70511}, optionKey=\"alchemy\", skillID=171,\n    tip = \"loot Elemental Enemies \",\n    maximum = 1,\n    short = \"|cffc300ff(Alc)|r\",\n    long = \"|cffc300ffAlchemy -|r\"\n  },\n  {name=\"Decaying Phlegm\", quests={70504}, optionKey=\"alchemy\", skillID=171,\n    tip = \"loot Rousing Decay Enemies\",\n    maximum = 1,\n    short = \"|cffc300ff(Alc)|r\",\n    long = \"|cffc300ffAlchemy -|r\"\n  },\n  \n  \n  --Blacksmithing\n  {name=\"Dirt/Pack\", quests={66381, 66382}, optionKey=\"blacksmithing\", skillID=164,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 1,\n    short = \"|cffc98e64(BS)|r\",\n    long = \"|cffc98e64Blacksmithing -|r\"\n  },\n  {name=\"Molten Globule\", quests={70513}, optionKey=\"blacksmithing\", skillID=164,\n    tip = \"Loot Rousing Fire Enemies\",\n    maximum = 1,\n    short = \"|cffc98e64(BS)|r\",\n    long = \"|cffc98e64Blacksmithing -|r\"\n  },\n  {name=\"Primeval Earth Fragment\", quests={70512}, optionKey=\"blacksmithing\", skillID=164,\n    tip = \"loot Rousing Earth Enemies\",\n    maximum = 1,\n    short = \"|cffc98e64(BS)|r\",\n    long = \"|cffc98e64Blacksmithing -|r\"\n  },\n  \n  \n  --Enchanting\n  {name=\"Dirt/Pack\", quests={66377, 66378}, optionKey=\"enchanting\", skillID=333,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 1,\n    short = \"|cff3000ff(Enc)|r\",\n    long = \"|cff3000ffEnchanting -|r\"\n  },\n  \n  {name=\"Primalist Charm\", quests={70515}, optionKey=\"enchanting\", skillID=333,\n    tip = \"loot Humanoid Primalist Enemies\",\n    maximum = 1,\n    short = \"|cff3000ff(Enc)|r\",\n    long = \"|cff3000ffEnchanting -|r\"\n  },\n  {name=\"Primordial Aether\", quests={70514}, optionKey=\"enchanting\", skillID=333,\n    tip = \"loot Arcane Enemies\",\n    maximum = 1,\n    short = \"|cff3000ff(Enc)|r\",\n    long = \"|cff3000ffEnchanting -|r\"\n  },\n  \n  \n  --Engineering\n  {name=\"Dirt/Pack\", quests={66379, 66380}, optionKey=\"engineering\", skillID=202,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 2,\n    short = \"|cff30aaff(Eng)|r\",\n    long = \"|cff30aaffEngineering -|r\"\n  },\n  \n  {name=\"Infinitely Attachable Pair o' Docks\", quests={70517}, optionKey=\"engineering\", skillID=202,\n    tip = \"loot Dragonkin Enemies\",\n    maximum = 1,\n    short = \"|cff30aaff(Eng)|r\",\n    long = \"|cff30aaffEngineering -|r\"\n  },\n  {name=\"Keeper's Mark\", quests={70516}, optionKey=\"engineering\", skillID=202,\n    tip = \"loot Titan Enemies\",\n    maximum = 1,\n    short = \"|cff30aaff(Eng)|r\",\n    long = \"|cff30aaffEngineering -|r\"\n  }, \n  \n  \n  --Inscription\n  {name=\"Dirt/Pack\", quests={66375, 66376}, optionKey=\"inscription\", skillID=773,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 2,\n    short = \"|cffffff99(Ins)|r\",\n    long = \"|cffffff99Inscription|r\"\n  },\n  {name=\"Draconic Glamour\", quests={70519}, optionKey=\"inscription\", skillID=773,\n    tip = \"kill/loot Dragonkin Enemies\",\n    maximum = 1,\n    short = \"|cffffff99(Ins)|r\",\n    long = \"|cffffff99Inscription|r\"\n  },\n  {name=\"Curious Djaradin Rune\", quests={70518}, optionKey=\"inscription\", skillID=773,\n    tip = \"Kill/loot Djaradin Enemies\",\n    maximum = 1,\n    short = \"|cffffff99(Ins)|r\",\n    long = \"|cffffff99Inscription|r\"\n  },\n  \n  --Jewelcrafting\n  {name=\"Dirt/Pack\", quests={66388, 66389}, optionKey=\"jewelcrafting\", skillID=755,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 2,\n    short = \"|cffff0066(JC)|r\",\n    long = \"|cffff0066Jewelcrafting|r\"\n  },\n  {name=\"Incandescent Curio\", quests={70520}, optionKey=\"jewelcrafting\", skillID=755,\n    tip = \"loot Elemental Enemies\",\n    maximum = 1,\n    short = \"|cffff0066(JC)|r\",\n    long = \"|cffff0066Jewelcrafting|r\"\n  }, \n  {name=\"Elegantly Engraved..\", quests={70521}, optionKey=\"jewelcrafting\", skillID=755,\n    tip = \"Embellishment loot Nokhud/Sundered Flame Enemies\",\n    maximum = 1,\n    short = \"|cffff0066(JC)|r\",\n    long = \"|cffff0066Jewelcrafting|r\"\n  }, \n  \n  --Leatherworking\n  {name=\"Dirt/Pack\", quests={66384, 66385}, optionKey=\"leatherworking\", skillID=165,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\",\n    maximum = 2,\n    short = \"|cffffaa00(LW)|r\",\n    long = \"|cffffaa00Leatherworking)|r\"\n  },\n  {name=\"Exceedingly Soft Skin\", quests={70523}, optionKey=\"leatherworking\", skillID=165,\n    tip = \"loot Slyvern/Vorquin Enemies\",\n    maximum = 1,\n    short = \"|cffffaa00(LW)|r\",\n    long = \"|cffffaa00Leatherworking)|r\"\n  }, \n  {name=\"Ossified Hide\", quests={70522}, optionKey=\"leatherworking\", skillID=165,\n    tip = \"Proto-drake or Proto-dragon Enemies\",\n    maximum = 1,\n    short = \"|cffffaa00(LW)|r\",\n    long = \"|cffffaa00Leatherworking)|r\"\n  },  \n  \n  \n  --Tailoring\n  {name=\"Dirt/Pack\", quests={66386, 66387}, optionKey=\"tailoring\", skillID=197,\n    tip = \"Dig Disturbed Dirt or Loot Expedition Scout's Pack\", \n    maximum = 2,\n    short = \"|cff595959(Tail)|r\",\n    long = \"|cff595959Ttailoring)|r\"\n  },\n  {name=\"Stupidly Effective Stitchery\", quests={70525}, optionKey=\"tailoring\", skillID=197,\n    tip = \"loot Gnoll Enemies\",\n    maximum = 1,\n    short = \"|cff595959(Tail)|r\",\n    long = \"|cff595959Ttailoring)|r\"\n  },\n  {name=\"Ohn'arhan Weave\", quests={70524}, optionKey=\"tailoring\", skillID=197,\n    tip = \"loot Nokhud Enemies\",\n    maximum = 1,\n    short = \"|cff595959(Tail)|r\",\n    long = \"|cff595959Ttailoring)|r\"\n  },\n  \n  \n  --Herbalism\n  {name=\"Dreambloom\", quests={71857, 71858, 71859, 71860, 71861, 71864}, optionKey=\"herbalism\", skillID=182,\n    tip = \"Any herbs\",\n    maximum = 6,\n    short = \"|cff00ff59(Herb)|r\",\n    long = \"|cff00ff59Herbalism|r\"\n  },\n  \n  \n  --Mining\n  {name = \"Iridescent Ore\", quests= {72160,72161,72162,72163,72164,72165},optionKey = \"mining\",skillID=186,\n    tip = \"Any Mining\",\n    maximum = 6,\n    short = \"|cffff6633(Mine)|r\",\n    long = \"|cffff6633Mining|r\",\n  },\n  \n  \n  --Skinning\n  {name=\"Curious Hide\", quests={70381, 70383, 70384, 70385, 70386, 70389}, optionKey=\"skinning\", skillID=393,\n    tip=\"Any Skining\",\n    maximum = 6,\n    short = \"|cff884422(SK)|r\",\n    long = \"|cff884422Skinning|r\"\n  },\n  \n}\n\n-- This returns true if at least one of the required quests is currently active.\nlocal is_active = function(objective)\n  if not aura_env.config[objective.optionKey] then\n    return false\n  end\n  if not objective.required_quests then\n    return true\n  end\n  for _, q in ipairs(objective.required_quests) do\n    if C_TaskQuest.GetQuestTimeLeftSeconds(q) or C_QuestLog.IsQuestFlaggedCompleted(q) then\n      return true\n    end\n  end\nend\n\n-- This returns the number of quests that are not complete.\nlocal remaining_quests = function(objective)\n  local c = #objective.quests\n  for _, q in ipairs(objective.quests) do\n    if C_QuestLog.IsQuestFlaggedCompleted(q) then\n      c = c - 1\n    end\n  end\n  return c\nend\n\nlocal profession_known = function(objective)\n  local prof1, prof2 = GetProfessions()\n  local prof1SkillID, prof2SkillID, _\n  if (prof1 ~= nil) then\n    _,_,_,_,_,_,prof1SkillID = GetProfessionInfo(prof1)\n  end\n  if (prof2 ~= nil) then\n    _,_,_,_,_,_,prof2SkillID = GetProfessionInfo(prof2)\n  end\n  if (objective.skillID == prof1SkillID) or (objective.skillID == prof2SkillID) then\n    return true\n  else\n    if not aura_env.config[\"automaticDetection\"] then\n      return true\n    else\n      return false\n    end\n  end\nend\n\n-- check if simple or detailed\nif aura_env.config.Extra and aura_env.config.Show then\n  aura_env.update_display = function()\n    aura_env.text = \"|cff00ffaaProfession Knowledge Weeklies|r \\n\"\n    for _, objective in ipairs(objectives) do\n      if is_active(objective) and profession_known(objective) then\n        local c = remaining_quests(objective)\n        if c > 0 then\n          if aura_env.text then\n            aura_env.text = aura_env.text ..  \"\\n\" ..objective.long..\" - \"..objective.name .. \" = \" .. c ..\" remaining\"..\" Knowledge by \"..objective.tip ..\" \" \n          else\n            aura_env.text = objective.long..\" - \"..objective.name .. \" = \" .. c ..\" remaining\"..\" Knowledge by \"..objective.tip ..\" \" \n          end\n        end\n      end\n    end\n  end\nelseif aura_env.config.Show then\n  aura_env.update_display = function()\n    aura_env.text = \"|cff00ffaaProfession Knowledge Weeklies|r\"\n    for _, objective in ipairs(objectives) do\n      if is_active(objective) and profession_known(objective) then\n        local c = remaining_quests(objective)\n        if c > 0 then\n          if aura_env.text then\n            aura_env.text = aura_env.text .. \"\\n\" ..objective.short..\"-\"..objective.name .. \": \" .. c ..\" remaining\"\n          else\n            aura_env.text = objective.short..\"-\"..objective.name .. \": \" .. c  ..\" remaining\"\n          end\n        end\n      end\n    end\n  end\nelse\n  aura_env.update_display = function()\n    aura_env.text = nil\n  end\nend\n\n\n\naura_env.update_display()",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["use_alwaystrue"] = true,
						["unevent"] = "auto",
						["duration"] = "1",
						["event"] = "Conditions",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["use_absorbMode"] = true,
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["internalVersion"] = 64,
			["wordWrap"] = "WordWrap",
			["font"] = "Expressway",
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["load"] = {
				["use_size"] = false,
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["use_never"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_zoneIds"] = true,
				["use_petbattle"] = false,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["fontSize"] = 12,
			["source"] = "import",
			["anchorFrameParent"] = true,
			["shadowXOffset"] = 1,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["anchorFrameFrame"] = "WeakAuras:PBG",
			["regionType"] = "text",
			["yOffset"] = 0,
			["fixedWidth"] = 246,
			["parent"] = "Profession Module",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_time_precision"] = 1,
			["uid"] = "ND0cwyV3bbg",
			["displayText"] = "%c",
			["semver"] = "4.99.2",
			["justify"] = "LEFT",
			["tocversion"] = 100002,
			["id"] = "Knowledge workshop",
			["xOffset"] = 17,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["selfPoint"] = "BOTTOMLEFT",
			["config"] = {
				["inscription"] = true,
				["blacksmithing"] = true,
				["skinning"] = true,
				["herbalism"] = true,
				["mining"] = true,
				["alchemy"] = true,
				["Show"] = true,
				["tailoring"] = true,
				["automaticDetection"] = true,
				["jewelcrafting"] = true,
				["engineering"] = true,
				["leatherworking"] = true,
				["Extra"] = false,
				["enchanting"] = true,
			},
			["displayText_format_c_format"] = "none",
			["preferToUpdate"] = false,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["automaticWidth"] = "Auto",
		},
		["Dragonscale Expedition"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Reps Pack",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["factionID"] = 2507,
						["use_unit"] = true,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.DESH then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = true,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["iconSource"] = -1,
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 4687628,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_1.standingld_format"] = "none",
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_1v_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["anchorXOffset"] = 0,
					["text_text_format_t_format"] = "timed",
					["text_text_format_1.Value_format"] = "none",
					["text_fontType"] = "None",
					["type"] = "subtext",
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_1.standingid_format"] = "none",
					["text_text"] = "%p - %1.standing",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_1.value_format"] = "none",
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_p_format"] = "timed",
					["text_text_format_1.standingId_format"] = "none",
					["text_shadowXOffset"] = 1,
					["text_text_format_1value_format"] = "none",
					["text_text_format_p_time_format"] = 0,
				}, -- [3]
				{
					["text_text_format_n_format"] = "string",
					["text_text"] = " %n ",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 150,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_fontType"] = "None",
					["text_wordWrap"] = "Elide",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_shadowXOffset"] = 1,
					["text_text_format_n_abbreviate_max"] = 18,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_n_abbreviate"] = false,
				}, -- [4]
			},
			["gradientOrientation"] = "HORIZONTAL",
			["internalVersion"] = 64,
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["selfPoint"] = "CENTER",
			["source"] = "import",
			["uid"] = "lI(MPD56etL",
			["config"] = {
				["Rep"] = {
					["DESH"] = false,
				},
			},
			["xOffset"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["alpha"] = 1,
			["height"] = 16,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["spark"] = false,
			["zoom"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Dragonscale Expedition",
			["backgroundColor"] = {
				1, -- [1]
				0.070588238537312, -- [2]
				0.070588238537312, -- [3]
				0.75, -- [4]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["version"] = 80,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFF02ff00enabled|r)",
							["key"] = "DESH",
							["useDesc"] = true,
							["name"] = "|cFFff0000Dragonscale Expedition Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				0.48235297203064, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.DESH",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "",
					["do_custom"] = false,
				},
			},
		},
		["Enchanting"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Enchanting one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "TENC",
					["useDesc"] = true,
					["name"] = "Track Enchanting",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Enchanting Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0.18823531270027, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "34P95HTYyYN",
			["displayIcon"] = "4620672",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Enc Module",
			["barColor2"] = {
				0.086274512112141, -- [1]
				0, -- [2]
				0.45490199327469, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620672,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TENC then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 7411,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Enchanting",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				0.18823531270027, -- [1]
				0, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["onlyElites"] = false,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Enchanting",
						["zone"] = 5,
						["hiddenQuestId"] = "74110",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 18.7,
						["X"] = 62.42,
						["name"] = "Profession Master Shalasar Glimmerdusk",
						["zone"] = 2,
						["hiddenQuestId"] = "70251",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
					{
						["Y"] = 83.60000000000001,
						["X"] = 57.5,
						["name"] = "Flashfrozen Scroll",
						["zone"] = 1,
						["hiddenQuestId"] = "70320",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 26.8,
						["X"] = 68,
						["name"] = "Lava-Infused Seed",
						["zone"] = 1,
						["hiddenQuestId"] = "70283",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 58.5,
						["X"] = 57.5,
						["name"] = "Enchanted Debris",
						["zone"] = 1,
						["hiddenQuestId"] = "70272",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 67.6,
						["X"] = 61.4,
						["name"] = "Stormbound Horn",
						["zone"] = 2,
						["hiddenQuestId"] = "70291",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 59.2,
						["X"] = 38.5,
						["name"] = "Forgotten Arcane Tome",
						["zone"] = 3,
						["hiddenQuestId"] = "70336",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 61.2,
						["X"] = 45.1,
						["name"] = "Faintly Enchanted Remains",
						["zone"] = 3,
						["hiddenQuestId"] = "70290",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 45.54,
						["X"] = 21.56,
						["name"] = "Enriched Earthen Shard",
						["zone"] = 3,
						["hiddenQuestId"] = "70298",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [9]
					{
						["Y"] = 70.4,
						["X"] = 59.9,
						["name"] = "Fractured Titanic Sphere",
						["zone"] = 4,
						["hiddenQuestId"] = "70342",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [10]
				},
				["TENC"] = true,
				["hideCompleted"] = true,
				["Utt"] = true,
			},
		},
		["Tailoring"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Tailoring one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "TTAI",
					["useDesc"] = true,
					["name"] = "Track Tailor",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Tailoring Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset array  data",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "4q9krWQ6vCc",
			["displayIcon"] = "4620681",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Tai Module",
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				0.75, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620681,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TTAI then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 3908,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Tailoring",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  \n  {\n    zoneId = 2112,\n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["onlyElites"] = false,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Tailoring",
						["zone"] = 5,
						["hiddenQuestId"] = "74115",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 45.76,
						["X"] = 27.96,
						["name"] = "Profession Masters Elysa Raywinder",
						["zone"] = 5,
						["hiddenQuestId"] = "70260",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
					{
						["Y"] = 37.9,
						["X"] = 74.7,
						["name"] = "Mysterious Banner",
						["zone"] = 1,
						["hiddenQuestId"] = "70302",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 69.7,
						["X"] = 24.9,
						["name"] = "Itinerant Singed Fabric",
						["zone"] = 1,
						["hiddenQuestId"] = "70304",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 40.12,
						["X"] = 35.34,
						["name"] = "Noteworthy Scrap of Carpet",
						["zone"] = 2,
						["hiddenQuestId"] = "70295",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 52.9,
						["X"] = 66.1,
						["name"] = "Silky Surprise",
						["zone"] = 2,
						["hiddenQuestId"] = "70303",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 38.8,
						["X"] = 16.2,
						["name"] = "Decaying Brackenhide Blanket",
						["zone"] = 3,
						["hiddenQuestId"] = "70284",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 54.5,
						["X"] = 40.7,
						["name"] = "Intriguing Bolt of Blue Cloth",
						["zone"] = 3,
						["hiddenQuestId"] = "70267",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 79.7,
						["X"] = 60.4,
						["name"] = "Miniature Bronze Dragonflight Banner",
						["zone"] = 4,
						["hiddenQuestId"] = "70288",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [9]
					{
						["Y"] = 45.8,
						["X"] = 58.6,
						["name"] = "Ancient Dragonweave Bolt",
						["zone"] = 4,
						["hiddenQuestId"] = "70372",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [10]
				},
				["TTAI"] = true,
				["hideCompleted"] = true,
				["Utt"] = true,
			},
		},
		["todo list"] = {
			["outline"] = "OUTLINE",
			["displayText_format_text_format"] = "none",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Todo list Pack",
			["displayText"] = "%c",
			["customText"] = "function()\n  aura_env.text = aura_env.update_display()\n  \n  return aura_env.text \nend",
			["shadowYOffset"] = -1,
			["anchorPoint"] = "BOTTOMLEFT",
			["displayText_format_p_time_format"] = 0,
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "--code is a modified version of Korthia Checklist https://wago.io/cyRj6ikQz by Dorovon#1260 for the original todo lists in korthia\n-- Default Locale --\naura_env.defaultLocale = 'enUS'\n-- User Locale Var--\naura_env.userLocale = GetLocale()\n-- Get Text sinppet --\naura_env.get_text_snippet = function(name)\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.userLocale] then\n    return aura_env.textSnippets[name][aura_env.userLocale]\n  end\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.defaultLocale] then\n    return aura_env.textSnippets[name][aura_env.defaultLocale]\n  end\n  return name\nend\n-- World quest Availibility --\naura_env.is_world_quest_available = function(quest)\n  if not C_TaskQuest.GetQuestTimeLeftSeconds(quest) then\n    return true\n  end\n  return false\nend\n-- Quest Completion check --\naura_env.is_quest_completed = function(quest)\n  if C_QuestLog.IsQuestFlaggedCompleted(quest) then\n    return true\n  end\n  return false\nend\n\n-- Title items --\n--Norah#21256 thank you for French Tranlations\n--Beatrice#2650 & Podwiznaia#2373 thank you both for help with the Russian Translations\n--Shokuhou (Orillion), Lars, phoi thank you all for your japanese Translations\n--Shokuhou (Orillion) thank you for your Dutch Translations\n--Zamy thank you for your Koreran Translations\n--三皈依#3388 thank you for your Translations\n--hohunide thank you for your Translations\n--N3cro#92 thank you for your Translations\naura_env.textSnippets = {\n  overviewHeadline = { enUS = ' Todo list:',\n    deDE = 'Aufgabenliste:',\n    zhTW = '的任務列表: ', \n    zhCN = ' 任务列表:', \n    ruRU = 'Список дел ' ,\n    frFR = 'Liste de choses à faire :' ,\n    jaJP = 'タマのやること帳・ ',\n    koKR = '숙제 리스트 ',\n  },\n  \n  worldBoss = { \n    enUS = 'World Boss: ',\n    deDE = 'Weltboss: ',\n    zhTW = '世界首領', \n    zhCN = '世界BOSS: ',\n    ruRU = 'Мировой босс:',\n    frFR = 'Boss mondial: ',\n    nlNL = 'Wereld Baas',\n    jaJP = 'ワールドボス',\n    koKR = '필드보스',\n  },\n  \n  worldQuests = {\n    enUS = 'World Quests: ',\n    deDE = 'Welt-Quests: ',\n    zhTW = '世界任務', \n    zhCN = '世界任务: ',\n    ruRU = 'МЛокальные задания:',\n    frFR = 'Quêtes mondiales: ',\n    nlNL = 'World Quests',\n    jaJP = 'アコードを手伝う',\n    koKR = '전역 퀘스트',\n  },\n  \n  weeklyQuest = {\n    enUS = 'Aiding the Accord: ',\n    deDE = 'Unterstützung des Abkommens ',\n    zhTW = '支援協調者：', \n    zhCN = '协助援军： ',\n    ruRU = 'Содействие Соглашению: ',\n    frFR = 'Aider le concordat: ',\n    nlNL = 'Accord Assistentie',\n    jaJP='アコードを手伝う',\n    koKR = '협의회 지원',\n  },\n  \n  CommunityFeast = {\n    enUS = 'Community Feast: ',\n    deDE = ' Gemeinschaftliches Festmahl: ',\n    zhTW = '集體盛宴：', \n    zhCN = '社区盛宴： ',\n    ruRU = 'Большое пиршество: ',\n    frFR = 'Festin tribal:  ',\n    nlNL = 'Gemeenschap`s Feestmaal',\n    jaJP = 'コミュニティの宴会',\n    koKR = '공동체 잔치',\n  },\n  \n  elements = {\n    enUS = 'Trial of Elements: ',\n    deDE = 'Prüfung der Elemente:',\n    zhTW = '元素的試煉: ', \n    zhCN = '元素审判:  ',\n    ruRU = 'Испытание элементов: ',\n    frFR = 'L’épreuve des éléments: ',\n    nlNL = 'Test van de Elementen',\n    jaJP = '五大の試し',\n    koKR = '원소의 시험',\n  },\n  \n  flood = {\n    enUS = 'Trial of Flood: ',\n    deDE = 'Prüfung der Flut:',\n    zhTW = '洪流的試煉: ', \n    zhCN = '洪水的审判： ',\n    ruRU = 'Испытание наводнения: ', \n    frFR = 'L’épreuve du déluge:  ',\n    nlNL = 'Test van de Overstroming',\n    jaJP = '洪水の試し',\n    koKR = '홍수의 시험',\n  },\n  \n  SoDK = {\n    enUS = 'Siege of Dragonscale Keep: ',\n    deDE = 'Belagerung der Drachenfluchfestung: ',\n    zhTW = '攻打龍禍要塞： ', \n    zhCN = '围攻灭龙要塞: ',\n    ruRU = 'Осада драконьей погибели: ',\n    frFR = 'Siege du Fleau-des-dragons: ',\n    nlNL = 'Belegering van Fort Dragonscale',\n    jaJP =' ドラゴンスケール天守の包囲',\n    koKR = '용의 파멸 성채 공성전',\n  },\n  \n  Hunt = {\n    enUS = 'Grand Hunts: ',\n    deDE = 'Große Jagd: ',\n    zhTW = '大狩獵: ', \n    zhCN = '洪荒狩猎: ',\n    ruRU = 'Великая охота: ',\n    frFR = 'Grandes Chasses: ',\n    nlNL = 'Grootse Jachten',\n    jaJP = '盛大狩り',\n    koKR = '사냥의 제전',\n  },\n  Chests = {\n    enUS = 'Supply Chest (warmode): ',\n    deDE = 'Versorgungstruhe (Kriegsmodus): ',\n    zhTW = '补给箱（战争模式): ', \n    zhCN = '补给箱（战争模式): ',\n    ruRU = 'Сундук питания (теплоход): ',\n    frFR = 'Coffre d\\'approvisionnement (mode guerre): ',\n    nlNL = 'Forsyningskiste (krigstilstand):',\n    jaJP = '補給箱(ウォーモード)',\n    koKR = '보급 상자 (전쟁 모드)',\n  },\n}\n-- TODO - Items --\naura_env.todoList = {\n  {name = \"weeklyQuest\", maximum = 1,\n    quests = {\n      {questId = 70750,},--Aiding the Accord-- \n    },\n  },\n  \n  {name = \"CommunityFeast\",maximum = 1,\n    quests = {\n      {questId = 70893,},-- Hidden quest ID 70893--\n    },\n  },\n  \n  {name = \"SoDK\",maximum = 1,\n    quests = {\n      {questId = 70866,},-- confirm this Hidden ID72025 0r 70866--\n    },\n  },\n  \n  {name = \"Hunt\",maximum = 3,\n    quests = {\n      {questId = 70906,},\n      {questId = 71136,},\n      {questId = 71137,},--WS 25.44,92.29-- Epic\n      -- {questId = 69998,},-- WS 25.44,92.29--\n      -- {questId = 69999,},-- WS 40.98,84.46--\n      -- {questId = 70000,},-- WS 25.44,92.29--\n    },\n  },\n  {name = \"flood\",maximum = 1,\n    quests = {\n      {questId = 71033,}, --Raging Torrent mobID 197221 hidden ID 71033 --\n    },\n  },\n  {name = \"elements\",maximum = 1,\n    quests = {\n      {questId = 71995,}, --Therrocite mob id 197749--\n    },\n  },\n  {name = \"Chests\",maximum = 1,\n    quests = {\n      {questId = 72376,}, --Supply Chest (warmode)\n    },\n  },\n  \n  { name = \"worldBoss\",  maximum = 1,\n    quests = {\n      {questId = 69927,}, -- Bazual mobID 193532, hidden ID####--\n      {questId = 69928,},-- Liskanoth  mobID 193533, hidden ID####--\n      {questId = 69929,},-- Strunraan mobID 193534, hidden ID####--\n      {questId = 69930,},-- Basrikron mobID 193535, hidden ID####--\n      \n    },\n  },\n  \n}\n\n--Output Varible--\naura_env.text = '';\n--Output Main function--\naura_env.update_overview_display = function()\n  local text = ''\n  --Include switches\n  local todov = aura_env.config.TD.showOverview\n  local wbv = aura_env.config.TD.includeWorldBoss\n  local Cfv = aura_env.config.TD.includeCommunityFeast\n  local elev = aura_env.config.TD.includeelements\n  local floodv = aura_env.config.TD.includeFlood\n  local SoDKv = aura_env.config.TD.includeSoDK\n  local huntv = aura_env.config.TD.includeHunt\n  local WQv = aura_env.config.TD.includeWeeklyQuest\n  local Warv = aura_env.config.TD.includeWar\n  --Hide switches\n  local wbh = aura_env.config.TD.hide\n  local Cfh = aura_env.config.TD.hide\n  local eleh = aura_env.config.TD.hide\n  local floodh = aura_env.config.TD.hide\n  local SoDKh = aura_env.config.TD.hide\n  local hunth = aura_env.config.TD.hide\n  local WQh = aura_env.config.TD.hide\n  local Warh = aura_env.config.TD.hide\n  local tracking = 0\n  -----------------------------------------------------Todo list Prep--------------------------------------------------------------------------- \n  for _, todoEntry in ipairs(aura_env.todoList) do\n    -- PINK --\n    local entry, color, completed, maximum = '', 'ffff00ff', 0, #todoEntry.quests\n    if \n    --set up the items to display\n    todoEntry.name == 'Chests' and Warv or--Supply Chest (warmode)--\n    todoEntry.name == 'worldBoss' and wbv or -- world boss\n    todoEntry.name == 'CommunityFeast' and Cfv or-- Tuskarr Community Feast--\n    todoEntry.name == 'elements' and elev or--Trial of Elements --\n    todoEntry.name == 'flood' and floodv or--Trial of Floods --\n    todoEntry.name == 'SoDK' and SoDKv or--Siege of Dragonscale Keep --\n    todoEntry.name == 'Hunt' and huntv or--Grand Hunts --\n    todoEntry.name == 'weeklyQuest' and WQv then--Aiding the Accord--\n      if todoEntry.maximum then\n        maximum = todoEntry.maximum\n      end\n      for _, todoQuest in ipairs(todoEntry.quests) do\n        if todoEntry.name == 'worldBoss' then\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n            tracking = tracking +1\n          end\n        else\n          if aura_env.is_quest_completed(todoQuest.questId) then\n            completed = completed + 1\n            tracking = tracking +1\n          end\n        end\n      end\n      if (maximum > 1) and (completed >= (maximum / 2)) then\n        -- Burnt Orange --\n        color = 'ffff7801'\n      end \n      if completed >= maximum then\n        -- JADE--\n        color = 'FF00ff96'\n      end\n      \n      if completed >= maximum then\n        if\n        --check if the use wants to hide the line after complete\n        todoEntry.name == 'Chests' and not Warh  or--Supply Chest (warmode)--\n        todoEntry.name == 'worldBoss' and not wbh or-- world boss\n        todoEntry.name == 'CommunityFeast' and not Cfh or -- Tuskarr Community Feast--\n        todoEntry.name == 'elements' and not eleh or --Trial of Elements --\n        todoEntry.name == 'flood' and not floodh or --Trial of Floods --\n        todoEntry.name == 'SoDK' and not SoDKh or--Siege of Dragonscale Keep --\n        todoEntry.name == 'Hunt' and not hunth or --Grand Hunts --\n        todoEntry.name == 'weeklyQuest' and not WQh then --Aiding the Accord--\n          entry ='    ' ..  aura_env.get_text_snippet(todoEntry.name) .. ' ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n        end\n      else\n        entry ='    ' .. aura_env.get_text_snippet(todoEntry.name) .. ' ' .. WrapTextInColorCode(completed .. ' / ' .. maximum, color) .. '\\r\\n'\n      end\n      \n      text = text .. entry\n    end\n  end\n  \n  return text\nend\n\n--Update output varible--\naura_env.update_display = function()\n  local text = ''\n  ---todo list items update---\n  if aura_env.config.TD.showOverview then -- cheack if use want to show\n    -- if tracking <5 then\n    text ='  ' .. text .. WrapTextInColorCode(aura_env.get_text_snippet('overviewHeadline'), 'ff00ff96') .. '\\r\\n'--apped header\n    --   end\n    text = text .. aura_env.update_overview_display() .. '\\r' --append todo list items\n  end \n  return text\nend\naura_env.text = aura_env.update_display()",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["custom"] = "function(states, event, ...)\n    aura_env.text = aura_env.update_display() \n    \n    return true\nend",
						["events"] = "CHAT_MSG_LOOT,PARTY_KILL,BAG_UPDATE,QUEST_COMPLETE,QUEST_AUTOCOMPLETE,WORLD_QUEST_COMPLETED_BY_SPELL,UPDATE_FACTION,QUEST_LOG_UPDATE,ENCOUNTER_LOOT_RECEIVED,QUEST_TURNED_IN,QUEST_LOG_UPDATE",
						["subeventPrefix"] = "SPELL",
						["check"] = "event",
						["custom_type"] = "stateupdate",
						["spellIds"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["unit"] = "player",
						["event"] = "Health",
						["names"] = {
						},
						["subeventPrefix"] = "SPELL",
						["custom"] = "function(states, event, ...)\n    aura_env.text = aura_env.update_display() \n    \n    return true\nend",
						["spellIds"] = {
						},
						["events"] = "CHAT_MSG_LOOT,PARTY_KILL,BAG_UPDATE,QUEST_COMPLETE,QUEST_AUTOCOMPLETE,WORLD_QUEST_COMPLETED_BY_SPELL,UPDATE_FACTION,QUEST_LOG_UPDATE,ENCOUNTER_LOOT_RECEIVED,QUEST_TURNED_IN,QUEST_LOG_UPDATE",
						["check"] = "event",
						["dynamicDuration"] = false,
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["useTooltip"] = true,
			["wordWrap"] = "WordWrap",
			["desc"] = "--code is a modified version of Korthia Checklist https://wago.io/cyRj6ikQz by Dorovon#1260 for the original todo lists in korthia",
			["font"] = "Expressway",
			["version"] = 80,
			["displayText_format_c_format"] = "none",
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["uid"] = "ZmTSbhCcKka",
			["fontSize"] = 12,
			["source"] = "import",
			["shadowXOffset"] = 1,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["preferToUpdate"] = false,
			["anchorFrameFrame"] = "WeakAuras:BGtd",
			["regionType"] = "text",
			["conditions"] = {
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["selfPoint"] = "TOPLEFT",
			["displayText_format_p_time_precision"] = 1,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["internalVersion"] = 64,
			["justify"] = "LEFT",
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "todo list",
			["yOffset"] = 0,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["xOffset"] = 0,
			["config"] = {
				["TD"] = {
					["includeelements"] = true,
					["includeFlood"] = true,
					["includeCommunityFeast"] = true,
					["includeWar"] = false,
					["includeHunt"] = true,
					["includeSoDK"] = true,
					["includeWorldBoss"] = true,
					["showOverview"] = true,
					["includeWeeklyQuest"] = true,
					["hide"] = false,
				},
			},
			["anchorFrameParent"] = false,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Todo list",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the todo list text |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "showOverview",
							["useDesc"] = true,
							["name"] = "|cFF00ffaaWeekly Todo list|r",
							["width"] = 1,
						}, -- [1]
						{
							["useName"] = true,
							["type"] = "header",
							["text"] = "Todo list items Tracking",
							["noMerge"] = true,
							["width"] = 1,
						}, -- [2]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeWeeklyQuest",
							["useDesc"] = true,
							["name"] = "Aiding the Accord",
							["width"] = 1,
						}, -- [3]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeCommunityFeast",
							["useDesc"] = true,
							["name"] = "Iskaara Community Feast",
							["width"] = 1,
						}, -- [4]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeSoDK",
							["useDesc"] = true,
							["name"] = "Siege of Dragonscale Keep",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeHunt",
							["useDesc"] = true,
							["name"] = "Grand Hunt",
							["width"] = 1,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeelements",
							["useDesc"] = true,
							["name"] = "Trial of elements",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeFlood",
							["useDesc"] = true,
							["name"] = "Trial of Flood",
							["width"] = 1,
						}, -- [8]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the task |n|n(default: |cFF02ff00enabled|r)",
							["key"] = "includeWorldBoss",
							["useDesc"] = true,
							["name"] = "World Boss",
							["width"] = 1,
						}, -- [9]
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If Enabled will display the task |n|(default: |cFFff0000disabled|r)",
							["key"] = "includeWar",
							["useDesc"] = true,
							["name"] = "Supply Chest (warmode)",
							["width"] = 1,
						}, -- [10]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If enabled, will hide Tasks marked as complete.|n(default: |cFF02ff00enabled|r)",
							["key"] = "hide",
							["useDesc"] = true,
							["name"] = "Hide completed",
							["width"] = 2,
						}, -- [11]
					},
					["hideReorder"] = true,
					["nameSource"] = 0,
					["name"] = "Todo list Config",
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = true,
					["key"] = "TD",
					["collapse"] = true,
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 245,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["automaticWidth"] = "Auto",
		},
		["SKAB 9"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "SKAB 9",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "dRoFpuORb4N",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Sk Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Rares Packs"] = {
			["grow"] = "DOWN",
			["controlledChildren"] = {
				"Rares Bar", -- [1]
			},
			["borderBackdrop"] = "ElvUI Blank",
			["wagoID"] = "9MpDLGWp3",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "BOTTOM",
			["arcLength"] = 360,
			["authorOptions"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["useAnchorPerUnit"] = false,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["internalVersion"] = 64,
			["space"] = 2,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["align"] = "CENTER",
			["groupIcon"] = 236693,
			["sortHybridTable"] = {
				["Rares Bar"] = false,
			},
			["desc"] = "green text = unkilled and in same zone\nred text = killed \nwhite text  not in same zone and not killed\n\nif a rare drops a cloak ring or trinket that has int/str/agi it will be marked as always show the classes picked below are ignore those items",
			["stagger"] = 0,
			["parent"] = "Weekly/Daily Module",
			["version"] = 80,
			["subRegions"] = {
			},
			["fullCircle"] = true,
			["rowSpace"] = 1,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["customSort"] = "function() \n  return WeakAuras.SortAscending{'name'}\nend\n--WeakAuras.SortDescending{'name'}",
			["backdropColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.88000000268221, -- [4]
			},
			["radius"] = 200,
			["animate"] = true,
			["frameStrata"] = 1,
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["borderEdge"] = "None",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 1,
			["sort"] = "none",
			["selfPoint"] = "TOP",
			["gridType"] = "RD",
			["rotation"] = 0,
			["hybridSortMode"] = "descending",
			["constantFactor"] = "RADIUS",
			["source"] = "import",
			["borderOffset"] = 0.5,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Rares Packs",
			["useLimit"] = false,
			["gridWidth"] = 5,
			["anchorFrameType"] = "SELECTFRAME",
			["anchorFrameFrame"] = "WeakAuras:Reps Pack",
			["borderInset"] = 1,
			["hybridPosition"] = "hybridFirst",
			["limit"] = 5,
			["uid"] = "919Q6Tk)2fc",
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
			},
			["config"] = {
			},
		},
		["Enc Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Enchanting", -- [1]
				"EncCAB", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620672,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "ywGGSuKkCgE",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:BS Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Enc Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["EncCAB"] = false,
				["Enchanting"] = false,
			},
		},
		["ALCAB"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_zoneIds"] = true,
				["use_petbattle"] = false,
				["use_size"] = false,
				["use_ingroup"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = false,
				["use_spellknown"] = false,
				["use_alive"] = true,
				["spellknown"] = 2259,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0.76470595598221, -- [1]
				0, -- [2]
				1, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "ALCAB",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "giWOHVXZebD",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "alc module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Artisans Consort"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["wagoID"] = "9MpDLGWp3",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["backgroundColor"] = {
				0.67058825492859, -- [1]
				0.67058825492859, -- [2]
				0.48235297203064, -- [3]
				0.75, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["use_standingId"] = false,
						["spellIds"] = {
						},
						["use_friendshipRank"] = false,
						["factionID"] = 2544,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.AC then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 64,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFFff0000disabled|r)",
							["key"] = "AC",
							["useDesc"] = true,
							["name"] = "|cFFabababArtisan's Consortium Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = false,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["barColor"] = {
				0.67058825492859, -- [1]
				0.67058825492859, -- [2]
				0.48235297203064, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 4549141,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 130,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["height"] = 16,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.CA",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["sparkOffsetY"] = 0,
			["source"] = "import",
			["gradientOrientation"] = "HORIZONTAL",
			["uid"] = "BRfUAfivQIG",
			["sparkOffsetX"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["frameStrata"] = 1,
			["icon"] = true,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["semver"] = "4.99.2",
			["zoom"] = 0,
			["spark"] = false,
			["tocversion"] = 100002,
			["id"] = "Artisans Consort",
			["config"] = {
				["Rep"] = {
					["AC"] = false,
				},
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["enableGradient"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["parent"] = "Reps Pack",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				0.67058825492859, -- [1]
				0.67058825492859, -- [2]
				0.48235297203064, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["JCAB "] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "JCAB ",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "hX5TRJdGVt8",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "JC Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Sabellion"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["wagoID"] = "9MpDLGWp3",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["backgroundColor"] = {
				1, -- [1]
				0, -- [2]
				0.66666668653488, -- [3]
				0.75, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["use_standingId"] = false,
						["spellIds"] = {
						},
						["use_friendshipRank"] = false,
						["factionID"] = 2518,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.Seb then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 64,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFFff0000disabled|r)",
							["key"] = "Seb",
							["useDesc"] = true,
							["name"] = "|cFFff00aaSabellion Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = false,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0.66666668653488, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 4559236,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 110,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["height"] = 16,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.Seb",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["sparkOffsetY"] = 0,
			["source"] = "import",
			["gradientOrientation"] = "HORIZONTAL",
			["uid"] = "6LtNjF8kGWp",
			["sparkOffsetX"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["frameStrata"] = 1,
			["icon"] = true,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["semver"] = "4.99.2",
			["zoom"] = 0,
			["spark"] = false,
			["tocversion"] = 100002,
			["id"] = "Sabellion",
			["config"] = {
				["Rep"] = {
					["Seb"] = false,
				},
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["enableGradient"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["parent"] = "Reps Pack",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["TiaAB"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "TiaAB",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "McTJeXfPBch",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Tai Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Sk Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Skinning", -- [1]
				"SKAB 9", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4625106,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "taUoCpBTZOC",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Minning Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Sk Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Skinning"] = false,
				["SKAB 9"] = false,
			},
		},
		["Profession Module"] = {
			["controlledChildren"] = {
				"PBG", -- [1]
				"Knowledge workshop", -- [2]
				"alc module", -- [3]
				"BS Module", -- [4]
				"Enc Module", -- [5]
				"Eng Module ", -- [6]
				"Herb Module", -- [7]
				"Isc Module", -- [8]
				"JC Module", -- [9]
				"LW Module", -- [10]
				"Minning Module", -- [11]
				"Sk Module", -- [12]
				"Tai Module", -- [13]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Tama's Dragonflight helper",
			["preferToUpdate"] = false,
			["yOffset"] = 100.10833740234,
			["anchorPoint"] = "LEFT",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 64,
			["selfPoint"] = "CENTER",
			["version"] = 80,
			["subRegions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 1,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["config"] = {
			},
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Profession Module",
			["authorOptions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["groupIcon"] = 446127,
			["uid"] = "wIY8GI46rUi",
			["xOffset"] = 132.12268066406,
			["borderInset"] = 1,
			["conditions"] = {
			},
			["information"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Engineering"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Engineering one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "track profession",
					["key"] = "TENG",
					["useDesc"] = true,
					["name"] = "Track Engineering",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Enginneering Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0.18823531270027, -- [1]
				0.66666668653488, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "(e5E6FNwpEl",
			["displayIcon"] = "4620673",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Eng Module ",
			["barColor2"] = {
				0.086274512112141, -- [1]
				0, -- [2]
				0.45490199327469, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620673,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TENG then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 4036,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Engineering",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				0.18823531270027, -- [1]
				0.66666668653488, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["onlyElites"] = false,
				["TENG"] = true,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on engineering",
						["zone"] = 5,
						["hiddenQuestId"] = "74111",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 21.7,
						["X"] = 17.8,
						["name"] = "Profession Master  Frizz Buzzcrank",
						["zone"] = 3,
						["hiddenQuestId"] = "70252",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
					{
						["Y"] = 44.9,
						["X"] = 56,
						["name"] = "Boomthyr Rocket",
						["zone"] = 1,
						["hiddenQuestId"] = "70270",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 77.54,
						["X"] = 49.09,
						["name"] = "Intact Coil Capacitor",
						["zone"] = 1,
						["hiddenQuestId"] = "70275",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
				},
				["hideCompleted"] = true,
				["Utt"] = true,
			},
		},
		["header"] = {
			["outline"] = "OUTLINE",
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["customText"] = "function()\n  aura_env.text = aura_env.update_display()\n  \n  return aura_env.text \nend",
			["yOffset"] = -6.9135877821181,
			["anchorPoint"] = "CENTER",
			["displayText_format_p_time_format"] = 0,
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "",
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_time_mod_rate"] = true,
			["displayText_format_p_time_legacy_floor"] = false,
			["selfPoint"] = "CENTER",
			["font"] = "Expressway",
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["fontSize"] = 12,
			["source"] = "import",
			["shadowXOffset"] = 1,
			["parent"] = "Todo list Pack",
			["displayText_format_p_format"] = "timed",
			["regionType"] = "text",
			["automaticWidth"] = "Auto",
			["conditions"] = {
			},
			["displayText"] = "Tama's Dragonflight helper",
			["preferToUpdate"] = false,
			["displayText_format_p_time_precision"] = 1,
			["uid"] = "5N4p2jn)M8b",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["justify"] = "LEFT",
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "header",
			["shadowYOffset"] = -1,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 126.4198811849,
			["config"] = {
			},
			["color"] = {
				0, -- [1]
				1, -- [2]
				0.66666668653488, -- [3]
				1, -- [4]
			},
			["wordWrap"] = "WordWrap",
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["internalVersion"] = 64,
		},
		["Weekly/Daily Module"] = {
			["controlledChildren"] = {
				"Todo list Pack", -- [1]
				"Reps Pack", -- [2]
				"Rares Packs", -- [3]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["groupIcon"] = 413590,
			["anchorPoint"] = "TOPLEFT",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["desc"] = "This is the dragon flight version of my popular Zereth Mortis Helper",
			["version"] = 80,
			["subRegions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 0.9,
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Tamas Dragonflight helper",
			["regionType"] = "group",
			["borderSize"] = 2,
			["anchorFrameParent"] = false,
			["config"] = {
			},
			["borderInset"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Weekly/Daily Module",
			["xOffset"] = 144.1985405816,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "Tama's Dragonflight helper",
			["uid"] = ")99bHQtc(Am",
			["yOffset"] = 586.66693793403,
			["borderEdge"] = "Square Full White",
			["conditions"] = {
			},
			["information"] = {
			},
			["selfPoint"] = "CENTER",
		},
		["User guide (Note shown) Work in progress"] = {
			["grow"] = "DOWN",
			["controlledChildren"] = {
				"Notice", -- [1]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 577.77819824219,
			["anchorPoint"] = "TOPLEFT",
			["fullCircle"] = true,
			["rowSpace"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["internalVersion"] = 64,
			["selfPoint"] = "TOP",
			["align"] = "CENTER",
			["gridWidth"] = 5,
			["sortHybridTable"] = {
				["Notice"] = false,
			},
			["stagger"] = 0,
			["useLimit"] = false,
			["version"] = 80,
			["subRegions"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["space"] = 2,
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animate"] = false,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "34s0JqFAfIT",
			["source"] = "import",
			["borderInset"] = 1,
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["sort"] = "none",
			["xOffset"] = 727.11010742188,
			["radius"] = 200,
			["anchorFrameParent"] = false,
			["constantFactor"] = "RADIUS",
			["arcLength"] = 360,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "User guide (Note shown) Work in progress",
			["rotation"] = 0,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["limit"] = 5,
			["config"] = {
			},
			["parent"] = "Tama's Dragonflight helper",
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
		},
		["Jewelcrafting"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Jewelcrafting one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "track this profession ",
					["key"] = "TJC",
					["useDesc"] = true,
					["name"] = "Track Jewelcrafting",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Jewelcrafting Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0.40000003576279, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "wxwFE2IFMEd",
			["displayIcon"] = "4620677",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "JC Module",
			["barColor2"] = {
				0, -- [1]
				0.4627451300621, -- [2]
				0.69803923368454, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620677,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TJC then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 25229,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Jewelcrafting",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				1, -- [1]
				0, -- [2]
				0.40000003576279, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["onlyElites"] = false,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Jewelcrafting",
						["zone"] = 5,
						["hiddenQuestId"] = "74112",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 40.79,
						["X"] = 46.21,
						["name"] = "Profession master Pluutar",
						["zone"] = 3,
						["hiddenQuestId"] = "70255",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
					{
						["Y"] = 45.1,
						["X"] = 50.4,
						["name"] = "Closely Guarded Shiny",
						["zone"] = 1,
						["hiddenQuestId"] = "70292",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 63.7,
						["X"] = 33.9,
						["name"] = "Igneous Gem",
						["zone"] = 1,
						["hiddenQuestId"] = "70273",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 35.4,
						["X"] = 25.2,
						["name"] = "Lofty Malygite",
						["zone"] = 2,
						["hiddenQuestId"] = "70282",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 13,
						["X"] = 61.8,
						["name"] = "Fragmented Key",
						["zone"] = 2,
						["hiddenQuestId"] = "70263",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 61.3,
						["X"] = 45,
						["name"] = "Crystalline Overgrowth",
						["zone"] = 3,
						["hiddenQuestId"] = "70277",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 61.2,
						["X"] = 44.6,
						["name"] = "Harmonic Crystal Harmonizer",
						["zone"] = 3,
						["hiddenQuestId"] = "70271",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 65.2,
						["X"] = 59.8,
						["name"] = "Alexstraszite Cluster",
						["zone"] = 4,
						["hiddenQuestId"] = "70285",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [9]
					{
						["Y"] = 43.68,
						["X"] = 56.91,
						["name"] = "Painter's Pretty Jewel",
						["zone"] = 4,
						["hiddenQuestId"] = "70261",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [10]
				},
				["Utt"] = true,
				["hideCompleted"] = true,
				["TJC"] = true,
			},
		},
		["Rares Bar"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["xOffset"] = 0,
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n  aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.regions = {}\naura_env.zones = {\n    { zoneID = 2024, zone = \"Azure Span\" },\n    { zoneID = 2023, zone = \"Ohn'ahran Plains\" },\n    { zoneID = 2025, zone = \"Thaldraszus\" },\n    { zoneID = 2022, zone = \"Waking Shores\" },\n}\n\naura_env.slots = {\n    [1] = \"Helmet\",\n    [2] = \"Neck\",\n    [3] = \"Shoulders\",\n    [4] = \"Cloak\",\n    [5] = \"Chest\",\n    [6] = \"Bracers\",\n    [7] = \"Gloves\",\n    [8] = \"Belt\",\n    [9] = \"Legs\",\n    [10] = \"Boots\",\n    [11] = \"Ring\",\n    [12] = \"Trinket\",\n    [13] = \"1H\",\n    [14] = \"2H\",\n    [15] = \"Off Hand\",\n    [16] = \"Pattern\",\n    [17] = \"Toy\",\n    [18] = \"Pet\",\n    [19] = \"Mount\",\n    [20] = \"Skill\",\n}\n\n\n",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "VERTICAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["preferToUpdate"] = false,
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["barColor2"] = {
				0, -- [1]
				1, -- [2]
				0.6235294342041, -- [3]
				1, -- [4]
			},
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.015686275437474, -- [3]
								1, -- [4]
							},
							["property"] = "sub.4.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["linked"] = true,
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.14117647707462, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["orientation"] = "HORIZONTAL",
			["desaturateBackground"] = false,
			["enableGradient"] = true,
			["zoom"] = 0,
			["customTextUpdate"] = "update",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    currentZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        if aura_env.config.rareSettings.SLpting then -- check if single line out pout has been selected in custome options\n          for cloneID, region in pairs(aura_env.regions) do\n            local over = MouseIsOver(region)\n            if over and states[cloneID] then\n              for _, link in ipairs(states[cloneID].links) do\n                lootLink = lootLink .. link .. \" \"-- print loot to chat window (in a single line)\n              end\n              print(states[cloneID].disp .. \": \" .. lootLink)\n            end\n          end\n        else\n          for cloneID, region in pairs(aura_env.regions) do\n            local over = MouseIsOver(region)\n            if over and states[cloneID] then\n              print(states[cloneID].disp)\n              for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n                print(link)\n              end\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.rareSettings.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    local update\n    local playerzone = map\n    for i, rare in ipairs(cfg.rares) do\n      -- check zones\n      local rareZone = aura_env.zones[rare.zone]\n      local inZone = rareZone.zoneID == map and true or false\n      -- check completion\n      local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.questID)\n      local skip = (cfg.rareSettings.hideComplete and isCompleted) or (cfg.rareSettings.onlyElites and not rare.isElite) or (aura_env.config[\"rareSettings\"].currentZone and map ~= rareZone.zoneID)\n      \n      if skip and states[rare.questID] then\n        states[rare.questID] = { changed = true, show = false }\n        update = true\n        \n      elseif not skip and not states[rare.questID] then\n        \n        -- how are we organizing this?\n        local index = rare.name\n        if cfg[\"rareSettings\"].rareSort == 2 then\n          index = (inZone and 0 or 10) + rare.zone^2 + (rare.isElite and 0 or 1)\n        end\n        \n        \n        local tooltip = rare.name ..format(\" (%s) |cFFFFFFFF/way %s, %s|r\", rareZone.zone, rare.X, rare.Y) -- show /way in tooltip\n        --local tooltip = rare.name .. \" (\" .. rareZone.zone .. \")\" -- dont show /way in tooltip\n        \n        states[rare.questID] = {\n          icon = rare.isElite and \"vignetteeventelite\" or \"vignetteevent\",\n          disp = rare.name,\n          zone = rareZone.zoneShort,\n          zoneID = rareZone.zoneID,\n          inZone = inZone,\n          currentZone = cfg[\"rareSettings\"].currentZone,\n          isCompleted = isCompleted,\n          tooltip = tooltip,\n          tooltipWrap = false,\n          index = index,\n          links = {},\n          X = rare.X,\n          Y = rare.Y,\n          changed = true,\n          show = true\n        }\n        \n        -- check loot\n        local slots = 1 -- scarp varible \n        for _, a in ipairs(cfg.rares[i].loot) do\n          local itemID    = a.itemID\n          local itemSlot  = a.itemSlot\n          local itemClass = a.class\n          local item = Item:CreateFromItemID(itemID)\n          local link\n          local slot = aura_env.slots[itemSlot]\n          \n          if item and not item:IsItemEmpty() then\n            -- check relevant only\n            if cfg.rareSettings.relOnly and not itemClass[class] then\n              tooltip = tooltip\n            elseif aura_env.config.rareSettings.Att then\n              item:ContinueOnItemLoad(function()\n                  tooltip = tooltip .. \"\\n|cFFFFFFFF[\" .. slot .. \"] \" .. item:GetItemLink()\n                  link = item:GetItemLink()\n                end\n              )\n              table.insert(states[rare.questID].links, link)\n            end\n          end\n        end\n        states[rare.questID].tooltip = tooltip\n        update = true\n      elseif states[rare.questID] and states[rare.questID].isCompleted ~= isCompleted then\n        states[rare.questID].isCompleted = isCompleted\n        states[rare.questID].changed = true\n        update = true\n      elseif states[rare.questID] and states[rare.questID].inZone ~= inZone then\n        states[rare.questID].inZone = inZone\n        states[rare.questID].changed = true\n        update = true\n      end            \n    end\n    \n    return update\n  end\nend\n\n\n\n\n\n\n\n",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config[\"rareSettings\"].rareEnable then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["instance_type"] = {
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_alive"] = true,
				["use_never"] = false,
				["zoneIds"] = "2112, 2022, 2023, 2024, 2025, 2085",
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["wordWrap"] = "WordWrap",
			["width"] = 280,
			["user_y"] = 0,
			["compress"] = false,
			["discrete_rotation"] = 0,
			["sparkHidden"] = "NEVER",
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text_format_zone_format"] = "none",
					["text_text"] = "%zone",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_locy_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_c_format"] = "none",
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_fontType"] = "OUTLINE",
					["text_shadowYOffset"] = 0,
					["anchorXOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_text_format_disp_format"] = "none",
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["text_text_format_locx_format"] = "none",
					["text_shadowXOffset"] = 0,
				}, -- [4]
				{
					["text_text_format_n_format"] = "none",
					["text_text_format_zone_format"] = "none",
					["text_text"] = "%drops",
					["text_text_format_drops_format"] = "none",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_locy_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 434,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_visible"] = false,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "LEFT",
					["anchorXOffset"] = 0,
					["text_text_format_disp_format"] = "none",
					["text_fontSize"] = 12,
					["text_text_format_locx_format"] = "none",
					["text_shadowXOffset"] = 0,
				}, -- [5]
			},
			["height"] = 16,
			["rotate"] = true,
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["justify"] = "CENTER",
			["uid"] = "(nVqW4aBMdE",
			["displayText_format_disp_format"] = "string",
			["mirror"] = false,
			["displayIcon"] = "1322722",
			["displayText_format_p_time_precision"] = 1,
			["displayText_format_p_time_format"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["icon_side"] = "LEFT",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Rare Module",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["useName"] = true,
							["type"] = "header",
							["text"] = "What to show!",
							["noMerge"] = false,
							["width"] = 1,
						}, -- [1]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display the rare list |n(default: |cFF02ff00enabled|r)",
							["key"] = "rareEnable",
							["useDesc"] = true,
							["name"] = "Display Rares?",
							["width"] = 1,
						}, -- [2]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display only the super rares |n(default: |cFF02ff00enabled|r)",
							["key"] = "onlyElites",
							["useDesc"] = true,
							["name"] = "Supers Rares Only",
							["width"] = 1,
						}, -- [3]
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If enabled, will only display rares in your current zone.|n(default: |cFF02ff00enabled|r)",
							["key"] = "currentZone",
							["useDesc"] = true,
							["name"] = "Current Zone Only",
							["width"] = 1,
						}, -- [4]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If enabled, will hide rares marked as complete.|n(default: |cFF02ff00enabled|r)",
							["key"] = "hideComplete",
							["useDesc"] = true,
							["name"] = "|cFFff0000Toggle completed|r",
							["width"] = 1,
						}, -- [5]
						{
							["useName"] = true,
							["type"] = "header",
							["text"] = "How to show it!",
							["noMerge"] = true,
							["width"] = 2,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "Show only loot for your class|n(default: |cFF02ff00enabled|r)",
							["key"] = "relOnly",
							["useDesc"] = true,
							["name"] = "Class Loot Only",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "Show loot in mouse over tool tip|n(default: |cFFff0000disabled|r)",
							["key"] = "Att",
							["useDesc"] = true,
							["name"] = "Advanced tooltip",
							["width"] = 1,
						}, -- [8]
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If enabled will print loot to  chat window output on single line|n(default: |cFFff0000disabled|r)",
							["key"] = "SLpting",
							["useDesc"] = true,
							["name"] = "Chat window output on single line",
							["width"] = 1,
						}, -- [9]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "Turn on Tomtom world markers|n(default: |cFF02ff00enabled|r)",
							["key"] = "Utt",
							["useDesc"] = true,
							["name"] = "TomTom intergration",
							["width"] = 1,
						}, -- [10]
						{
							["desc"] = "Which order do you want the rares sorted by Name or Zone",
							["type"] = "select",
							["values"] = {
								"Name", -- [1]
								"Zone", -- [2]
							},
							["default"] = 1,
							["key"] = "rareSort",
							["useDesc"] = true,
							["name"] = "Sort By",
							["width"] = 0.5,
						}, -- [11]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Rares",
					["key"] = "rareSettings",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Rare /loot config",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [3]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Super Rare",
							["width"] = 2,
						}, -- [1]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [2]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "questID",
							["name"] = "Quest ID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [3]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 0.5,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X",
							["default"] = 0,
						}, -- [4]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 0.5,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y",
							["default"] = 0,
						}, -- [5]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Azure Span", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Thaldraszus", -- [3]
								"Waking Shores", -- [4]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [6]
						{
							["subOptions"] = {
								{
									["type"] = "input",
									["useDesc"] = false,
									["width"] = 1,
									["key"] = "itemName",
									["name"] = "Item Name",
									["multiline"] = false,
									["length"] = 10,
									["default"] = "",
									["useLength"] = false,
								}, -- [1]
								{
									["type"] = "number",
									["useDesc"] = false,
									["max"] = 999999999999,
									["step"] = 1,
									["width"] = 1,
									["min"] = 0,
									["key"] = "itemID",
									["name"] = "Item ID",
									["default"] = 0,
								}, -- [2]
								{
									["type"] = "select",
									["default"] = 1,
									["values"] = {
										"Helmet", -- [1]
										"Neck", -- [2]
										"Shoulders", -- [3]
										"Cloak", -- [4]
										"Chest", -- [5]
										"Bracers", -- [6]
										"Gloves", -- [7]
										"Belt", -- [8]
										"Legs", -- [9]
										"Boots", -- [10]
										"Ring", -- [11]
										"Trinket", -- [12]
										"1H Weapon", -- [13]
										"2H Weapon", -- [14]
										"Off Hand", -- [15]
										"Pattern", -- [16]
										"Toy", -- [17]
										"Pet", -- [18]
										"Mount", -- [19]
										"Skill", -- [20]
									},
									["key"] = "itemSlot",
									["useDesc"] = false,
									["name"] = "Slot",
									["width"] = 1,
								}, -- [3]
								{
									["type"] = "multiselect",
									["default"] = {
										false, -- [1]
										false, -- [2]
										false, -- [3]
										false, -- [4]
										false, -- [5]
										false, -- [6]
										false, -- [7]
										false, -- [8]
										false, -- [9]
										false, -- [10]
										false, -- [11]
										false, -- [12]
										false, -- [13]
									},
									["values"] = {
										"|cFFc69b6dWarrior", -- [1]
										"|cFFf48cbaPaladin", -- [2]
										"|cFFaad372Hunter", -- [3]
										"|cFFfff468Rogue", -- [4]
										"Priest", -- [5]
										"|cFFc41e3aDeath Knight", -- [6]
										"|cFF0070ddShaman", -- [7]
										"|cFF3fc7ebMage", -- [8]
										"|cFF8788eeWarlock", -- [9]
										"|cFF00ff98Monk", -- [10]
										"|cFFff7c0aDruid", -- [11]
										"|cFFa330c9Demon Hunter", -- [12]
										"|cFF33937fEvoker", -- [13]
									},
									["key"] = "class",
									["useDesc"] = false,
									["name"] = "Class Relevance",
									["width"] = 1,
								}, -- [4]
							},
							["hideReorder"] = false,
							["useDesc"] = false,
							["nameSource"] = 1,
							["collapse"] = false,
							["width"] = 1,
							["useCollapse"] = true,
							["noMerge"] = false,
							["name"] = "Loot Editor",
							["key"] = "loot",
							["limitType"] = "none",
							["groupType"] = "array",
							["type"] = "group",
							["size"] = 10,
						}, -- [7]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 2,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Rare Editor",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [4]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset rare and loot data",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [5]
			},
			["sparkRotationMode"] = "AUTO",
			["sparkHeight"] = 30,
			["config"] = {
				["rareSettings"] = {
					["SLpting"] = false,
					["Utt"] = true,
					["Att"] = true,
					["onlyElites"] = true,
					["relOnly"] = true,
					["rareEnable"] = false,
					["hideComplete"] = true,
					["rareSort"] = 1,
					["currentZone"] = true,
				},
				["rares"] = {
					{
						["Y"] = 76.60000000000001,
						["X"] = 40,
						["loot"] = {
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200228,
								["itemName"] = "Protoscale Pauldrons",
							}, -- [1]
							{
								["itemSlot"] = 3,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200682,
								["itemName"] = "Hardened Scale Shoulderguards",
							}, -- [2]
							{
								["itemSlot"] = 15,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200165,
								["itemName"] = "Aegis of Scales",
							}, -- [3]
						},
						["zone"] = 3,
						["questID"] = "72834",
						["name"] = "Acrosoth",
						["isElite"] = false,
					}, -- [1]
					{
						["Y"] = 58.6,
						["X"] = 59,
						["loot"] = {
							{
								["itemSlot"] = 14,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200303,
								["itemName"] = "Dreamweaver Acolyte's Staff",
							}, -- [1]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200299,
								["itemName"] = "Strange Clockwork Gladius",
							}, -- [2]
							{
								["itemSlot"] = 14,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200138,
								["itemName"] = "Ancient Dancer's Longspear",
							}, -- [3]
							{
								["itemSlot"] = 5,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200758,
								["itemName"] = "Breastplate of Storied Antiquity",
							}, -- [4]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194641,
								["itemName"] = "Design: Elemental Lariat",
							}, -- [5]
						},
						["zone"] = 3,
						["questID"] = "74055",
						["name"] = "Ancient Protector",
						["isElite"] = true,
					}, -- [2]
					{
						["Y"] = 58.8,
						["X"] = 28.6,
						["loot"] = {
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200247,
								["itemName"] = "Inextinguishable Gavel",
							}, -- [1]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									true, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200217,
								["itemName"] = "Blazing Essence",
							}, -- [2]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200252,
								["itemName"] = "Molten Flak Cannon",
							}, -- [3]
							{
								["itemSlot"] = 11,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200163,
								["itemName"] = "Ring of Embers",
							}, -- [4]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200133,
								["itemName"] = "Volcanic Chakram",
							}, -- [5]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [6]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [7]
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [8]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [9]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [10]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200232,
								["itemName"] = "Raptor Talonglaive",
							}, -- [11]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [12]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [13]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [14]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [15]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [16]
						},
						["zone"] = 4,
						["questID"] = "74040",
						["name"] = "Battlehorn Pyrhus",
						["isElite"] = true,
					}, -- [3]
					{
						["Y"] = 30.8,
						["X"] = 13.8,
						["loot"] = {
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [1]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [2]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [3]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200232,
								["itemName"] = "Raptor Talonglaive",
							}, -- [4]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [5]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [6]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [7]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [8]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [9]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [10]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [11]
						},
						["zone"] = 1,
						["questID"] = "73985",
						["name"] = "Blisterhide",
						["isElite"] = true,
					}, -- [4]
					{
						["Y"] = 76,
						["X"] = 26.8,
						["loot"] = {
							{
								["itemSlot"] = 14,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200286,
								["itemName"] = "Dragonbane Lance",
							}, -- [1]
							{
								["itemSlot"] = 1,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200757,
								["itemName"] = "Qalashi War-Helm",
							}, -- [2]
							{
								["itemSlot"] = 13,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200169,
								["itemName"] = "Protector's Molten Cudgel",
							}, -- [3]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194481,
								["itemName"] = "Plans: Obsidian Seared Crusher",
							}, -- [4]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194507,
								["itemName"] = "Plans: Serevite Skeleton Key",
							}, -- [5]
						},
						["zone"] = 4,
						["questID"] = "73075",
						["name"] = "Captain Lancer",
						["isElite"] = true,
					}, -- [5]
					{
						["Y"] = 55.2,
						["X"] = 31,
						["loot"] = {
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194481,
								["itemName"] = "Plans: Obsidian Seared Crusher",
							}, -- [1]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194476,
								["itemName"] = "Plans: Obsidian Seared Hexsword",
							}, -- [2]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194483,
								["itemName"] = "Plans: Obsidian Seared Slicer",
							}, -- [3]
							{
								["itemSlot"] = 13,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200169,
								["itemName"] = "Protector's Molten Cudgel",
							}, -- [4]
							{
								["itemSlot"] = 1,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200757,
								["itemName"] = "Qalashi War-Helm",
							}, -- [5]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200857,
								["itemName"] = "Talisman of Sargha",
							}, -- [6]
						},
						["zone"] = 4,
						["questID"] = "74042",
						["name"] = "Cauldronbearer Blakor",
						["isElite"] = true,
					}, -- [6]
					{
						["Y"] = 48.4,
						["X"] = 29.8,
						["loot"] = {
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200244,
								["itemName"] = "Enchanted Muckstompers",
							}, -- [1]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200683,
								["itemName"] = "Legguards of the Deep Strata",
							}, -- [2]
							{
								["itemSlot"] = 14,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200246,
								["itemName"] = "Lost Delving Lamp",
							}, -- [3]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200198,
								["itemName"] = "Primalist Prison",
							}, -- [4]
							{
								["itemSlot"] = 15,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200439,
								["itemName"] = "Earthpact Scepter",
							}, -- [5]
							{
								["itemSlot"] = 3,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200292,
								["itemName"] = "Cragforge Pauldrons",
							}, -- [6]
							{
								["itemSlot"] = 4,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200313,
								["itemName"] = "Earthen Protoscale Drape",
							}, -- [7]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200293,
								["itemName"] = "Primal Scion's Twinblade",
							}, -- [8]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200199,
								["itemName"] = "Elements' Burden",
							}, -- [9]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200294,
								["itemName"] = "Primal Chain Hauberk",
							}, -- [10]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [11]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 191580,
								["itemName"] = "Recipe: Transmute: Awakened Earth",
							}, -- [12]
						},
						["zone"] = 4,
						["questID"] = "74043",
						["name"] = "Char",
						["isElite"] = true,
					}, -- [7]
					{
						["Y"] = 69,
						["X"] = 44.8,
						["loot"] = {
							{
								["itemSlot"] = 15,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200166,
								["itemName"] = "Corrupted Drake Horn",
							}, -- [1]
							{
								["itemSlot"] = 3,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200292,
								["itemName"] = "Cragforge Pauldrons",
							}, -- [2]
							{
								["itemSlot"] = 4,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200313,
								["itemName"] = "Earthen Protoscale Drape",
							}, -- [3]
							{
								["itemSlot"] = 15,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200439,
								["itemName"] = "Earthpact Scepter",
							}, -- [4]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200199,
								["itemName"] = "Elements' Burden",
							}, -- [5]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200233,
								["itemName"] = "Paradox Saber",
							}, -- [6]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200294,
								["itemName"] = "Primal Chain Hauberk",
							}, -- [7]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200293,
								["itemName"] = "Primal Scion's Twinblade",
							}, -- [8]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200198,
								["itemName"] = "Primalist Prison",
							}, -- [9]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200204,
								["itemName"] = "Sandshine Chestplate",
							}, -- [10]
						},
						["zone"] = 3,
						["questID"] = "74060",
						["name"] = "Corrupted Proto-Dragon",
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 54.4,
						["X"] = 31.8,
						["loot"] = {
							{
								["itemSlot"] = 11,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200159,
								["itemName"] = "Blaze Ring",
							}, -- [1]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									true, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200217,
								["itemName"] = "Blazing Essence",
							}, -- [2]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200252,
								["itemName"] = "Molten Flak Cannon",
							}, -- [3]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200247,
								["itemName"] = "Inextinguishable Gavel",
							}, -- [4]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200133,
								["itemName"] = "Volcanic Chakram",
							}, -- [5]
							{
								["itemSlot"] = 11,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200163,
								["itemName"] = "Ring of Embers",
							}, -- [6]
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [7]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [8]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [9]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [10]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [11]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [12]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [13]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [14]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200232,
								["itemName"] = "Raptor Talonglaive",
							}, -- [15]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [16]
						},
						["zone"] = 1,
						["questID"] = "73074",
						["name"] = "Death's Shadow",
						["isElite"] = false,
					}, -- [9]
					{
						["Y"] = 64.8,
						["X"] = 21.6,
						["loot"] = {
							{
								["itemSlot"] = 13,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200167,
								["itemName"] = "Regurgitated Stone Handaxe",
							}, -- [1]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200133,
								["itemName"] = "Volcanic Chakram",
							}, -- [2]
						},
						["zone"] = 4,
						["questID"] = "73072",
						["name"] = "Enkine the Voracious",
						["isElite"] = true,
					}, -- [10]
					{
						["Y"] = 76.2,
						["X"] = 33,
						["loot"] = {
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200858,
								["itemName"] = "Plume of the Forgotten",
							}, -- [1]
							{
								["itemSlot"] = 15,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200256,
								["itemName"] = "Darkmaul Soul Horn",
							}, -- [2]
							{
								["itemSlot"] = 11,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200158,
								["itemName"] = "Eerie Spectral Ring",
							}, -- [3]
							{
								["itemSlot"] = 4,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200310,
								["itemName"] = "Stole of the Iron Phantom",
							}, -- [4]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [5]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200232,
								["itemName"] = "Raptor Talonglaive",
							}, -- [6]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [7]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [8]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [9]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [10]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [11]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [12]
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [13]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [14]
						},
						["zone"] = 4,
						["questID"] = "73073",
						["name"] = "Forgotten Gryphon",
						["isElite"] = false,
					}, -- [11]
					{
						["Y"] = 37.6,
						["X"] = 14,
						["loot"] = {
							{
								["itemSlot"] = 13,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200259,
								["itemName"] = "Forest Dweller's Shield",
							}, -- [1]
							{
								["itemSlot"] = 7,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200267,
								["itemName"] = "Reinforced Garden Tenders",
							}, -- [2]
						},
						["zone"] = 1,
						["questID"] = "73996",
						["name"] = "Gnarls",
						["isElite"] = true,
					}, -- [12]
					{
						["Y"] = 77.2,
						["X"] = 55.6,
						["loot"] = {
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200880,
								["itemName"] = "Wind-Sealed Mana Capsule",
							}, -- [1]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [2]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [3]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200232,
								["itemName"] = "Raptor Talonglaive",
							}, -- [4]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [5]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [6]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [7]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [8]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [9]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [10]
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [11]
						},
						["zone"] = 3,
						["questID"] = "72814",
						["name"] = "Henlare",
						["isElite"] = false,
					}, -- [13]
					{
						["Y"] = 33.6,
						["X"] = 16.2,
						["loot"] = {
							{
								["itemSlot"] = 9,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200283,
								["itemName"] = "Gnoll-Gnawed Breeches",
							}, -- [1]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200266,
								["itemName"] = "Gnollish Chewtoy Launcher",
							}, -- [2]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200178,
								["itemName"] = "Infected Ichor",
							}, -- [3]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200432,
								["itemName"] = "Rotguard Cowl",
							}, -- [4]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200127,
								["itemName"] = "Gold-Alloy Blade",
							}, -- [5]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194298,
								["itemName"] = "Pattern: Forlorn Funeral Pall",
							}, -- [6]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194312,
								["itemName"] = "Pattern: Gnoll Tent",
							}, -- [7]
						},
						["zone"] = 1,
						["questID"] = "74004",
						["name"] = "High Shaman Rotknuckle",
						["isElite"] = true,
					}, -- [14]
					{
						["Y"] = 52.6,
						["X"] = 32.6,
						["loot"] = {
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200207,
								["itemName"] = "Petrified Fungal Spores",
							}, -- [1]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200244,
								["itemName"] = "Enchanted Muckstompers",
							}, -- [2]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200683,
								["itemName"] = "Legguards of the Deep Strata",
							}, -- [3]
							{
								["itemSlot"] = 14,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200246,
								["itemName"] = "Lost Delving Lamp",
							}, -- [4]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [5]
						},
						["zone"] = 4,
						["questID"] = "74067",
						["name"] = "Morchok",
						["isElite"] = false,
					}, -- [15]
					{
						["Y"] = 59.2,
						["X"] = 28.6,
						["loot"] = {
							{
								["itemSlot"] = 15,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194503,
								["itemName"] = "Plans: Black Dragon Touched Hammer",
							}, -- [1]
							{
								["itemSlot"] = 15,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194508,
								["itemName"] = "Plans: Alvin the Anvil",
							}, -- [2]
							{
								["itemSlot"] = 15,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194483,
								["itemName"] = "Plans: Obsidian Seared Slicer",
							}, -- [3]
							{
								["itemSlot"] = 15,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194481,
								["itemName"] = "Plans: Obsidian Seared Crusher",
							}, -- [4]
							{
								["itemSlot"] = 13,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200169,
								["itemName"] = "Protector's Molten Cudgel",
							}, -- [5]
							{
								["itemSlot"] = 1,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200757,
								["itemName"] = "Qalashi War-Helm",
							}, -- [6]
						},
						["zone"] = 4,
						["questID"] = "74052",
						["name"] = "Rohzor Forgesmash",
						["isElite"] = true,
					}, -- [16]
					{
						["Y"] = 57.6,
						["X"] = 24,
						["loot"] = {
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [1]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [2]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [3]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [4]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [5]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [6]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200232,
								["itemName"] = "Raptor Talonglaive",
							}, -- [7]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [8]
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [9]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [10]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [11]
							{
								["itemSlot"] = 20,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 191784,
								["itemName"] = "Dragon Shard of Knowledge",
							}, -- [12]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 0,
								["itemName"] = "",
							}, -- [13]
						},
						["zone"] = 4,
						["questID"] = "74077",
						["name"] = "Shas'ith",
						["isElite"] = false,
					}, -- [17]
					{
						["Y"] = 32.2,
						["X"] = 11,
						["loot"] = {
							{
								["itemSlot"] = 9,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200283,
								["itemName"] = "Gnoll-Gnawed Breeches",
							}, -- [1]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200266,
								["itemName"] = "Gnollish Chewtoy Launcher",
							}, -- [2]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194298,
								["itemName"] = "Pattern: Forlorn Funeral Pall",
							}, -- [3]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 194312,
								["itemName"] = "Pattern: Gnoll Tent",
							}, -- [4]
						},
						["zone"] = 1,
						["questID"] = "74032",
						["name"] = "Snarglebone",
						["isElite"] = true,
					}, -- [18]
					{
						["Y"] = 34,
						["X"] = 55,
						["loot"] = {
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200211,
								["itemName"] = "Snowman's Icy Gaze",
							}, -- [1]
							{
								["itemSlot"] = 14,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200187,
								["itemName"] = "Rod of Glacial Force",
							}, -- [2]
							{
								["itemSlot"] = 11,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200164,
								["itemName"] = "Iceloop",
							}, -- [3]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200552,
								["itemName"] = "Torrent Caller's Shell",
							}, -- [4]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [5]
						},
						["zone"] = 1,
						["questID"] = "74082",
						["name"] = "Spellwrought Snowman",
						["isElite"] = false,
					}, -- [19]
					{
						["Y"] = 55.6,
						["X"] = 33.6,
						["loot"] = {
							{
								["itemSlot"] = 14,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200246,
								["itemName"] = "Lost Delving Lamp",
							}, -- [1]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200244,
								["itemName"] = "Enchanted Muckstompers",
							}, -- [2]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200683,
								["itemName"] = "Legguards of the Deep Strata",
							}, -- [3]
							{
								["itemSlot"] = 12,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200563,
								["itemName"] = "Primal Ritual Shell",
							}, -- [4]
							{
								["itemSlot"] = 16,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 191580,
								["itemName"] = "Recipe: Transmute: Awakened Earth",
							}, -- [5]
						},
						["zone"] = 4,
						["questID"] = "74054",
						["name"] = "Turboris",
						["isElite"] = true,
					}, -- [20]
					{
						["Y"] = 73,
						["X"] = 46.6,
						["loot"] = {
							{
								["itemSlot"] = 7,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200214,
								["itemName"] = "Grasp of the Weeping Widow",
							}, -- [1]
							{
								["itemSlot"] = 2,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200445,
								["itemName"] = "Lucky Hunting Charm",
							}, -- [2]
							{
								["itemSlot"] = 20,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 191784,
								["itemName"] = "Dragon Shard of Knowledge",
							}, -- [3]
							{
								["itemSlot"] = 10,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									false, -- [4]
									true, -- [5]
									false, -- [6]
									false, -- [7]
									true, -- [8]
									true, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200193,
								["itemName"] = "Manafrond Sandals",
							}, -- [4]
							{
								["itemSlot"] = 12,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200859,
								["itemName"] = "Seasoned Hunter's Trophy",
							}, -- [5]
							{
								["itemSlot"] = 1,
								["class"] = {
									false, -- [1]
									false, -- [2]
									true, -- [3]
									false, -- [4]
									false, -- [5]
									false, -- [6]
									true, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									true, -- [13]
								},
								["itemID"] = 200186,
								["itemName"] = "Amberquill Shroud",
							}, -- [6]
							{
								["itemSlot"] = 5,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200442,
								["itemName"] = "Basilisk Hide Jerkin",
							}, -- [7]
							{
								["itemSlot"] = 13,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200131,
								["itemName"] = "Reclaimed Survivalist's Dagger",
							}, -- [8]
							{
								["itemSlot"] = 3,
								["class"] = {
									false, -- [1]
									false, -- [2]
									false, -- [3]
									true, -- [4]
									false, -- [5]
									false, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									false, -- [13]
								},
								["itemID"] = 200174,
								["itemName"] = "Bonesigil Shoulderguards",
							}, -- [9]
							{
								["itemSlot"] = 17,
								["class"] = {
									true, -- [1]
									true, -- [2]
									true, -- [3]
									true, -- [4]
									true, -- [5]
									true, -- [6]
									true, -- [7]
									true, -- [8]
									true, -- [9]
									true, -- [10]
									true, -- [11]
									true, -- [12]
									true, -- [13]
								},
								["itemID"] = 200249,
								["itemName"] = "Mage's Chewed Wand",
							}, -- [10]
							{
								["itemSlot"] = 9,
								["class"] = {
									true, -- [1]
									true, -- [2]
									false, -- [3]
									false, -- [4]
									false, -- [5]
									true, -- [6]
									false, -- [7]
									false, -- [8]
									false, -- [9]
									false, -- [10]
									false, -- [11]
									false, -- [12]
									false, -- [13]
								},
								["itemID"] = 200195,
								["itemName"] = "Thunderscale Legguards",
							}, -- [11]
						},
						["zone"] = 3,
						["questID"] = "74086",
						["name"] = "The Weeping Vilomah",
						["isElite"] = false,
					}, -- [21]
				},
			},
			["startAngle"] = 0,
			["backgroundColor"] = {
				0.58431375026703, -- [1]
				0.58431375026703, -- [2]
				0.58431375026703, -- [3]
				0.75, -- [4]
			},
			["semver"] = "4.99.2",
			["displayText_format_p_format"] = "timed",
			["id"] = "Rares Bar",
			["desc"] = "green text = unkilled and in same zone\nred text = killed \nwhite text  not in same zone and not killed",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["anchorPoint"] = "CENTER",
			["inverse"] = false,
			["icon"] = true,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["parent"] = "Rares Packs",
		},
		["Alchemy"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Alchemy  one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "track profession",
					["key"] = "TALC",
					["useDesc"] = true,
					["name"] = "Track Alchemy",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Alchemy Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0.76470595598221, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "0uz24Z0oHIh",
			["displayIcon"] = 4620669,
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "alc module",
			["barColor2"] = {
				0.40000003576279, -- [1]
				0, -- [2]
				0.52156865596771, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620669,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TALC then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 2259,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Alchemy",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				0.76470595598221, -- [1]
				0, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["Utt"] = true,
				["TALC"] = true,
				["rares"] = {
					{
						["Y"] = 75.84,
						["X"] = 60.92,
						["name"] = "Profession Master Grigori Vialtry",
						["zone"] = 1,
						["hiddenQuestId"] = "70247",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 81,
						["X"] = 55,
						["name"] = "Frostforged Potion",
						["zone"] = 1,
						["hiddenQuestId"] = "70274",
						["drops"] = "198663",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [2]
					{
						["Y"] = 73.3,
						["X"] = 25.1,
						["name"] = "Well Insulated Mug",
						["zone"] = 1,
						["hiddenQuestId"] = "70289",
						["drops"] = "198685",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 83.8,
						["X"] = 79.2,
						["name"] = "Canteen of Suspicious Water",
						["zone"] = 2,
						["hiddenQuestId"] = "70305",
						["drops"] = "198710",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 38.5,
						["X"] = 16.4,
						["name"] = "Experimental Decay Sample",
						["zone"] = 3,
						["hiddenQuestId"] = "70208",
						["drops"] = "198599",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 13.2,
						["X"] = 67,
						["name"] = "Firewater Powder Sample",
						["zone"] = 3,
						["hiddenQuestId"] = "70309",
						["drops"] = "198712",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 30.5,
						["X"] = 55.2,
						["name"] = "Furry Gloop",
						["zone"] = 4,
						["hiddenQuestId"] = "70278",
						["drops"] = "201003",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 38.4,
						["X"] = 59.5,
						["name"] = "Contraband Concoction",
						["zone"] = 4,
						["hiddenQuestId"] = "70301",
						["drops"] = "198697",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Alchemy",
						["zone"] = 5,
						["hiddenQuestId"] = "74108",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [9]
				},
				["hideCompleted"] = true,
				["onlyElites"] = true,
			},
		},
		["Reps Pack"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"spacer", -- [1]
				"Dragonscale Expedition", -- [2]
				"Maruuk Centaur", -- [3]
				"Valdrakken Accord", -- [4]
				"Iskaara Tuskarr", -- [5]
				"Sabellion", -- [6]
				"Wrathion", -- [7]
				"Cobalt Assembly", -- [8]
				"Artisans Consort", -- [9]
				"Community Feast timer bar", -- [10]
				"Dragonbane Keep timer bar", -- [11]
				"sp3", -- [12]
			},
			["borderBackdrop"] = "ElvUI Blank",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Weekly/Daily Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 656543,
			["anchorPoint"] = "CENTER",
			["fullCircle"] = true,
			["space"] = 2,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.88000000268221, -- [4]
			},
			["uid"] = "xK8vR4nepx0",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:sp1",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 2,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Reps Pack",
			["borderEdge"] = "RothSquare",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = true,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Dragonscale Expedition"] = false,
				["Dragonbane Keep timer bar"] = false,
				["spacer"] = false,
				["Iskaara Tuskarr"] = false,
				["Sabellion"] = false,
				["Community Feast timer bar"] = false,
				["Valdrakken Accord"] = false,
				["Wrathion"] = false,
				["Artisans Consort"] = false,
				["sp3"] = false,
				["Cobalt Assembly"] = false,
				["Maruuk Centaur"] = false,
			},
		},
		["Herbalism"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Herbalism one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "THER",
					["useDesc"] = true,
					["name"] = "Track Herbalisum",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Herbalism Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0, -- [1]
				1, -- [2]
				0.34901961684227, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "mMDFLoBqQmv",
			["displayIcon"] = "4624731",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Herb Module",
			["barColor2"] = {
				0, -- [1]
				0.4627451300621, -- [2]
				0.69803923368454, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4624731,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.THER then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 2366,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Herbalism",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				0, -- [1]
				1, -- [2]
				0.35294118523598, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["Utt"] = true,
				["THER"] = true,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on herbalism",
						["zone"] = 5,
						["hiddenQuestId"] = "74107",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 50.04,
						["X"] = 58.42,
						["name"] = "Profession master  Hua Greenpaw",
						["zone"] = 2,
						["hiddenQuestId"] = "70253",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
				},
				["hideCompleted"] = true,
				["onlyElites"] = false,
			},
		},
		["IscAB 7"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "IscAB 7",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "8dBzseCKi2H",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Isc Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["spacer"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "",
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "CENTER",
			["desaturate"] = true,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["frameStrata"] = 1,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["xOffset"] = 0,
			["rotation"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "spacer",
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.086274512112141, -- [3]
				0, -- [4]
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "Reps Pack",
			["uid"] = "QbFjSYiTA7W",
			["width"] = 280,
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Iskaara Tuskarr"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Reps Pack",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["use_standingId"] = false,
						["spellIds"] = {
						},
						["factionID"] = 2511,
						["use_unit"] = true,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.ITSH then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["iconSource"] = -1,
			["barColor"] = {
				0, -- [1]
				0.66666668653488, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 4687629,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 110,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["gradientOrientation"] = "HORIZONTAL",
			["internalVersion"] = 64,
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["selfPoint"] = "CENTER",
			["source"] = "import",
			["uid"] = "GOhHXBY(goh",
			["config"] = {
				["Rep"] = {
					["ITSH"] = false,
				},
			},
			["xOffset"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["alpha"] = 1,
			["height"] = 16,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["spark"] = false,
			["zoom"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Iskaara Tuskarr",
			["backgroundColor"] = {
				0.58431375026703, -- [1]
				0.58431375026703, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["version"] = 80,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFF02ff00enabled|r)",
							["key"] = "ITSH",
							["useDesc"] = true,
							["name"] = "|cFF00ffffIskaara Tuskarr Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = false,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.ITSH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
		},
		["EngAB"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "EngAB",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "AdfOHZVrhv7",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Eng Module ",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["JC Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Jewelcrafting", -- [1]
				"JCAB ", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620677,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "oQzl496bnKO",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Isc Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "JC Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Jewelcrafting"] = false,
				["JCAB "] = false,
			},
		},
		["Tai Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Tailoring", -- [1]
				"TiaAB", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620681,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 6.103515625e-05,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "9kBYxoWh2CL",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Sk Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Tai Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Tailoring"] = false,
				["TiaAB"] = false,
			},
		},
		["Wrathion"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["wagoID"] = "9MpDLGWp3",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["backgroundColor"] = {
				0.74509805440903, -- [1]
				0.44313728809357, -- [2]
				0.14901961386204, -- [3]
				0.75, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["use_standingId"] = false,
						["spellIds"] = {
						},
						["use_friendshipRank"] = false,
						["factionID"] = 2517,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.Wrath then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 64,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFFff0000disabled|r)",
							["key"] = "Wrath",
							["useDesc"] = true,
							["name"] = "|cFFffaa11Wrathion Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = false,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["barColor"] = {
				0.74509805440903, -- [1]
				0.44705885648727, -- [2]
				0.14901961386204, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 1394891,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 110,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["height"] = 16,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.Wrath",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["sparkOffsetY"] = 0,
			["source"] = "import",
			["gradientOrientation"] = "HORIZONTAL",
			["uid"] = "Gi2zSDSP6XH",
			["sparkOffsetX"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["frameStrata"] = 1,
			["icon"] = true,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["semver"] = "4.99.2",
			["zoom"] = 0,
			["spark"] = false,
			["tocversion"] = 100002,
			["id"] = "Wrathion",
			["config"] = {
				["Rep"] = {
					["Wrath"] = false,
				},
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["enableGradient"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["parent"] = "Reps Pack",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				1, -- [1]
				0.60000002384186, -- [2]
				0.20000001788139, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Herb Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Herbalism", -- [1]
				"Herb LCAB", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4624731,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = ")LiyZFbM4a6",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Eng Module ",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Herb Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Herbalism"] = false,
				["Herb LCAB"] = false,
			},
		},
		["LWAB 5"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "LWAB 5",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "eA9vkWdQoRj",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "LW Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Isc Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Inscription", -- [1]
				"IscAB 7", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620676,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "2BmROBnLOzX",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Herb Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Isc Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Inscription"] = false,
				["IscAB 7"] = false,
			},
		},
		["sp3"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "",
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "CENTER",
			["desaturate"] = true,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["frameStrata"] = 1,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["xOffset"] = 0,
			["rotation"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "sp3",
			["color"] = {
				1, -- [1]
				0, -- [2]
				0.086274512112141, -- [3]
				0, -- [4]
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["parent"] = "Reps Pack",
			["uid"] = "g0USqnwceJp",
			["width"] = 280,
			["config"] = {
			},
			["conditions"] = {
			},
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Herb LCAB"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["use_size"] = false,
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_never"] = false,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_ingroup"] = false,
				["use_petbattle"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Herb LCAB",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "j(lB63)DHCR",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Herb Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Blacksmithing"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Blacksmithing  one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "track profession",
					["key"] = "TBS",
					["useDesc"] = true,
					["name"] = "Track Blacksmithing",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = " show only master and treatise",
					["key"] = "onlyElites",
					["useDesc"] = true,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "master or treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Blacksmithing Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0.78823536634445, -- [1]
				0.55686277151108, -- [2]
				0.39215689897537, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "ce7abi1P6rE",
			["displayIcon"] = "4620670",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "BS Module",
			["barColor2"] = {
				0.39607846736908, -- [1]
				0.28235295414925, -- [2]
				0.19607844948769, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620670,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TBS then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 2018,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Blacksmithing",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				0.78823536634445, -- [1]
				0.55686277151108, -- [2]
				0.39215689897537, -- [3]
				0.75, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["Utt"] = true,
				["rares"] = {
					{
						["Y"] = 66.6,
						["X"] = 43.32,
						["name"] = "Master Grekka Anvilsmash",
						["zone"] = 1,
						["hiddenQuestId"] = "70250",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 19.5,
						["X"] = 56.4,
						["name"] = "Glimmer of Blacksmithing Wisdom",
						["zone"] = 1,
						["hiddenQuestId"] = "70230",
						["drops"] = "198791",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [2]
					{
						["Y"] = 87,
						["X"] = 22,
						["name"] = "Ancient Monument",
						["zone"] = 1,
						["hiddenQuestId"] = "70246",
						["drops"] = "201007",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 25.7,
						["X"] = 65.5,
						["name"] = "Curious Ingots",
						["zone"] = 1,
						["hiddenQuestId"] = "70312",
						["drops"] = "201005",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 64.3,
						["X"] = 35.5,
						["name"] = "Molten Ingot",
						["zone"] = 1,
						["hiddenQuestId"] = "70296",
						["drops"] = "201008",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 67.1,
						["X"] = 34.5,
						["name"] = "Qalashi Weapon Diagram",
						["zone"] = 1,
						["hiddenQuestId"] = "70310",
						["drops"] = "201010",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 37.9,
						["X"] = 81.10000000000001,
						["name"] = "Ancient Spear Shards",
						["zone"] = 2,
						["hiddenQuestId"] = "70313",
						["drops"] = "201004",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 66.5,
						["X"] = 50.9,
						["name"] = "Falconer Gauntlet Drawings",
						["zone"] = 2,
						["hiddenQuestId"] = "70353",
						["drops"] = "201009",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 65.3,
						["X"] = 53.1,
						["name"] = "Spelltouched Tongs",
						["zone"] = 3,
						["hiddenQuestId"] = "70314",
						["drops"] = "201011",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [9]
					{
						["Y"] = 80.5,
						["X"] = 52.2,
						["name"] = "Draconic Flux",
						["zone"] = 4,
						["hiddenQuestId"] = "70311",
						["drops"] = "201006",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [10]
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise of Blacksmithing",
						["zone"] = 5,
						["hiddenQuestId"] = "74109",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [11]
				},
				["TBS"] = true,
				["hideCompleted"] = true,
				["onlyElites"] = false,
			},
		},
		["Skinning"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "Enable Tomtom Intergration if installed",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [1]
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Skiinging one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "TSK",
					["useDesc"] = true,
					["name"] = "Track Skinning",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Skinning Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				0.53333336114883, -- [1]
				0.26666668057442, -- [2]
				0.13333334028721, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "gSlU9dFYmEl",
			["displayIcon"] = "4625106",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Sk Module",
			["barColor2"] = {
				0.53333336114883, -- [1]
				0.26666668057442, -- [2]
				0.13333334028721, -- [3]
				0.75, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4625106,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TSK then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 366259,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Skinning",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				0.53333336114883, -- [1]
				0.26666668057442, -- [2]
				0.13333334028721, -- [3]
				0.5, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["onlyElites"] = false,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Skinning",
						["zone"] = 5,
						["hiddenQuestId"] = "74114",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 69.72,
						["X"] = 73.34,
						["name"] = "Prefession master Zenzi",
						["zone"] = 1,
						["hiddenQuestId"] = "70259",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
				},
				["TSK"] = true,
				["hideCompleted"] = true,
				["Utt"] = true,
			},
		},
		["BSAB"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "BSAB",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "SZnPCV7qwLT",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "BS Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["alc module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Alchemy", -- [1]
				"ALCAB", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620669,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "zpZQkZ17Hw8",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Profession Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "alc module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Alchemy"] = false,
				["ALCAB"] = false,
			},
		},
		["Tama's Dragonflight helper"] = {
			["controlledChildren"] = {
				"User guide (Note shown) Work in progress", -- [1]
				"Weekly/Daily Module", -- [2]
				"Profession Module", -- [3]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = -126.8403930664063,
			["anchorPoint"] = "LEFT",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["desc"] = "Thanks for using Tama's Dragonflight helper\nif your haveing issue please let me know on https://wago.io/TamasDragonflightHelperand ill do me best to answer your question",
			["version"] = 80,
			["subRegions"] = {
			},
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["source"] = "import",
			["scale"] = 1,
			["border"] = false,
			["borderEdge"] = "Square Full White",
			["regionType"] = "group",
			["borderSize"] = 2,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Tama's Dragonflight helper",
			["uid"] = "9)4LLvW7W(G",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "CENTER",
			["borderInset"] = 1,
			["config"] = {
			},
			["groupIcon"] = "4532349",
			["conditions"] = {
			},
			["information"] = {
			},
			["xOffset"] = -6.875556468963623,
		},
		["Notice"] = {
			["outline"] = "OUTLINE",
			["displayText_format_text_format"] = "none",
			["wagoID"] = "9MpDLGWp3",
			["xOffset"] = 0,
			["displayText"] = "%c",
			["customText"] = "function()\n  local text =\"|cff00ffaaUser Guide/set up|r. \\n\\n|cffffffffPlease note this is note displayed when you close the main weak auras window config window|r\\n\\n\"\n  text = text..\"|cffff0066Update 4.99|r\\n\\n\"\n  text = text..\"|cffff0000I've had to split the Weak aura in to indivduial modules everything is still there but this Weak had exceeded 50k import|r\\n\\n\"\n  ---- Weekly/Daily Module info----\n  text = text..\"|cff0055FFWeekly/Daily Module|r |cff00ff55(Inluded)|r\\nBase module that started it all tracks renown/rares and general weekly todo items\\n\\n\"\n  \n  text = text..\"|cff0055FFProfession Module|r |cff00ff55(Inluded)|r\\nThis module includes all your crafting one time treasures (bars) & the weekly collectables\\n\\n\"\n  ---- Primals Module info----\n  text = text..\"|cff0055FfAll other module Module are now|r |cffff0066Seperate downloads|r\\n\"\n  \n  text = text..\"|cffffaa00Groups list as \\\"<name> Module\\\" can be moved independantly of each other. the items within the Modules are linked and should not be moved/changed.\\n\\n\"\n  text = text..\"if you wish to edit or modify the code you are free todo so however im unable to support these modifications\\n\\n\"\n  text = text..\"please do not delete elements if you dont wish to use a module click on it then go to custom options and set to off (you can also use the never load condiation should you to too)|r\\n\\n\"\n  \n  \n  return text\nend",
			["shadowYOffset"] = -1,
			["anchorPoint"] = "TOPLEFT",
			["displayText_format_p_time_format"] = 0,
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.update_display = function()\n  aura_env.text = \"\"\n  local text = \"\"\n  ---todo list items update---\n  text = text .. \"test\"\n  text = text .. aura_env.update_overview_display() .. '\\r' --append todo list items\n  return text\nend\n\n\n",
					["do_custom"] = false,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_alwaystrue"] = true,
						["use_absorbMode"] = true,
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["custom_type"] = "status",
						["event"] = "Conditions",
						["custom_hide"] = "timed",
						["subeventSuffix"] = "_CAST_START",
						["spellIds"] = {
						},
						["events"] = "CHAT_MSG_LOOT,PARTY_KILL,BAG_UPDATE,QUEST_COMPLETE,QUEST_AUTOCOMPLETE,WORLD_QUEST_COMPLETED_BY_SPELL,UPDATE_FACTION,QUEST_LOG_UPDATE,ENCOUNTER_LOOT_RECEIVED,QUEST_TURNED_IN,QUEST_LOG_UPDATE",
						["subeventPrefix"] = "SPELL",
						["check"] = "event",
						["names"] = {
						},
						["use_unit"] = true,
						["dynamicDuration"] = false,
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["displayText_format_p_format"] = "timed",
			["displayText_format_p_time_legacy_floor"] = false,
			["wordWrap"] = "WordWrap",
			["desc"] = "--code is a modified version of Korthia Checklist https://wago.io/cyRj6ikQz by Dorovon#1260 for the original todo lists in korthia",
			["font"] = "Expressway",
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["anchorFrameParent"] = false,
			["load"] = {
				["use_ingroup"] = false,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["yOffset"] = 0,
			["fontSize"] = 12,
			["source"] = "import",
			["useTooltip"] = true,
			["shadowXOffset"] = 1,
			["conditions"] = {
			},
			["preferToUpdate"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps Pack",
			["regionType"] = "text",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["uid"] = "swLJrg5OWKt",
			["internalVersion"] = 64,
			["displayText_format_p_time_precision"] = 1,
			["parent"] = "User guide (Note shown) Work in progress",
			["selfPoint"] = "BOTTOMLEFT",
			["justify"] = "LEFT",
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Notice",
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "option",
					["useDesc"] = false,
					["name"] = "Option 1",
					["width"] = 1,
				}, -- [1]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["config"] = {
				["option"] = false,
			},
			["automaticWidth"] = "Fixed",
			["displayText_format_p_time_mod_rate"] = true,
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 400,
			["information"] = {
				["forceEvents"] = true,
			},
			["displayText_format_c_format"] = "none",
		},
		["MIAB 8"] = {
			["wagoID"] = "9MpDLGWp3",
			["authorOptions"] = {
			},
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "TOPRIGHT",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.PRH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["custom_hide"] = "timed",
						["type"] = "unit",
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["use_absorbMode"] = true,
						["event"] = "Conditions",
						["unit"] = "player",
						["use_alwaystrue"] = true,
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "START",
						["check"] = "event",
						["custom_type"] = "status",
						["use_unit"] = true,
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["selfPoint"] = "BOTTOMLEFT",
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
			},
			["height"] = 1,
			["rotate"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["source"] = "import",
			["mirror"] = false,
			["anchorFrameFrame"] = "WeakAuras:Reps and timer tracking",
			["regionType"] = "texture",
			["blendMode"] = "BLEND",
			["width"] = 250,
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["xOffset"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "MIAB 8",
			["frameStrata"] = 1,
			["alpha"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["uid"] = "Wi5hM5EG4yr",
			["config"] = {
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["parent"] = "Minning Module",
			["conditions"] = {
			},
			["information"] = {
				["ignoreOptionsEventErrors"] = true,
			},
			["rotation"] = 0,
		},
		["Minning Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Minning", -- [1]
				"MIAB 8", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4625105,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "1GfbB8Dh9oT",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:LW Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Minning Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["MIAB 8"] = false,
				["Minning"] = false,
			},
		},
		["Community Feast timer bar"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				0, -- [1]
				0.90196084976196, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_encounter"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_ingroup"] = false,
				["use_size"] = false,
				["use_never"] = false,
				["use_petbattle"] = false,
				["use_alive"] = true,
				["use_zoneIds"] = true,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["texture"] = "WorldState Score",
			["cooldownTextDisabled"] = true,
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["uid"] = "(UetWgTP1Ig",
			["displayIcon"] = "4687629",
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Reps Pack",
			["cooldownSwipe"] = false,
			["sparkRotationMode"] = "AUTO",
			["cooldownEdge"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["use_alwaystrue"] = true,
						["use_absorbMode"] = true,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["use_absorbHealMode"] = true,
						["custom_type"] = "stateupdate",
						["event"] = "Conditions",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["events"] = "DRAGONFLIGHT_EVENT_TRACKER,START",
						["custom"] = "function(allstates, event, id)\n  \n  \n  if not aura_env.config.Feast then \n    return false \n  end\n  if aura_env.config.hideComplete and aura_env.isComplete() then \n    return    false \n  end\n  \n  if event == \"DRAGONFLIGHT_EVENT_TRACKER\" and id == aura_env.id or event == \"STATUS\" or event == \"OPTIONS\" then\n    local regionTimers = {\n      [1] = 1670335260, -- NA\n      [2] = 1670704260, -- KR\n      [3] = 1670333460, -- EU\n      [4] = 1670704260, -- TW\n      [5] = 1670679060 } -- CN\n    \n    \n    local settime1 = regionTimers[GetCurrentRegion()]\n    \n    local resettimer = 210 --aura_env.config.fbre -- need to finish adding this varibles in custom  options\n    local Rtime = resettimer * 60 -- multiply mins by secs and assign total secs\n    local interval = Rtime\n    \n    local ActiveDrutation = 15 --aura_env.config.sdur  -- need to finish adding this varibles in custom  options\n    local Atime = ActiveDrutation *60 -- multiply mins by secs and assign total secs\n    local duration = Atime\n    \n    \n    local Offsetmins = aura_env.config.fOffsetammout -- get off set amount in mins\n    local Otime = Offsetmins * 60-- multiply mins by secs and assign total secs\n    local offset = Otime\n    \n    settime1 = aura_env.config.feastoffset and settime1+offset or settime1\n    \n    local TtNK = interval - ((GetServerTime() - settime1) % interval)\n    \n    local active = interval - TtNK < duration\n    local remaining = duration - (interval - TtNK)\n    \n    allstates[\"\"] = {\n      changed = true,\n      show = true,\n      progressType = \"timed\",\n      autoHide = true,\n      duration = active and duration or interval-duration,\n      expirationTime = GetTime() + (active and remaining or TtNK),\n      icon = 4687629,\n      active = active\n    }\n    return true\n  end\nend",
						["spellIds"] = {
						},
						["check"] = "event",
						["use_unit"] = true,
						["unit"] = "player",
						["customVariables"] = "{\n    active = {\n        display = \"tTigger\",\n        type = \"bool\",\n    }\n}",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "player",
						["names"] = {
						},
						["custom"] = "function()\n    if aura_env.config.Feast then\n        return true\n    end \nend",
						["events"] = "START",
						["subeventPrefix"] = "SPELL",
						["check"] = "event",
						["custom_type"] = "status",
						["spellIds"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 64,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subforeground",
				}, -- [1]
				{
					["type"] = "subbackground",
				}, -- [2]
				{
					["text_text_format_p_time_format"] = 2,
					["text_text"] = "%p",
					["text_text_format_p_gcd_cast"] = false,
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_1.formattedTime_format"] = "none",
					["rotateText"] = "NONE",
					["text_text_format_p_decimal_precision"] = 1,
					["text_text_format_p_gcd_gcd"] = true,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_text_format_p_gcd_channel"] = false,
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_p_gcd_hide_zero"] = false,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_p_time_mod_rate"] = true,
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["type"] = "subtext",
					["text_anchorXOffset"] = -10,
					["text_font"] = "Expressway",
					["text_anchorYOffset"] = 0,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_text_format_p_big_number_format"] = "AbbreviateNumbers",
					["text_text_format_p_format"] = "timed",
					["text_shadowXOffset"] = 1,
				}, -- [3]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "Feast in",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["text_text_format_p_format"] = "timed",
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_p_time_precision"] = 1,
					["type"] = "subtext",
					["text_text_format_p_time_mod_rate"] = true,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_text_format_p_time_format"] = 0,
					["text_shadowYOffset"] = -1,
					["text_visible"] = true,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_anchorYOffset"] = 0,
					["anchorYOffset"] = 0,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_text_format_n_format"] = "none",
				}, -- [4]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "Active",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = false,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [5]
			},
			["height"] = 17,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["source"] = "import",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["barColor2"] = {
				0.55686277151108, -- [1]
				0.92941182851791, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["icon_side"] = "LEFT",
			["zoom"] = 0.3,
			["information"] = {
			},
			["sparkHeight"] = 30,
			["backgroundColor"] = {
				0.58431375026703, -- [1]
				0.58431375026703, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["desc"] = "code sampled and edited from the original WA by putro https://wago.io/fTuRJ__jk\n\n",
			["config"] = {
				["feastoffset"] = false,
				["hideComplete"] = false,
				["Feast"] = true,
				["fOffsetammout"] = 1,
			},
			["semver"] = "4.99.2",
			["width"] = 280,
			["id"] = "Community Feast timer bar",
			["useCooldownModRate"] = true,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["sparkHidden"] = "NEVER",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Event timer",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "If Enabled will display the Dragonbane Feast timer |n(default: |cFF02ff00enabled|r)",
					["key"] = "Feast",
					["useDesc"] = true,
					["name"] = "|cFF00ffffFeast timer|r",
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "If enabled, will hide feast if marked as completed |n(default: |cFF02ff00enabled|r)",
					["key"] = "hideComplete",
					["useDesc"] = true,
					["name"] = "|cFF00ffffHide Complete|r",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["desc"] = "If enabled, will use the off setto assist in correcting the time|n(default: |cFFff0000disabled|r)",
					["key"] = "feastoffset",
					["useDesc"] = true,
					["name"] = "|cFF00aaaaUse off-set|r",
					["width"] = 1,
				}, -- [4]
				{
					["softMin"] = 1,
					["type"] = "range",
					["bigStep"] = 1,
					["max"] = 720,
					["step"] = 0.5,
					["width"] = 1,
					["min"] = 1,
					["key"] = "fOffsetammout",
					["desc"] = "Off set ammount in Minutes",
					["softMax"] = 720,
					["useDesc"] = true,
					["name"] = "|cFF00aaaaSet Event Offset (in minutes)|r",
					["default"] = 1,
				}, -- [5]
			},
			["inverse"] = true,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "-- Default Locale --\naura_env.defaultLocale = 'enUS'\n-- User Locale Var--\naura_env.userLocale = GetLocale()\n-- Get Text sinppet --\naura_env.get_text_snippet = function(name)\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.userLocale] then\n    return aura_env.textSnippets[name][aura_env.userLocale]\n  end\n  if aura_env.textSnippets[name] and aura_env.textSnippets[name][aura_env.defaultLocale] then\n    return aura_env.textSnippets[name][aura_env.defaultLocale]\n  end\n  return name\nend\n\nfunction aura_env.isComplete()\n  if C_QuestLog.IsQuestFlaggedCompleted(70893) then\n    return true\n  end\n  \n  return false\nend",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "C_Timer.After(0, function() WeakAuras.ScanEvents(\"DRAGONFLIGHT_EVENT_TRACKER\", aura_env.id) end)",
					["do_custom"] = true,
				},
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "<=",
						["variable"] = "active",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
						{
							["property"] = "sub.4.text_visible",
						}, -- [2]
						{
							["value"] = true,
							["property"] = "sub.5.text_visible",
						}, -- [3]
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.5.text_color",
						}, -- [4]
					},
				}, -- [1]
			},
			["cooldown"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
		},
		["Cobalt Assembly"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["wagoID"] = "9MpDLGWp3",
			["xOffset"] = 0,
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["backgroundColor"] = {
				0.40392160415649, -- [1]
				0.37254902720451, -- [2]
				1, -- [3]
				0.75, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_unit"] = true,
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["use_standingId"] = false,
						["spellIds"] = {
						},
						["use_friendshipRank"] = false,
						["factionID"] = 2550,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.CA then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["internalVersion"] = 64,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = false,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFFff0000disabled|r)",
							["key"] = "CA",
							["useDesc"] = true,
							["name"] = "|cFF0055ffCobalt Assembly Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = false,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["barColor"] = {
				0, -- [1]
				0.27843138575554, -- [2]
				0.67058825492859, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 237031,
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 110,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["height"] = 16,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.CA",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["sparkOffsetY"] = 0,
			["source"] = "import",
			["gradientOrientation"] = "HORIZONTAL",
			["uid"] = "s5VrlWXAoaG",
			["sparkOffsetX"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["frameStrata"] = 1,
			["icon"] = true,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["semver"] = "4.99.2",
			["zoom"] = 0,
			["spark"] = false,
			["tocversion"] = 100002,
			["id"] = "Cobalt Assembly",
			["config"] = {
				["Rep"] = {
					["CA"] = false,
				},
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["enableGradient"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["parent"] = "Reps Pack",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				0, -- [1]
				0.41568630933762, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
		},
		["Valdrakken Accord"] = {
			["sparkWidth"] = 10,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Reps Pack",
			["preferToUpdate"] = false,
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["sparkRotationMode"] = "AUTO",
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["use_factionID"] = true,
						["use_absorbHealMode"] = true,
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["event"] = "Faction Reputation",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["factionID"] = 2510,
						["use_unit"] = true,
						["type"] = "unit",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["custom_hide"] = "timed",
						["event"] = "Chat Message",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["custom"] = "function()\n    if aura_env.config.Rep.VASH then\n        return true\n    end \nend\n\n\n\n",
						["events"] = "START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend\n",
				["activeTriggerMode"] = -10,
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["enableGradient"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["iconSource"] = -1,
			["barColor"] = {
				0, -- [1]
				1, -- [2]
				0.66666668653488, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["information"] = {
				["forceEvents"] = true,
				["ignoreOptionsEventErrors"] = true,
			},
			["displayIcon"] = 4687630,
			["sparkOffsetY"] = 0,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = "%p - %1.standing",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_fixedWidth"] = 64,
					["text_text_format_p_time_legacy_floor"] = false,
					["rotateText"] = "NONE",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "WordWrap",
					["text_visible"] = true,
					["text_text_format_1.standing_format"] = "none",
					["text_text_format_t_time_dynamic_threshold"] = 60,
					["text_text_format_p_format"] = "timed",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_text_format_t_time_format"] = 0,
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_text_format_t_format"] = "timed",
					["type"] = "subtext",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 12,
					["text_font"] = "Expressway",
					["text_text_format_p_time_precision"] = 1,
					["text_text_format_p_time_dynamic_threshold"] = 60,
					["text_text_format_t_time_legacy_floor"] = false,
					["text_text_format_p_time_format"] = 0,
					["text_text_format_t_time_mod_rate"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["text_text_format_t_time_precision"] = 1,
					["text_text_format_1.standingId_format"] = "none",
					["text_text_format_1.standingid_format"] = "none",
					["text_text_format_p_time_mod_rate"] = true,
					["text_fontType"] = "None",
				}, -- [3]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%n",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Fixed",
					["text_fixedWidth"] = 110,
					["anchorYOffset"] = 0,
					["text_justify"] = "RIGHT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = -1,
					["text_wordWrap"] = "Elide",
					["text_fontType"] = "None",
					["text_anchorPoint"] = "INNER_RIGHT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 1,
				}, -- [4]
			},
			["gradientOrientation"] = "HORIZONTAL",
			["internalVersion"] = 64,
			["load"] = {
				["use_size"] = false,
				["use_never"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["use_ingroup"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["use_petbattle"] = false,
				["use_zoneIds"] = true,
				["use_alive"] = true,
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["selfPoint"] = "CENTER",
			["source"] = "import",
			["uid"] = "WRgRSZHAP3e",
			["config"] = {
				["Rep"] = {
					["VASH"] = false,
				},
			},
			["xOffset"] = 0,
			["width"] = 280,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["alpha"] = 1,
			["height"] = 16,
			["icon_side"] = "LEFT",
			["sparkHidden"] = "NEVER",
			["sparkHeight"] = 30,
			["texture"] = "WorldState Score",
			["spark"] = false,
			["zoom"] = 0,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Valdrakken Accord",
			["backgroundColor"] = {
				0.58431375026703, -- [1]
				1, -- [2]
				0.58431375026703, -- [3]
				0.75, -- [4]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["version"] = 80,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Reps",
					["noMerge"] = false,
					["width"] = 1,
				}, -- [1]
				{
					["subOptions"] = {
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "If Enabled will display reputation tracking|n(default: |cFF02ff00enabled|r)",
							["key"] = "VASH",
							["useDesc"] = true,
							["name"] = "|cFF00ff55Valdrakken Accord Rep Bar|r",
							["width"] = 1,
						}, -- [1]
					},
					["hideReorder"] = true,
					["useDesc"] = false,
					["nameSource"] = 0,
					["collapse"] = false,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "|cFF00ffaaRep bar module|r",
					["key"] = "Rep",
					["limitType"] = "none",
					["groupType"] = "simple",
					["type"] = "group",
					["size"] = 10,
				}, -- [2]
			},
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["barColor2"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.Rep.VASH",
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
		},
		["Leatherworking"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Leatherworking  one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "TLW",
					["useDesc"] = true,
					["name"] = "Track Leatherworking",
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Leatherworking Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				1, -- [1]
				0.66666668653488, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "sRNZFqhwCAz",
			["displayIcon"] = "4620678",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "LW Module",
			["barColor2"] = {
				0, -- [1]
				0.4627451300621, -- [2]
				0.69803923368454, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4620678,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TLW then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 2108,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Leatherworking",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				1, -- [1]
				0.66666668653488, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["onlyElites"] = false,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Leatherworking",
						["zone"] = 5,
						["hiddenQuestId"] = "74113",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 50.67,
						["X"] = 82.45,
						["name"] = "Profession Master Erden",
						["zone"] = 2,
						["hiddenQuestId"] = "70256",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
					{
						["Y"] = 86,
						["X"] = 39,
						["name"] = "Poacher's Pack",
						["zone"] = 1,
						["hiddenQuestId"] = "70308",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [3]
					{
						["Y"] = 25.4,
						["X"] = 64.3,
						["name"] = "Spare Djaradin Tools",
						["zone"] = 1,
						["hiddenQuestId"] = "70280",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [4]
					{
						["Y"] = 53.7,
						["X"] = 86.4,
						["name"] = "Wind-Blessed Hide",
						["zone"] = 2,
						["hiddenQuestId"] = "70300",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [5]
					{
						["Y"] = 49.4,
						["X"] = 12.5,
						["name"] = "Well-Danced Drum",
						["zone"] = 3,
						["hiddenQuestId"] = "70269",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [6]
					{
						["Y"] = 38.8,
						["X"] = 16.7,
						["name"] = "Decay-Infused Tanning Oil",
						["zone"] = 3,
						["hiddenQuestId"] = "70266",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [7]
					{
						["Y"] = 41.3,
						["X"] = 57.5,
						["name"] = "Treated Hides",
						["zone"] = 3,
						["hiddenQuestId"] = "70286",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [8]
					{
						["Y"] = 30.5,
						["X"] = 56.8,
						["name"] = "Decayed Scales",
						["zone"] = 4,
						["hiddenQuestId"] = "70294",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = false,
					}, -- [9]
				},
				["TLW"] = true,
				["hideCompleted"] = true,
				["Utt"] = true,
			},
		},
		["Minning"] = {
			["sparkWidth"] = 10,
			["iconSource"] = -1,
			["user_x"] = 0,
			["authorOptions"] = {
				{
					["useName"] = true,
					["type"] = "header",
					["text"] = "Mining one time knowledge",
					["noMerge"] = true,
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "TMIN",
					["useDesc"] = true,
					["name"] = "Track Mining",
					["width"] = 1,
				}, -- [2]
				{
					["type"] = "toggle",
					["default"] = true,
					["desc"] = "track profession",
					["key"] = "Utt",
					["useDesc"] = true,
					["name"] = "Tomtom Intergration",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "hideCompleted",
					["useDesc"] = false,
					["name"] = "Hide completed/Colected",
					["width"] = 1,
				}, -- [4]
				{
					["type"] = "toggle",
					["default"] = false,
					["key"] = "onlyElites",
					["useDesc"] = false,
					["name"] = "hide one time treasures",
					["width"] = 1,
				}, -- [5]
				{
					["type"] = "space",
					["variableWidth"] = true,
					["height"] = 2,
					["width"] = 2,
					["useHeight"] = true,
				}, -- [6]
				{
					["subOptions"] = {
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "name",
							["name"] = "Name",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [1]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "X",
							["desc"] = "West - East postion",
							["name"] = "X-Coordinates",
							["default"] = 0,
						}, -- [2]
						{
							["type"] = "number",
							["useDesc"] = true,
							["max"] = 100,
							["step"] = 0.01,
							["width"] = 1,
							["min"] = 0,
							["key"] = "Y",
							["desc"] = "North - South Postion",
							["name"] = "Y-Coordinates",
							["default"] = 0,
						}, -- [3]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 1,
							["key"] = "hiddenQuestId",
							["name"] = "Hidden QuestID",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [4]
						{
							["desc"] = "Choose a zone",
							["type"] = "select",
							["values"] = {
								"Waking Shores", -- [1]
								"Ohn'ahran Plains", -- [2]
								"Azure Span", -- [3]
								"Thaldraszus", -- [4]
								"Valdrakken", -- [5]
							},
							["default"] = 1,
							["key"] = "zone",
							["useDesc"] = false,
							["name"] = "Zone",
							["width"] = 1,
						}, -- [5]
						{
							["type"] = "input",
							["useDesc"] = false,
							["width"] = 2,
							["key"] = "drops",
							["name"] = "Loot table",
							["multiline"] = false,
							["length"] = 10,
							["default"] = "",
							["useLength"] = false,
						}, -- [6]
						{
							["type"] = "toggle",
							["default"] = false,
							["key"] = "isElite",
							["useDesc"] = false,
							["name"] = "Masters or Treatise",
							["width"] = 1,
						}, -- [7]
						{
							["type"] = "toggle",
							["default"] = true,
							["desc"] = "",
							["key"] = "alwaysDisplay",
							["useDesc"] = false,
							["name"] = "Track",
							["width"] = 1,
						}, -- [8]
					},
					["hideReorder"] = false,
					["useDesc"] = false,
					["nameSource"] = 1,
					["collapse"] = true,
					["width"] = 1,
					["useCollapse"] = true,
					["noMerge"] = false,
					["name"] = "Minning Setup",
					["key"] = "rares",
					["limitType"] = "none",
					["groupType"] = "array",
					["type"] = "group",
					["size"] = 10,
				}, -- [7]
				{
					["type"] = "description",
					["text"] = "|cffff0000 Do Not |r use reset to default button it will reset Array any data ",
					["fontSize"] = "medium",
					["width"] = 2,
				}, -- [8]
			},
			["displayText"] = "%disp",
			["yOffset"] = 0,
			["foregroundColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkRotation"] = 0,
			["sameTexture"] = true,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["icon"] = true,
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = true,
			["selfPoint"] = "BOTTOM",
			["barColor"] = {
				1, -- [1]
				0.40000003576279, -- [2]
				0.20000001788139, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["rotation"] = 0,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["gradientOrientation"] = "HORIZONTAL",
			["crop_y"] = 0.41,
			["textureWrapMode"] = "CLAMPTOBLACKADDITIVE",
			["foregroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["shadowXOffset"] = 1,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["blendMode"] = "BLEND",
			["slantMode"] = "INSIDE",
			["texture"] = "WorldState Score",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 100002,
			["alpha"] = 1,
			["displayText_format_disp_abbreviate_max"] = 8,
			["uid"] = "GscpCSs(krH",
			["displayIcon"] = "4625105",
			["backgroundOffset"] = 2,
			["outline"] = "OUTLINE",
			["preferToUpdate"] = false,
			["sparkOffsetX"] = 0,
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Minning Module",
			["barColor2"] = {
				0, -- [1]
				0.4627451300621, -- [2]
				0.69803923368454, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    --Translit Edit\nend",
			["shadowYOffset"] = -1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "isCompleted",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0.086274512112141, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "AND",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "inZone",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "isCompleted",
								["value"] = 0,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.023529414087534, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [2]
			},
			["desaturateBackground"] = false,
			["orientation"] = "HORIZONTAL",
			["enableGradient"] = false,
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["desaturateForeground"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "custom",
						["customVariables"] = "{\n    disp = 'string',\n    inZone = 'bool',\n    isCompleted = 'bool'\n}",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["unit"] = "player",
						["custom"] = "function(states, event, ...)\n  if event == \"GLOBAL_MOUSE_UP\" and ... then\n    local button = ...\n    if button == \"LeftButton\" then-----Mouse input block Start-------------------------------------------------------------\n      if IsControlKeyDown() then\n        local lootLink = \"\"\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region)\n          if over and states[cloneID] then\n            print(states[cloneID].disp)\n            for _, link in ipairs(states[cloneID].links) do-- print loot to chat window (in a list)\n              print(link)\n            end\n          end\n        end\n      elseif  IsShiftKeyDown() then\n        for cloneID, region in pairs(aura_env.regions) do\n          local over = MouseIsOver(region.icon)\n          if over and states[cloneID] then\n            local x, y = states[cloneID].X, states[cloneID].Y\n            if x ~= 0 and y ~=0 then\n              if IsAddOnLoaded(\"TomTom\") and aura_env.config.Utt then-- checks if tomtom is installed and if the users wants to use tomtom need to dig in to see if theres tomtom:resetall << its not that as i tried that :P\n                TomTom:AddWaypoint(states[cloneID].zoneID, x/100, y/100, {title=states[cloneID].disp,from=\"WeakAuras\"})\n              else --set blizzard work markers\n                C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(states[cloneID].zoneID, x/100, y/100, 0))\n                C_SuperTrack.SetSuperTrackedUserWaypoint(true)\n              end\n            end\n            break\n          end\n        end\n      end\n    elseif button == \"RightButton\" then\n      for cloneID, region in pairs(aura_env.regions) do\n        local over = MouseIsOver(region)\n        if over and states[cloneID] then\n          C_Map.ClearUserWaypoint()-- Clear map pins blizzard\n          break\n        end\n      end\n    end -----Mouse input block End--------------------------------------------------------------------------------------------------------------------\n  else\n    local cfg = aura_env.config\n    local map = C_Map.GetBestMapForUnit(\"player\")\n    local class = select(3, UnitClass(\"player\"))\n    --print(\"------------------\")\n    local update\n    for _, rare in ipairs(cfg.rares) do\n      if rare.alwaysDisplay --or rare.classDisplay[class] --\n      then            \n        if type(rare.hiddenQuestId) == \"string\" then\n          local isCompleted = C_QuestLog.IsQuestFlaggedCompleted(rare.hiddenQuestId)\n          local skip = (cfg.hideCompleted and isCompleted) or (cfg.onlyElites and not rare.isElite)\n          \n          local inZone = true\n          local rareZone = aura_env.zones[rare.zone]\n          if rareZone.zoneId ~= map then\n            inZone = false\n          end\n          \n          if skip and states[rare.hiddenQuestId] then\n            states[rare.hiddenQuestId] = {\n              changed = true,\n              show = false,\n            }\n            update = true\n          elseif not skip and not states[rare.hiddenQuestId] then\n            local index = inZone and 0 or 10\n            index = index + rare.zone^2 + (rare.isElite and 0 or 1)\n            \n            local tooltip = format(\"%s|n|cFFFFFFFF/way %s %s|r\", rareZone.zone, rare.X, rare.Y)\n            \n            states[rare.hiddenQuestId] = {\n              icon = rare.isElite and 878214 or 4625105,\n              disp = rare.name,\n              zone = rareZone.zoneShort,\n              zoneID = rareZone.zoneId,\n              inZone = inZone,\n              isCompleted = isCompleted,\n              tooltip = tooltip,\n              tooltipWrap = true,\n              index = index,\n              links = {},\n              X = rare.X,\n              Y = rare.Y,\n              changed = true,\n              show = true,\n            }\n            for itemID in rare.drops:gmatch(\"%d+\") do\n              if itemID and itemID ~= \"\" then\n                itemID = tonumber(itemID)\n                local item = Item:CreateFromItemID(itemID)\n                local link\n                if item and not item:IsItemEmpty() then\n                  item:ContinueOnItemLoad(function()\n                      link = item:GetItemLink()\n                    end\n                  )\n                  table.insert(states[rare.hiddenQuestId].links, link)\n                end\n              end\n            end\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].isCompleted ~= isCompleted\n          then\n            states[rare.hiddenQuestId].isCompleted = isCompleted\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          elseif states[rare.hiddenQuestId]\n          and states[rare.hiddenQuestId].inZone ~= inZone\n          then\n            states[rare.hiddenQuestId].inZone = inZone\n            states[rare.hiddenQuestId].changed = true\n            update = true\n          end            \n        end\n      end\n    end\n    \n    return update\n  end\nend",
						["spellIds"] = {
						},
						["events"] = "PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP PLAYER_REGEN_ENABLED, PLAYER_TARGET_CHANGED, ZONE_CHANGED_NEW_AREA, ZONE_CHANGED, ZONE_CHANGED_INDOORS GLOBAL_MOUSE_UP",
						["check"] = "event",
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    --Translit Edit\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["events"] = "START",
						["custom_type"] = "status",
						["check"] = "event",
						["unit"] = "player",
						["custom"] = "function()\n    if aura_env.config.TMIN then\n        return true\n    end \nend",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(trigger)\n    return trigger[1] and (trigger[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["endAngle"] = 360,
			["internalVersion"] = 64,
			["displayText_format_p_time_dynamic_threshold"] = 60,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["fixedWidth"] = 200,
			["compress"] = false,
			["width"] = 250,
			["zoom"] = 0,
			["discrete_rotation"] = 0,
			["load"] = {
				["use_petbattle"] = false,
				["use_encounter"] = false,
				["zone"] = "Korthia, The Rift, The Maw",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["zoneIds"] = "2112,2022,2023,2024,2025,2085",
				["use_size"] = false,
				["use_zoneIds"] = true,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["use_spellknown"] = true,
				["size"] = {
					["multi"] = {
						["none"] = true,
					},
				},
				["ingroup"] = {
					["multi"] = {
						["solo"] = true,
						["group"] = true,
					},
				},
				["use_never"] = false,
				["use_alive"] = true,
				["spellknown"] = 366260,
				["use_ingroup"] = false,
			},
			["version"] = 80,
			["subRegions"] = {
				{
					["type"] = "subbackground",
				}, -- [1]
				{
					["type"] = "subforeground",
				}, -- [2]
				{
					["text_text_format_n_format"] = "none",
					["text_text"] = "%disp",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_text_format_disp_format"] = "none",
					["text_selfPoint"] = "AUTO",
					["text_automaticWidth"] = "Auto",
					["text_fixedWidth"] = 64,
					["anchorYOffset"] = 0,
					["text_justify"] = "LEFT",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowYOffset"] = 0,
					["text_wordWrap"] = "WordWrap",
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_LEFT",
					["text_visible"] = true,
					["text_fontSize"] = 12,
					["anchorXOffset"] = 0,
					["text_shadowXOffset"] = 0,
				}, -- [3]
			},
			["height"] = 16,
			["rotate"] = true,
			["id"] = "Minning",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["fontSize"] = 12,
			["source"] = "import",
			["backgroundTexture"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Auras\\Aura3",
			["semver"] = "4.99.2",
			["startAngle"] = 0,
			["mirror"] = false,
			["customTextUpdate"] = "update",
			["displayText_format_p_time_format"] = 0,
			["displayText_format_p_time_precision"] = 1,
			["xOffset"] = 0,
			["icon_side"] = "LEFT",
			["actions"] = {
				["start"] = {
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nif region and region.state and region.state.show then\n    aura_env.regions[aura_env.cloneId] = region\nend",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Icon1=aura_env.config.AKSH\naura_env.regions = {}\naura_env.zones = {\n  {\n    zoneId = 2022, \n    zone = \"Waking Shores\",\n  },\n  {\n    zoneId = 2023, \n    zone = \"Ohn'ahran Plains\"\n  },\n  {\n    zoneId = 2024, \n    zone = \"Azure Span\"\n  },\n  {\n    zoneId = 2025, \n    zone = \"Thaldraszus\"\n  },\n  {\n    zoneId = 2112, \n    zone = \"Valdrakken\"\n  }\n}",
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "if aura_env.regions[aura_env.cloneId] then\n    aura_env.regions[aura_env.cloneId] = nil\nend",
					["do_custom"] = true,
				},
			},
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 30,
			["displayText_format_disp_format"] = "string",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayText_format_p_format"] = "timed",
			["justify"] = "CENTER",
			["backgroundColor"] = {
				1, -- [1]
				0.40000003576279, -- [2]
				0.20000001788139, -- [3]
				0.5, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["anchorPoint"] = "CENTER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["user_y"] = 0,
			["displayText_format_disp_abbreviate"] = false,
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["shadowColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["crop_x"] = 0.41,
			["information"] = {
				["forceEvents"] = false,
				["ignoreOptionsEventErrors"] = true,
			},
			["config"] = {
				["Utt"] = true,
				["rares"] = {
					{
						["Y"] = 59.9,
						["X"] = 42.6,
						["name"] = "Treatise on Mining",
						["zone"] = 5,
						["hiddenQuestId"] = "74106",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [1]
					{
						["Y"] = 76.86,
						["X"] = 61.41,
						["name"] = "Prefession master Bridgette Holdug",
						["zone"] = 4,
						["hiddenQuestId"] = "70258",
						["drops"] = "",
						["alwaysDisplay"] = true,
						["isElite"] = true,
					}, -- [2]
				},
				["TMIN"] = true,
				["hideCompleted"] = true,
				["onlyElites"] = false,
			},
		},
		["Eng Module "] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Engineering", -- [1]
				"EngAB", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620673,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "yOE2ebS)Hjs",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:Enc Module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "Eng Module ",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["Engineering"] = false,
				["EngAB"] = false,
			},
		},
		["BS Module"] = {
			["arcLength"] = 360,
			["controlledChildren"] = {
				"Blacksmithing", -- [1]
				"BSAB", -- [2]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["wagoID"] = "9MpDLGWp3",
			["parent"] = "Profession Module",
			["preferToUpdate"] = false,
			["groupIcon"] = 4620670,
			["anchorPoint"] = "BOTTOM",
			["fullCircle"] = true,
			["space"] = 1,
			["url"] = "https://wago.io/TamasDragonflightHelper/80",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["unit"] = "player",
						["type"] = "aura2",
						["spellIds"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
						["event"] = "Health",
						["names"] = {
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
			},
			["columnSpace"] = 1,
			["radius"] = 200,
			["sort"] = "none",
			["useLimit"] = false,
			["align"] = "CENTER",
			["xOffset"] = 0,
			["internalVersion"] = 64,
			["authorOptions"] = {
			},
			["rotation"] = 0,
			["stagger"] = 0,
			["version"] = 80,
			["subRegions"] = {
			},
			["grow"] = "DOWN",
			["selfPoint"] = "TOP",
			["load"] = {
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["uid"] = "DYpigNJKZns",
			["source"] = "import",
			["borderColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["scale"] = 1,
			["centerType"] = "LR",
			["border"] = false,
			["anchorFrameFrame"] = "WeakAuras:alc module",
			["regionType"] = "dynamicgroup",
			["borderSize"] = 2,
			["limit"] = 5,
			["borderInset"] = 1,
			["gridWidth"] = 5,
			["constantFactor"] = "RADIUS",
			["rowSpace"] = 1,
			["borderOffset"] = 4,
			["semver"] = "4.99.2",
			["tocversion"] = 100002,
			["id"] = "BS Module",
			["borderEdge"] = "Square Full White",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SELECTFRAME",
			["animate"] = false,
			["config"] = {
			},
			["yOffset"] = 0,
			["gridType"] = "RD",
			["conditions"] = {
			},
			["information"] = {
			},
			["sortHybridTable"] = {
				["BSAB"] = false,
				["Blacksmithing"] = false,
			},
		},
	},
	["registered"] = {
	},
	["editor_font_size"] = 12,
	["editor_theme"] = "Monokai",
}
