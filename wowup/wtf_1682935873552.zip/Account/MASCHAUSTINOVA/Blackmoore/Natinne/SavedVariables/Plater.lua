
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[577] = 30,
		[581] = 30,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-580-0A6684B6"] = true,
	},
	["minimap"] = {
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[577] = 30,
		[581] = 30,
	},
}
