
CHANNELPULLOUT_FADEFRAMES = {
	"ChannelPulloutBackground", -- [1]
	"ChannelPulloutCloseButton", -- [2]
	"ChannelPulloutRosterScroll", -- [3]
}
DISPLAYED_COMMUNITIES_INVITATIONS = {
}
