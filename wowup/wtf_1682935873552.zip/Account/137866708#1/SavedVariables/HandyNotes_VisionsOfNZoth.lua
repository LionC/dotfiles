
HandyNotes_VisionsOfNZothDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Default",
		["Lioncilu - Blackmoore"] = "Default",
		["Ämelia - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
		["Lionc - Blackmoore"] = "Default",
		["Jakuup - Blackmoore"] = "Default",
		["Crayona - Blackmoore"] = "Default",
		["Xyresia - Blackmoore"] = "Default",
		["Laeduin - Blackmoore"] = "Default",
		["Amilanoo - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
