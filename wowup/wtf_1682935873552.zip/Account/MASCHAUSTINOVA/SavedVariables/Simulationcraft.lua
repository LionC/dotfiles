
SimulationCraftDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Taifunari - Blackmoore",
		["Allegory - Blackmoore"] = "Allegory - Blackmoore",
	},
	["profiles"] = {
		["Taifunari - Blackmoore"] = {
		},
		["Allegory - Blackmoore"] = {
			["minimap"] = {
				["minimapPos"] = 135.557005383598,
			},
		},
	},
}
