
DeathGraphsDBDeaths = {
}
DeathGraphsDBEndurance = {
}
DeathGraphsDBCurrent = {
}
DeathGraphsDBGraph = {
}
