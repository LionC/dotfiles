
CliqueDB = nil
CliqueDB3 = {
	["char"] = {
		["Xyresia - Blackmoore"] = {
			["spec1_profileKey"] = "Xyresia - Blackmoore",
			["fastooc"] = false,
			["alerthidden"] = true,
			["downclick"] = false,
			["spec3_profileKey"] = "Xyresia - Blackmoore",
			["spec2_profileKey"] = "Xyresia - Blackmoore",
			["specswap"] = false,
		},
		["Lionc - Blackmoore"] = {
			["spec1_profileKey"] = "Lionc - Blackmoore",
			["alerthidden"] = true,
			["downclick"] = false,
			["fastooc"] = false,
			["spec3_profileKey"] = "Lionc - Blackmoore",
			["spec2_profileKey"] = "Lionc - Blackmoore",
			["specswap"] = false,
		},
	},
	["profileKeys"] = {
		["Xyresia - Blackmoore"] = "Xyresia - Blackmoore",
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
	},
	["profiles"] = {
		["Xyresia - Blackmoore"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Lionc - Blackmoore"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
	},
}
