
g_professionsSpecsSelectedTabs = {
	[2834] = 404,
	[2830] = 377,
}
g_professionsSpecsSelectedPaths = {
	[403] = 34689,
	[404] = 34726,
	[377] = 31180,
	[350] = 28543,
	[405] = 34757,
	[376] = 31145,
	[348] = 28438,
}
