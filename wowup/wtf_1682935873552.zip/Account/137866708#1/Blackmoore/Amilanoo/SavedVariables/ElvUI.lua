
ElvCharacterDB = {
	["ChatEditHistory"] = {
	},
	["ChatHistoryLog"] = {
	},
}
