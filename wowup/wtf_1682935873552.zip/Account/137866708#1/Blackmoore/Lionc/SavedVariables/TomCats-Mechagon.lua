
TomCats_Mechagon_Character = {
	["preferences"] = {
		["TomCats-MechagonMinimapButton"] = {
			["position"] = -2.600421211616223,
		},
	},
}
