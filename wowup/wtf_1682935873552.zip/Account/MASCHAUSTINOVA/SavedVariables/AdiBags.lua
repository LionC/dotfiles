
AdiBagsDB = {
	["namespaces"] = {
		["ItemLevel"] = {
		},
		["FilterOverride"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 3,
				},
			},
		},
		["ItemCategory"] = {
		},
		["NewItem"] = {
		},
		["AdiBags_TooltipInfo"] = {
		},
		["MoneyFrame"] = {
		},
		["ItemSets"] = {
		},
		["CurrencyFrame"] = {
		},
		["DataSource"] = {
		},
		["Junk"] = {
		},
		["Equipment"] = {
		},
	},
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Allegory - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["maxHeight"] = 0.47,
			["positions"] = {
				["Backpack"] = {
					["xOffset"] = -1.824019881751156,
					["yOffset"] = 0.9910311377458214,
				},
			},
		},
	},
}
