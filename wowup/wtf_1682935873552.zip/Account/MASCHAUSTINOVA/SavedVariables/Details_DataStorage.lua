
DetailsDataStorage = {
	[14] = {
	},
	[15] = {
	},
	["mythic_plus"] = {
	},
	[16] = {
	},
	[17] = {
		[2605] = {
		},
	},
	["VERSION"] = 5,
	["totalkills"] = {
		[2605] = {
			[17] = {
				["time_incombat"] = 477.3980000000011,
				["time_fasterkill"] = 477.3980000000011,
				["wipes"] = 4,
				["kills"] = 1,
				["dps_best"] = 12270.80759456258,
				["dps_best_raid_when"] = 1673877701,
				["time_fasterkill_when"] = 1673877701,
				["dps_best_when"] = 1673877701,
				["dps_best_raid"] = 368561.1586139859,
			},
		},
	},
	["Data"] = {
	},
	["saved_encounters"] = {
	},
}
