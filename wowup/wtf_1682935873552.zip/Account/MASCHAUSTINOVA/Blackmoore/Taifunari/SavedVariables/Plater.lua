
PlaterDBChr = {
	["spellRangeCheckRangeFriendly"] = {
		[64] = 40,
		[63] = 40,
		[62] = 40,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-580-0A021747"] = true,
	},
	["minimap"] = {
	},
	["resources_on_target"] = false,
	["debuffsBanned"] = {
	},
	["spellRangeCheckRangeEnemy"] = {
		[64] = 40,
		[63] = 40,
		[62] = 40,
	},
}
