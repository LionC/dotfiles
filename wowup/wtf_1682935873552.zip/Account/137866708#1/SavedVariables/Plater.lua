
PlaterDB = {
	["captured_spells"] = {
		[396364] = {
			["type"] = "DEBUFF",
			["source"] = "Raszageth",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 199388,
		},
		[383823] = {
			["source"] = "Nokhud Hornsounder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192796,
		},
		[387411] = {
			["source"] = "Soulharvester Tumen",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195929,
		},
		[384808] = {
			["encounterName"] = "Teera and Maruuk",
			["type"] = "BUFF",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186339,
		},
		[383061] = {
			["source"] = "Liquid Magma Totem",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 97369,
		},
		[386015] = {
			["source"] = "Primalist Stormspeaker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194894,
		},
		[209859] = {
			["type"] = "BUFF",
			["source"] = "Nokhud Hornsounder",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 192796,
		},
		[192226] = {
			["type"] = "BUFF",
			["source"] = "Liquid Magma Totem",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 97369,
		},
		[387127] = {
			["source"] = "Primalist Thunderbeast",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195696,
		},
		[384492] = {
			["source"] = "Nokhud Beastmaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192794,
		},
		[387826] = {
			["source"] = "Ukhel Beastcaller",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195878,
		},
		[117588] = {
			["source"] = "Primal Fire Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 61029,
		},
		[386747] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[395669] = {
			["encounterName"] = "Teera and Maruuk",
			["type"] = "DEBUFF",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186338,
		},
		[386176] = {
			["type"] = "BUFF",
			["source"] = "Unknown",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17252,
		},
		[376683] = {
			["encounterName"] = "Balakar Khan",
			["type"] = "BUFF",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186151,
		},
		[386748] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[395035] = {
			["source"] = "Soulharvester Tumen",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195929,
		},
		[90361] = {
			["type"] = "BUFF",
			["source"] = "CasyFan",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 165189,
		},
		[396369] = {
			["type"] = "DEBUFF",
			["source"] = "Raszageth",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 199388,
		},
		[384336] = {
			["source"] = "Nokhud Plainstomper",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 191847,
		},
		[57984] = {
			["source"] = "Primal Fire Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 61029,
		},
		[376829] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[384686] = {
			["encounterName"] = "The Raging Tempest",
			["type"] = "BUFF",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[387131] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[118297] = {
			["source"] = "Primal Fire Elemental",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 61029,
		},
		[90328] = {
			["type"] = "BUFF",
			["source"] = "CasyFan",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 165189,
		},
		[387608] = {
			["source"] = "Ukhel Corruptor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195842,
		},
		[387132] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[108446] = {
			["type"] = "BUFF",
			["source"] = "Unknown",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 17252,
		},
		[263854] = {
			["source"] = "Bonedurmom",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 165189,
		},
		[394975] = {
			["source"] = "Void Lasher",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 198757,
		},
		[387133] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[386022] = {
			["type"] = "BUFF",
			["source"] = "Primalist Stormspeaker",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194894,
		},
		[167381] = {
			["source"] = "Normal Tank Dummy",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194649,
		},
		[394976] = {
			["type"] = "DEBUFF",
			["source"] = "Void Lasher",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 198757,
		},
		[394754] = {
			["source"] = "Lindormi",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 197915,
		},
		[388817] = {
			["encounterName"] = "Granyth",
			["source"] = "Granyth",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186616,
		},
		[392151] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186339,
		},
		[382277] = {
			["source"] = "Balara",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 193457,
		},
		[387135] = {
			["source"] = "Primalist Arcblade",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194898,
		},
		[384881] = {
			["type"] = "BUFF",
			["source"] = "Stormsurge Totem",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194897,
		},
		[16827] = {
			["source"] = "Bonedurmom",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 165189,
		},
		[2649] = {
			["source"] = "Bonedurmom",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 165189,
		},
		[188046] = {
			["source"] = "Denizen of the Dream",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 198489,
		},
		[386914] = {
			["type"] = "BUFF",
			["source"] = "The Raging Tempest",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[382628] = {
			["encounterName"] = "The Raging Tempest",
			["type"] = "DEBUFF",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[387613] = {
			["source"] = "Ukhel Corruptor",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195842,
		},
		[376723] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Nokhud Stormcaster",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 190294,
		},
		[386026] = {
			["source"] = "Unstable Squall",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194895,
		},
		[382233] = {
			["source"] = "Batak",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 193462,
		},
		[384185] = {
			["encounterName"] = "The Raging Tempest",
			["type"] = "DEBUFF",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[376724] = {
			["encounterName"] = "Balakar Khan",
			["type"] = "BUFF",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186151,
		},
		[386916] = {
			["encounterName"] = "The Raging Tempest",
			["type"] = "DEBUFF",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[386694] = {
			["type"] = "BUFF",
			["source"] = "Stormsurge Totem",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194897,
		},
		[91800] = {
			["encounterName"] = "Balakar Khan",
			["type"] = "DEBUFF",
			["source"] = "Risen Ghoul",
			["encounterID"] = 2580,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 26125,
		},
		[400474] = {
			["type"] = "DEBUFF",
			["source"] = "Stormsurge Totem",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194897,
		},
		[386028] = {
			["source"] = "Primalist Thunderbeast",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195696,
		},
		[260249] = {
			["type"] = "BUFF",
			["source"] = "Unknown",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 165189,
		},
		[373392] = {
			["source"] = "Nokhud Hornsounder",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192796,
		},
		[396411] = {
			["type"] = "DEBUFF",
			["source"] = "Raszageth",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 199388,
		},
		[259277] = {
			["type"] = "DEBUFF",
			["source"] = "Unknown",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 165189,
		},
		[115804] = {
			["type"] = "DEBUFF",
			["source"] = "Unknown",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 165189,
		},
		[376634] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[376727] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[386411] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186339,
		},
		[167385] = {
			["type"] = "BUFF",
			["source"] = "Normal Tank Dummy",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194649,
		},
		[384316] = {
			["encounterName"] = "The Raging Tempest",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186615,
		},
		[376708] = {
			["type"] = "BUFF",
			["source"] = "Ohn'ahra",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 187895,
		},
		[384761] = {
			["encounterName"] = "The Raging Tempest",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186615,
		},
		[386063] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186338,
		},
		[63619] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Shadowfiend",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 19668,
		},
		[384476] = {
			["type"] = "BUFF",
			["source"] = "Nokhud Longbow",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 192789,
		},
		[386921] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[1604] = {
			["type"] = "DEBUFF",
			["source"] = "Shikaar Ranger",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 196306,
		},
		[386223] = {
			["type"] = "BUFF",
			["source"] = "Primal Stormshield",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194896,
		},
		[381683] = {
			["source"] = "Nokhud Warspear",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192791,
		},
		[208963] = {
			["type"] = "BUFF",
			["source"] = "Skyfury Totem",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 105427,
		},
		[386319] = {
			["type"] = "BUFF",
			["source"] = "Primal Gust",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 195579,
		},
		[375937] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[387145] = {
			["source"] = "Stormcaller Boroo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194317,
		},
		[384510] = {
			["type"] = "BUFF",
			["source"] = "Nokhud Lancemaster",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 192800,
		},
		[386320] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194367,
		},
		[376827] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[376725] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Nokhud Stormcaster",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 190294,
		},
		[375943] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[393421] = {
			["encounterName"] = "Balakar Khan",
			["type"] = "DEBUFF",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186151,
		},
		[382670] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186339,
		},
		[386547] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186339,
		},
		[376892] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[375929] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[386227] = {
			["type"] = "BUFF",
			["source"] = "Primal Stormshield",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 194896,
		},
		[383067] = {
			["type"] = "BUFF",
			["source"] = "Balara",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 193457,
		},
		[388450] = {
			["type"] = "BUFF",
			["source"] = "Nokhud Stormcaller",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 196484,
		},
		[385434] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186339,
		},
		[385339] = {
			["encounterName"] = "Teera and Maruuk",
			["type"] = "BUFF",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186338,
		},
		[382267] = {
			["source"] = "Balara",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 193457,
		},
		[376894] = {
			["encounterName"] = "Balakar Khan",
			["type"] = "DEBUFF",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186151,
		},
		[193635] = {
			["source"] = "Void Tendril",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192337,
		},
		[392198] = {
			["encounterName"] = "Teera and Maruuk",
			["type"] = "BUFF",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186338,
		},
		[388801] = {
			["source"] = "Risen Warrior",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195855,
		},
		[384134] = {
			["source"] = "Nokhud Warspear",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192791,
		},
		[372147] = {
			["source"] = "Balara",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 193457,
		},
		[376705] = {
			["type"] = "BUFF",
			["source"] = "Nokhud Stormcaster",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 190294,
		},
		[376864] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[384620] = {
			["encounterName"] = "The Raging Tempest",
			["type"] = "BUFF",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[387596] = {
			["source"] = "Risen Mystic",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195877,
		},
		[376706] = {
			["type"] = "BUFF",
			["source"] = "Nokhud Stormcaster",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 190294,
		},
		[376865] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[193473] = {
			["type"] = "DEBUFF",
			["source"] = "Void Tendril",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 192337,
		},
		[114404] = {
			["encounterName"] = "Granyth",
			["type"] = "DEBUFF",
			["source"] = "Void Tendril",
			["encounterID"] = 2637,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 65282,
		},
		[387629] = {
			["source"] = "Desecrated Ohuna",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195876,
		},
		[381692] = {
			["source"] = "Nokhud Warspear",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192791,
		},
		[376644] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186151,
		},
		[345561] = {
			["type"] = "DEBUFF",
			["source"] = "Maruuk",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186338,
		},
		[383693] = {
			["source"] = "Nokhud Beastmaster",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192794,
		},
		[384868] = {
			["source"] = "Nokhud Longbow",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 192789,
		},
		[385916] = {
			["encounterName"] = "Granyth",
			["source"] = "Granyth",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186616,
		},
		[382836] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 186338,
		},
		[373279] = {
			["source"] = "Thing From Beyond",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 189988,
		},
		[387155] = {
			["encounterName"] = "Granyth",
			["type"] = "DEBUFF",
			["source"] = "Granyth",
			["encounterID"] = 2637,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186616,
		},
		[386012] = {
			["source"] = "Stormcaller Boroo",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 194317,
		},
		[387614] = {
			["source"] = "Ukhel Deathspeaker",
			["event"] = "SPELL_CAST_SUCCESS",
			["npcID"] = 195851,
		},
		[389029] = {
			["type"] = "BUFF",
			["source"] = "Gravelord Monkh",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 195933,
		},
		[394875] = {
			["encounterName"] = "The Raging Tempest",
			["type"] = "DEBUFF",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
		[334610] = {
			["type"] = "DEBUFF",
			["source"] = "War Ohuna",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 192803,
		},
		[386915] = {
			["type"] = "BUFF",
			["source"] = "The Raging Tempest",
			["event"] = "SPELL_AURA_APPLIED",
			["npcID"] = 186615,
		},
	},
	["captured_casts"] = {
		[381575] = {
			["source"] = "Rustpine Immolator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187396,
		},
		[396665] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Magmas",
			["npcID"] = 199027,
		},
		[373392] = {
			["source"] = "Nokhud Hornsounder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192796,
		},
		[375950] = {
			["source"] = "Primalist Icecaller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190377,
		},
		[394620] = {
			["source"] = "Nightrot",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188707,
		},
		[395899] = {
			["source"] = "Primalist Chillblaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 199124,
		},
		[369813] = {
			["source"] = "Consuming Upswell",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188672,
		},
		[212784] = {
			["source"] = "Watchful Inquisitor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 105715,
		},
		[373395] = {
			["source"] = "Batak",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193462,
		},
		[217260] = {
			["source"] = "Mudfin Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186679,
		},
		[153067] = {
			["encounterName"] = "Nhallish",
			["source"] = "Nhallish",
			["encounterID"] = 1688,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75829,
		},
		[193092] = {
			["encounterName"] = "Hymdall",
			["source"] = "Hymdall",
			["encounterID"] = 1805,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 94960,
		},
		[379023] = {
			["source"] = "Hillside Forager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191240,
		},
		[390788] = {
			["source"] = "Chief Grrlgllmesh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186678,
		},
		[396159] = {
			["source"] = "Worldcarver Wurmling",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187366,
		},
		[396415] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Khakad the Ancient",
			["npcID"] = 196379,
		},
		[369050] = {
			["source"] = "Nokhud Galebringer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193958,
		},
		[377490] = {
			["source"] = "Thunderspine Crasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191057,
		},
		[398206] = {
			["source"] = "Exhumed Spirit",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75979,
		},
		[385419] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Forge-Keep Custodian",
			["npcID"] = 192703,
		},
		[393348] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stalwart Broodwarden",
			["npcID"] = 198263,
		},
		[375446] = {
			["source"] = "Horned Plainstomper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193407,
		},
		[376725] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Nokhud Stormcaster",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190294,
		},
		[386700] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Tender",
			["npcID"] = 186111,
		},
		[152814] = {
			["source"] = "Shadowmoon Bone-Mender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75713,
		},
		[389514] = {
			["source"] = "Bazual",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193532,
		},
		[395908] = {
			["source"] = "Primal Icebulk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192767,
		},
		[376727] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[199361] = {
			["source"] = "Valarjar Trapper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96934,
		},
		[369055] = {
			["source"] = "Djaradin Crustshaper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186110,
		},
		[391050] = {
			["source"] = "High Channeler Ryvati",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197535,
		},
		[371358] = {
			["source"] = "Unstable Curator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187154,
		},
		[373405] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["encounterID"] = 2592,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187967,
		},
		[392075] = {
			["source"] = "Arkhuu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195300,
		},
		[396423] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Khakad the Ancient",
			["npcID"] = 196379,
		},
		[398981] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stalwart Broodwarden",
			["npcID"] = 198263,
		},
		[379033] = {
			["source"] = "Shikaar Bakar",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191063,
		},
		[391821] = {
			["source"] = "Snowhide Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189654,
		},
		[372129] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["encounterID"] = 2592,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187967,
		},
		[381592] = {
			["source"] = "Brutal Motivator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184453,
		},
		[391055] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[378012] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Tarasek Elementalist",
			["npcID"] = 190080,
		},
		[152818] = {
			["source"] = "Shadowmoon Bone-Mender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75713,
		},
		[398985] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Broodguardian Ziruss",
			["npcID"] = 198214,
		},
		[392080] = {
			["source"] = "Maneet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188704,
		},
		[392336] = {
			["source"] = "Arcane Commander",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190776,
		},
		[375201] = {
			["source"] = "Stream Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193306,
		},
		[375457] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Juvenile Frost Proto-Dragon",
			["npcID"] = 191222,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[394895] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Phenran",
			["npcID"] = 193688,
		},
		[374691] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[396430] = {
			["source"] = "Arcane Golem",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190779,
		},
		[390548] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["npcID"] = 184986,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2605,
		},
		[375459] = {
			["source"] = "Thunderspine Rumbler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192941,
		},
		[200901] = {
			["encounterName"] = "Hyrja",
			["source"] = "Solsten",
			["encounterID"] = 1806,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97219,
		},
		[385434] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186339,
		},
		[376483] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Charred Cinderling",
			["npcID"] = 187404,
		},
		[375716] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Primalist Mage",
			["npcID"] = 191206,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[396432] = {
			["source"] = "Acrosoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193243,
		},
		[392341] = {
			["source"] = "Khuumog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194761,
		},
		[197961] = {
			["encounterName"] = "Odyn",
			["source"] = "Odyn",
			["encounterID"] = 1809,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95676,
		},
		[385181] = {
			["encounterName"] = "Gulping Goliath",
			["source"] = "Gulping Goliath",
			["encounterID"] = 2616,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189722,
		},
		[372394] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Dathea Stormlash",
			["npcID"] = 187768,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[392087] = {
			["source"] = "Alpha Cascade Swog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197400,
		},
		[389274] = {
			["source"] = "Mudfin Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186679,
		},
		[387740] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Tyrhold Watcher",
			["npcID"] = 192696,
		},
		[396180] = {
			["source"] = "Worldcarver Wurmling",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187366,
		},
		[114646] = {
			["source"] = "Haunting Sha",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59555,
		},
		[391833] = {
			["source"] = "Sherath",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188710,
		},
		[384161] = {
			["source"] = "Qalashi Irontorch",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189464,
		},
		[369072] = {
			["source"] = "Auburntusk Mammoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188098,
		},
		[372397] = {
			["source"] = "Brackenhide Scrapper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186359,
		},
		[374699] = {
			["source"] = "Flamecaller Aymi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190368,
		},
		[373932] = {
			["encounterName"] = "Azureblade",
			["source"] = "Draconic Image",
			["encounterID"] = 2585,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190187,
		},
		[383651] = {
			["source"] = "Qalashi Lavamancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193944,
		},
		[385442] = {
			["encounterName"] = "Gulping Goliath",
			["source"] = "Gulping Goliath",
			["encounterID"] = 2616,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189722,
		},
		[373678] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[378282] = {
			["source"] = "Qalashi Thaumaturge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192788,
		},
		[212031] = {
			["source"] = "Bound Energy",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 105705,
		},
		[377004] = {
			["encounterName"] = "Crawth",
			["source"] = "Crawth",
			["encounterID"] = 2564,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191736,
		},
		[373424] = {
			["encounterName"] = "Chargath, Bane of Scales",
			["source"] = "Chargath, Bane of Scales",
			["encounterID"] = 2613,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189340,
		},
		[209602] = {
			["encounterName"] = "Advisor Melandrus",
			["source"] = "Advisor Melandrus",
			["encounterID"] = 1870,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104218,
		},
		[395675] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Embar Firepath",
			["npcID"] = 187767,
		},
		[372147] = {
			["source"] = "Balara",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193457,
		},
		[391840] = {
			["source"] = "Taresh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188711,
		},
		[385958] = {
			["encounterName"] = "Vexamus",
			["source"] = "Vexamus",
			["encounterID"] = 2562,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194181,
		},
		[193235] = {
			["encounterName"] = "Hymdall",
			["source"] = "Hymdall",
			["encounterID"] = 1805,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 94960,
		},
		[392097] = {
			["source"] = "Diluu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195431,
		},
		[391825] = {
			["source"] = "Mistyvale Splashcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193973,
		},
		[388773] = {
			["encounterName"] = "Umbrelskul",
			["source"] = "Umbrelskul",
			["encounterID"] = 2584,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186738,
		},
		[370615] = {
			["encounterName"] = "Eranog",
			["source"] = "Eranog",
			["npcID"] = 184972,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[384132] = {
			["encounterName"] = "Azureblade",
			["source"] = "Azureblade",
			["encounterID"] = 2585,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186739,
		},
		[381357] = {
			["source"] = "Wild Ottuk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188338,
		},
		[371383] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Spellwrought Snowman",
			["npcID"] = 193238,
		},
		[394876] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Phenran",
			["npcID"] = 193688,
		},
		[396447] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Thornmu the Ancient",
			["npcID"] = 196382,
		},
		[397726] = {
			["source"] = "Shrieking Whelp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187159,
		},
		[395936] = {
			["source"] = "Riverback Savage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189468,
		},
		[209477] = {
			["source"] = "Mana Wyrm",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 105703,
		},
		[375988] = {
			["source"] = "Nimblewing Slyvern",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191051,
		},
		[388008] = {
			["encounterName"] = "Telash Greywing",
			["source"] = "Telash Greywing",
			["encounterID"] = 2583,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186737,
		},
		[207815] = {
			["encounterName"] = "Patrol Captain Gerdo",
			["source"] = "Patrol Captain Gerdo",
			["encounterID"] = 1868,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104215,
		},
		[387243] = {
			["source"] = "Time-Lost Murhulk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195095,
		},
		[389515] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Shiverweb Creeper",
			["npcID"] = 185811,
		},
		[210875] = {
			["source"] = "Stormforged Sentinel",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96574,
		},
		[196543] = {
			["encounterName"] = "Fenryr",
			["source"] = "Fenryr",
			["encounterID"] = 1807,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95674,
		},
		[377503] = {
			["source"] = "Rune Seal Keeper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187155,
		},
		[400542] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Kalecgos",
			["npcID"] = 193460,
		},
		[374430] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Tectonic Crusher",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190588,
		},
		[384686] = {
			["encounterName"] = "The Raging Tempest",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186615,
		},
		[198077] = {
			["encounterName"] = "Odyn",
			["source"] = "Odyn",
			["encounterID"] = 1809,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95676,
		},
		[367807] = {
			["source"] = "Worldbreaker Escapee",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185626,
		},
		[386991] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cavern Hunter",
			["npcID"] = 196420,
		},
		[377017] = {
			["encounterName"] = "Warlord Sargha",
			["source"] = "Warlord Sargha",
			["encounterID"] = 2611,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189901,
		},
		[375945] = {
			["source"] = "Vigilant Ram",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195040,
		},
		[374969] = {
			["encounterName"] = "Forgemaster Gorek",
			["source"] = "Forgemaster Gorek",
			["encounterID"] = 2612,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189478,
		},
		[373692] = {
			["source"] = "Blazebound Destroyer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190034,
		},
		[391849] = {
			["source"] = "Molten Uprising",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187868,
		},
		[106841] = {
			["encounterName"] = "Liu Flameheart",
			["source"] = "Liu Flameheart",
			["encounterID"] = 1416,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56732,
		},
		[386223] = {
			["source"] = "Primal Stormshield",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194896,
		},
		[396709] = {
			["source"] = "Parched Shortcoat Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195248,
		},
		[389804] = {
			["source"] = "Unstable Curator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187154,
		},
		[120149] = {
			["source"] = "Mirror Image",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194853,
		},
		[393385] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Chalsec of the Earth",
			["npcID"] = 193847,
		},
		[376200] = {
			["source"] = "Forgewrought Monstrosity",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194816,
		},
		[392332] = {
			["source"] = "Zumakh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194624,
		},
		[386992] = {
			["source"] = "Wild Proto-Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192636,
		},
		[373693] = {
			["source"] = "Blazebound Destroyer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190034,
		},
		[387504] = {
			["encounterName"] = "Primal Tsunami",
			["source"] = "Primal Tsunami",
			["encounterID"] = 2618,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189729,
		},
		[394869] = {
			["source"] = "Boneshaper Jardak",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188693,
		},
		[386993] = {
			["source"] = "Cascade Proto-Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194939,
		},
		[372107] = {
			["encounterName"] = "Kokia Blazehoof",
			["source"] = "Kokia Blazehoof",
			["encounterID"] = 2606,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189232,
		},
		[386173] = {
			["encounterName"] = "Vexamus",
			["source"] = "Vexamus",
			["encounterID"] = 2562,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194181,
		},
		[375485] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Dragonspawn Flamebender",
			["npcID"] = 191230,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[389040] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Thondrozus",
			["npcID"] = 192769,
		},
		[375439] = {
			["encounterName"] = "Magmatusk",
			["source"] = "Magmatusk",
			["encounterID"] = 2610,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 181861,
		},
		[395941] = {
			["source"] = "Riverback Savage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189468,
		},
		[212423] = {
			["source"] = "Risen Skulker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 99541,
		},
		[381570] = {
			["source"] = "Pitchstone Rumbler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188014,
		},
		[392366] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Awakened Juggernaut",
			["npcID"] = 197793,
		},
		[207806] = {
			["encounterName"] = "Patrol Captain Gerdo",
			["source"] = "Patrol Captain Gerdo",
			["encounterID"] = 1868,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104215,
		},
		[377505] = {
			["encounterName"] = "Terros",
			["source"] = "Terros",
			["npcID"] = 190496,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2639,
		},
		[392111] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Shiverweb Crusher",
			["npcID"] = 185814,
		},
		[395939] = {
			["source"] = "Riverback Savage",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189468,
		},
		[152962] = {
			["encounterName"] = "Nhallish",
			["source"] = "Nhallish",
			["encounterID"] = 1688,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75829,
		},
		[391856] = {
			["source"] = "Tenmod",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194763,
		},
		[385974] = {
			["encounterName"] = "Vexamus",
			["source"] = "Professor Maxdormu",
			["encounterID"] = 2562,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189668,
		},
		[211401] = {
			["source"] = "Blazing Imp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104295,
		},
		[303308] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Infuser",
			["npcID"] = 186112,
		},
		[392579] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Quarry Stonebreaker",
			["npcID"] = 197831,
		},
		[394891] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Braekkas",
			["npcID"] = 196855,
		},
		[392369] = {
			["source"] = "Earth Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190173,
		},
		[396717] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cyclas",
			["npcID"] = 199029,
		},
		[272167] = {
			["source"] = "Bilescourge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 136404,
		},
		[374215] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[396400] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Glacias",
			["npcID"] = 199028,
		},
		[387960] = {
			["source"] = "Caldera Stomper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187919,
		},
		[118297] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Fire Elemental",
			["npcID"] = 61029,
		},
		[374724] = {
			["source"] = "Flamecaller Aymi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190368,
		},
		[369865] = {
			["source"] = "Nokhud Raider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193840,
		},
		[152964] = {
			["source"] = "Void Spawn",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75652,
		},
		[396975] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Firava the Rekindler",
			["npcID"] = 195915,
		},
		[209485] = {
			["source"] = "Arcane Manifestation",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 105704,
		},
		[370104] = {
			["source"] = "Dragonbane Protector",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186600,
		},
		[209741] = {
			["encounterName"] = "Advisor Melandrus",
			["source"] = "Image of Advisor Melandrus",
			["encounterID"] = 1870,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 105754,
		},
		[392884] = {
			["source"] = "Tevgai",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195132,
		},
		[378818] = {
			["source"] = "Qalashi Thaumaturge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192788,
		},
		[376997] = {
			["encounterName"] = "Crawth",
			["source"] = "Crawth",
			["encounterID"] = 2564,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191736,
		},
		[388537] = {
			["encounterName"] = "Vexamus",
			["source"] = "Vexamus",
			["encounterID"] = 2562,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194181,
		},
		[198595] = {
			["source"] = "Valarjar Thundercaller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95842,
		},
		[385980] = {
			["source"] = "Strunraan",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193534,
		},
		[377029] = {
			["source"] = "Scythid Stalker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197198,
		},
		[394676] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Council Icecaller",
			["npcID"] = 198501,
		},
		[385959] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Fragmented Energy",
			["npcID"] = 198385,
		},
		[377765] = {
			["source"] = "Galestrike Primalist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187175,
		},
		[388283] = {
			["encounterName"] = "Granyth",
			["source"] = "Granyth",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186616,
		},
		[374706] = {
			["source"] = "Flamecaller Aymi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190368,
		},
		[387191] = {
			["source"] = "Strunraan",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193534,
		},
		[372683] = {
			["source"] = "Infused Whelp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187894,
		},
		[387261] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[398770] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Akiormi",
			["npcID"] = 200702,
		},
		[369359] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Karantun",
			["npcID"] = 193647,
		},
		[394167] = {
			["source"] = "Cygenoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185660,
		},
		[383866] = {
			["source"] = "Magma Droplet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194526,
		},
		[391610] = {
			["source"] = "Gusting Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190401,
		},
		[211406] = {
			["source"] = "Blazing Imp",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104295,
		},
		[384663] = {
			["source"] = "Forgewrought Monstrosity",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194816,
		},
		[384194] = {
			["source"] = "Primalist Cinderweaver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190207,
		},
		[385157] = {
			["source"] = "Riverback Rambler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189463,
		},
		[393148] = {
			["source"] = "Maneet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188704,
		},
		[389054] = {
			["source"] = "Arcane Forager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196694,
		},
		[377034] = {
			["encounterName"] = "Crawth",
			["source"] = "Crawth",
			["encounterID"] = 2564,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191736,
		},
		[392635] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Kaurdyth",
			["npcID"] = 197835,
		},
		[376257] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Tarasek Earthreaver",
			["npcID"] = 191225,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[397931] = {
			["source"] = "Minion of Doubt",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 57109,
		},
		[394426] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Council Flamecaller",
			["npcID"] = 198503,
		},
		[388544] = {
			["encounterName"] = "Overgrown Ancient",
			["source"] = "Overgrown Ancient",
			["encounterID"] = 2563,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196482,
		},
		[374735] = {
			["source"] = "Flamecaller Aymi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190368,
		},
		[376780] = {
			["encounterName"] = "Warlord Sargha",
			["source"] = "Warlord Sargha",
			["encounterID"] = 2611,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189901,
		},
		[375249] = {
			["source"] = "Bluebill Waddler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192947,
		},
		[387708] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Tyrhold Watcher",
			["npcID"] = 192696,
		},
		[388801] = {
			["source"] = "Risen Warrior",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195855,
		},
		[378827] = {
			["source"] = "Qalashi Plunderer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192786,
		},
		[396907] = {
			["encounterName"] = "Liu Flameheart",
			["source"] = "Yu'lon",
			["encounterID"] = 1416,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56762,
		},
		[395707] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Raszageth",
			["npcID"] = 199031,
		},
		[391790] = {
			["source"] = "Seismic Stomps",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197829,
		},
		[199772] = {
			["source"] = "Valarjar Champion",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97087,
		},
		[396475] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mellg the Ancient",
			["npcID"] = 196381,
		},
		[152801] = {
			["encounterName"] = "Nhallish",
			["source"] = "Nhallish",
			["encounterID"] = 1688,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75829,
		},
		[386757] = {
			["encounterName"] = "Khajin the Unyielding",
			["source"] = "Khajin the Unyielding",
			["encounterID"] = 2617,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189727,
		},
		[381582] = {
			["source"] = "Brutal Motivator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184453,
		},
		[197558] = {
			["encounterName"] = "Fenryr",
			["source"] = "Fenryr",
			["encounterID"] = 1807,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95674,
		},
		[376272] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Tarasek Earthreaver",
			["npcID"] = 191225,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[388804] = {
			["encounterName"] = "Umbrelskul",
			["source"] = "Umbrelskul",
			["encounterID"] = 2584,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186738,
		},
		[198750] = {
			["encounterName"] = "Odyn",
			["source"] = "Stormforged Obliterator",
			["encounterID"] = 1809,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 102019,
		},
		[114571] = {
			["encounterName"] = "Lorewalker Stonestep",
			["source"] = "Strife",
			["encounterID"] = 1417,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59051,
		},
		[389572] = {
			["source"] = "Time-Lost Devilsaur",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187262,
		},
		[388296] = {
			["source"] = "Crust Lurker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192626,
		},
		[106856] = {
			["encounterName"] = "Liu Flameheart",
			["source"] = "Liu Flameheart",
			["encounterID"] = 1416,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56732,
		},
		[375011] = {
			["source"] = "Seismic Force",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192745,
		},
		[375251] = {
			["encounterName"] = "Magmatusk",
			["source"] = "Magmatusk",
			["encounterID"] = 2610,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 181861,
		},
		[387783] = {
			["source"] = "Windseeker Avash",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192045,
		},
		[378832] = {
			["source"] = "Mistyvale Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193948,
		},
		[385652] = {
			["source"] = "Awakened Crag",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195243,
		},
		[376723] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Nokhud Stormcaster",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190294,
		},
		[396991] = {
			["source"] = "Drakonid Breaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187240,
		},
		[215204] = {
			["encounterName"] = "Patrol Captain Gerdo",
			["source"] = "Vigilant Duskwatch",
			["npcID"] = 104918,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 1868,
		},
		[393411] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Chalsec of the Earth",
			["npcID"] = 193847,
		},
		[393361] = {
			["source"] = "Nightrot",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188707,
		},
		[383693] = {
			["source"] = "Nokhud Beastmaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192794,
		},
		[372696] = {
			["source"] = "Primal Juggernaut",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188244,
		},
		[386259] = {
			["source"] = "Basrikron",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193535,
		},
		[210261] = {
			["source"] = "Duskwatch Sentry",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104251,
		},
		[386411] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186339,
		},
		[396392] = {
			["source"] = "Dueling Student",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 199377,
		},
		[394436] = {
			["source"] = "Shas'ith",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189822,
		},
		[153485] = {
			["source"] = "Carrion Worm",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 76057,
		},
		[17843] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Novice Timewalker",
			["npcID"] = 189583,
		},
		[388302] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Dathea, Ascended",
			["npcID"] = 189813,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[376186] = {
			["source"] = "Overseer Lahar",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189235,
		},
		[396739] = {
			["source"] = "Gargantuan Hornswog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191606,
		},
		[396645] = {
			["source"] = "Alpha Mountain Stonefang",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197376,
		},
		[209495] = {
			["source"] = "Guardian Construct",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104270,
		},
		[387277] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Revenant",
			["npcID"] = 195917,
		},
		[396641] = {
			["source"] = "Alpha Mountain Stonefang",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197376,
		},
		[395112] = {
			["source"] = "Enkine the Voracious",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193134,
		},
		[383953] = {
			["source"] = "Bakar Companion",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194255,
		},
		[388310] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Custodial Protector",
			["npcID"] = 192694,
		},
		[212773] = {
			["source"] = "Duskwatch Reinforcement",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 107073,
		},
		[381659] = {
			["source"] = "Cascade",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186962,
		},
		[391019] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[392394] = {
			["source"] = "Flamegullet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197697,
		},
		[372456] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[345495] = {
			["source"] = "Frothing Pustule",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 175519,
		},
		[384978] = {
			["encounterName"] = "Umbrelskul",
			["source"] = "Umbrelskul",
			["encounterID"] = 2584,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186738,
		},
		[392395] = {
			["source"] = "Thunderhead",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197698,
		},
		[375929] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[394706] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Unstable Frost",
			["npcID"] = 198702,
		},
		[374135] = {
			["source"] = "Craggy Stag",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191541,
		},
		[381408] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Shiverweb Crawler",
			["npcID"] = 185810,
		},
		[389583] = {
			["source"] = "Arcane Manipulator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188172,
		},
		[384223] = {
			["encounterName"] = "Azureblade",
			["source"] = "Azureblade",
			["encounterID"] = 2585,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186739,
		},
		[391118] = {
			["source"] = "Scalebane Lieutenant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191739,
		},
		[196838] = {
			["encounterName"] = "Fenryr",
			["source"] = "Fenryr",
			["encounterID"] = 1807,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 99868,
		},
		[393430] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Forge-Keep Custodian",
			["npcID"] = 192703,
		},
		[388817] = {
			["encounterName"] = "Granyth",
			["source"] = "Granyth",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186616,
		},
		[388316] = {
			["source"] = "Oppressive Artificer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184444,
		},
		[392398] = {
			["source"] = "Primal Thundercloud",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197509,
		},
		[386526] = {
			["source"] = "Nullmagic Hornswog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187246,
		},
		[199652] = {
			["source"] = "King Haldor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95843,
		},
		[384993] = {
			["source"] = "Furious Horned Filcher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197174,
		},
		[153623] = {
			["encounterName"] = "Nhallish",
			["source"] = "Nhallish",
			["encounterID"] = 1688,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75829,
		},
		[396503] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Loamas",
			["npcID"] = 199030,
		},
		[385386] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Menial Attendant",
			["npcID"] = 192702,
		},
		[396386] = {
			["source"] = "Melter Igneous",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188226,
		},
		[117665] = {
			["encounterName"] = "Sha of Doubt",
			["source"] = "Sha of Doubt",
			["encounterID"] = 1439,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56439,
		},
		[225100] = {
			["source"] = "Guardian Construct",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104270,
		},
		[372452] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Drift",
			["npcID"] = 186421,
		},
		[395214] = {
			["source"] = "Worldcarver A'tir",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186859,
		},
		[394972] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Qalashi Lavabearer",
			["npcID"] = 197148,
		},
		[391634] = {
			["source"] = "Glacial Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190403,
		},
		[106864] = {
			["encounterName"] = "Liu Flameheart",
			["source"] = "Liu Flameheart",
			["encounterID"] = 1416,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56732,
		},
		[378847] = {
			["source"] = "Qalashi Spinecrusher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192787,
		},
		[209628] = {
			["encounterName"] = "Advisor Melandrus",
			["source"] = "Advisor Melandrus",
			["encounterID"] = 1870,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104218,
		},
		[369129] = {
			["source"] = "Modak Flamespit",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186509,
		},
		[388822] = {
			["encounterName"] = "Echo of Doragosa",
			["source"] = "Echo of Doragosa",
			["encounterID"] = 2565,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190609,
		},
		[373733] = {
			["encounterName"] = "Chargath, Bane of Scales",
			["source"] = "Chargath, Bane of Scales",
			["encounterID"] = 2613,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189340,
		},
		[377204] = {
			["encounterName"] = "Warlord Sargha",
			["source"] = "Warlord Sargha",
			["encounterID"] = 2611,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189901,
		},
		[383452] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Snowscruff Bakar",
			["npcID"] = 193401,
		},
		[192307] = {
			["encounterName"] = "Hyrja",
			["source"] = "Hyrja",
			["encounterID"] = 1806,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95833,
		},
		[387049] = {
			["source"] = "Bouldron",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193644,
		},
		[391613] = {
			["source"] = "Subterranean Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190404,
		},
		[384476] = {
			["source"] = "Nokhud Longbow",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192789,
		},
		[381663] = {
			["source"] = "Apex Blazewing",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193291,
		},
		[378850] = {
			["source"] = "Arcane Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190780,
		},
		[391382] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Volatile Infuser",
			["npcID"] = 197671,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[372201] = {
			["source"] = "Qalashi Irontorch",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189464,
		},
		[106797] = {
			["encounterName"] = "Liu Flameheart",
			["source"] = "Liu Flameheart",
			["encounterID"] = 1416,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56732,
		},
		[386012] = {
			["source"] = "Stormcaller Boroo",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194317,
		},
		[392406] = {
			["source"] = "Storm Warrior",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197982,
		},
		[396640] = {
			["encounterName"] = "Overgrown Ancient",
			["source"] = "Ancient Branch",
			["encounterID"] = 2563,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196548,
		},
		[397010] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Qalashi Honor Guard",
			["npcID"] = 197147,
		},
		[386660] = {
			["encounterName"] = "Leymor",
			["source"] = "Leymor",
			["encounterID"] = 2582,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186644,
		},
		[369901] = {
			["source"] = "Smoldering Feather",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186965,
		},
		[393686] = {
			["source"] = "Turboris",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187886,
		},
		[397011] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Qalashi Honor Guard",
			["npcID"] = 197147,
		},
		[387037] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Revenant",
			["npcID"] = 195917,
		},
		[372971] = {
			["source"] = "Qalashi Blacksmith",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189471,
		},
		[382434] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[188404] = {
			["encounterName"] = "Hymdall",
			["source"] = "Storm Drake",
			["encounterID"] = 1805,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97788,
		},
		[386015] = {
			["source"] = "Primalist Stormspeaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194894,
		},
		[393432] = {
			["source"] = "Refti Defender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190340,
		},
		[392665] = {
			["source"] = "Time-Lost Thunderhide",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187258,
		},
		[391898] = {
			["source"] = "Mistyvale Firestarter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193969,
		},
		[157331] = {
			["source"] = "Primal Storm Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 77942,
		},
		[386921] = {
			["encounterName"] = "Granyth",
			["source"] = "Dragonkiller Lance",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194367,
		},
		[395872] = {
			["source"] = "The Talking Fish",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59546,
		},
		[397014] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Qalashi Emissary",
			["npcID"] = 197146,
		},
		[198959] = {
			["source"] = "Valarjar Runecarver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96664,
		},
		[392411] = {
			["source"] = "Tsokorg",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195417,
		},
		[398300] = {
			["source"] = "Shambling Infester",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200387,
		},
		[376943] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Dathea, Ascended",
			["npcID"] = 189813,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[374765] = {
			["source"] = "Ravine Vulture",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190943,
		},
		[387297] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Sundered Runebinder",
			["npcID"] = 186354,
		},
		[397783] = {
			["encounterName"] = "Wise Mari",
			["source"] = "Wise Mari",
			["encounterID"] = 1418,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56448,
		},
		[392924] = {
			["source"] = "High Channeler Ryvati",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197535,
		},
		[381430] = {
			["source"] = "Pitchstone Rumbler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188014,
		},
		[198892] = {
			["source"] = "Storm Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97068,
		},
		[376279] = {
			["encounterName"] = "Terros",
			["source"] = "Terros",
			["npcID"] = 190496,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2639,
		},
		[209378] = {
			["source"] = "Imacu'tya",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104275,
		},
		[398296] = {
			["source"] = "Shambling Infester",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200387,
		},
		[392414] = {
			["source"] = "Tsokorg",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195417,
		},
		[377609] = {
			["source"] = "Worldbreaker Guard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185594,
		},
		[392926] = {
			["source"] = "Flickering Ember",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197906,
		},
		[391136] = {
			["source"] = "Drakonid Breaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187240,
		},
		[381683] = {
			["source"] = "Nokhud Warspear",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192791,
		},
		[381681] = {
			["source"] = "Rustpine Immolator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187396,
		},
		[392927] = {
			["source"] = "Yaankhi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195101,
		},
		[208165] = {
			["encounterName"] = "Talixae Flamewreath",
			["source"] = "Talixae Flamewreath",
			["encounterID"] = 1869,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104217,
		},
		[371956] = {
			["source"] = "Primal Terrasentry",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188011,
		},
		[372082] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["encounterID"] = 2592,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187967,
		},
		[381701] = {
			["source"] = "Entranced Water Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185490,
		},
		[369921] = {
			["source"] = "Blazing Firesquall",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195448,
		},
		[378222] = {
			["source"] = "Cascade Swog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191561,
		},
		[372851] = {
			["encounterName"] = "Melidrussa Chillworn",
			["source"] = "Melidrussa Chillworn",
			["encounterID"] = 2609,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188252,
		},
		[396774] = {
			["source"] = "Klozicc the Ascended",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187209,
		},
		[386024] = {
			["source"] = "Primalist Stormspeaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194894,
		},
		[397914] = {
			["source"] = "Depraved Mistweaver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200137,
		},
		[387559] = {
			["encounterName"] = "Primal Tsunami",
			["source"] = "Primal Tsunami",
			["encounterID"] = 2618,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189729,
		},
		[377594] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[372223] = {
			["source"] = "Qalashi Bonetender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189265,
		},
		[395488] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Pipspark Thundersnap",
			["npcID"] = 193684,
		},
		[211299] = {
			["source"] = "Watchful Inquisitor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 105715,
		},
		[376827] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[386026] = {
			["source"] = "Unstable Squall",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194895,
		},
		[395489] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Karantun",
			["npcID"] = 193647,
		},
		[384492] = {
			["source"] = "Nokhud Beastmaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192794,
		},
		[396001] = {
			["source"] = "The Songbird Queen",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59553,
		},
		[388706] = {
			["source"] = "Invading Storm Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191235,
		},
		[387427] = {
			["source"] = "Arcane Commander",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190776,
		},
		[384493] = {
			["source"] = "Shikaar Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191065,
		},
		[377341] = {
			["source"] = "Aqua Rager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190407,
		},
		[386028] = {
			["source"] = "Primalist Thunderbeast",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195696,
		},
		[392686] = {
			["source"] = "Diluu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195431,
		},
		[207980] = {
			["source"] = "Baalgar the Watchful",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104274,
		},
		[372474] = {
			["source"] = "Nokhud Fighter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187297,
		},
		[372730] = {
			["source"] = "Primal Juggernaut",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188244,
		},
		[375296] = {
			["source"] = "Mistyvale Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193948,
		},
		[387564] = {
			["source"] = "Conjured Lasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196102,
		},
		[387317] = {
			["source"] = "Mistyvale Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193970,
		},
		[374020] = {
			["source"] = "Containment Apparatus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190342,
		},
		[199674] = {
			["source"] = "King Bjorn",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97081,
		},
		[371976] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["encounterID"] = 2592,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187967,
		},
		[394982] = {
			["source"] = "Crystalized Steelshard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188048,
		},
		[392284] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Wild Proto-Dragon",
			["npcID"] = 194091,
		},
		[373614] = {
			["source"] = "Blazebound Destroyer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190034,
		},
		[396020] = {
			["source"] = "The Golden Beetle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59545,
		},
		[392539] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Awakened Terrasentry",
			["npcID"] = 197801,
		},
		[374892] = {
			["source"] = "Highland Mammoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194307,
		},
		[396786] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Rimebound Controller",
			["npcID"] = 191654,
		},
		[372222] = {
			["encounterName"] = "Azureblade",
			["source"] = "Azureblade",
			["encounterID"] = 2585,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186739,
		},
		[391915] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cragsworn Stoneshaper",
			["npcID"] = 191661,
		},
		[395240] = {
			["source"] = "Enkine the Voracious",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193134,
		},
		[388335] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Sundered Runebinder",
			["npcID"] = 186354,
		},
		[396775] = {
			["source"] = "Klozicc the Ascended",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187209,
		},
		[389870] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Colossal Stormfiend",
			["npcID"] = 197145,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[395241] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Voltweaver",
			["npcID"] = 198868,
		},
		[396520] = {
			["source"] = "Rumbling Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187212,
		},
		[386546] = {
			["source"] = "Arcane Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186741,
		},
		[389725] = {
			["source"] = "Bazual",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193532,
		},
		[207979] = {
			["source"] = "Jazshariu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104273,
		},
		[199034] = {
			["source"] = "Valarjar Aspirant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 101637,
		},
		[372225] = {
			["source"] = "Qalashi Bonesplitter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189467,
		},
		[387826] = {
			["source"] = "Ukhel Beastcaller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195878,
		},
		[376829] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[51963] = {
			["encounterName"] = "Eranog",
			["source"] = "Ebon Gargoyle",
			["npcID"] = 27829,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[372226] = {
			["source"] = "Qalashi Bonetender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189265,
		},
		[389213] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Flame Guardian",
			["npcID"] = 192764,
		},
		[401382] = {
			["source"] = "Past Self",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185800,
		},
		[376063] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Smoldering Hellion",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191510,
		},
		[395756] = {
			["source"] = "Qalashi Flameslinger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196336,
		},
		[390897] = {
			["source"] = "Scalepiercer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186632,
		},
		[384095] = {
			["source"] = "Ohuna Companion",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194254,
		},
		[395501] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Volatile Infuser",
			["npcID"] = 192934,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[385024] = {
			["source"] = "Russet Mudwalker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189841,
		},
		[388862] = {
			["source"] = "Corrupted Manafiend",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196045,
		},
		[193659] = {
			["encounterName"] = "God-King Skovald",
			["source"] = "God-King Skovald",
			["encounterID"] = 1808,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95675,
		},
		[379134] = {
			["source"] = "Rumbling Primalist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187172,
		},
		[377344] = {
			["source"] = "Territorial Eagle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192329,
		},
		[384761] = {
			["encounterName"] = "The Raging Tempest",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186615,
		},
		[198263] = {
			["encounterName"] = "Odyn",
			["source"] = "Odyn",
			["encounterID"] = 1809,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95676,
		},
		[378112] = {
			["source"] = "Nibbling Hornswog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189026,
		},
		[375580] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Dathea, Ascended",
			["npcID"] = 189813,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[387843] = {
			["source"] = "Spectral Invoker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196202,
		},
		[383237] = {
			["source"] = "Provoking Flame",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188697,
		},
		[393458] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Malifron",
			["npcID"] = 190278,
		},
		[381438] = {
			["source"] = "Hissing Springsoul",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191712,
		},
		[374533] = {
			["encounterName"] = "Forgemaster Gorek",
			["source"] = "Forgemaster Gorek",
			["encounterID"] = 2612,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189478,
		},
		[374789] = {
			["encounterName"] = "Leymor",
			["source"] = "Leymor",
			["encounterID"] = 2582,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186644,
		},
		[374022] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[388882] = {
			["source"] = "Infuser Sariya",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190405,
		},
		[392280] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Kaurdyth",
			["npcID"] = 197835,
		},
		[380174] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[391414] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Borzgas",
			["npcID"] = 193896,
		},
		[386555] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Dathea Stormlash",
			["npcID"] = 187768,
		},
		[396018] = {
			["source"] = "The Crybaby Hozen",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59552,
		},
		[387067] = {
			["source"] = "Arcane Construct",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186740,
		},
		[383231] = {
			["source"] = "Qalashi Lavamancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193944,
		},
		[395763] = {
			["source"] = "Qalashi Flameslinger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196336,
		},
		[396019] = {
			["source"] = "The Golden Beetle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59545,
		},
		[382561] = {
			["source"] = "Snowhide Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189654,
		},
		[376851] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Dathea, Ascended",
			["npcID"] = 189813,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[392279] = {
			["source"] = "Wild Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194089,
		},
		[397043] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cyclas",
			["npcID"] = 199029,
		},
		[386059] = {
			["source"] = "Basrikron",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193535,
		},
		[59638] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mirror Image",
			["npcID"] = 31216,
		},
		[387083] = {
			["source"] = "Time-Lost Briarback",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187264,
		},
		[199050] = {
			["source"] = "Valarjar Shieldmaiden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95832,
		},
		[395254] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Tempestmaker",
			["npcID"] = 198878,
		},
		[376073] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[386559] = {
			["encounterName"] = "Khajin the Unyielding",
			["source"] = "Khajin the Unyielding",
			["encounterID"] = 2617,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189727,
		},
		[377608] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Frigellus",
			["npcID"] = 189217,
		},
		[392870] = {
			["source"] = "Yamakh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195283,
		},
		[378120] = {
			["source"] = "Unstable Rock",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192799,
		},
		[371306] = {
			["source"] = "Arcane Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186741,
		},
		[396023] = {
			["encounterName"] = "Eranog",
			["source"] = "Eranog",
			["npcID"] = 184972,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[165193] = {
			["source"] = "Anchorite Valest",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 81101,
		},
		[371983] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["npcID"] = 187967,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2592,
		},
		[374045] = {
			["source"] = "Containment Apparatus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190342,
		},
		[372495] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ensnaring Current",
			["npcID"] = 191328,
		},
		[374797] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Windblessed Ohuna",
			["npcID"] = 188088,
		},
		[371984] = {
			["source"] = "Flashfrost Chillweaver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188067,
		},
		[385883] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Forge-Keep Custodian",
			["npcID"] = 192703,
		},
		[397048] = {
			["source"] = "Frostbreath Arachnid",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 199333,
		},
		[395857] = {
			["source"] = "Oppressive Artificer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184444,
		},
		[369442] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Karantun",
			["npcID"] = 193647,
		},
		[374885] = {
			["source"] = "Astral Attendant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189555,
		},
		[377612] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[157355] = {
			["source"] = "Voidseer Kalurg",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 83385,
		},
		[385574] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[157772] = {
			["source"] = "Voidseer Kalurg",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 83385,
		},
		[390912] = {
			["source"] = "Vile Lasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197219,
		},
		[396367] = {
			["source"] = "Decayed Elder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197142,
		},
		[375056] = {
			["encounterName"] = "Chargath, Bane of Scales",
			["source"] = "Chargath, Bane of Scales",
			["encounterID"] = 2613,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189340,
		},
		[394749] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Unstable Storm",
			["npcID"] = 198716,
		},
		[397051] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cyclas",
			["npcID"] = 199029,
		},
		[188046] = {
			["source"] = "Denizen of the Dream",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 198489,
		},
		[394512] = {
			["source"] = "Void Spawn",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75652,
		},
		[381721] = {
			["source"] = "Ravenous Bloodbeak",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185350,
		},
		[390988] = {
			["source"] = "Enkine the Voracious",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193134,
		},
		[199805] = {
			["source"] = "Stormforged Sentinel",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96574,
		},
		[381525] = {
			["encounterName"] = "Kyrakka and Erkhart Stormvein",
			["source"] = "Kyrakka",
			["encounterID"] = 2623,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190484,
		},
		[379406] = {
			["source"] = "Qalashi Lavabearer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189472,
		},
		[369193] = {
			["source"] = "Worldbreaker Shapist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185593,
		},
		[392194] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[377105] = {
			["source"] = "Vault Guard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190510,
		},
		[375591] = {
			["source"] = "Bubbling Sapling",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191313,
		},
		[390916] = {
			["source"] = "Melkhop",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193311,
		},
		[193668] = {
			["encounterName"] = "God-King Skovald",
			["source"] = "God-King Skovald",
			["encounterID"] = 1808,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95675,
		},
		[392451] = {
			["source"] = "Flame Channeler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197985,
		},
		[385068] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Colossal Stormfiend",
			["npcID"] = 197145,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[373034] = {
			["source"] = "Mudfin Mudrunner",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186690,
		},
		[390150] = {
			["source"] = "Wyrmeater",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186612,
		},
		[369946] = {
			["source"] = "Boneshaper Jardak",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188693,
		},
		[384524] = {
			["encounterName"] = "Watcher Irideus",
			["source"] = "Watcher Irideus",
			["encounterID"] = 2615,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189719,
		},
		[387849] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Dathea, Ascended",
			["npcID"] = 189813,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[385036] = {
			["source"] = "Primalist Galesinger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190373,
		},
		[396819] = {
			["source"] = "Fuming Ice Burrower",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197177,
		},
		[377384] = {
			["source"] = "Aqua Rager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190407,
		},
		[392272] = {
			["source"] = "Shortcoat Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195198,
		},
		[384014] = {
			["encounterName"] = "Watcher Irideus",
			["source"] = "Watcher Irideus",
			["encounterID"] = 2615,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189719,
		},
		[373017] = {
			["encounterName"] = "Kokia Blazehoof",
			["source"] = "Blazebound Firestorm",
			["encounterID"] = 2606,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189886,
		},
		[377383] = {
			["source"] = "Alpha Eagle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192333,
		},
		[375575] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Dragonspawn Flamebender",
			["npcID"] = 191230,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[207261] = {
			["encounterName"] = "Patrol Captain Gerdo",
			["source"] = "Patrol Captain Gerdo",
			["encounterID"] = 1868,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104215,
		},
		[392455] = {
			["source"] = "Yamakh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195283,
		},
		[387596] = {
			["source"] = "Risen Mystic",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195877,
		},
		[388911] = {
			["source"] = "Spellbound Battleaxe",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196577,
		},
		[392733] = {
			["source"] = "Towering Fickleshells",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193389,
		},
		[388383] = {
			["source"] = "Iskaara Defender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186431,
		},
		[385551] = {
			["encounterName"] = "Gulping Goliath",
			["source"] = "Gulping Goliath",
			["encounterID"] = 2616,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189722,
		},
		[209410] = {
			["source"] = "Duskwatch Arcanist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104247,
		},
		[386063] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186338,
		},
		[387411] = {
			["source"] = "Soulharvester Galtmaa",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195927,
		},
		[396805] = {
			["source"] = "Gorger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192759,
		},
		[391247] = {
			["source"] = "Bazual",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193532,
		},
		[375834] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[387343] = {
			["source"] = "Bouldron",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193644,
		},
		[385553] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Stormseeker Acolyte",
			["npcID"] = 194990,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[374361] = {
			["encounterName"] = "Echo of Doragosa",
			["source"] = "Echo of Doragosa",
			["encounterID"] = 2565,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190609,
		},
		[384597] = {
			["source"] = "Qalashi Warden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193293,
		},
		[375068] = {
			["encounterName"] = "Magmatusk",
			["source"] = "Lava Tentacles",
			["encounterID"] = 2610,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190023,
		},
		[388623] = {
			["encounterName"] = "Overgrown Ancient",
			["source"] = "Overgrown Ancient",
			["encounterID"] = 2563,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196482,
		},
		[391948] = {
			["source"] = "Sulfuric Rager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191682,
		},
		[395273] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Stormsentry",
			["npcID"] = 196856,
		},
		[396552] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Magmas",
			["npcID"] = 199027,
		},
		[373279] = {
			["source"] = "Thing From Beyond",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189988,
		},
		[387410] = {
			["source"] = "Scalesmith Mita",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191010,
		},
		[385108] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Restless Podling",
			["npcID"] = 187317,
		},
		[388944] = {
			["source"] = "Cascade",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186962,
		},
		[397338] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Tectonic Crusher",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190588,
		},
		[385812] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Volatile Infuser",
			["npcID"] = 192934,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[387091] = {
			["source"] = "Time-Lost Sunseeker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187239,
		},
		[385363] = {
			["source"] = "Maneet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188704,
		},
		[370212] = {
			["source"] = "Qalashi Wallcrasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187813,
		},
		[156718] = {
			["source"] = "Monstrous Corpse Spider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 76104,
		},
		[31707] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Wasserelementar",
			["npcID"] = 78116,
		},
		[382233] = {
			["source"] = "Batak",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193462,
		},
		[378397] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Earthshard",
			["npcID"] = 185647,
		},
		[396044] = {
			["encounterName"] = "Melidrussa Chillworn",
			["source"] = "Melidrussa Chillworn",
			["encounterID"] = 2609,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188252,
		},
		[104318] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Wild Imp",
			["npcID"] = 55659,
		},
		[373027] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["npcID"] = 187967,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2592,
		},
		[396812] = {
			["source"] = "Spellbound Scepter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196576,
		},
		[396316] = {
			["source"] = "Nokhud Huntmaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185353,
		},
		[375388] = {
			["source"] = "Mistyvale Splashcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193973,
		},
		[378143] = {
			["source"] = "Primalist Infiltrator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189895,
		},
		[198944] = {
			["source"] = "Valarjar Shieldmaiden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95832,
		},
		[374563] = {
			["source"] = "Dazzling Dragonfly",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190362,
		},
		[376865] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[153395] = {
			["source"] = "Carrion Worm",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 76057,
		},
		[372262] = {
			["source"] = "Qalashi Bonesplitter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189467,
		},
		[388886] = {
			["source"] = "Spellbound Scepter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196576,
		},
		[372279] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Dathea Stormlash",
			["npcID"] = 187768,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[396559] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Raszageth",
			["npcID"] = 199031,
		},
		[388942] = {
			["source"] = "Arcane Ravager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196671,
		},
		[382749] = {
			["source"] = "Alpha Cascade Swog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197400,
		},
		[153268] = {
			["source"] = "Shadowmoon Exhumer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 77700,
		},
		[386640] = {
			["source"] = "Tarasek Looter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187242,
		},
		[153524] = {
			["source"] = "Plagued Bat",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75459,
		},
		[390934] = {
			["source"] = "Melkhop",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193311,
		},
		[385065] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[385578] = {
			["encounterName"] = "Azureblade",
			["source"] = "Azureblade",
			["encounterID"] = 2585,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186739,
		},
		[385339] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186338,
		},
		[391958] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cloying Gale",
			["npcID"] = 198126,
		},
		[374823] = {
			["source"] = "Squallbringer Cyraz",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190370,
		},
		[375079] = {
			["source"] = "Squallbringer Cyraz",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190370,
		},
		[369197] = {
			["source"] = "Dragonbane Firebinder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186599,
		},
		[156722] = {
			["source"] = "Shadowmoon Exhumer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 77700,
		},
		[224375] = {
			["encounterName"] = "Talixae Flamewreath",
			["source"] = "Infernal Imp",
			["npcID"] = 112668,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 1869,
		},
		[317792] = {
			["encounterName"] = "Eranog",
			["source"] = "Magus of the Dead",
			["npcID"] = 163366,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[388635] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Volatile Spark",
			["npcID"] = 194999,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[378420] = {
			["source"] = "Provoked Geode",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189040,
		},
		[394262] = {
			["source"] = "Cygenoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185660,
		},
		[378150] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Molten Primalist",
			["npcID"] = 186825,
		},
		[395797] = {
			["source"] = "Primalist Frostsculptor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 198424,
		},
		[164907] = {
			["source"] = "Reanimated Ritual Bones",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75715,
		},
		[373803] = {
			["encounterName"] = "Melidrussa Chillworn",
			["source"] = "Infused Whelp",
			["encounterID"] = 2609,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189893,
		},
		[372828] = {
			["source"] = "Mudfin Shaman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186679,
		},
		[387614] = {
			["source"] = "Ukhel Deathspeaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195851,
		},
		[387629] = {
			["source"] = "Desecrated Ohuna",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195876,
		},
		[391195] = {
			["source"] = "Bisquius",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197557,
		},
		[191401] = {
			["source"] = "Valarjar Marksman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96640,
		},
		[385569] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[373549] = {
			["source"] = "Proto Dragonfly",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193302,
		},
		[374073] = {
			["source"] = "Primalist Geomancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190345,
		},
		[200969] = {
			["source"] = "King Tor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97084,
		},
		[396823] = {
			["source"] = "Fuming Ice Burrower",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197177,
		},
		[192018] = {
			["encounterName"] = "Hyrja",
			["source"] = "Hyrja",
			["encounterID"] = 1806,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95833,
		},
		[377411] = {
			["source"] = "Nimblewing Striker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192938,
		},
		[384292] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Thunder Caller",
			["npcID"] = 194647,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[394816] = {
			["source"] = "Fuming Ice Burrower",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197177,
		},
		[375384] = {
			["source"] = "Primalist Earthshaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190371,
		},
		[396327] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Glacias",
			["npcID"] = 199028,
		},
		[377402] = {
			["source"] = "Infuser Sariya",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190405,
		},
		[396825] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Rimebound Controller",
			["npcID"] = 195836,
		},
		[395035] = {
			["source"] = "Soulharvester Galtmaa",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195927,
		},
		[377900] = {
			["source"] = "Qalashi Skullhauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 199298,
		},
		[377658] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[377389] = {
			["source"] = "Alpha Eagle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192333,
		},
		[191508] = {
			["source"] = "Valarjar Aspirant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 101637,
		},
		[209027] = {
			["source"] = "Duskwatch Guard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104246,
		},
		[382249] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Trickclaw Mystic",
			["npcID"] = 185528,
		},
		[388643] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[387659] = {
			["source"] = "Yaankhi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195101,
		},
		[385063] = {
			["source"] = "Primalist Cinderweaver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190207,
		},
		[384296] = {
			["source"] = "Ayanga",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192961,
		},
		[391726] = {
			["source"] = "Thunderhead",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197698,
		},
		[376892] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[396317] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Loamas",
			["npcID"] = 199030,
		},
		[375871] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[395819] = {
			["source"] = "Qalashi Scaleripper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187602,
		},
		[57984] = {
			["source"] = "Greater Fire Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95061,
		},
		[397341] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[198934] = {
			["source"] = "Valarjar Mystic",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95834,
		},
		[396605] = {
			["source"] = "Rapid Wooly Ewe",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197200,
		},
		[381519] = {
			["source"] = "Tarasek Warrior",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187352,
		},
		[224374] = {
			["encounterName"] = "Talixae Flamewreath",
			["source"] = "Infernal Imp",
			["npcID"] = 112668,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 1869,
		},
		[373046] = {
			["encounterName"] = "Melidrussa Chillworn",
			["source"] = "Melidrussa Chillworn",
			["encounterID"] = 2609,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188252,
		},
		[375348] = {
			["source"] = "Gusting Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190401,
		},
		[209413] = {
			["source"] = "Guardian Construct",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104270,
		},
		[388424] = {
			["encounterName"] = "Primal Tsunami",
			["source"] = "Primal Tsunami",
			["encounterID"] = 2618,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189729,
		},
		[388392] = {
			["source"] = "Unruly Textbook",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196044,
		},
		[382277] = {
			["source"] = "Balara",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193457,
		},
		[375605] = {
			["source"] = "Arcane Golem",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190779,
		},
		[394275] = {
			["source"] = "Cygenoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185660,
		},
		[375094] = {
			["source"] = "Swiftfoot Tallstrider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195366,
		},
		[118905] = {
			["source"] = "Capacitor Totem",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 61245,
		},
		[372311] = {
			["source"] = "Qalashi Trainee",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189266,
		},
		[374839] = {
			["encounterName"] = "Forgemaster Gorek",
			["source"] = "Forgemaster Gorek",
			["encounterID"] = 2612,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189478,
		},
		[392486] = {
			["source"] = "Tempest Channeler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 198047,
		},
		[395811] = {
			["source"] = "Qalashi Bonebreakers",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187599,
		},
		[390952] = {
			["source"] = "Grand Flame",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188009,
		},
		[391998] = {
			["source"] = "Magmaticus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196599,
		},
		[372027] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Embar Firepath",
			["npcID"] = 187767,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[396348] = {
			["source"] = "Parched Shortcoat Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195248,
		},
		[372539] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Sennarth",
			["npcID"] = 187967,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2592,
		},
		[382002] = {
			["source"] = "Apex Blazewing",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193291,
		},
		[373051] = {
			["source"] = "Mudfin Salamancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186669,
		},
		[396836] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Colossal Glacier",
			["npcID"] = 194798,
		},
		[396069] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Earthshard",
			["npcID"] = 185647,
		},
		[394802] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Council Stormcaller",
			["npcID"] = 198502,
		},
		[372310] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Spellwrought Snowman",
			["npcID"] = 193238,
		},
		[377923] = {
			["source"] = "Bound Spark",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186624,
		},
		[377927] = {
			["source"] = "Smoldering Feather",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192690,
		},
		[377912] = {
			["source"] = "Guardian Sentry",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192680,
		},
		[388923] = {
			["encounterName"] = "Overgrown Ancient",
			["source"] = "Overgrown Ancient",
			["encounterID"] = 2563,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196482,
		},
		[391723] = {
			["source"] = "Flamegullet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197697,
		},
		[396071] = {
			["source"] = "Decayed Elder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197142,
		},
		[209033] = {
			["source"] = "Duskwatch Guard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104246,
		},
		[396861] = {
			["source"] = "Arcane Golem",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190779,
		},
		[395816] = {
			["source"] = "Qalashi Wallcrasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187813,
		},
		[154175] = {
			["encounterName"] = "Bonemaw",
			["source"] = "Bonemaw",
			["encounterID"] = 1679,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75452,
		},
		[385075] = {
			["encounterName"] = "Umbrelskul",
			["source"] = "Umbrelskul",
			["encounterID"] = 2584,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186738,
		},
		[368984] = {
			["source"] = "Zhurtan the Riverboiler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188687,
		},
		[369751] = {
			["source"] = "Qalashi Necksnapper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186109,
		},
		[386866] = {
			["source"] = "Gorging Stagbeetle",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195709,
		},
		[387122] = {
			["source"] = "Arcane Construct",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186740,
		},
		[391470] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Piton",
			["npcID"] = 194464,
		},
		[393772] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Hihveer",
			["npcID"] = 188717,
		},
		[211464] = {
			["source"] = "Felbound Enforcer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104278,
		},
		[375870] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[374080] = {
			["source"] = "Primalist Ravager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190348,
		},
		[378428] = {
			["source"] = "Turboris",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187886,
		},
		[396075] = {
			["source"] = "Raging Torrent",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197221,
		},
		[392239] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Plainswalker Mammoth",
			["npcID"] = 190906,
		},
		[373327] = {
			["encounterName"] = "Eranog",
			["source"] = "Primal Flame",
			["npcID"] = 187593,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[397109] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stormbound Colossus",
			["npcID"] = 187843,
		},
		[384823] = {
			["encounterName"] = "Kokia Blazehoof",
			["source"] = "Blazebound Firestorm",
			["encounterID"] = 2606,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189886,
		},
		[387125] = {
			["source"] = "Primalist Thunderbeast",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195696,
		},
		[373059] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Kadros Icewrath",
			["npcID"] = 187771,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[389949] = {
			["source"] = "Teerai Battlemaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191494,
		},
		[397100] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Magmas",
			["npcID"] = 199027,
		},
		[369750] = {
			["source"] = "Qalashi Scaleripper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187602,
		},
		[393520] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Ceeqa the Peacetaker",
			["npcID"] = 188708,
		},
		[374339] = {
			["source"] = "Refti Defender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190340,
		},
		[396078] = {
			["source"] = "Consuming Upswell",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188672,
		},
		[398380] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Seismodor, Earth's Wrath",
			["npcID"] = 199664,
		},
		[209676] = {
			["encounterName"] = "Advisor Melandrus",
			["source"] = "Advisor Melandrus",
			["encounterID"] = 1870,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104218,
		},
		[394800] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Council Earthcaller",
			["npcID"] = 198500,
		},
		[388918] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[397358] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[377154] = {
			["source"] = "Scythid Stalker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197198,
		},
		[389686] = {
			["source"] = "Crystal Fury",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187160,
		},
		[372047] = {
			["source"] = "Defier Draghar",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187897,
		},
		[192158] = {
			["encounterName"] = "Hyrja",
			["source"] = "Olmyr the Enlightened",
			["encounterID"] = 1806,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97202,
		},
		[384316] = {
			["encounterName"] = "The Raging Tempest",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186615,
		},
		[372296] = {
			["source"] = "Irontorch Commander",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189466,
		},
		[376644] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[372808] = {
			["encounterName"] = "Melidrussa Chillworn",
			["source"] = "Melidrussa Chillworn",
			["encounterID"] = 2609,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188252,
		},
		[387652] = {
			["source"] = "Frozen Revenant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187203,
		},
		[393780] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Flame Guardian",
			["npcID"] = 192764,
		},
		[193826] = {
			["encounterName"] = "God-King Skovald",
			["source"] = "God-King Skovald",
			["encounterID"] = 1808,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95675,
		},
		[393787] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Iskakx",
			["npcID"] = 192761,
		},
		[388410] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Dathea, Ascended",
			["npcID"] = 189813,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[393781] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Flame Guardian",
			["npcID"] = 192764,
		},
		[382791] = {
			["source"] = "Qalashi Lavamancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193944,
		},
		[370764] = {
			["source"] = "Crystal Fury",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187160,
		},
		[387388] = {
			["source"] = "Worldbreaker Cultist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185595,
		},
		[215433] = {
			["source"] = "Valarjar Mystic",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95834,
		},
		[396084] = {
			["source"] = "Entranced Water Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185490,
		},
		[397881] = {
			["source"] = "Corrupt Living Water",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59873,
		},
		[192288] = {
			["encounterName"] = "Hyrja",
			["source"] = "Olmyr the Enlightened",
			["encounterID"] = 1806,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97202,
		},
		[393783] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Iskakx",
			["npcID"] = 192761,
		},
		[389947] = {
			["source"] = "Nokhud Dominator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193839,
		},
		[370766] = {
			["source"] = "Crystal Thrasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187139,
		},
		[383298] = {
			["source"] = "Summoned Lava Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 182815,
		},
		[390715] = {
			["encounterName"] = "Eranog",
			["source"] = "Eranog",
			["npcID"] = 184972,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[211470] = {
			["source"] = "Shadow Mistress",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104300,
		},
		[387135] = {
			["source"] = "Primalist Arcblade",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194898,
		},
		[375630] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Drakonid Stormbringer",
			["npcID"] = 191232,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[396854] = {
			["source"] = "Brutal Motivator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184453,
		},
		[397110] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stormbound Colossus",
			["npcID"] = 187843,
		},
		[397112] = {
			["source"] = "Acrosoth",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193243,
		},
		[396599] = {
			["source"] = "Rapid Wooly Ewe",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197200,
		},
		[397878] = {
			["source"] = "Corrupt Living Water",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59873,
		},
		[106823] = {
			["encounterName"] = "Liu Flameheart",
			["source"] = "Liu Flameheart",
			["encounterID"] = 1416,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56732,
		},
		[381512] = {
			["encounterName"] = "Kyrakka and Erkhart Stormvein",
			["source"] = "Erkhart Stormvein",
			["encounterID"] = 2623,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190485,
		},
		[396600] = {
			["source"] = "Rapid Wooly Ewe",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197200,
		},
		[396856] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Firava the Rekindler",
			["npcID"] = 195915,
		},
		[389951] = {
			["source"] = "Strunraan",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193534,
		},
		[391230] = {
			["source"] = "Bisquius",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197557,
		},
		[390463] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[370259] = {
			["source"] = "Crystalized Steelshard",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188048,
		},
		[372561] = {
			["source"] = "Qalashi Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189227,
		},
		[396346] = {
			["source"] = "Nokhud Dominator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193839,
		},
		[395833] = {
			["source"] = "Mara'nar the Thunderous",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196913,
		},
		[373329] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[391999] = {
			["source"] = "Nokhud Scavenger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185445,
		},
		[380487] = {
			["encounterName"] = "Terros",
			["source"] = "Terros",
			["npcID"] = 190496,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2639,
		},
		[377166] = {
			["encounterName"] = "Terros",
			["source"] = "Terros",
			["npcID"] = 190496,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2639,
		},
		[376399] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Wild Proto-Drake",
			["npcID"] = 194444,
		},
		[211473] = {
			["source"] = "Shadow Mistress",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104300,
		},
		[374865] = {
			["source"] = "Mountain Stonefang",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192644,
		},
		[394558] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Unstable Flame",
			["npcID"] = 198577,
		},
		[196512] = {
			["encounterName"] = "Fenryr",
			["source"] = "Fenryr",
			["encounterID"] = 1807,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95674,
		},
		[372045] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Caustic Spiderling",
			["encounterID"] = 2592,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189233,
		},
		[392257] = {
			["source"] = "Broadhoof Bull",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193385,
		},
		[387398] = {
			["source"] = "Worldbreaker Brute",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 185589,
		},
		[381516] = {
			["encounterName"] = "Kyrakka and Erkhart Stormvein",
			["source"] = "Erkhart Stormvein",
			["encounterID"] = 2623,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190485,
		},
		[387910] = {
			["source"] = "Algeth'ar Echoknight",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196200,
		},
		[374343] = {
			["encounterName"] = "Echo of Doragosa",
			["source"] = "Echo of Doragosa",
			["encounterID"] = 2565,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190609,
		},
		[154442] = {
			["encounterName"] = "Ner'zhul",
			["source"] = "Ner'zhul",
			["encounterID"] = 1682,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 76407,
		},
		[381517] = {
			["encounterName"] = "Kyrakka and Erkhart Stormvein",
			["source"] = "Erkhart Stormvein",
			["encounterID"] = 2623,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190485,
		},
		[372566] = {
			["source"] = "Qalashi Hunter",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189227,
		},
		[389431] = {
			["source"] = "Bazual",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193532,
		},
		[381765] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Rimebound Controller",
			["npcID"] = 191654,
		},
		[397886] = {
			["source"] = "Corrupt Droplet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 62358,
		},
		[387127] = {
			["source"] = "Primalist Thunderbeast",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195696,
		},
		[387145] = {
			["source"] = "Stormcaller Boroo",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194317,
		},
		[372056] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Opalfang",
			["npcID"] = 187772,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[382542] = {
			["source"] = "Raging Ice Burrower",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195012,
		},
		[390982] = {
			["source"] = "Qalashi Stonemender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187600,
		},
		[377661] = {
			["source"] = "Sparring Vorquin",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195048,
		},
		[393540] = {
			["source"] = "Zhurtan the Riverboiler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188687,
		},
		[397888] = {
			["source"] = "Fallen Waterspeaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200126,
		},
		[394795] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Stonewrecker Tokara",
			["npcID"] = 193442,
		},
		[398400] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Seismodor, Earth's Wrath",
			["npcID"] = 199664,
		},
		[396073] = {
			["source"] = "The Nodding Tiger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59544,
		},
		[397889] = {
			["source"] = "Fallen Waterspeaker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200126,
		},
		[383823] = {
			["source"] = "Nokhud Hornsounder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192796,
		},
		[396355] = {
			["source"] = "Tarasek Marauder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184461,
		},
		[395061] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Molka The Grinder",
			["npcID"] = 193443,
		},
		[372315] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Kadros Icewrath",
			["npcID"] = 187771,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[211477] = {
			["source"] = "Legion Hound",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104277,
		},
		[207881] = {
			["encounterName"] = "Talixae Flamewreath",
			["source"] = "Talixae Flamewreath",
			["encounterID"] = 1869,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104217,
		},
		[384336] = {
			["source"] = "Nokhud Plainstomper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191847,
		},
		[378454] = {
			["source"] = "Bouldron",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193644,
		},
		[372538] = {
			["source"] = "Lava Flare",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189470,
		},
		[398403] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Furious Earth",
			["npcID"] = 200431,
		},
		[373084] = {
			["source"] = "Irontorch Commander",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189466,
		},
		[397892] = {
			["source"] = "Imacu'tya",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104275,
		},
		[388941] = {
			["source"] = "Cascade",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186962,
		},
		[387151] = {
			["encounterName"] = "Telash Greywing",
			["source"] = "Telash Greywing",
			["encounterID"] = 2583,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186737,
		},
		[396614] = {
			["source"] = "Alpha Thornsided Basilisk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197352,
		},
		[374364] = {
			["encounterName"] = "Leymor",
			["source"] = "Leymor",
			["encounterID"] = 2582,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186644,
		},
		[395080] = {
			["source"] = "Enkine the Voracious",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193134,
		},
		[381521] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Encroaching Downpour",
			["npcID"] = 191324,
		},
		[374066] = {
			["source"] = "Primalist Geomancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190345,
		},
		[374365] = {
			["encounterName"] = "Magmatusk",
			["source"] = "Magmatusk",
			["encounterID"] = 2610,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 181861,
		},
		[398150] = {
			["source"] = "Shadowmoon Dominator",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 76446,
		},
		[396360] = {
			["source"] = "Tarasek Marauder",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184461,
		},
		[373087] = {
			["encounterName"] = "Kokia Blazehoof",
			["source"] = "Blazebound Firestorm",
			["encounterID"] = 2606,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189886,
		},
		[377435] = {
			["source"] = "Time-Lost Geomancer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187265,
		},
		[374622] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Thundering Ravager",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190690,
		},
		[390223] = {
			["source"] = "Flashfrost Tarasek",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187089,
		},
		[396617] = {
			["source"] = "Stormshroud Matriarch",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192534,
		},
		[394827] = {
			["source"] = "Windseeker Avash",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192045,
		},
		[374623] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Frozen Destroyer",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190686,
		},
		[116] = {
			["npcID"] = 188027,
		},
		[374112] = {
			["encounterName"] = "Sennarth, The Cold Breath",
			["source"] = "Frostbreath Arachnid",
			["encounterID"] = 2592,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189234,
		},
		[397897] = {
			["source"] = "Jazshariu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104273,
		},
		[374624] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Frozen Destroyer",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190686,
		},
		[270481] = {
			["source"] = "Demonic Tyrant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 135002,
		},
		[390938] = {
			["source"] = "Aggravated Skitterfly",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197406,
		},
		[387668] = {
			["source"] = "Awakened Crag",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195243,
		},
		[398154] = {
			["source"] = "Defiled Spirit",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75451,
		},
		[371812] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Menial Attendant",
			["npcID"] = 192702,
		},
		[375351] = {
			["source"] = "Glacial Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190403,
		},
		[397899] = {
			["source"] = "Sha-Touched Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200131,
		},
		[385310] = {
			["source"] = "Primalist Shockcaster",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195119,
		},
		[317791] = {
			["encounterName"] = "Eranog",
			["source"] = "Magus of the Dead",
			["npcID"] = 163366,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[374567] = {
			["encounterName"] = "Leymor",
			["source"] = "Leymor",
			["encounterID"] = 2582,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186644,
		},
		[382555] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Bracken Warscourge",
			["npcID"] = 185529,
		},
		[209404] = {
			["source"] = "Duskwatch Arcanist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104247,
		},
		[153680] = {
			["encounterName"] = "Bonemaw",
			["source"] = "Bonemaw",
			["encounterID"] = 1679,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75452,
		},
		[392530] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Quarry Infuser",
			["npcID"] = 197799,
		},
		[375327] = {
			["source"] = "Subterranean Proto-Dragon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190404,
		},
		[397134] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Opalfang",
			["npcID"] = 187772,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[393298] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Smoldering Colossus",
			["npcID"] = 188673,
		},
		[395784] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Raszageth",
			["npcID"] = 199031,
		},
		[394833] = {
			["source"] = "Auburntusk Bull",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195984,
		},
		[375652] = {
			["source"] = "Arcane Tender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196115,
		},
		[372839] = {
			["source"] = "Nokhud Raider",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193840,
		},
		[384291] = {
			["source"] = "Ayanga",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192961,
		},
		[381535] = {
			["source"] = "Animated Cindershards",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189875,
		},
		[375653] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Drakonid Stormbringer",
			["npcID"] = 191232,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[393750] = {
			["source"] = "Taresh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 188711,
		},
		[381280] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Uktulut Trainee",
			["npcID"] = 193204,
		},
		[397904] = {
			["source"] = "Sha-Touched Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 200131,
		},
		[387613] = {
			["source"] = "Ukhel Corruptor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195842,
		},
		[374038] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Embar Firepath",
			["npcID"] = 187767,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[3110] = {
			["source"] = "Pipnuk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 58959,
		},
		[395859] = {
			["source"] = "Haunting Sha",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59555,
		},
		[375331] = {
			["encounterName"] = "The Primal Council",
			["source"] = "Dathea Stormlash",
			["npcID"] = 187768,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2590,
		},
		[393302] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Smoldering Colossus",
			["npcID"] = 188673,
		},
		[383496] = {
			["source"] = "Strunraan",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193534,
		},
		[395860] = {
			["source"] = "Gargantuan Hornswog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191606,
		},
		[396807] = {
			["source"] = "Lost Armoredon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196272,
		},
		[383073] = {
			["encounterName"] = "Terros",
			["source"] = "Terros",
			["npcID"] = 190496,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2639,
		},
		[392957] = {
			["source"] = "Creekside Grazer",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191317,
		},
		[397907] = {
			["source"] = "Baalgar the Watchful",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104274,
		},
		[157348] = {
			["source"] = "Primal Storm Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 77942,
		},
		[388863] = {
			["source"] = "Corrupted Manafiend",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196045,
		},
		[376169] = {
			["source"] = "High Thaumaturge Fural",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189905,
		},
		[382563] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[199210] = {
			["source"] = "Valarjar Marksman",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96640,
		},
		[393305] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Earthwarden",
			["npcID"] = 193709,
		},
		[165578] = {
			["encounterName"] = "Bonemaw",
			["source"] = "Bonemaw",
			["encounterID"] = 1679,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75452,
		},
		[376426] = {
			["source"] = "Alora Mistbreeze",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189243,
		},
		[207906] = {
			["encounterName"] = "Talixae Flamewreath",
			["source"] = "Talixae Flamewreath",
			["encounterID"] = 1869,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104217,
		},
		[152792] = {
			["encounterName"] = "Nhallish",
			["source"] = "Nhallish",
			["encounterID"] = 1688,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 75829,
		},
		[376171] = {
			["source"] = "Primalist Icecaller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190377,
		},
		[385277] = {
			["source"] = "Crust Lurker",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192626,
		},
		[376683] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[393307] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Flamecaller",
			["npcID"] = 193558,
		},
		[374126] = {
			["source"] = "Bruffalon Bull",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195552,
		},
		[371313] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Blazing Manifestation",
			["npcID"] = 186336,
		},
		[384868] = {
			["source"] = "Nokhud Longbow",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192789,
		},
		[393308] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Flamecaller",
			["npcID"] = 193558,
		},
		[393454] = {
			["source"] = "Battlehorn Pyrhus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190986,
		},
		[393306] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Earthwarden",
			["npcID"] = 193709,
		},
		[378731] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Frigellus",
			["npcID"] = 189217,
		},
		[394731] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Unstable Earth",
			["npcID"] = 198709,
		},
		[191284] = {
			["encounterName"] = "Hymdall",
			["source"] = "Hymdall",
			["encounterID"] = 1805,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 94960,
		},
		[387683] = {
			["source"] = "Frozen Revenant",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187203,
		},
		[192563] = {
			["source"] = "Valarjar Purifier",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97197,
		},
		[375919] = {
			["source"] = "Streamside Scythid",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191469,
		},
		[382708] = {
			["source"] = "Qalashi Warden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193293,
		},
		[387684] = {
			["source"] = "Earthen Spire",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195348,
		},
		[373618] = {
			["source"] = "Hypnosis Bat",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190174,
		},
		[199341] = {
			["source"] = "Valarjar Trapper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96934,
		},
		[385383] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Forge-Keep Overseer",
			["npcID"] = 192699,
		},
		[371824] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Forge-Keep Overseer",
			["npcID"] = 192699,
		},
		[367481] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Claw Fighter",
			["npcID"] = 185508,
		},
		[374898] = {
			["source"] = "Parched Shortcoat Mauler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195248,
		},
		[396637] = {
			["source"] = "Alpha Mountain Stonefang",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197376,
		},
		[373364] = {
			["source"] = "Gerenth the Vile",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 107435,
		},
		[386547] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186339,
		},
		[372735] = {
			["source"] = "Flashfrost Earthshaper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187969,
		},
		[369157] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Tarasek",
			["npcID"] = 188372,
		},
		[395871] = {
			["source"] = "Qalashi Stonemender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187600,
		},
		[199726] = {
			["source"] = "King Ranulf",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97083,
		},
		[383084] = {
			["source"] = "Water Primalist",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190066,
		},
		[372087] = {
			["source"] = "Defier Draghar",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187897,
		},
		[267997] = {
			["source"] = "Vilefiend",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 135816,
		},
		[367484] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Claw Fighter",
			["npcID"] = 185508,
		},
		[396007] = {
			["source"] = "The Songbird Queen",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59553,
		},
		[386410] = {
			["encounterName"] = "Raszageth the Storm-Eater",
			["source"] = "Raszageth",
			["npcID"] = 189492,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2607,
		},
		[384620] = {
			["encounterName"] = "The Raging Tempest",
			["source"] = "The Raging Tempest",
			["encounterID"] = 2636,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186615,
		},
		[377532] = {
			["source"] = "Thunderspine Crasher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191057,
		},
		[377971] = {
			["source"] = "Baby Thresher",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197883,
		},
		[384365] = {
			["source"] = "Nokhud Plainstomper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 191847,
		},
		[391903] = {
			["source"] = "Ruby Warden",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190916,
		},
		[373742] = {
			["encounterName"] = "Chargath, Bane of Scales",
			["source"] = "Chargath, Bane of Scales",
			["encounterID"] = 2613,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189340,
		},
		[369788] = {
			["source"] = "Kerzanthi",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196973,
		},
		[387571] = {
			["encounterName"] = "Primal Tsunami",
			["source"] = "Primal Tsunami",
			["encounterID"] = 2618,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189729,
		},
		[390760] = {
			["source"] = "Chief Grrlgllmesh",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186678,
		},
		[375671] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Calving Elemental",
			["npcID"] = 189312,
		},
		[387039] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Nokhud Commander",
			["npcID"] = 195761,
		},
		[385390] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Forge-Keep Sentinel",
			["npcID"] = 192700,
		},
		[384623] = {
			["source"] = "Qalashi Blacksmith",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189471,
		},
		[386781] = {
			["encounterName"] = "Telash Greywing",
			["source"] = "Telash Greywing",
			["encounterID"] = 2583,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186737,
		},
		[396388] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Glacias",
			["npcID"] = 199028,
		},
		[395987] = {
			["source"] = "Jumping Spiderling",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 199182,
		},
		[388716] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Broodkeeper Diurna",
			["npcID"] = 190245,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[198888] = {
			["source"] = "Storm Drake",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 97068,
		},
		[125056] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Mammut",
			["npcID"] = 165189,
		},
		[198962] = {
			["source"] = "Valarjar Runecarver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 96664,
		},
		[395878] = {
			["source"] = "The Talking Fish",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 59546,
		},
		[387950] = {
			["source"] = "Caldera Stomper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187919,
		},
		[385137] = {
			["source"] = "Basrikron",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193535,
		},
		[396646] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Loamas",
			["npcID"] = 199030,
		},
		[391385] = {
			["source"] = "Summoned Lava Elemental",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 182815,
		},
		[382836] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Maruuk",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186338,
		},
		[372862] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primal Splash",
			["npcID"] = 185645,
		},
		[387440] = {
			["source"] = "Ukhel Beastcaller",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195878,
		},
		[375420] = {
			["source"] = "Mud Beaver",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193496,
		},
		[371584] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Embertooth Pooltender",
			["npcID"] = 187445,
		},
		[372863] = {
			["encounterName"] = "Kokia Blazehoof",
			["source"] = "Kokia Blazehoof",
			["encounterID"] = 2606,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189232,
		},
		[397801] = {
			["encounterName"] = "Wise Mari",
			["source"] = "Wise Mari",
			["encounterID"] = 1418,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 56448,
		},
		[214692] = {
			["source"] = "Gerenth the Vile",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 107435,
		},
		[388976] = {
			["source"] = "Arcane Ravager",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196671,
		},
		[303300] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Primalist Infuser",
			["npcID"] = 186112,
		},
		[386675] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Novice Timewalker",
			["npcID"] = 189583,
		},
		[370307] = {
			["encounterName"] = "Eranog",
			["source"] = "Eranog",
			["npcID"] = 184972,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2587,
		},
		[382670] = {
			["encounterName"] = "Teera and Maruuk",
			["source"] = "Teera",
			["encounterID"] = 2581,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186339,
		},
		[385141] = {
			["source"] = "Primalist Galesinger",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190373,
		},
		[389273] = {
			["source"] = "Wyrmeater",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186612,
		},
		[391791] = {
			["source"] = "Furious Deluge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197220,
		},
		[377502] = {
			["source"] = "Time-Lost Murloc",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190584,
		},
		[392130] = {
			["source"] = "Professor Maxdormu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189668,
		},
		[392640] = {
			["source"] = "Thunderhead",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197698,
		},
		[205231] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Darkglare",
			["npcID"] = 103673,
		},
		[383864] = {
			["source"] = "Magmaticus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196599,
		},
		[395427] = {
			["source"] = "Overseer Lahar",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189235,
		},
		[370054] = {
			["source"] = "Battlehorn Pyrhus",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190986,
		},
		[391793] = {
			["source"] = "Furious Deluge",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197220,
		},
		[392106] = {
			["source"] = "Diluu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 195431,
		},
		[375937] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[393584] = {
			["source"] = "Gladehorn Armoredon",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 196555,
		},
		[207278] = {
			["encounterName"] = "Patrol Captain Gerdo",
			["source"] = "Patrol Captain Gerdo",
			["encounterID"] = 1868,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 104215,
		},
		[373636] = {
			["source"] = "Mountain Stonefang",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192644,
		},
		[385145] = {
			["source"] = "Time-Lost Raptor",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187256,
		},
		[135029] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Wasserelementar",
			["npcID"] = 78116,
		},
		[377473] = {
			["encounterName"] = "Warlord Sargha",
			["source"] = "Warlord Sargha",
			["encounterID"] = 2611,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189901,
		},
		[371875] = {
			["source"] = "Qalashi Trainee",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189266,
		},
		[396925] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Qalashi Lavamancer",
			["npcID"] = 197149,
		},
		[372615] = {
			["source"] = "Tamed Phoenix",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189247,
		},
		[377512] = {
			["source"] = "Basalt Shell",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186622,
		},
		[367500] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Bracken Warscourge",
			["npcID"] = 185529,
		},
		[395377] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Thondrozus",
			["npcID"] = 192769,
		},
		[392349] = {
			["source"] = "Khuumog",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194761,
		},
		[378003] = {
			["source"] = "Guardian Sentry",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192680,
		},
		[389269] = {
			["source"] = "Expedition Guardian",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187123,
		},
		[398447] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Seismodor, Earth's Wrath",
			["npcID"] = 199664,
		},
		[395694] = {
			["source"] = "Primalist Shocktrooper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 199037,
		},
		[381602] = {
			["encounterName"] = "Kyrakka and Erkhart Stormvein",
			["source"] = "Kyrakka",
			["encounterID"] = 2623,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190484,
		},
		[385916] = {
			["encounterName"] = "Granyth",
			["source"] = "Granyth",
			["encounterID"] = 2637,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186616,
		},
		[392574] = {
			["source"] = "Tempest Channeler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 198047,
		},
		[374152] = {
			["source"] = "Alpha Thornsided Basilisk",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197352,
		},
		[384134] = {
			["source"] = "Nokhud Warspear",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192791,
		},
		[389247] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Blacktalon Avenger",
			["npcID"] = 187187,
		},
		[375943] = {
			["encounterName"] = "Balakar Khan",
			["source"] = "Balakar Khan",
			["encounterID"] = 2580,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 186151,
		},
		[396659] = {
			["source"] = "Stormshroud Matriarch",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192534,
		},
		[382593] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Cruel Bonecrusher",
			["npcID"] = 186206,
		},
		[394362] = {
			["source"] = "Rasnar the War Ender",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 193232,
		},
		[392576] = {
			["source"] = "Tempest Channeler",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 198047,
		},
		[387453] = {
			["source"] = "Professor Maxdormu",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 189668,
		},
		[395893] = {
			["encounterName"] = "Kurog Grimtotem",
			["source"] = "Kurog Grimtotem",
			["encounterID"] = 2605,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 184986,
		},
		[387965] = {
			["source"] = "Time-Lost Bladewing",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187232,
		},
		[377991] = {
			["source"] = "Guardian Sentry",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 192680,
		},
		[392569] = {
			["source"] = "Flamegullet",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 197697,
		},
		[167385] = {
			["source"] = "Dungeoneer's Training Dummy",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194644,
		},
		[377488] = {
			["source"] = "Rune Seal Keeper",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 187155,
		},
		[381605] = {
			["encounterName"] = "Kyrakka and Erkhart Stormvein",
			["source"] = "Kyrakka",
			["encounterID"] = 2623,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190484,
		},
		[368287] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Bonebolt Hunter",
			["npcID"] = 185534,
		},
		[382620] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Bonebolt Hunter",
			["npcID"] = 185534,
		},
		[198715] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Val'kyr Battlemaiden",
			["encounterID"] = 2635,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 100876,
		},
		[389280] = {
			["event"] = "SPELL_CAST_START",
			["source"] = "Shiverweb Crusher",
			["npcID"] = 185814,
		},
		[390290] = {
			["source"] = "Infuser Sariya",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 190405,
		},
		[375475] = {
			["encounterName"] = "Broodkeeper Diurna",
			["source"] = "Juvenile Frost Proto-Dragon",
			["npcID"] = 191222,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2614,
		},
		[194112] = {
			["encounterName"] = "God-King Skovald",
			["source"] = "God-King Skovald",
			["encounterID"] = 1808,
			["event"] = "SPELL_CAST_START",
			["npcID"] = 95675,
		},
		[397431] = {
			["encounterName"] = "Dathea, Ascended",
			["source"] = "Volatile Infuser",
			["npcID"] = 192934,
			["event"] = "SPELL_CAST_START",
			["encounterID"] = 2635,
		},
		[386694] = {
			["source"] = "Stormsurge Totem",
			["event"] = "SPELL_CAST_START",
			["npcID"] = 194897,
		},
	},
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Quazii Plater",
		["Bhrian - Blackmoore"] = "Default",
		["Zakarum - Blackmoore"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["use_ui_parent"] = true,
			["class_colors"] = {
				["DEATHKNIGHT"] = {
					["colorStr"] = "ffc31d3a",
				},
				["WARRIOR"] = {
					["colorStr"] = "ffc69a6d",
				},
				["PALADIN"] = {
					["colorStr"] = "fff48bb9",
				},
				["WARLOCK"] = {
					["colorStr"] = "ff8687ed",
				},
				["DEMONHUNTER"] = {
					["colorStr"] = "ffa22fc8",
				},
				["ROGUE"] = {
					["colorStr"] = "fffff467",
				},
				["DRUID"] = {
					["colorStr"] = "ffff7c09",
				},
				["EVOKER"] = {
					["colorStr"] = "ff33937e",
				},
				["SHAMAN"] = {
					["colorStr"] = "ff006fdd",
				},
			},
			["script_auto_imported"] = {
				["Aura - Buff Alert"] = 15,
				["Cast - Effect After Cast [P]"] = 2,
				["Explosion Affix M+"] = 14,
				["Aura - Debuff Alert"] = 12,
				["Cast - Castbar is Timer [P]"] = 2,
				["Cast - Ultra Important"] = 14,
				["Add - Health Markers [P]"] = 1,
				["Cast - Small Alert"] = 12,
				["Add - Important [P]"] = 4,
				["Aura - Blink Time Left"] = 13,
				["Add - Tag Number [P]"] = 2,
				["Cast - Glowing [P]"] = 10,
				["Cast - Important Target [P]"] = 2,
				["Cast - Very Important"] = 15,
				["Cast - Alert + Timer [P]"] = 4,
				["Aura is Shield [P]"] = 2,
				["Add - Warning [P]"] = 5,
				["Aura While Casting [P]"] = 1,
				["Cast - Big Alert"] = 14,
				["Unit - Show Energy"] = 11,
				["Spiteful Affix"] = 3,
				["Cast - Shield Interrupt"] = 2,
				["Add - Non Elite Trash [P]"] = 4,
				["Cast - Circular Swipe"] = 4,
				["Cast - Quick Flash"] = 2,
				["Countdown"] = 11,
				["Fixate by Unit Buff [P]"] = 2,
				["Cast - Frontal Cone"] = 15,
				["Add - Explode on Die [P]"] = 1,
				["Fixate"] = 11,
				["Cast - Stop Casting"] = 4,
				["Auto Set Skull"] = 11,
				["Fixate On You"] = 11,
			},
			["expansion_triggerwipe"] = {
				[9] = true,
			},
			["script_data"] = {
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --creates a glow around the icon\n    envTable.buffIconGlow = envTable.buffIconGlow or Plater.CreateIconGlow (self, scriptTable.config.glowColor)\n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Hide()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        Plater.StopDotAnimation(self, envTable.dotAnimation)\n    end\n    \n    \nend",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    \n    \n    \nend",
					["Time"] = 1669327144,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura",
					["Enabled"] = true,
					["Revision"] = 632,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Add the buff name in the trigger box.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						398151, -- [1]
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura - Buff Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Buff in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Glow Enabled",
							["Value"] = false,
							["Key"] = "glowEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.403921568627451, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Dots Enabled",
							["Value"] = true,
							["Key"] = "dotsEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.3215686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dots Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Show()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        envTable.dotAnimation = Plater.PlayDotAnimation(self, 6, scriptTable.config.dotsColor, 6, 3) \n    end\n    \nend\n\n\n\n\n",
				}, -- [1]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    \n    --set the castbar config\n    envTable.configAltCastBar = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end    \n        \n        \n    end\nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (envTable._SpellID == 191284) then\n        Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 4.70, GetTime(), 191284)\n        \n        C_Timer.After(4.75, function()\n                Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 5.30, GetTime(), 191284)\n        end)\n        \n        C_Timer.After(4.75 + 5.30, function()\n                Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 4.30, GetTime(), 191284)\n                C_Timer.After(4.50, function() unitFrame.castBar2:Hide() end)\n        end)\n    end\n    \nend",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1671066705,
					["url"] = "",
					["Icon"] = 134229,
					["Enabled"] = true,
					["Revision"] = 37,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Start extra cast bars for effects after the cast is done. Setup the effect on On Hide script.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						191284, -- [1]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Effect After Cast [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [2]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    function envTable.PlaySwipeAnimation(unitFrame)\n        unitFrame.CastSwipeTexture:Show()\n        unitFrame.CastSwipeAnimation:Play()\n        unitFrame.StartSwipeAnimation:Play()\n    end\n    \n    function envTable.StopSwipeAnimation(unitFrame)\n        unitFrame.EndSwipeAnimation:Play()\n        C_Timer.After(0.21, function()\n                unitFrame.CastSwipeAnimation:Stop()\n                unitFrame.CastSwipeTexture:Hide()\n        end)\n    end\n    \n    function envTable.CreateSwipeTextureAndAnimations(unitFrame)\n        if (unitFrame.CastSwipeTexture) then\n            return\n        end\n        \n        local swipeTexture = unitFrame:CreateTexture(nil, \"overlay\")\n        swipeTexture:SetTexture([[Interface\\AddOns\\Plater\\images\\circular_swipe]])\n        swipeTexture:SetPoint(\"center\", 0, 0)\n        swipeTexture:SetSize(64, 64)\n        swipeTexture:Hide()\n        \n        unitFrame.CastSwipeTexture = swipeTexture\n        \n        --rotation animation\n        unitFrame.CastSwipeAnimation = Plater:CreateAnimationHub(swipeTexture)\n        unitFrame.CastSwipeAnimation:SetLooping(\"repeat\")\n        unitFrame.CastSwipeAnimation.Rotation = Plater:CreateAnimation(unitFrame.CastSwipeAnimation, \"rotation\", 1, 1, 360)\n        \n        --starting animation\n        unitFrame.StartSwipeAnimation = Plater:CreateAnimationHub(swipeTexture, function()swipeTexture:Show() end)\n        unitFrame.StartSwipeAnimation.Alpha = Plater:CreateAnimation(unitFrame.StartSwipeAnimation, \"alpha\", 1, 0.2, 0, 1)\n        unitFrame.StartSwipeAnimation.Scale = Plater:CreateAnimation(unitFrame.StartSwipeAnimation, \"scale\", 1, 0.2, 1.3, 1.3, 1, 1)        \n        \n        --finished animation\n        unitFrame.EndSwipeAnimation = Plater:CreateAnimationHub(swipeTexture, nil, function()swipeTexture:Hide() end)\n        unitFrame.EndSwipeAnimation.Alpha = Plater:CreateAnimation(unitFrame.EndSwipeAnimation, \"alpha\", 1, 0.2, 1, 0)\n        unitFrame.EndSwipeAnimation.Scale = Plater:CreateAnimation(unitFrame.EndSwipeAnimation, \"scale\", 1, 0.2, 1, 1, 1.3, 1.3)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.StopSwipeAnimation(unitFrame)\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "		function (self, unitId, unitFrame, envTable, scriptTable)\n			--insert code here\n			\n		end\n	",
					["Time"] = 1670428019,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\circular_swipe",
					["Enabled"] = true,
					["Revision"] = 162,
					["semver"] = "",
					["Author"] = "Butazzul-Valdrakken",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Play a animation when the spell effect is an circular AoE around the caster.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						385916, -- [1]
						386063, -- [2]
						388822, -- [3]
						373087, -- [4]
						397785, -- [5]
						106864, -- [6]
						193660, -- [7]
						198263, -- [8]
						387910, -- [9]
						370766, -- [10]
						375591, -- [11]
						384336, -- [12]
						209404, -- [13]
						209378, -- [14]
						210875, -- [15]
						396001, -- [16]
						397899, -- [17]
						386559, -- [18]
						382555, -- [19]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Circle AoE [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 0.3,
							["Desc"] = "Rotation Duration",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.15,
							["Name"] = "Rotation Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "rotationDuration",
						}, -- [1]
						{
							["Type"] = 6,
							["Name"] = "Option 5",
							["Value"] = 0,
							["Key"] = "option5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 2,
							["Max"] = 1.5,
							["Desc"] = "Animation Start Duration",
							["Min"] = 0,
							["Name"] = "Animation Start Duration",
							["Value"] = 0.3,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "animStartDuration",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Texture Alpha when the animation start playing, this effect in intended to catch the player attention",
							["Min"] = 0,
							["Key"] = "textureStartAlpha",
							["Value"] = 1,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Texture Start Alpha",
						}, -- [4]
						{
							["Type"] = 6,
							["Key"] = "option5",
							["Value"] = 0,
							["Name"] = "Option 5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "Texture Scale",
							["Min"] = 0.6,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Name"] = "Texture Scale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureScale",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Texture Alpha",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 1,
							["Name"] = "Texture Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureAlpha",
						}, -- [7]
						{
							["Type"] = 1,
							["Name"] = "Texture Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "textureColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Texture Color",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.CreateSwipeTextureAndAnimations(unitFrame)\n    \n    local options = scriptTable.config\n    \n    local targetScale = scriptTable.config.textureScale\n    \n    --swipe rotation duration    \n    unitFrame.CastSwipeAnimation.Rotation:SetDuration(scriptTable.config.rotationDuration)\n    \n    --swipe texture settings\n    unitFrame.CastSwipeTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.textureColor))\n    unitFrame.CastSwipeTexture:SetScale(targetScale)\n    unitFrame.CastSwipeTexture:SetAlpha(scriptTable.config.textureAlpha)  \n    \n    unitFrame.StartSwipeAnimation.Alpha:SetDuration(scriptTable.config.animStartDuration)\n    unitFrame.StartSwipeAnimation.Alpha:SetFromAlpha(scriptTable.config.textureStartAlpha)\n    unitFrame.StartSwipeAnimation.Alpha:SetToAlpha(scriptTable.config.textureAlpha)\n    \n    unitFrame.StartSwipeAnimation.Scale:SetDuration(scriptTable.config.animStartDuration)\n    unitFrame.StartSwipeAnimation.Scale:SetScaleTo(targetScale, targetScale)\n    \n    unitFrame.EndSwipeAnimation.Scale:SetDuration(0.1)\n    unitFrame.EndSwipeAnimation.Alpha:SetDuration(0.1)\n    \n    --start playing\n    envTable.PlaySwipeAnimation(unitFrame)    \n    \nend\n\n\n",
				}, -- [3]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --creates a glow around the icon\n    envTable.buffIconGlow = envTable.buffIconGlow or Plater.CreateIconGlow (self, scriptTable.config.glowColor)\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Hide()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        Plater.StopDotAnimation(self, envTable.dotAnimation)\n    end\n    \n    \nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Time"] = 1669327144,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura",
					["Enabled"] = true,
					["Revision"] = 368,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Desc"] = "Add the debuff name in the trigger box.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura - Debuff Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Buff in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Glow Enabled",
							["Value"] = false,
							["Key"] = "glowEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.403921568627451, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Dots Enabled",
							["Value"] = true,
							["Key"] = "dotsEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.3215686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dots Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Show()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        envTable.dotAnimation = Plater.PlayDotAnimation(self, 6, scriptTable.config.dotsColor, 6, 3) \n    end\nend\n\n\n",
				}, -- [4]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \n    --check if there's a timer for this spell\n    local timer = scriptTable.config.timerList[tostring(envTable._SpellID)]\n    \n    if (timer) then\n        --insert code here\n        \n        --set the castbar config\n        local config = {\n            iconTexture = \"\",\n            iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n            iconAlpha = 1,\n            iconSize = 14,\n            \n            text = \"Spikes Incoming!\",\n            textSize = 8,\n            \n            texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n            color = {.6, .6, .6, 0.8},\n            \n            isChanneling = false,\n            canInterrupt = false,\n            \n            height = 5,\n            width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n            \n            spellNameAnchor = {side = 3, x = 0, y = -2},\n            timerAnchor = {side = 5, x = 0, y = -2},\n        }\n        \n        Plater.SetAltCastBar(unitFrame.PlateFrame, config, timer, nil, nil)\n        local castBar2 = unitFrame.castBar2\n        castBar2.Text:ClearAllPoints()\n        castBar2.Text:SetPoint (\"topleft\", castBar2, \"bottomleft\", 0, 0)\n        castBar2.percentText:ClearAllPoints()\n        castBar2.percentText:SetPoint (\"topright\", castBar2, \"bottomright\", 0, 0)\n        Plater:SetFontSize(castBar2.percentText, 8)\n    end\n    \nend\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1670203758,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["Enabled"] = true,
					["Revision"] = 1213,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Player an animation when the cast start. Start a timer when the cast finishes. Set the time in the options.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						350421, -- [1]
						355787, -- [2]
						348513, -- [3]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Alert + Timer [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Cast start animation settings",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Key"] = "flashDuration",
							["Value"] = 0.4,
							["Name"] = "Flash Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 5,
							["Name"] = "Cast Bar Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Key"] = "shakeDuration",
							["Value"] = 0.2,
							["Name"] = "Shake Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Key"] = "shakeAmplitude",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Amplitude",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 40,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Frequency",
						}, -- [11]
						{
							["Type"] = 7,
							["Key"] = "timerList",
							["Value"] = {
							},
							["Name"] = "Timer (Key is SpellId and Value is Time)",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the spellId and value is the amount of time of the Timer",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [5]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings\n    envTable.NameplateSizeOffset = scriptTable.config.castBarHeight\n    envTable.ShowArrow = scriptTable.config.showArrow\n    envTable.ArrowAlpha = scriptTable.config.arrowAlpha\n    \n    --creates the spark to show the cast progress inside the health bar\n    envTable.overlaySpark = envTable.overlaySpark or Plater:CreateImage (unitFrame.healthBar)\n    envTable.overlaySpark:SetBlendMode (\"ADD\")\n    envTable.overlaySpark.width = 16\n    envTable.overlaySpark.height = 36\n    envTable.overlaySpark.alpha = .9\n    envTable.overlaySpark.texture = [[Interface\\AddOns\\Plater\\images\\spark3]]\n    \n    envTable.topArrow = envTable.topArrow or Plater:CreateImage (unitFrame.healthBar)\n    envTable.topArrow:SetBlendMode (\"ADD\")\n    envTable.topArrow.width = scriptTable.config.arrowWidth\n    envTable.topArrow.height = scriptTable.config.arrowHeight\n    envTable.topArrow.alpha = envTable.ArrowAlpha\n    envTable.topArrow.texture = [[Interface\\BUTTONS\\Arrow-Down-Up]]\n    \n    --scale animation\n    envTable.smallScaleAnimation = envTable.smallScaleAnimation or Plater:CreateAnimationHub (unitFrame.healthBar)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 1, 0.075, 1, 1, 1.08, 1.08)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 2, 0.075, 1, 1, 0.95, 0.95)    \n    --envTable.smallScaleAnimation:Play() --envTable.smallScaleAnimation:Stop()\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))    \n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    \n    envTable.overlaySpark:Hide()\n    envTable.topArrow:Hide()\n    \n    Plater.RefreshNameplateColor (unitFrame)\n    \n    envTable.smallScaleAnimation:Stop()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)\n    \n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --update the percent\n    envTable.overlaySpark:SetPoint (\"left\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100)-9, 0)\n    \n    envTable.topArrow:SetPoint (\"bottomleft\", unitFrame.healthBar, \"topleft\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100) - 4, 2 )\n    \n    --forces the script to update on a 60Hz base\n    self.ThrottleUpdate = 0\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1670790652,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_red",
					["Enabled"] = true,
					["Revision"] = 694,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Used on casts that make the mob explode or transform if the cast passes.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						383823, -- [1]
						382670, -- [2]
						388537, -- [3]
						372851, -- [4]
						200682, -- [5]
						192307, -- [6]
						196838, -- [7]
						193827, -- [8]
						194043, -- [9]
						209410, -- [10]
						211464, -- [11]
						361180, -- [12]
						156718, -- [13]
						395859, -- [14]
						358320, -- [15]
						374045, -- [16]
						386757, -- [17]
						367500, -- [18]
						370225, -- [19]
						376200, -- [20]
						372107, -- [21]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Ultra Important [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Plays a special animation showing the explosion time.",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Option 3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "Increases the health bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 3,
							["Name"] = "Health Bar Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [5]
						{
							["Type"] = 1,
							["Key"] = "healthBarColor",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [6]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 4,
							["Name"] = "Use Cast Bar Color",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above Use Cast Bar Color",
						}, -- [8]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.168627455830574, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast Bar Color",
						}, -- [9]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 5,
							["Key"] = "option6",
							["Value"] = "Arrow:",
							["Name"] = "Arrow:",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [11]
						{
							["Type"] = 4,
							["Name"] = "Show Arrow",
							["Value"] = true,
							["Key"] = "showArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above the nameplate showing the cast bar progress.",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Arrow alpha.",
							["Min"] = 0,
							["Key"] = "arrowAlpha",
							["Value"] = 0.5,
							["Name"] = "Arrow Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Width.",
							["Min"] = 4,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "arrowWidth",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Width",
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Height.",
							["Min"] = 4,
							["Key"] = "arrowHeight",
							["Value"] = 8,
							["Name"] = "Arrow Height",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [15]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [16]
						{
							["Type"] = 5,
							["Key"] = "option12",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation:",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [17]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								1, -- [1]
								0.615686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dot animation.",
						}, -- [18]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot X Offset",
							["Min"] = -10,
							["Key"] = "xOffset",
							["Value"] = 4,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot X Offset",
						}, -- [19]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot Y Offset",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 3,
							["Name"] = "Dot Y Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "yOffset",
						}, -- [20]
						{
							["Type"] = 7,
							["Key"] = "castColor",
							["Value"] = {
								{
									"200682", -- [1]
									"darkslateblue", -- [2]
								}, -- [1]
								{
									"192307", -- [1]
									"goldenrod", -- [2]
								}, -- [2]
								{
									"196838", -- [1]
									"maroon", -- [2]
								}, -- [3]
								{
									"193827", -- [1]
									"darkgreen", -- [2]
								}, -- [4]
								{
									"194043", -- [1]
									"darkgreen", -- [2]
								}, -- [5]
								{
									"156718", -- [1]
									"DRUID", -- [2]
								}, -- [6]
								{
									"395859", -- [1]
									"ROGUE", -- [2]
								}, -- [7]
							},
							["Name"] = "Color List by SpellId",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the spellId in the Key, and the color name in the Value",
						}, -- [21]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.overlaySpark:Show()\n    \n    if (envTable.ShowArrow) then\n        envTable.topArrow:Show()\n    else\n        envTable.topArrow:Hide()\n    end\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    envTable.smallScaleAnimation:Play()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    envTable.overlaySpark.height = nameplateHeight + 5\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, customColor or scriptTable.config.castBarColor, envTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.healthBarColor)        \n        Plater.DenyColorChange(unitFrame, true)            \n    end\n    \nend",
				}, -- [6]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.lifePercent = { --dragonflight\n        [197697] = {50}, --Flamegullet\n        [59544] = {50}, --The Nodding Tiger\n        \n    }\n    \n    \n    function envTable.CreateMarker(unitFrame)\n        unitFrame.healthMarker = unitFrame.healthBar:CreateTexture(nil, \"overlay\")\n        unitFrame.healthMarker:SetColorTexture(1, 1, 1)\n        unitFrame.healthMarker:SetSize(1, unitFrame.healthBar:GetHeight())\n        \n        unitFrame.healthOverlay = unitFrame.healthBar:CreateTexture(nil, \"overlay\")\n        unitFrame.healthOverlay:SetColorTexture(1, 1, 1)\n        unitFrame.healthOverlay:SetSize(1, unitFrame.healthBar:GetHeight())\n    end\n    \n    function envTable.UpdateMarkers(unitFrame)\n        local markersTable = envTable.lifePercent[envTable._NpcID]\n        if (markersTable) then\n            local unitLifePercent = envTable._HealthPercent / 100\n            for i, percent in ipairs(markersTable) do\n                percent = percent / 100\n                if (unitLifePercent > percent) then\n                    if (not unitFrame.healthMarker) then\n                        envTable.CreateMarker(unitFrame)\n                    end\n                    \n                    unitFrame.healthMarker:Show()\n                    local width = unitFrame.healthBar:GetWidth()\n                    unitFrame.healthMarker:SetPoint(\"left\", unitFrame.healthBar, \"left\", width*percent, 0)\n                    \n                    local overlaySize = width * (unitLifePercent - percent)\n                    unitFrame.healthOverlay:SetWidth(overlaySize)\n                    unitFrame.healthOverlay:SetPoint(\"left\", unitFrame.healthMarker, \"right\", 0, 0)\n                    \n                    unitFrame.healthMarker:SetVertexColor(Plater:ParseColors(scriptTable.config.indicatorColor))\n                    unitFrame.healthMarker:SetAlpha(scriptTable.config.indicatorAlpha)\n                    \n                    unitFrame.healthOverlay:SetVertexColor(Plater:ParseColors(scriptTable.config.fillColor))\n                    unitFrame.healthOverlay:SetAlpha(scriptTable.config.fillAlpha)\n                    \n                    return\n                end\n            end --end for\n            \n            if (unitFrame.healthMarker and unitFrame.healthMarker:IsShown()) then\n                unitFrame.healthMarker:Hide()\n                unitFrame.healthOverlay:Hide()\n            end\n        end\n    end\nend      \n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (unitFrame.healthMarker) then\n        unitFrame.healthMarker:Hide()\n        unitFrame.healthOverlay:Hide()\n    end\nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateMarkers(unitFrame)\nend\n\n\n",
					["Time"] = 1669340967,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\health_indicator",
					["Enabled"] = true,
					["Revision"] = 137,
					["semver"] = "",
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Place a marker into the health bar to indicate when the unit will change phase or cast an important spell.",
					["NpcNames"] = {
						"197697", -- [1]
						"59544", -- [2]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Health Markers [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option1",
							["Value"] = "Add markers into the health bar to remind you about boss abilities at life percent.",
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "",
							["Value"] = 0,
							["Name"] = "blank line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "indicatorColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Vertical Line Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Indicator color.",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Indicator alpha.",
							["Min"] = 0.1,
							["Name"] = "Vertical Line Alpha",
							["Value"] = 0.79,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "indicatorAlpha",
						}, -- [4]
						{
							["Type"] = 6,
							["Name"] = "blank line",
							["Value"] = 0,
							["Key"] = "",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Fill Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "fillColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Fill color.",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Fill alpha.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "fillAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Fill Alpha",
						}, -- [7]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateMarkers(unitFrame)\nend\n\n\n",
				}, -- [7]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --flash duration\n    local CONFIG_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --manually create a new texture for the flash animation\n    if (not envTable.SmallFlashTexture) then\n        envTable.SmallFlashTexture = envTable.SmallFlashTexture or Plater:CreateImage (unitFrame.castBar)\n        envTable.SmallFlashTexture:SetColorTexture (1, 1, 1)\n        envTable.SmallFlashTexture:SetAllPoints()\n    end\n    \n    --manually create a flash animation using the framework\n    if (not envTable.SmallFlashAnimationHub) then \n        \n        local onPlay = function()\n            envTable.SmallFlashTexture:Show()\n        end\n        \n        local onFinished = function()\n            envTable.SmallFlashTexture:Hide()\n        end\n        \n        local animationHub = Plater:CreateAnimationHub (envTable.SmallFlashTexture, onPlay, onFinished)\n        envTable.flashIn = Plater:CreateAnimation (animationHub, \"Alpha\", 1, CONFIG_FLASH_DURATION/2, 0, .6)\n        envTable.flashOut = Plater:CreateAnimation (animationHub, \"Alpha\", 2, CONFIG_FLASH_DURATION/2, 1, 0)\n        \n        envTable.SmallFlashAnimationHub = animationHub\n    end\n    \n    envTable.flashIn:SetDuration(scriptTable.config.flashDuration / 2)\n    envTable.flashOut:SetDuration(scriptTable.config.flashDuration / 2)\n    envTable.SmallFlashTexture:SetColorTexture (Plater:ParseColors(scriptTable.config.flashColor))\n    \nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.SmallFlashAnimationHub:Stop()\n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    \n    \nend\n\n\n",
					["Time"] = 1669325410,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar",
					["Enabled"] = true,
					["Revision"] = 662,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Flashes the Cast Bar when a spell in the trigger list is Cast. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						376851, -- [1]
						396044, -- [2]
						381517, -- [3]
						373932, -- [4]
						397801, -- [5]
						208165, -- [6]
						392576, -- [7]
						198750, -- [8]
						387843, -- [9]
						387411, -- [10]
						211299, -- [11]
						198595, -- [12]
						198934, -- [13]
						198962, -- [14]
						156722, -- [15]
						350554, -- [16]
						348513, -- [17]
						351779, -- [18]
						328180, -- [19]
						319898, -- [20]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Small Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Plays a small animation when the cast start.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 3",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.6,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Flash Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "flashColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [6]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.SmallFlashAnimationHub:Play()\n    \nend\n\n\n",
				}, -- [8]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.NameplateColor = scriptTable.config.nameplateColor\n    envTable.NameplateSizeOffset = scriptTable.config.nameplateSizeOffset\n    \n    unitFrame.UnitImportantSkullTexture = unitFrame.UnitImportantSkullTexture or unitFrame:CreateTexture(nil, \"background\")\n    \n    unitFrame.UnitImportantSkullTexture:Hide()\nend\n\n--[=[\n\n154564 - debug\n\nUsing spellIDs for multi-language support\n\n196548 = ancient branch (academy dungeon)\n195580, 195821, 195820 = nokhub saboteur\n189886 = blazebound firestorm\n75966 = Defiled Spirit\n102019 = Stormforged Obliterator\n    187159 = Shrieking Whelp\n194897 = stormsurge totem\n104251 = duskwatch sentry\n101326 = honored ancestor\n189669 = binding speakl netharius\n192464 = raging ember neltharius\n--]=]\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)   \n    \n    --restore the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)    \n    \n    unitFrame.UnitImportantSkullTexture:Hide()\n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --check if can change the nameplate color\n    if (scriptTable.config.changeNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1670423785,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\skullbones_64",
					["Enabled"] = true,
					["Revision"] = 572,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Change the color and highlight a nameplate of an important Add. Add the unit name or NpcID into the trigger box to add more.",
					["NpcNames"] = {
						"196548", -- [1]
						"195580", -- [2]
						"195820", -- [3]
						"195821", -- [4]
						"189886", -- [5]
						"75966", -- [6]
						"102019", -- [7]
						"187159", -- [8]
						"194897", -- [9]
						"104251", -- [10]
						"101326", -- [11]
						"189669", -- [12]
						"192464", -- [13]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Important [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option6",
							["Value"] = "Enter the npc name or npcId in the \"Add Trigger\" box and hit \"Add\".",
							["Name"] = "Option 6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "changeNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "change to true to change the color",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "nameplateColor",
							["Value"] = {
								1, -- [1]
								0, -- [2]
								0.5254901960784314, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "increase the nameplate height by this value",
							["Min"] = 0,
							["Name"] = "Nameplate Size Offset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "nameplateSizeOffset",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.7137255072593689, -- [2]
								0, -- [3]
								0.5631310641765594, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Dot Color",
						}, -- [8]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 5,
							["Key"] = "option10",
							["Value"] = "Extra Texture",
							["Name"] = "Extra Texture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "Extra Texture",
						}, -- [10]
						{
							["Type"] = 4,
							["Name"] = "Show Extra Texture",
							["Value"] = false,
							["Key"] = "showExtraTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show Extra Texture",
						}, -- [11]
						{
							["Type"] = 1,
							["Key"] = "skullColor",
							["Value"] = {
								1, -- [1]
								0.4627450980392157, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Texture Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Texture Color",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Alpha",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Name"] = "Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "skullAlpha",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 2,
							["Desc"] = "Scale",
							["Min"] = 0.4,
							["Name"] = "Scale",
							["Value"] = 0.6,
							["Key"] = "skullScale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 7,
							["Name"] = "Npc Color By NpcID",
							["Value"] = {
								{
									"196548", -- [1]
									"forestgreen", -- [2]
								}, -- [1]
								{
									"195580", -- [1]
									"forestgreen", -- [2]
								}, -- [2]
								{
									"195820", -- [1]
									"forestgreen", -- [2]
								}, -- [3]
								{
									"195821", -- [1]
									"forestgreen", -- [2]
								}, -- [4]
								{
									"189886", -- [1]
									"forestgreen", -- [2]
								}, -- [5]
								{
									"75966", -- [1]
									"forestgreen", -- [2]
								}, -- [6]
								{
									"102019 ", -- [1]
									"forestgreen", -- [2]
								}, -- [7]
								{
									"187159", -- [1]
									"forestgreen", -- [2]
								}, -- [8]
								{
									"194897", -- [1]
									"forestgreen", -- [2]
								}, -- [9]
								{
									"104251", -- [1]
									"forestgreen", -- [2]
								}, -- [10]
							},
							["Key"] = "npcColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the npcID, value is the color name",
						}, -- [15]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (envTable.dotAnimation) then\n        Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    end\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotsColor, 3, 4) \n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    unitFrame.UnitImportantSkullTexture:Show()\n    \n    --color priority:\n    local npcIdString = tostring(envTable._NpcID)\n    envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.nameplateColor)    \n    \n    if (scriptTable.config.showExtraTexture) then\n        unitFrame.UnitImportantSkullTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.skullColor))\n        unitFrame.UnitImportantSkullTexture:SetAlpha(scriptTable.config.skullAlpha)\n        unitFrame.UnitImportantSkullTexture:SetScale(scriptTable.config.skullScale)\n        unitFrame.UnitImportantSkullTexture:SetTexture([[Interface/AddOns/Plater/media/x_64]])\n        unitFrame.UnitImportantSkullTexture:ClearAllPoints()\n        unitFrame.UnitImportantSkullTexture:SetPoint(\"right\", unitFrame.healthBar, \"left\", -2, 0)\n        unitFrame.UnitImportantSkullTexture:SetSize(28, 28)\n        unitFrame.UnitImportantSkullTexture:Show()\n    else\n        unitFrame.UnitImportantSkullTexture:Hide()\n    end\n    \n    --rules for some npcs\n    if (envTable._NpcID == 194895) then --unstable squall (explode at dying\n        unitFrame.UnitImportantSkullTexture:Hide()\n        Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation) \n    end\n    \n    if (scriptTable.config.changeNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        \n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.nameplateColor)        \n        \n        Plater.DenyColorChange(unitFrame, true)\n    end\n    \nend\n\n\n\n\n",
				}, -- [9]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings (require a /reload after editing any setting)\n    do\n        --blink and glow\n        envTable.BlinkEnabled = scriptTable.config.blinkEnabled\n        envTable.GlowEnabled = scriptTable.config.glowEnabled \n        envTable.ChangeNameplateColor = scriptTable.config.changeNameplateColor;\n        envTable.TimeLeftToBlink = scriptTable.config.timeleftToBlink;\n        envTable.BlinkSpeed = scriptTable.config.blinkSpeed; \n        envTable.BlinkColor = scriptTable.config.blinkColor; \n        envTable.BlinkMaxAlpha = scriptTable.config.blinkMaxAlpha; \n        envTable.NameplateColor = scriptTable.config.nameplateColor; \n        \n        --text color\n        envTable.TimerColorEnabled = scriptTable.config.timerColorEnabled \n        envTable.TimeLeftWarning = scriptTable.config.timeLeftWarning;\n        envTable.TimeLeftCritical = scriptTable.config.timeLeftCritical;\n        envTable.TextColor_Warning = scriptTable.config.warningColor; \n        envTable.TextColor_Critical = scriptTable.config.criticalColor; \n        \n        --list of spellIDs to ignore\n        envTable.IgnoredSpellID = {\n            [12] = true, --use a simple comma here\n            [13] = true,\n        }\n    end\n    \n    \n    --private\n    do\n        --if not envTable.blinkTexture then\n        envTable.blinkTexture = Plater:CreateImage (self, \"\", 1, 1, \"overlay\")\n        envTable.blinkTexture:SetPoint ('center', 0, 0)\n        envTable.blinkTexture:Hide()\n        \n        local onPlay = function()\n            envTable.blinkTexture:Show() \n            envTable.blinkTexture.color = envTable.BlinkColor\n        end\n        local onStop = function()\n            envTable.blinkTexture:Hide()  \n        end\n        envTable.blinkAnimation = Plater:CreateAnimationHub (envTable.blinkTexture, onPlay, onStop)\n        Plater:CreateAnimation (envTable.blinkAnimation, \"ALPHA\", 1, envTable.BlinkSpeed / 2, 0, envTable.BlinkMaxAlpha)\n        Plater:CreateAnimation (envTable.blinkAnimation, \"ALPHA\", 2, envTable.BlinkSpeed / 2, envTable.BlinkMaxAlpha, 0)\n        --end\n        \n        envTable.glowEffect = envTable.glowEffect or self.overlay or Plater.CreateIconGlow (self)\n        --envTable.glowEffect = envTable.glowEffect or Plater.CreateIconGlow (self)\n        --envTable.glowEffect:Show() --envTable.glowEffect:Hide()\n        \n    end\n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.blinkAnimation:Stop()\n    envTable.blinkTexture:Hide()\n    envTable.blinkAnimation:Stop()\n    envTable.glowEffect:Stop()\n    Plater:SetFontColor (self.Cooldown.Timer, Plater.db.profile.aura_timer_text_color)\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local timeLeft = envTable._RemainingTime\n    \n    --check if the spellID isn't being ignored\n    if (envTable.IgnoredSpellID [envTable._SpellID]) then\n        return\n    end\n    \n    --check the time left and start or stop the blink animation and also check if the time left is > zero\n    if ((envTable.BlinkEnabled or envTable.GlowEnabled) and timeLeft > 0) then\n        if (timeLeft < envTable.TimeLeftToBlink) then\n            --blink effect\n            if (envTable.BlinkEnabled) then\n                if (not envTable.blinkAnimation:IsPlaying()) then\n                    envTable.blinkAnimation:Play()\n                end\n            end\n            --glow effect\n            if (envTable.GlowEnabled) then\n                envTable.glowEffect:Show()\n            end\n            --nameplate color\n            if (envTable.ChangeNameplateColor) then\n                Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n            end\n        else\n            --blink effect\n            if (envTable.blinkAnimation:IsPlaying()) then\n                envTable.blinkAnimation:Stop()\n            end\n            --glow effect\n            if (envTable.GlowEnabled and envTable.glowEffect:IsShown()) then\n                envTable.glowEffect:Hide()\n            end\n        end\n    end\n    \n    --timer color\n    if (envTable.TimerColorEnabled and timeLeft > 0) then\n        if (timeLeft < envTable.TimeLeftCritical) then\n            Plater:SetFontColor (self.Cooldown.Timer, envTable.TextColor_Critical)\n        elseif (timeLeft < envTable.TimeLeftWarning) then\n            Plater:SetFontColor (self.Cooldown.Timer, envTable.TextColor_Warning)        \n        else\n            Plater:SetFontColor (self.Cooldown.Timer, Plater.db.profile.aura_timer_text_color)\n        end\n    end\n    \nend",
					["Time"] = 1626382829,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura_blink",
					["Enabled"] = true,
					["Revision"] = 375,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Blink, change the number and nameplate color. Add the debuffs int he trigger box. Set settings on constructor script.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura - Blink by Time Left [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option10",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option17",
							["Value"] = "Enter the spell name or spellID in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 17",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option10",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "blinkEnabled",
							["Value"] = true,
							["Name"] = "Blink Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable blink",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "glowEnabled",
							["Value"] = true,
							["Name"] = "Glow Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable glows",
						}, -- [5]
						{
							["Type"] = 4,
							["Key"] = "changeNameplateColor",
							["Value"] = false,
							["Name"] = "Change NamePlate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'true' to enable nameplate color change",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "in seconds, affects the blink effect only",
							["Min"] = 1,
							["Fraction"] = true,
							["Value"] = 3,
							["Key"] = "timeleftToBlink",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Timeleft to Blink",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 3,
							["Desc"] = "time to complete a blink loop",
							["Min"] = 0.5,
							["Fraction"] = true,
							["Value"] = 1,
							["Key"] = "blinkSpeed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Speed",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "max transparency in the animation loop (1.0 is full opaque)",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.6,
							["Key"] = "blinkMaxAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Max Alpha",
						}, -- [9]
						{
							["Type"] = 1,
							["Key"] = "blinkColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Blink Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color of the blink",
						}, -- [10]
						{
							["Type"] = 1,
							["Key"] = "nameplateColor",
							["Value"] = {
								0.2862745098039216, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "nameplate color if ChangeNameplateColor is true",
						}, -- [11]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option10",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [12]
						{
							["Type"] = 4,
							["Key"] = "timerColorEnabled",
							["Value"] = true,
							["Name"] = "Timer Color Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable changes in the color of the time left text",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "in seconds, affects the color of the text",
							["Min"] = 1,
							["Name"] = "Time Left Warning",
							["Value"] = 8,
							["Key"] = "timeLeftWarning",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "in seconds, affects the color of the text",
							["Min"] = 1,
							["Name"] = "Time Left Critical",
							["Value"] = 3,
							["Key"] = "timeLeftCritical",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [15]
						{
							["Type"] = 1,
							["Key"] = "warningColor",
							["Value"] = {
								1, -- [1]
								0.8705882352941177, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Warning Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color when the time left entered in a warning zone",
						}, -- [16]
						{
							["Type"] = 1,
							["Key"] = "criticalColor",
							["Value"] = {
								1, -- [1]
								0.07450980392156863, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Critical Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color when the time left is critical",
						}, -- [17]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.blinkTexture:SetSize (self:GetSize())\n    \nend\n\n\n",
				}, -- [10]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.AddSpawnIDTexture) then\n        unitFrame.AddSpawnIDTexture:Hide()\n        unitFrame.AddIcon:Hide()\n        unitFrame.AddNumber:Hide()\n    end\n    \nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1669340442,
					["url"] = "",
					["Icon"] = "interface/addons/plater/images/add_id_icon",
					["Enabled"] = false,
					["Revision"] = 161,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    \n    scriptTable.allAdds = {} \n    scriptTable.nextAddWave = 0\n    scriptTable.waveTime = 20\n    \n    function scriptTable.ArrangeNpcNumbers(GUID)\n        local spawnId = select(7, strsplit (\"-\", GUID))\n        spawnId = tonumber(spawnId, 16)\n        \n        if (spawnId) then\n            --check if this is a new wave of adds\n            if (GetTime() > scriptTable.nextAddWave) then\n                scriptTable.nextAddWave = GetTime() + scriptTable.waveTime\n                scriptTable.allAdds = {}\n            end\n            \n            local bIsAlreadyOnTheList = false\n            \n            for o = 1, #scriptTable.allAdds do\n                if (scriptTable.allAdds[o][1] == GUID) then\n                    bIsAlreadyOnTheList = true\n                end\n            end\n            \n            if (not bIsAlreadyOnTheList) then\n                scriptTable.allAdds[#scriptTable.allAdds+1] = {GUID, spawnId}\n            end\n        end\n        \n        table.sort(scriptTable.allAdds, function(t1, t2) return t1[2] < t2[2] end)\n        \n        --this is a \"loop\" because this is running each time a nameplate is added!\n        \n        for namePlateIndex, plateFrame in ipairs(Plater.GetAllShownPlates()) do\n            local unitFrame = plateFrame.unitFrame\n            \n            --get the unit GUID\n            local unitGUID = unitFrame.namePlateUnitGUID\n            \n            for addId = 1, #scriptTable.allAdds do\n                local addTable = scriptTable.allAdds[addId]\n                local addGUID = addTable[1]\n                \n                if (unitGUID == addGUID) then\n                    scriptTable.TagNameplate(unitFrame, unitGUID, addId)\n                    break\n                end\n            end\n            \n        end\n    end\n    \n    function scriptTable.TagNameplate(unitFrame, GUID, addId)\n        scriptTable.CreateAddWidgetsForNameplate(unitFrame, GUID, addId)\n        \n        if (addId and addId >= 1 and addId <= 8) then\n            unitFrame.AddSpawnIDTexture:Show()\n            unitFrame.AddIcon:Show()\n            unitFrame.AddNumber:Show()\n            \n            local addTexture = \"Interface\\\\TargetingFrame\\\\UI-RaidTargetingIcon_\" .. addId\n            \n            unitFrame.AddIcon:SetTexture(addTexture)\n            unitFrame.AddNumber:SetText(addId)\n        end\n    end\n    \n    function scriptTable.CreateAddWidgetsForNameplate(unitFrame, GUID, addId)\n        if (not unitFrame.AddSpawnIDTexture) then\n            local healthBar = unitFrame.healthBar\n            \n            local textureBackground = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 5)\n            local addIcon = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 6)\n            local addNumber = healthBar.FrameOverlay:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)           \n            \n            unitFrame.AddSpawnIDTexture = textureBackground\n            unitFrame.AddIcon = addIcon\n            unitFrame.AddNumber = addNumber\n        end\n    end    \nend\n\n--Creature-0-2085-1-11042-153285-0002F8DB2B --training dummy for testing\n--195138 Detonating Crystal\n--192955 dracomoc illusion\n--190294 nokhub stormcaster\n--76518 ritual of bones\n\n\n\n\n",
					["Desc"] = "Put a number above multiples adds, numbers follow their respawn id.",
					["NpcNames"] = {
						"195138", -- [1]
						"192955", -- [2]
						"190294", -- [3]
						"76518", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Tag Number [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.AddSpawnIDTexture) then\n        unitFrame.AddSpawnIDTexture:Hide()\n        unitFrame.AddIcon:Hide()\n        unitFrame.AddNumber:Hide()\n    end\n    \n    scriptTable.ArrangeNpcNumbers(unitFrame.namePlateUnitGUID)\n    \n    local textureBackground = unitFrame.AddSpawnIDTexture\n    textureBackground:SetSize(22, 10)\n    textureBackground:ClearAllPoints()\n    textureBackground:SetPoint(\"bottomright\", unitFrame.healthBar, \"topright\", 0, 1)\n    \n    textureBackground:SetMask([[Interface\\AddOns\\Plater\\masks\\mask_smallrectangle_rounded1]])\n    textureBackground:SetTexture([[Interface\\AddOns\\Plater\\masks\\mask_smallrectangle_rounded1]])\n    textureBackground:SetVertexColor(0.1215, 0.1176, 0.1294, 1)\n    \n    \n    --textureBackground:SetMask([[Interface/ChatFrame/UI-ChatIcon-HotS]])\n    --    \"Interface/ChatFrame/UI-ChatIcon-HotS\"\n    \n    local addIcon = unitFrame.AddIcon\n    addIcon:ClearAllPoints()\n    addIcon:SetPoint(\"left\", textureBackground, \"left\", 2, 0)\n    addIcon:SetSize(10, 10)\n    \n    local addNumber = unitFrame.AddNumber\n    addNumber:ClearAllPoints()\n    addNumber:SetPoint(\"right\", textureBackground, \"right\", -2, 0)\n    DetailsFramework:SetFontSize(addNumber, 10)\n    \nend\n\n\n",
				}, -- [11]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do --max amount of segments is 20\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.Textures) then\n        for i = 1, scriptTable.config.segmentsAmount  do\n            local texture = unitFrame.felAnimation.Textures[i]\n            if (texture) then\n                texture:Hide()\n            end\n        end\n    end\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.textureStretched) then\n        local textureStretched = unitFrame.felAnimation.textureStretched\n        if (textureStretched) then\n            textureStretched:Hide()\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    if (not envTable.NextPercent) then\n        return\n    end\n    \n    local castBar = unitFrame.castBar\n    \n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then --eeror here, compare with nil\n        local nextPercent = 100  / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1672514190,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_glow",
					["Enabled"] = true,
					["Revision"] = 547,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Show a different animation for the cast bar.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						376644, -- [1]
						386781, -- [2]
						384823, -- [3]
						385536, -- [4]
						392398, -- [5]
						375596, -- [6]
						387135, -- [7]
						209033, -- [8]
						360850, -- [9]
						212784, -- [10]
						207980, -- [11]
						199033, -- [12]
						199034, -- [13]
						200969, -- [14]
						394512, -- [15]
						397881, -- [16]
						396020, -- [17]
						374430, -- [18]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Glowing [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Key"] = "segmentsAmount",
							["Value"] = 7,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Amount of Segments",
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 7,
							["Key"] = "castColor",
							["Value"] = {
								{
									"385536", -- [1]
									"maroon", -- [2]
								}, -- [1]
								{
									"198750", -- [1]
									"midnightblue", -- [2]
								}, -- [2]
								{
									"360850", -- [1]
									"lime", -- [2]
								}, -- [3]
								{
									"212784", -- [1]
									"deepskyblue", -- [2]
								}, -- [4]
								{
									"207980", -- [1]
									"midnightblue", -- [2]
								}, -- [5]
								{
									"199033", -- [1]
									"gold", -- [2]
								}, -- [6]
								{
									"199034", -- [1]
									"gold", -- [2]
								}, -- [7]
								{
									"200969", -- [1]
									"orange", -- [2]
								}, -- [8]
								{
									"394512", -- [1]
									"indigo", -- [2]
								}, -- [9]
								{
									"397881", -- [1]
									"deepskyblue", -- [2]
								}, -- [10]
								{
									"396020", -- [1]
									"khaki", -- [2]
								}, -- [11]
							},
							["Name"] = "Cast Color by SpellID",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the Spell ID in the to Key and a color name into the Value",
						}, -- [4]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        --texture:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.trailColor))\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    Plater.SetCastBarColorForScript(self, true, customColor or scriptTable.config.castBarColor, envTable)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [12]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --create a texture to use for a flash behind the cast bar\n    \n    if (not unitFrame.backGroundFlashTextureImpTarget) then\n        unitFrame.backGroundFlashTextureImpTarget =  Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    end\n    \n    local backGroundFlashTexture = unitFrame.backGroundFlashTextureImpTarget\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\n    \n    --create the target unit name box\n    if (not unitFrame.targetBox) then\n        unitFrame.targetBox = CreateFrame(\"frame\", unitFrame:GetName() .. \"ScriptImportantTarget\", unitFrame, \"BackdropTemplate\")\n        unitFrame.targetBox:SetSize(80, 20)\n        unitFrame.targetBox:SetFrameStrata(\"TOOLTIP\")\n        unitFrame.targetBox:Hide()\n        unitFrame.targetBox:SetPoint(\"left\", unitFrame, \"right\", 0, 0)\n        \n        unitFrame.targetBox:SetBackdrop({edgeFile = [[Interface\\Buttons\\WHITE8X8]], edgeSize = 1, bgFile = [[Interface\\AddOns\\Details\\images\\background]], tile = true, tileSize = 16})\n        unitFrame.targetBox:SetBackdropColor(.2, .2, .2, .8)\n        unitFrame.targetBox:SetBackdropBorderColor(0, 0, 0, 1)\n        \n        unitFrame.targetBoxName = unitFrame.targetBox:CreateFontString(nil, \"artwork\", \"GameFontNormal\")\n        unitFrame.targetBoxName:SetPoint(\"center\")\n    end\n    \n    function envTable.UpdateTargetBox(unitFrame, unitId)\n        local targetUnitId = unitId .. \"target\"\n        local unitName = UnitName(targetUnitId)\n        \n        if (unitName) then\n            if (scriptTable.config.colorByClass) then\n                Plater:SetFontColor(unitFrame.targetBoxName, \"white\")\n                unitName = Plater.SetTextColorByClass(targetUnitId, unitName)\n            else\n                Plater:SetFontColor(unitFrame.targetBoxName, scriptTable.config.textColor)\n            end\n            \n            unitFrame.targetBoxName:SetText(unitName)\n            Plater:SetFontSize(unitFrame.targetBoxName, scriptTable.config.targetNameSize)\n            unitFrame.targetBox:SetBackdropColor(Plater:ParseColors(scriptTable.config.targetBgColor))\n            unitFrame.targetBox:SetBackdropBorderColor(Plater:ParseColors(scriptTable.config.targetBgBorderColor))\n            unitFrame.targetBox:Show()\n            \n            unitFrame.targetBox:SetWidth(scriptTable.config.targetFrameWidth)\n            unitFrame.targetBox:SetHeight(scriptTable.config.targetFrameHeight)\n            \n            if (not Plater.HasDotAnimationPlaying(unitFrame.targetBox)) then\n                envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.targetBox, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n            end\n            \n            unitFrame.backGroundFlashTextureImpTarget:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n            \n            return true\n            \n        end\n    end\n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.targetBox, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \n    unitFrame.targetBox:Hide()\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.UpdateTargetBox(unitFrame, unitId) \n    \nend\n\n\n",
					["Time"] = 1669339628,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_target",
					["Enabled"] = true,
					["Revision"] = 878,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Highlight the target name",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Important Target [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Shows the target name in a separate box",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Flash:",
							["Name"] = "Flash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.8,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [6]
						{
							["Type"] = 1,
							["Key"] = "flashColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Flash Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Name"] = "Shake",
							["Value"] = "Shake:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Name"] = "Shake Amplitude",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 40,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Key"] = "option14",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Dot X Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "xOffset",
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot Y Offset",
							["Value"] = 3,
							["Key"] = "yOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [17]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Key"] = "option19",
							["Value"] = "Cast Bar",
							["Name"] = "Option 19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Use Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Key"] = "castBarColor",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
						{
							["Type"] = 6,
							["Name"] = "Option 27",
							["Value"] = 0,
							["Key"] = "option27",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [27]
						{
							["Type"] = 5,
							["Name"] = "Option 28",
							["Value"] = "Target Options",
							["Key"] = "option28",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [28]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "",
							["Min"] = 8,
							["Name"] = "Text Size",
							["Value"] = 14,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "targetNameSize",
						}, -- [29]
						{
							["Type"] = 4,
							["Name"] = "Use Class Color",
							["Value"] = true,
							["Key"] = "colorByClass",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [30]
						{
							["Type"] = 1,
							["Name"] = "Text Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "textColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [31]
						{
							["Type"] = 1,
							["Name"] = "Background Color",
							["Value"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								0.9846720322966576, -- [4]
							},
							["Key"] = "targetBgColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [32]
						{
							["Type"] = 1,
							["Name"] = "Border Color",
							["Value"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "targetBgBorderColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [33]
						{
							["Type"] = 2,
							["Max"] = 160,
							["Desc"] = "",
							["Min"] = 30,
							["Name"] = "Frame Width",
							["Value"] = 90,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "targetFrameWidth",
						}, -- [34]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "",
							["Min"] = 8,
							["Key"] = "targetFrameHeight",
							["Value"] = 20,
							["Name"] = "Frame Height",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [35]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (envTable.UpdateTargetBox(unitFrame, unitId)) then\n        \n        envTable.BackgroundFlash:Play()\n        \n        Plater.FlashNameplateBorder (unitFrame, 0.05)   \n        Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n        \n        unitFrame:PlayFrameShake (envTable.FrameShake)\n        \n        if (envTable._CanInterrupt) then\n            if (scriptTable.config.useCastbarColor) then\n                self:SetStatusBarColor (Plater:ParseColors (scriptTable.config.castBarColor))\n            end\n        end\n        \n    end\n    \nend\n\n\n\n\n\n\n",
				}, -- [13]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end    \n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1669324381,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_quickflash.tga",
					["Enabled"] = true,
					["Revision"] = 887,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Play a very fast flash when the cast start",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						392640, -- [1]
						397888, -- [2]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Quick Flash [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces a notable but fast effect in the cast bar when a spell from the 'Triggers' starts to cast.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 0,
							["Key"] = "castBarHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.1,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 200,
							["Desc"] = "How strong is the shake.",
							["Min"] = 10,
							["Name"] = "Shake Amplitude",
							["Value"] = 25,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 30,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [14]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    local unitPowerBar = unitFrame.powerBar\n    unitPowerBar:Hide()\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE) then\n        return \n    end\n    \n    local continuationToken\n    local slots\n    local foundAura = false\n    \n    repeat    \n        slots = { UnitAuraSlots(unitId, \"HELPFUL\", BUFF_MAX_DISPLAY, continuationToken) }\n        continuationToken = slots[1]\n        numSlots = #slots\n        \n        for i = 2, numSlots do\n            local slot = slots[i]\n            local name, texture, count, actualAuraType, duration, expirationTime, caster, canStealOrPurge, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, isCastByPlayer, nameplateShowAll, timeMod, auraAmount = UnitAuraBySlot(unitId, slot) \n            \n            if (spellId == envTable._SpellID) then --need to get the trigger spellId\n                --Ablative Shield\n                local unitPowerBar = unitFrame.powerBar\n                if (not unitPowerBar:IsShown()) then\n                    unitPowerBar:SetUnit(unitId)\n                end\n                \n                foundAura = true\n                return\n            end\n        end\n        \n    until continuationToken == nil\n    \n    if (not foundAura) then\n        local unitPowerBar = unitFrame.powerBar\n        if (unitPowerBar:IsShown()) then\n            unitPowerBar:Hide()\n        end\n    end\nend",
					["Time"] = 1669327146,
					["url"] = "",
					["Icon"] = 610472,
					["Enabled"] = true,
					["Revision"] = 65,
					["semver"] = "",
					["Author"] = "Keyspell-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Show power bar where its value is the buff value (usualy shown in the buff tooltip)",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Aura is Shield [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [15]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n--190187 draconic image\n--189893 infused whelp\n--99922 Ebonclaw Packmate\n--104822 flames of woe",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.DenyColorChange(unitFrame, false)\n    unitFrame.onShowAddToKillFlash:Stop()\n    \nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\nend\n\n\n\n\n",
					["Time"] = 1670427654,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/exclamation_64",
					["Enabled"] = true,
					["Revision"] = 162,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Change the color of  add",
					["NpcNames"] = {
						"190187", -- [1]
						"189893", -- [2]
						"99922", -- [3]
						"104822", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Warning [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								1, -- [1]
								0.4392157196998596, -- [2]
								0.458823561668396, -- [3]
								1, -- [4]
							},
							["Key"] = "healthBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option5",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Flash Nameplate",
							["Value"] = true,
							["Key"] = "useFlash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Flash Nameplate",
						}, -- [4]
						{
							["Type"] = 7,
							["Name"] = "NpcID to Color",
							["Value"] = {
								{
									"189893", -- [1]
									"olivedrab", -- [2]
								}, -- [1]
								{
									"190187", -- [1]
									"olivedrab", -- [2]
								}, -- [2]
								{
									"99922", -- [1]
									"olivedrab", -- [2]
								}, -- [3]
								{
									"153285", -- [1]
									"olivedrab", -- [2]
								}, -- [4]
								{
									"104822", -- [1]
									"olivedrab", -- [2]
								}, -- [5]
							},
							["Key"] = "npcColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "If the npc isn't on this list, use the default color set in the Health Bar Color",
						}, -- [5]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    unitFrame.onShowAddToKillFlash = unitFrame.onShowAddToKillFlash or Plater.CreateFlash (unitFrame.healthBar, 0.25, 1, \"white\")\n    \n    if (scriptTable.config.useFlash) then\n        unitFrame.onShowAddToKillFlash:Play()\n    end\n    \n    if (scriptTable.config.useNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.healthBarColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end\nend\n\n\n\n\n\n\n\n\n\n",
				}, -- [16]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not Plater.IsShowingCastBarTest) then\n        --don't execute on battlegrounds and arenas\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end    \n    end\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1670203603,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["Enabled"] = true,
					["Revision"] = 1194,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Flash, Bounce and Red Color the CastBar border when when an important cast is happening. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						396640, -- [1]
						372743, -- [2]
						377389, -- [3]
						396812, -- [4]
						388392, -- [5]
						387955, -- [6]
						386546, -- [7]
						377503, -- [8]
						384808, -- [9]
						386024, -- [10]
						387615, -- [11]
						387606, -- [12]
						225100, -- [13]
						211401, -- [14]
						211470, -- [15]
						215433, -- [16]
						192563, -- [17]
						198959, -- [18]
						152818, -- [19]
						156776, -- [20]
						398206, -- [21]
						153524, -- [22]
						396073, -- [23]
						396018, -- [24]
						345202, -- [25]
						377950, -- [26]
						372223, -- [27]
						350421, -- [28]
						352158, -- [29]
						349985, -- [30]
						329239, -- [31]
						328400, -- [32]
						384194, -- [33]
						392451, -- [34]
						392924, -- [35]
						397889, -- [36]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Big Alert [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces a notable effect in the cast bar when a spell from the 'Triggers' starts to cast.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Name"] = "Flash Duration",
							["Value"] = 0.4,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Name"] = "Cast Bar Height Mod",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "castBarHeight",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 40,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (not Plater.IsShowingCastBarTest) then\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    --set the color of the cast bar to dark orange (only if can be interrupted)\n    --Plater auto set this color to default when a new cast starts, no need to reset this value at OnHide.    \n    if (envTable._CanInterrupt) then\n        if (scriptTable.config.useCastbarColor) then\n            self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n        end\n    end\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [17]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings\n    envTable.NameplateSizeOffset = scriptTable.config.castBarHeight\n    envTable.ShowArrow = scriptTable.config.showArrow\n    envTable.ArrowAlpha = scriptTable.config.arrowAlpha\n    \n    --creates the spark to show the cast progress inside the health bar\n    envTable.overlaySpark = envTable.overlaySpark or Plater:CreateImage (unitFrame.healthBar)\n    envTable.overlaySpark:SetBlendMode (\"ADD\")\n    envTable.overlaySpark.width = 16\n    envTable.overlaySpark.height = 36\n    envTable.overlaySpark.alpha = .9\n    envTable.overlaySpark.texture = [[Interface\\AddOns\\Plater\\images\\spark3]]\n    \n    envTable.topArrow = envTable.topArrow or Plater:CreateImage (unitFrame.healthBar)\n    envTable.topArrow:SetBlendMode (\"ADD\")\n    envTable.topArrow.width = scriptTable.config.arrowWidth\n    envTable.topArrow.height = scriptTable.config.arrowHeight\n    envTable.topArrow.alpha = envTable.ArrowAlpha\n    envTable.topArrow.texture = [[Interface\\BUTTONS\\Arrow-Down-Up]]\n    \n    --scale animation\n    envTable.smallScaleAnimation = envTable.smallScaleAnimation or Plater:CreateAnimationHub (unitFrame.healthBar)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 1, 0.075, 1, 1, 1.08, 1.08)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 2, 0.075, 1, 1, 0.95, 0.95)    \n    --envTable.smallScaleAnimation:Play() --envTable.smallScaleAnimation:Stop()\n    \nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    \n    envTable.overlaySpark:Hide()\n    envTable.topArrow:Hide()\n    \n    Plater.RefreshNameplateColor (unitFrame)\n    \n    envTable.smallScaleAnimation:Stop()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)\n    \n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --update the percent\n    envTable.overlaySpark:SetPoint (\"left\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100)-9, 0)\n    \n    envTable.topArrow:SetPoint (\"bottomleft\", unitFrame.healthBar, \"topleft\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100) - 4, 2 )\n    \n    --forces the script to run the update as fast as the game framerate\n    self.ThrottleUpdate = 0\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \n    local dotSpeed = abs(envTable._Duration - envTable._RemainingTime) + 1.5\n    envTable.dotAnimation.textureInfo.speedMultiplier = dotSpeed\nend\n\n\n\n\n",
					["Time"] = 1670201853,
					["url"] = "",
					["Icon"] = 2175503,
					["Enabled"] = true,
					["Revision"] = 533,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Apply several animations when the explosion orb cast starts on a Mythic Dungeon with Explosion Affix",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						240446, -- [1]
						385339, -- [2]
						198077, -- [3]
						210261, -- [4]
						360857, -- [5]
					},
					["PlaterCore"] = 1,
					["Name"] = "Explosion Affix M+ [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 3,
							["Key"] = "castBarHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Changes the cast bar color to this one.",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 5,
							["Name"] = "Arrow:",
							["Value"] = "Arrow:",
							["Key"] = "option6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Show Arrow",
							["Value"] = true,
							["Key"] = "showArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above the nameplate showing the cast bar progress.",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Arrow alpha.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 1,
							["Key"] = "arrowAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Alpha",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Width.",
							["Min"] = 4,
							["Name"] = "Arrow Width",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "arrowWidth",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Height.",
							["Min"] = 4,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "arrowHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Height",
						}, -- [8]
						{
							["Type"] = 6,
							["Name"] = "Option 13",
							["Value"] = 0,
							["Key"] = "option13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 5,
							["Name"] = "Dot Animation:",
							["Value"] = "Dot Animation:",
							["Key"] = "option12",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 1,
							["Name"] = "Dot Color",
							["Value"] = {
								1, -- [1]
								0.615686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "dotColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dot animation.",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot X Offset",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 4,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot Y Offset",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot Y Offset",
						}, -- [13]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "Option 18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 5,
							["Key"] = "option17",
							["Value"] = "Nameplate Color",
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [15]
						{
							["Type"] = 4,
							["Name"] = "Change Nameplate Color",
							["Value"] = false,
							["Key"] = "useNameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [16]
						{
							["Type"] = 1,
							["Key"] = "healthBarColor",
							["Value"] = {
								1, -- [1]
								0.1843137294054031, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Health Bar Color",
						}, -- [17]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.overlaySpark:Show()\n    \n    if (envTable.ShowArrow) then\n        envTable.topArrow:Show()\n    end\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    envTable.smallScaleAnimation:Play()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    envTable.overlaySpark.height = nameplateHeight + 5\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    Plater.SetCastBarColorForScript(self, true, scriptTable.config.castBarColor, envTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.healthBarColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end       \nend\n\n\n\n\n\n\n",
				}, -- [18]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    --check for marks\n    function  envTable.CheckMark (unitId, unitFrame)\n        if (not GetRaidTargetIndex(unitId)) then\n            if (scriptTable.config.onlyInCombat) then\n                if (not UnitAffectingCombat(unitId)) then\n                    return\n                end                \n            end\n            \n            SetRaidTarget(unitId, 8)\n        end       \n    end\nend\n\n\n--163520 - forsworn squad-leader\n--163618 - zolramus necromancer - The Necrotic Wake\n--164506 - anciet captain - theater of pain\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n",
					["Time"] = 1604696441,
					["url"] = "",
					["Icon"] = "Interface\\Worldmap\\GlowSkull_64Grey",
					["Enabled"] = false,
					["Revision"] = 63,
					["semver"] = "",
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Auto set skull marker",
					["NpcNames"] = {
						"163520", -- [1]
						"163618", -- [2]
						"164506", -- [3]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Auto Set Skull",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option1",
							["Value"] = "Auto set a raid target Skull on the unit.",
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "onlyInCombat",
							["Value"] = false,
							["Name"] = "Only in Combat",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Set the mark only if the unit is in combat.",
						}, -- [3]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [19]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount = Plater:CreateLabel (unitFrame, \"\", 16, \"silver\");\n    envTable.EnergyAmount:SetPoint (\"bottom\", unitFrame, \"top\", 0, 18);    \n    \n    envTable.EnergyAmount.fontsize = scriptTable.config.fontSize\n    envTable.EnergyAmount.fontcolor = scriptTable.config.fontColor\n    envTable.EnergyAmount.outline = scriptTable.config.outline\n    \n    \nend\n\n--[=[\n\n164406 = Shriekwing\n164407 = Sludgefist\n162100 = kryxis the voracious\n162099 = general kaal - sanguine depths\n162329 = Xav the Unfallen - threater of pain\n--]=]",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Hide()\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local currentPower = UnitPower(unitId)\n    \n    if (currentPower and currentPower > 0) then\n        local maxPower = UnitPowerMax (unitId)\n        local percent = floor (currentPower / maxPower * 100)\n        \n        envTable.EnergyAmount.text = \"\" .. percent;\n        \n        if (scriptTable.config.showLater) then\n            local alpha = (percent -80) * 5\n            alpha = alpha / 100\n            alpha = max(0, alpha)\n            envTable.EnergyAmount:SetAlpha(alpha)\n            \n        else\n            envTable.EnergyAmount:SetAlpha(1.0)\n        end\n        \n        \n    else\n        envTable.EnergyAmount.text = \"\"\n    end\nend\n\n\n\n\n\n\n\n\n",
					["Time"] = 1604357453,
					["url"] = "",
					["Icon"] = 136048,
					["Enabled"] = true,
					["Revision"] = 233,
					["semver"] = "",
					["Author"] = "Celian-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Show the energy amount above the nameplate.",
					["NpcNames"] = {
						"164406", -- [1]
						"164407", -- [2]
						"162100", -- [3]
						"162099", -- [4]
						"162329", -- [5]
						"164558", -- [6]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Unit - Show Energy [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option3",
							["Value"] = "Show the power of the unit above the nameplate.",
							["Name"] = "script desc",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "add trigger",
							["Value"] = "Add the unit name or unitId in the \"Add Trigger\" field and press \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "showLater",
							["Value"] = true,
							["Name"] = "Show at 80% of Energy",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the energy won't start showing until the unit has 80% energy.",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Option 2",
							["Value"] = 0,
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Text size.",
							["Min"] = 8,
							["Name"] = "Text Size",
							["Value"] = 16,
							["Key"] = "fontSize",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "fontColor",
							["Value"] = {
								0.803921568627451, -- [1]
								0.803921568627451, -- [2]
								0.803921568627451, -- [3]
								1, -- [4]
							},
							["Name"] = "Font Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the text.",
						}, -- [8]
						{
							["Type"] = 4,
							["Key"] = "outline",
							["Value"] = true,
							["Name"] = "Enable Text Outline",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the text uses outline.",
						}, -- [9]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Show()\nend\n\n\n",
				}, -- [20]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n\n--Scorchling 194622\n--Scorchling 190205\n--197398  Hungry Lasher\n--77006 corpse skitterling\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --restoring and color state and scale even if disabled, maybe the player disabled during the combat\n    Plater.DenyColorChange(unitFrame, false)\n    unitFrame.healthBar:SetScale(unitFrame.healthBar._savedOriginalScale)\n    \nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n",
					["Time"] = 1670427838,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/duck_64",
					["Enabled"] = true,
					["Revision"] = 111,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "",
					["NpcNames"] = {
						"194622", -- [1]
						"190205", -- [2]
						"197398", -- [3]
						"77006", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Non Elite Trash [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = false,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								0.062745101749897, -- [1]
								0.062745101749897, -- [2]
								0.0941176563501358, -- [3]
								1, -- [4]
							},
							["Key"] = "nameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Change Nameplate Scale",
							["Value"] = true,
							["Key"] = "useNameplateScale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Scale",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Nameplate Scale",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Key"] = "scale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Nameplate Scale",
						}, -- [5]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.nameplateColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end    \n    \n    unitFrame.healthBar._savedOriginalScale = unitFrame.healthBar:GetScale()\n    \n    if (scriptTable.config.useNameplateScale) then\n        unitFrame.healthBar:SetScale(scriptTable.config.scale)\n    end\n    \nend\n\n\n\n\n",
				}, -- [21]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    \n    if (not healthBar.absorbBar) then\n        healthBar.absorbBar = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\")\n        healthBar.absorbBar:SetTexture([[Interface\\RaidFrame\\Shield-Fill]])\n        healthBar.absorbBar:Hide()\n    end\n    \n    if (not healthBar.absorbSpark) then\n        healthBar.absorbSpark = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\")\n        healthBar.absorbSpark:SetTexture([[Interface\\CastingBar\\UI-CastingBar-Spark]])\n        healthBar.absorbSpark:SetBlendMode(\"ADD\")\n        healthBar.absorbSpark:Hide()\n    end\n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Hide()    \n    healthBar.absorbSpark:Hide()\n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Show()\n    healthBar.absorbSpark:Show()\n    \n    local maxValue = healthBar.absorbBar.MaxValue\n    local currentValue = UnitGetTotalAbsorbs(unitId) or 0\n    \n    if (currentValue > 0) then\n        local minValue = 0\n        \n        local percent = currentValue / maxValue\n        healthBar.absorbBar:SetTexCoord(0, percent, 0, 1)\n        healthBar.absorbBar:SetWidth(percent * healthBar:GetWidth())\n        \n        healthBar.absorbSpark:SetPoint(\"left\", healthBar, \"left\", percent * healthBar:GetWidth() - 16, 0)\n        \n    else\n        healthBar.absorbBar:Hide()    \n        healthBar.absorbSpark:Hide()\n    end\n    \n    self.ThrottleUpdate = 0\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1669325411,
					["url"] = "",
					["Icon"] = "interface/addons/plater/images/cast_bar - absorb",
					["Enabled"] = true,
					["Revision"] = 101,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "When the caster has a shield and only when the shield is removed the cast can be interrupted",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						373688, -- [1]
						391050, -- [2]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Shield Interrupt [P]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Show()\n    healthBar.absorbSpark:Show()\n    \n    healthBar.absorbBar:SetTexture([[Interface\\RaidFrame\\Shield-Fill]])\n    \n    healthBar.absorbBar:ClearAllPoints()    \n    healthBar.absorbBar:SetPoint(\"topleft\", healthBar, \"topleft\", 0, 0)\n    healthBar.absorbBar:SetPoint(\"bottomleft\", healthBar, \"bottomleft\", 0, 0)\n    \n    healthBar.absorbBar:SetAlpha(1)\n    \n    healthBar.absorbBar.MaxValue = UnitGetTotalAbsorbs(unitId) or 0\n    healthBar.absorbBar.MinValue = 0\nend\n\n\n",
				}, -- [22]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    if (not unitFrame.spitefulTexture) then\n        unitFrame.spitefulTexture = unitFrame.healthBar:CreateTexture(nil, \"overlay\", nil, 6)\n        unitFrame.spitefulTexture:SetPoint('right', 0, 0)\n        unitFrame.spitefulTexture:SetSize(27, 14)\n        unitFrame.spitefulTexture:SetColorTexture(.3, .3, 1, .7)\n        \n        unitFrame.spitefulText = unitFrame.healthBar:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)\n        DetailsFramework:SetFontFace (unitFrame.spitefulText, \"2002\")\n        unitFrame.spitefulText:SetPoint(\"right\", unitFrame.spitefulTexture, \"right\", -2, 0)\n        unitFrame.spitefulText:SetJustifyH(\"right\")\n        \n        unitFrame.roleIcon = unitFrame:CreateTexture(nil, \"overlay\")\n        unitFrame.roleIcon:SetPoint(\"left\", unitFrame.healthBar, \"left\", 2, 0)\n        unitFrame.targetName = unitFrame:CreateFontString(nil, \"overlay\", \"GameFontNormal\")\n        unitFrame.targetName:SetPoint(\"left\", unitFrame.roleIcon, \"right\", 2, 0)\n        \n        unitFrame.spitefulTexture:Hide()\n        unitFrame.spitefulText:Hide()\n    end\n    \n    function envTable.UpdateSpitefulWidget(unitFrame)\n        \n        local r, g, b, a = Plater:ParseColors(scriptTable.config.bgColor)\n        unitFrame.spitefulTexture:SetColorTexture(r, g, b, a)\n        unitFrame.spitefulTexture:SetSize(scriptTable.config.bgWidth, unitFrame.healthBar:GetHeight())   \n        Plater:SetFontSize(unitFrame.spitefulText, scriptTable.config.textSize)\n        Plater:SetFontColor(unitFrame.spitefulText, scriptTable.config.textColor)\n        \n        local currentHealth = unitFrame.healthBar.CurrentHealth\n        local maxHealth = unitFrame.healthBar.CurrentHealthMax\n        \n        local healthPercent = currentHealth / maxHealth * 100\n        local timeToDie = format(\"%.1fs\", healthPercent / 8)\n        unitFrame.spitefulText:SetText(timeToDie)\n        \n        unitFrame.spitefulText:Show()\n        unitFrame.spitefulTexture:Show()\n        \n        if scriptTable.config.switchTargetName then\n            local plateFrame = unitFrame.PlateFrame\n            \n            local target = UnitName(unitFrame.namePlateUnitToken .. \"target\") or UnitName(unitFrame.namePlateUnitToken)\n            \n            if (target and target ~= \"\") then\n                local _, class = UnitClass(unitFrame.namePlateUnitToken .. \"target\")\n                if (class) then\n                    target = DetailsFramework:AddClassColorToText(target, class)\n                end\n                \n                local role = UnitGroupRolesAssigned(unitFrame.namePlateUnitToken .. \"target\")\n                if (role and role ~= \"NONE\") then\n                    target = DetailsFramework:AddRoleIconToText(target, role)\n                end\n                \n                plateFrame.namePlateUnitName = target\n                Plater.UpdateUnitName(plateFrame)\n            end\n        end\n        \n        if scriptTable.config.useTargetingColor then\n            local targeted = UnitIsUnit(unitFrame.namePlateUnitToken .. \"target\", \"player\")\n            if targeted then\n                Plater.SetNameplateColor (unitFrame, scriptTable.config.targetingColor)\n            else\n                Plater.RefreshNameplateColor(unitFrame)\n            end\n        end\n    end\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    if (unitFrame.spitefulTexture) then\n        unitFrame.spitefulText:Hide()\n        unitFrame.spitefulTexture:Hide()    \n        unitFrame.roleIcon:Hide()\n        unitFrame.targetName:Hide()\n    end\nend\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
					["Time"] = 1611844883,
					["url"] = "",
					["Icon"] = 135945,
					["Enabled"] = true,
					["Revision"] = 186,
					["semver"] = "",
					["Author"] = "Symantec-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Time to die Spiteful affix",
					["NpcNames"] = {
						"174773", -- [1]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "M+ Spiteful",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option12",
							["Value"] = "Time to Die",
							["Name"] = "Time to Die",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 2,
							["Max"] = 50,
							["Desc"] = "",
							["Min"] = 10,
							["Key"] = "bgWidth",
							["Value"] = 27,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Width",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "bgColor",
							["Value"] = {
								0.5058823529411764, -- [1]
								0.07058823529411765, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Background Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 24,
							["Desc"] = "",
							["Min"] = 7,
							["Key"] = "textSize",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Text Size",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "textColor",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Text Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 5,
							["Key"] = "option11",
							["Value"] = "Targeting",
							["Name"] = "Targeting",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 4,
							["Name"] = "Show Target instead of Name",
							["Value"] = true,
							["Key"] = "switchTargetName",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Name"] = "Change Color if targeting You",
							["Value"] = true,
							["Key"] = "useTargetingColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 1,
							["Name"] = "Color if targeting You",
							["Value"] = {
								0.07058823529411765, -- [1]
								0.6196078431372549, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "targetingColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 6,
							["Key"] = "option11",
							["Value"] = 0,
							["Name"] = "Option 11",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [11]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
				}, -- [23]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.stopCastingX) then\n        unitFrame.stopCastingX = castBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 7)\n        unitFrame.stopCastingX:SetPoint(\"center\", unitFrame.castBar.Spark, \"center\", 0, 0)\n        unitFrame.stopCastingX:SetTexture([[Interface\\AddOns\\Plater\\Media\\stop_64]])\n        unitFrame.stopCastingX:SetSize(16, 16)\n        unitFrame.stopCastingX:Hide()\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:Hide()\n    end\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Hide()    \n    unitFrame.stopCastingX:Hide()\n    \n    self.Text:SetDrawLayer(\"overlay\", 0)\n    self.Spark:SetDrawLayer(\"overlay\", 3)\n    self.Spark:Show()\n    \nend\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then\n        local nextPercent = 100 / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        \n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        --print(envTable.NextPercent, envTable.CurrentTexture)\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1672514185,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\stop_64",
					["Enabled"] = true,
					["Revision"] = 506,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Just stop casting",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						377004, -- [1]
						381516, -- [2]
						196543, -- [3]
						199726, -- [4]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Stop Casting [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Fraction"] = false,
							["Value"] = 20,
							["Name"] = "Amount of Segments",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "segmentsAmount",
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        --local duration = 0.6 --debug\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    unitFrame.stopCastingX:Show()\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    self.Text:SetDrawLayer(\"artwork\", 7)\n    self.Spark:SetDrawLayer(\"artwork\", 7)\n    self.Spark:Hide()\nend\n\n\n\n\n\n\n\n\n",
				}, -- [24]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "		function (self, unitId, unitFrame, envTable, scriptTable)\n			--insert code here\n			\n		end\n	",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (UnitIsUnit(unitId .. \"target\", \"player\")) then\n        Plater.SetNameplateColor(unitFrame, scriptTable.config.nameplateColor)\n    else\n        Plater.RefreshNameplateColor(unitFrame)\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1668886509,
					["url"] = "",
					["Icon"] = "Interface\\ICONS\\Ability_Fixated_State_Red",
					["Enabled"] = true,
					["Revision"] = 33,
					["semver"] = "",
					["Author"] = "Ditador-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Alert about a unit fixated on the player by using a buff on the enemy unit.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Fixate by Unit Buff [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								0, -- [1]
								0.5568627450980392, -- [2]
								0.03529411764705882, -- [3]
								1, -- [4]
							},
							["Key"] = "nameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Change the enemy nameplate color to this color when fixating you!",
						}, -- [1]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
				}, -- [25]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local movingArrowTexture = unitFrame._movingArrowTexture\n    if (not movingArrowTexture) then\n        movingArrowTexture = self:CreateTexture(nil, \"artwork\", nil, 6)\n        unitFrame._movingArrowTexture = movingArrowTexture\n    end\n    \n    envTable.movingAnimation = envTable.movingAnimation or Plater:CreateAnimationHub (unitFrame._movingArrowTexture, \n        function() \n            unitFrame._movingArrowTexture:Show() \n            unitFrame._movingArrowTexture:SetPoint(\"left\", 0, 0)\n        end, \n        function() unitFrame._movingArrowTexture:Hide() end)\n    \n    envTable.movingAnimation:SetLooping (\"REPEAT\")\n    \n    envTable.arrowAnimation = envTable.arrowAnimation or Plater:CreateAnimation (envTable.movingAnimation, \"translation\", 1, 0.20, self:GetWidth()-16, 0)\n    \n    envTable.arrowAnimation:SetDuration(scriptTable.config.animSpeed)\nend\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.movingAnimation:Stop()\nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    unitFrame._movingArrowTexture:SetAlpha(scriptTable.config.arrowAlpha)\n    \n    local percent = envTable.movingAnimation:GetProgress()\n    \n    if (percent < 0.4) then\n        local value = Lerp(0.01, scriptTable.config.arrowAlpha, percent) or 0\n        unitFrame._movingArrowTexture:SetAlpha(Saturate(value))\n        \n    elseif (percent > 0.6) then\n        local value = Lerp(scriptTable.config.arrowAlpha, 0.01, percent) or 0\n        unitFrame._movingArrowTexture:SetAlpha(Saturate(value))\n    end\n    \n    --unitFrame._movingArrowTexture:SetAlpha(1)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1670202265,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_frontal",
					["Enabled"] = true,
					["Revision"] = 620,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Does an animation for casts that affect the frontal area of the enemy. Add spell in the Add Trigger field.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						375943, -- [1]
						385958, -- [2]
						388623, -- [3]
						377034, -- [4]
						374361, -- [5]
						381525, -- [6]
						386660, -- [7]
						385578, -- [8]
						384699, -- [9]
						153501, -- [10]
						153686, -- [11]
						154442, -- [12]
						192018, -- [13]
						219488, -- [14]
						372087, -- [15]
						391726, -- [16]
						391723, -- [17]
						377383, -- [18]
						388976, -- [19]
						370764, -- [20]
						387067, -- [21]
						391118, -- [22]
						391136, -- [23]
						382233, -- [24]
						209027, -- [25]
						212031, -- [26]
						207261, -- [27]
						207979, -- [28]
						198888, -- [29]
						199805, -- [30]
						199050, -- [31]
						191508, -- [32]
						152792, -- [33]
						153395, -- [34]
						352833, -- [35]
						330403, -- [36]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Frontal Cone [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces an effect to indicate the spell will hit players in front of the enemy.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 4",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 3",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Set the alpha of the moving arrow",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.73,
							["Key"] = "arrowAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Alpha",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Time that takes for an arrow to travel from the to right.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "animSpeed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Animation Speed",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Use White Arrow",
							["Value"] = false,
							["Key"] = "desaturateArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the arrow color will be desaturated.",
						}, -- [7]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame._movingArrowTexture:SetTexture([[Interface\\PETBATTLES\\PetBattle-StatIcons]])\n    unitFrame._movingArrowTexture:SetSize(16, self:GetHeight() - 2)\n    unitFrame._movingArrowTexture:SetTexCoord(unpack({0, 15/32, 18/32, 30/32}))\n    unitFrame._movingArrowTexture:SetAlpha(scriptTable.config.arrowAlpha)\n    unitFrame._movingArrowTexture:SetDesaturated(scriptTable.config.desaturateArrow)    \n    \n    unitFrame._movingArrowTexture:SetParent(self.FrameOverlay)\n    unitFrame._movingArrowTexture:SetDrawLayer(\"overlay\",  7)\n    \n    envTable.arrowAnimation:SetDuration(scriptTable.config.animSpeed)\n    envTable.movingAnimation:Play()\nend\n\n\n",
				}, -- [26]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    function envTable.CreateWidgets()\n        --create a camera shake for the nameplate\n        if (not unitFrame.AddExplosionOnDieShake) then\n            unitFrame.AddExplosionOnDieShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n        end\n        \n        if (not unitFrame.AddExplosionOnDieBackground) then\n            unitFrame.AddExplosionOnDieBackground = unitFrame.healthBar:CreateTexture(nil, \"background\")\n            unitFrame.AddExplosionOnDieBackground:SetAllPoints(unitFrame.healthBar)\n            unitFrame.AddExplosionOnDieBackground:SetColorTexture(1, 0, 0, 1)\n        end\n    end\n    \nend\n\n--194895 = unstable squall\n--105703 = mana wyrm\n--59598 = lesser sha\n--58319 = lesser sha\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    healthBar:SetReverseFill(false)\n    \n    if (unitFrame.AddExplosionOnDieShake) then\n        unitFrame:StopFrameShake (unitFrame.AddExplosionOnDieShake)    \n    end\n    \n    if (unitFrame.AddExplosionOnDieBackground) then\n        unitFrame.AddExplosionOnDieBackground:Hide()\n    end\nend\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (envTable._HealthPercent < 50) then\n        local alpha = DetailsFramework:MapRangeClamped(0, 50, 0.5, 0, envTable._HealthPercent)\n        \n        unitFrame.AddExplosionOnDieBackground:SetAlpha(alpha)\n    else\n        unitFrame.AddExplosionOnDieBackground:SetAlpha(0)\n    end\n    \n    if (envTable._HealthPercent < 15 and scriptTable.config.useShake) then\n        local shakeAmpliture = DetailsFramework:MapRangeClamped(0.001, 15, 10, 1, envTable._HealthPercent)\n        \n        unitFrame.AddExplosionOnDieShake.OriginalAmplitude = scriptTable.config.shakeAmplitude * shakeAmpliture\n        unitFrame.AddExplosionOnDieShake.OriginalFrequency = scriptTable.config.shakeFrequency\n        \n        unitFrame:PlayFrameShake (unitFrame.AddExplosionOnDieShake)\n    end\n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1669340350,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/radio_64",
					["Enabled"] = true,
					["Revision"] = 106,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "",
					["NpcNames"] = {
						"194895", -- [1]
						"105703", -- [2]
						"59598", -- [3]
						"58319", -- [4]
						200388, -- [5]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Explode on Die [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useReverse",
							["Value"] = false,
							["Name"] = "Reverse Health Bar",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "option6",
							["Value"] = 0,
							["Name"] = "Option 6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "useShake",
							["Value"] = false,
							["Name"] = "Enable Shake",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "How strong is the shake.",
							["Min"] = 0.05,
							["Key"] = "shakeAmplitude",
							["Value"] = 0.2,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 70,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Key"] = "useBackground",
							["Value"] = true,
							["Name"] = "Show Red Background",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show Red Background",
						}, -- [7]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    \n    if (scriptTable.config.useReverse) then\n        healthBar:SetReverseFill(true)\n    end\n    \n    --unitFrame.AddExplosionOnDieShake\n    \n    envTable.CreateWidgets()\n    \n    unitFrame.AddExplosionOnDieShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    unitFrame.AddExplosionOnDieShake.OriginalDuration = 0.120\n    unitFrame.AddExplosionOnDieShake.OriginalFrequency = scriptTable.config.shakeFrequency\n    \n    if (scriptTable.config.useBackground) then\n        unitFrame.AddExplosionOnDieBackground:Show()\n        unitFrame.AddExplosionOnDieBackground:SetAlpha(0)\n    else\n        unitFrame.AddExplosionOnDieBackground:Hide()\n    end\nend\n\n\n\n\n\n\n",
				}, -- [27]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.BuffFrame, \"top\", 0, 10);    \n    \n    envTable.FixateIcon = Plater:CreateImage (unitFrame, 236188, 16, 16, \"overlay\");\n    envTable.FixateIcon:SetPoint (\"bottom\", envTable.FixateTarget, \"top\", 0, 4);    \n    \n    envTable.FixateTarget:Hide()\n    envTable.FixateIcon:Hide()\nend\n\n--165560 = Gormling Larva - MTS\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:Hide()\n    envTable.FixateIcon:Hide()\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    local targetName = UnitName (unitId .. \"target\");\n    if (targetName) then\n        local _, class = UnitClass (unitId .. \"target\");\n        targetName = Plater.SetTextColorByClass (unitId .. \"target\", targetName);\n        envTable.FixateTarget.text = targetName;\n        \n        envTable.FixateTarget:Show();\n        envTable.FixateIcon:Show();\n    end    \nend\n\n\n",
					["Time"] = 1604239880,
					["url"] = "",
					["Icon"] = 1029718,
					["Enabled"] = true,
					["Revision"] = 269,
					["semver"] = "",
					["Author"] = "Celian-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n\n\n\n\n",
					["Desc"] = "Show above the nameplate who is the player fixated",
					["NpcNames"] = {
						"165560", -- [1]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Fixate [Plater]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
				}, -- [28]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    envTable.npcInfo = {\n        [164427] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"1\", name = \"Boom!\"}, --reanimated warrior - plaguefall\n        \n        [164414] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"2\", name = \"Boom!\"}, --reanimated mage - plaguefall\n        \n        [164185] = {secondCastBar = true, timer = 20, timerId = 319941, altCastId = \"3\", remaining = 5, name = GetSpellInfo(319941)}, --Echelon - Halls of Atonement\n        \n        [164567] = {secondCastBar = true, altCastId = \"dromanswrath\", debuffTimer = 323059, name = GetSpellInfo(323059), spellIcon = 323059}, --Ingra Maloch -- tirna scythe\n        \n        [165408] = {secondCastBar = true, timer = 20, timerId = 322711, altCastId = \"4\", remaining = 5, name = GetSpellInfo(322711)}, --Halkias - Refracted Sinlight - Halls of Atonement\n        \n        \n        --[154564] = {secondCastBar = true, timerId = \"Test Bar\", altCastId = \"debugcast\", remaining = 5, name = GetSpellInfo(319941), spellIcon = 319941}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n        --[154580] = {secondCastBar = true, altCastId = \"debugcast\", debuffTimer = 204242, name = GetSpellInfo(81297), spellIcon = 81297}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n    }\n    \n    --set the castbar config\n    local config = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end\n        \n        DetailsFramework:TruncateText(unitFrame.castBar2.Text, unitFrame.castBar2:GetWidth() - 16)\n    end\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    Plater.ClearAltCastBar(unitFrame.PlateFrame)\nend",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                if (altCastId ~= npcInfo.altCastId or not unitFrame.castBar2:IsShown()) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n                end\n            end \n            \n        elseif (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                --get the debuff timeleft\n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                local startTime = expirationTime - duration\n                \n                if (not unitFrame.castBar2:IsShown() or unitFrame.castBar2.spellStartTime < startTime) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, startTime)\n                end\n                \n            else \n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1604354364,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\Images\\countdown_bar_icon",
					["Enabled"] = true,
					["Revision"] = 206,
					["semver"] = "",
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Some units has special events without a clear way to show. This script adds a second cast bar to inform the user about it.",
					["NpcNames"] = {
						"164427", -- [1]
						"164414", -- [2]
						"164185", -- [3]
						"164567", -- [4]
						"165408", -- [5]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Countdown",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                \n                envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, expirationTime-duration)\n            else\n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        else\n            envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [29]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.castBar, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1673994690,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_darkorange",
					["Enabled"] = true,
					["Revision"] = 828,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Highlight a very important cast applying several effects into the Cast Bar. Add spell in the Add Trigger field.",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.castBar, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\n    \n    --Dominator on Shadowmoon Burial Grounds\n    if (envTable._SpellID == 154327) then\n        if (UnitHealth(unitId) == UnitHealthMax(unitId)) then\n            if (envTable._Duration == 604800) then\n                Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, {1, 0, 0, 1}, envTable)\n            end\n        end\n    end\nend",
					["SpellIds"] = {
						373046, -- [1]
						372863, -- [2]
						164686, -- [3]
						153072, -- [4]
						153680, -- [5]
						196497, -- [6]
						388886, -- [7]
						387145, -- [8]
						384365, -- [9]
						152964, -- [10]
						398150, -- [11]
						152801, -- [12]
						397878, -- [13]
						397914, -- [14]
						183263, -- [15]
						3636, -- [16]
						376171, -- [17]
						350687, -- [18]
						372735, -- [19]
						373017, -- [20]
						392488, -- [21]
					},
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Plays a big animation when the cast start.",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Flash:",
							["Name"] = "Flash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [6]
						{
							["Type"] = 1,
							["Key"] = "flashColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Flash Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Name"] = "Shake",
							["Value"] = "Shake:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 5,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Amplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 40,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Frequency",
						}, -- [12]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Key"] = "option14",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 8,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot Y Offset",
						}, -- [17]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Key"] = "option19",
							["Value"] = "Cast Bar",
							["Name"] = "Option 19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Use Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Key"] = "castBarColor",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
					},
					["version"] = -1,
					["Name"] = "Cast - Very Important [Plater]",
					["NpcNames"] = {
					},
				}, -- [30]
				{
					["ConstructorCode"] = "--todo: add npc ids for multilanguage support\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.TextAboveNameplate = \"** On You **\"\n    envTable.NameplateColor = \"green\"\n    \n    --label to show the text above the nameplate\n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.healthBar, \"top\", 0, 30);\n    \n    --the spell casted by the npc in the trigger list needs to be in the list below as well\n    local spellList = {\n        [321891] = \"Freeze Tag Fixation\", --Illusionary Vulpin - MTS\n        \n    }\n    \n    --build the list with localized spell names\n    envTable.FixateDebuffs = {}\n    for spellID, enUSSpellName in pairs (spellList) do\n        local localizedSpellName = GetSpellInfo (spellID)\n        envTable.FixateDebuffs [localizedSpellName or enUSSpellName] = true\n    end\n    \n    --debug - smuggled crawg\n    envTable.FixateDebuffs [\"Jagged Maw\"] = true\n    \nend\n\n--[=[\nNpcIDs:\n136461: Spawn of G'huun (mythic uldir G'huun)\n\n--]=]\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:SetText (\"\")\n    envTable.FixateTarget:Hide()\n    \n    envTable.IsFixated = false\n    \n    Plater.RefreshNameplateColor (unitFrame)\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --swap this to true when it is fixated\n    local isFixated = false\n    \n    --check the debuffs the player has and see if any of these debuffs has been placed by this unit\n    for debuffId = 1, 40 do\n        local name, texture, count, debuffType, duration, expirationTime, caster = UnitDebuff (\"player\", debuffId)\n        \n        --cancel the loop if there's no more debuffs on the player\n        if (not name) then \n            break \n        end\n        \n        --check if the owner of the debuff is this unit\n        if (envTable.FixateDebuffs [name] and caster and UnitIsUnit (caster, unitId)) then\n            --the debuff the player has, has been placed by this unit, set the name above the unit name\n            envTable.FixateTarget:SetText (envTable.TextAboveNameplate)\n            envTable.FixateTarget:Show()\n            Plater.SetNameplateColor (unitFrame,  envTable.NameplateColor)\n            isFixated = true\n            \n            if (not envTable.IsFixated) then\n                envTable.IsFixated = true\n                Plater.FlashNameplateBody (unitFrame, \"fixate\", .2)\n            end\n        end\n        \n    end\n    \n    --check if the nameplate color is changed but isn't fixated any more\n    if (not isFixated and envTable.IsFixated) then\n        --refresh the nameplate color\n        Plater.RefreshNameplateColor (unitFrame)\n        --reset the text\n        envTable.FixateTarget:SetText (\"\")\n        \n        envTable.IsFixated = false\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1604087921,
					["url"] = "",
					["Icon"] = 841383,
					["Enabled"] = true,
					["Revision"] = 266,
					["semver"] = "",
					["Author"] = "Tecno-Azralon",
					["Desc"] = "When an enemy places a debuff and starts to chase you. This script changes the nameplate color and place your name above the nameplate as well.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						"spawn of g'huun", -- [1]
						"smuggled crawg", -- [2]
						"sergeant bainbridge", -- [3]
						"blacktooth scrapper", -- [4]
						"irontide grenadier", -- [5]
						"feral bloodswarmer", -- [6]
						"earthrager", -- [7]
						"crawler mine", -- [8]
						"rezan", -- [9]
					},
					["PlaterCore"] = 1,
					["Name"] = "Fixate On You [Plater]",
					["version"] = -1,
					["Options"] = {
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
				}, -- [31]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local plateFrame = unitFrame.PlateFrame\n    \n    if (not plateFrame.BWC_RedBackground) then\n        plateFrame.BWC_RedBackground = plateFrame:CreateTexture(nil, \"background\")\n        plateFrame.BWC_RedBackground:SetAllPoints()\n    end\n    \n    plateFrame.BWC_RedBackground:SetTexture([[Interface/AddOns/Plater/masks/mask1]])\n    plateFrame.BWC_RedBackground:Hide()\n    \n    function envTable.ShowBackground(unitFrame)\n        local plateFrame = unitFrame.PlateFrame\n        plateFrame.BWC_RedBackground:SetVertexColor(1, 0, 0, 0.4)\n        plateFrame.BWC_RedBackground:Show()\n    end\n    \n    function envTable.HideBackground(unitFrame)\n        plateFrame.BWC_RedBackground:Hide()\n    end\nend\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.HideBackground(unitFrame)\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (Plater.UnitIsCasting(unitId)) then\n        envTable.ShowBackground(unitFrame)\n    else\n        envTable.HideBackground(unitFrame)\n    end\n    \nend",
					["Time"] = 1673726734,
					["url"] = "",
					["Icon"] = 236209,
					["Enabled"] = true,
					["Revision"] = 18,
					["semver"] = "",
					["Author"] = "Tiranaa-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Highlight the nameplate of a unit when has a certain Buff (trigger) and start to cast a spell",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["SpellIds"] = {
						372743, -- [1]
						372749, -- [2]
						384933, -- [3]
					},
					["PlaterCore"] = 1,
					["Options"] = {
					},
					["version"] = -1,
					["Name"] = "Aura While Casting [P]",
					["NpcNames"] = {
					},
				}, -- [32]
			},
			["aura2_x_offset"] = 0,
			["hook_data"] = {
				{
					["Enabled"] = false,
					["Revision"] = 50,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Kastfall-Azralon",
					["Time"] = 1547392935,
					["Desc"] = "Easy way to change the color of an unit. Open the constructor script and follow the examples.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --list of npcs and their colors, can be inserted:\n    --name of the unit\n    --name of the unit in lower case\n    --npcID of the unit\n    \n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    \n    envTable.NpcColors = {\n        \n        --examples, using the unit name in lower case, regular unit name and the unitID:\n        \n        [\"Thunderlord Windreader\"] = \"red\", --using regular mob name and color it as red\n        [\"thunderlord crag-leaper\"] = {1, 1, 0}, --using lower case and coloring it yellow\n        [75790] = \"#00FF00\", --using the ID of the unit and using green as color\n        \n        --insert the new mobs here:\n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n    } --close custom color bracket\n    \nend\n\n\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --attempt to get the color from the unit color list\n    local color = envTable.NpcColors [unitFrame.namePlateUnitNameLower] or envTable.NpcColors [unitFrame.namePlateUnitName] or envTable.NpcColors [unitFrame.namePlateNpcId]\n    \n    --if the color exists, set the health bar color\n    if (color) then\n        Plater.SetNameplateColor (unitFrame, color)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Color Automation [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["role"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\color_bar",
					["HooksTemp"] = {
					},
				}, -- [1]
				{
					["Enabled"] = false,
					["Revision"] = 73,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1541606242,
					["Desc"] = "Hide neutral units, show when selected, see the constructor script for options.",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat) then\n            envTable.HideNameplate (unitFrame)\n        end\n    end\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end\n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat and InCombatLockdown()) then\n            return\n        end\n        \n        envTable.HideNameplate (unitFrame)\n    end\n    \nend\n\n\n\n\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat and InCombatLockdown()) then\n            return\n        end\n        \n        --check the unit reaction\n        if (unitFrame.namePlateIsTarget) then\n            envTable.ShowNameplate (unitFrame)\n            \n        else\n            envTable.HideNameplate (unitFrame)\n            \n        end    \n    end\n    \nend\n\n\n\n\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        envTable.ShowNameplate (unitFrame)\n    end\n    \nend\n\n\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when plater finishes an update on the nameplate\n    --check within the envTable if the healthBar of this nameplate should be hidden\n    if (envTable.IsHidden) then\n        if (unitFrame.healthBar:IsShown()) then\n            envTable.HideNameplate (unitFrame)\n        end\n    end\n    \nend\n\n\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat) then\n            envTable.ShowNameplate (unitFrame)\n        end\n    end\nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.OnlyInOpenWorld = true;\n    envTable.ShowInCombat = true;\n    \n    --consts\n    envTable.REACTION_NEUTRAL = 4;\n    \n    --functions to hide and show the healthBar\n    function envTable.HideNameplate (unitFrame)\n        Plater.HideHealthBar (unitFrame)\n        Plater.DisableHighlight (unitFrame)\n        envTable.IsHidden = true\n    end\n    \n    function envTable.ShowNameplate (unitFrame)\n        Plater.ShowHealthBar (unitFrame)\n        Plater.EnableHighlight (unitFrame)\n        envTable.IsHidden = false\n    end\n    \nend\n\n\n\n\n",
					},
					["Name"] = "Hide Neutral Units [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["race"] = {
						},
					},
					["url"] = "",
					["Icon"] = 1990989,
					["HooksTemp"] = {
					},
				}, -- [2]
				{
					["Enabled"] = false,
					["Revision"] = 93,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Options"] = {
					},
					["Author"] = "Kastfall-Azralon",
					["Time"] = 1596791840,
					["Desc"] = "Function Plater.UpdatePlateSize from Plater.lua exported to scritps.",
					["Hooks"] = {
						["Nameplate Added"] = "\n\n-- exported function Plater.UpdatePlateSize() from Plater.lua\n--this is for advanced users which wants to reorder the nameplate frame at their desire\n\n\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --check if there's a type of unit on this nameplate\n    local plateFrame = unitFrame:GetParent()\n    if (not plateFrame.actorType) then\n        return\n    end\n    \n    --get all the frames and cache some variables\n    local ACTORTYPE_ENEMY_PLAYER = \"enemyplayer\"\n    local profile = Plater.db.profile\n    local DB_PLATE_CONFIG = profile.plate_config\n    local isInCombat = Plater.IsInCombat()\n    local actorType = plateFrame.actorType\n    \n    local unitFrame = plateFrame.unitFrame\n    local healthBar = unitFrame.healthBar\n    local castBar = unitFrame.castBar\n    local powerBar = unitFrame.powerBar\n    local buffFrame1 = unitFrame.BuffFrame\n    local buffFrame2 = unitFrame.BuffFrame2\n    \n    --use in combat bars when in pvp\n    if (plateFrame.actorType == ACTORTYPE_ENEMY_PLAYER) then\n        if ((Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"arena\") and DB_PLATE_CONFIG.player.pvp_always_incombat) then\n            isInCombat = true\n        end\n    end\n    \n    --get the config for this actor type\n    local plateConfigs = DB_PLATE_CONFIG [actorType]\n    --get the config key based if the player is in combat\n    local castBarConfigKey, healthBarConfigKey, manaConfigKey = Plater.GetHashKey (isInCombat)\n    \n    --get the width and height from what the user set in the options panel\n    local healthBarWidth, healthBarHeight = unitFrame.customHealthBarWidth or plateConfigs [healthBarConfigKey][1], unitFrame.customHealthBarHeight or plateConfigs [healthBarConfigKey][2]\n    local castBarWidth, castBarHeight = unitFrame.customCastBarWidth or plateConfigs [castBarConfigKey][1], unitFrame.customCastBarHeight or plateConfigs [castBarConfigKey][2]\n    local powerBarWidth, powerBarHeight = unitFrame.customPowerBarHeight or plateConfigs [manaConfigKey][1], unitFrame.customPowerBarHeight or plateConfigs [manaConfigKey][2]\n    \n    --calculate the offset for the cast bar, this is done due to the cast bar be anchored to topleft and topright\n    local castBarOffSetX = (healthBarWidth - castBarWidth) / 2\n    local castBarOffSetY = plateConfigs.castbar_offset\n    \n    --calculate offsets for the power bar\n    local powerBarOffSetX = (healthBarWidth - powerBarWidth) / 2\n    local powerBarOffSetY = 0\n    \n    --calculate the size deviation for pets\n    local unitType = Plater.GetUnitType (plateFrame)\n    if (unitType == \"pet\") then\n        healthBarHeight = healthBarHeight * Plater.db.profile.pet_height_scale\n        healthBarWidth = healthBarWidth * Plater.db.profile.pet_width_scale\n        \n    elseif (unitType == \"minus\") then\n        healthBarHeight = healthBarHeight * Plater.db.profile.minor_height_scale\n        healthBarWidth = healthBarWidth * Plater.db.profile.minor_width_scale\n    end\n    \n    --unit frame - is set to be the same size as the plateFrame\n    unitFrame:ClearAllPoints()\n    unitFrame:SetAllPoints()\n    \n    --calculates the health bar anchor points\n    --it will always be placed in the center of the nameplate area (where it accepts mouse clicks) \n    local xOffSet = (plateFrame:GetWidth() - healthBarWidth) / 2\n    local yOffSet = (plateFrame:GetHeight() - healthBarHeight) / 2\n    \n    --set the health bar point\n    healthBar:ClearAllPoints()\n    PixelUtil.SetPoint (healthBar, \"topleft\", unitFrame, \"topleft\", xOffSet + profile.global_offset_x, -yOffSet + profile.global_offset_y)\n    PixelUtil.SetPoint (healthBar, \"bottomright\", unitFrame, \"bottomright\", -xOffSet + profile.global_offset_x, yOffSet + profile.global_offset_y)\n    \n    --set the cast bar point and size\n    castBar:ClearAllPoints()\n    PixelUtil.SetPoint (castBar, \"topleft\", healthBar, \"bottomleft\", castBarOffSetX, castBarOffSetY)\n    PixelUtil.SetPoint (castBar, \"topright\", healthBar, \"bottomright\", -castBarOffSetX, castBarOffSetY)\n    PixelUtil.SetHeight (castBar, castBarHeight)\n    PixelUtil.SetSize (castBar.Icon, castBarHeight, castBarHeight)\n    PixelUtil.SetSize (castBar.BorderShield, castBarHeight * 1.4, castBarHeight * 1.4)\n    \n    --set the power bar point and size\n    powerBar:ClearAllPoints()\n    PixelUtil.SetPoint (powerBar, \"topleft\", healthBar, \"bottomleft\", powerBarOffSetX, powerBarOffSetY)\n    PixelUtil.SetPoint (powerBar, \"topright\", healthBar, \"bottomright\", -powerBarOffSetX, powerBarOffSetY)\n    PixelUtil.SetHeight (powerBar, powerBarHeight)\n    \n    --power bar are hidden by default, show it if there's a custom size for it\n    if (unitFrame.customPowerBarWidth and unitFrame.customPowerBarHeight) then\n        powerBar:SetUnit (unitFrame.unit)\n    end\n    \n    --aura frames\n    local bf1Anchor = Plater.db.profile.aura_frame1_anchor\n    Plater.SetAnchor (buffFrame1, {side = bf1Anchor.side, x = bf1Anchor.x, y = bf1Anchor.y + plateConfigs.buff_frame_y_offset}, unitFrame.healthBar, (Plater.db.profile.aura_grow_direction or 2) == 2)\n    \n    local bf2Anchor = Plater.db.profile.aura_frame2_anchor\n    Plater.SetAnchor (buffFrame2, {side = bf2Anchor.side, x = bf2Anchor.x, y = bf2Anchor.y + plateConfigs.buff_frame_y_offset}, unitFrame.healthBar, (Plater.db.profile.aura2_grow_direction or 2) == 2)\n    \nend\n\n\n",
					},
					["version"] = -1,
					["Name"] = "Reorder Nameplate [Plater]",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["race"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["PlaterCore"] = 1,
					["url"] = "",
					["Icon"] = 574574,
					["HooksTemp"] = {
					},
				}, -- [3]
				{
					["Enabled"] = false,
					["Revision"] = 59,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1554138845,
					["Desc"] = "Change the nameplate color when a nameplate does not have the auras set in the constructor script.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    --Important: lines starting with double dashes are comments and are not part of the script\n    \n    --set this to true if you are not using threat colors in the health bar\n    envTable.ForceRefreshNameplateColor = true\n    \n    --if the unit does not have any of the following auras, it will be painted with the color listed below\n    --list of spells to track, can be the spell name (case-sensitive) or the spellID\n    envTable.TrackingAuras = {\n        --[\"Nightblade\"] = true, --this is an example using the spell name\n        --[195452] = true, --this is an example using the spellID\n        \n    }\n    \n    --which color the nameplate wil be changed\n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    --you may also use /plater colors\n    envTable.NameplateColor = \"pink\"\n    \nend",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --do nothing if the player isn't in combat\n    if (not Plater.IsInCombat()) then\n        return \n    end\n    \n    --do nothing if the unit isn't in combat\n    if (not unitFrame.InCombat) then\n        return\n    end\n    \n    --do nothing if the unit is the player it self\n    if (unitFrame.IsSelf) then\n        return\n    end\n    \n    --check the auras\n    local hasAura = false\n    \n    for auraName, _ in pairs (envTable.TrackingAuras) do\n        if (Plater.NameplateHasAura (unitFrame, auraName)) then\n            hasAura = true\n            break\n        end\n    end\n    \n    if (not hasAura) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    else\n        if (envTable.ForceRefreshNameplateColor) then\n            Plater.RefreshNameplateColor (unitFrame) \n        end\n    end    \n    \nend",
					},
					["Name"] = "Don't Have Aura [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["role"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 136207,
					["HooksTemp"] = {
					},
				}, -- [4]
				{
					["Enabled"] = false,
					["Revision"] = 176,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Tecno-Azralon",
					["Time"] = 1547409079,
					["Desc"] = "Add another border with more customizations. This border can also be manipulated by other scripts.",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --run constructor!\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    if (envTable.IsEnabled) then\n        if (unitFrame.IsSelf) then\n            if (envTable.ShowOnPersonalBar) then\n                envTable.BorderFrame:Show()\n            else\n                envTable.BorderFrame:Hide() \n            end\n        else\n            envTable.BorderFrame:Show()\n        end   \n    end\n    \nend   \n\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BorderFrame:Hide()\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BorderFrame:Hide()\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --border color\n    local borderColor = \"yellow\"\n    \n    --size of the border\n    local borderSize = 1\n    \n    --transparency\n    local borderAlpha = 1\n    \n    --enabled (set to false it you only want to use the extra border in other scripts)\n    local isEnabled = true\n    \n    --export border (allow the border to be used by other scripts)\n    --other scripts can use:\n    --unitFrame.healthBar.extraBorder:Show()\n    --unitFrame.healthBar.extraBorder:SetVertexColor (r, g, b)\n    --unitFrame.healthBar.extraBorder:SetBorderSizes (borderSize)\n    local canExportBorder = true\n    \n    --do not add the border to personal bar\n    local noPersonalBar = true\n    \n    --private\n    do\n        \n        local newBorder = CreateFrame (\"frame\", nil, unitFrame.healthBar, \"NamePlateFullBorderTemplate\")\n        envTable.BorderFrame = newBorder\n        \n        newBorder:SetBorderSizes (borderSize, borderSize, borderSize, borderSize)\n        newBorder:UpdateSizes()\n        \n        local r, g, b = DetailsFramework:ParseColors (borderColor)\n        newBorder:SetVertexColor (r, g, b, borderAlpha)\n        \n        envTable.ShowOnPersonalBar = not noPersonalBar\n        \n        if (canExportBorder) then\n            unitFrame.healthBar.extraBorder = newBorder\n        end\n        \n        if (not isEnabled) then\n            envTable.IsEnabled = false\n        else\n            envTable.IsEnabled = true\n        end\n    end\n    \nend\n\n\n",
					},
					["Name"] = "Extra Border [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["race"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 133689,
					["HooksTemp"] = {
					},
				}, -- [5]
				{
					["Enabled"] = false,
					["Revision"] = 93,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1552354619,
					["Desc"] = "Changes the target color to the color set in the constructor script.",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --usage: color name e.g \"red\" \"yellow\"; color table e.g {1, 0, 0} {1, 1, 0}; hex string e.g. \"#FF0000\" \"FFFF00\"\n    \n    envTable.TargetColor = \"purple\"\n    --envTable.TargetColor = \"#FF00FF\"\n    --envTable.TargetColor = {252/255, 0/255, 254/255}\n    \n    function envTable.UpdateColor (unitFrame)\n        --do not change the color of the personal bar\n        if (not unitFrame.IsSelf) then\n            \n            --if this nameplate the current target of the player?\n            if (unitFrame.namePlateIsTarget) then\n                Plater.SetNameplateColor (unitFrame, envTable.TargetColor)  --rgb\n            else\n                --refresh the nameplate color\n                Plater.RefreshNameplateColor (unitFrame)\n            end\n        end\n    end\n    \nend\n\n\n\n\n",
					},
					["Name"] = "Current Target Color [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["role"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 878211,
					["HooksTemp"] = {
					},
				}, -- [6]
				{
					["Enabled"] = false,
					["Revision"] = 348,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Options"] = {
						{
							["Type"] = 5,
							["Name"] = "Icon Settings",
							["Value"] = "Icon Settings:",
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 4,
							["Name"] = "Show Icon",
							["Value"] = true,
							["Key"] = "showIcon",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show the castbar icon when enabled",
						}, -- [2]
						{
							["Type"] = 4,
							["Name"] = "Icon on Left Side",
							["Value"] = true,
							["Key"] = "iconOnLeftSide",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled it anchor the icon on the left side, right otherwise",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "useFullSize",
							["Value"] = false,
							["Name"] = "Use Big Icon",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled the icon has the size of the cast bar plus the healthbar",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 5,
							["Desc"] = "Fine tune the icon size",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0,
							["Name"] = "Icon Size Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "iconSizeOffset",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 5,
							["Desc"] = "Space between the icon and the cast bar",
							["Min"] = -5,
							["Name"] = "Icon Padding",
							["Value"] = 0,
							["Key"] = "iconPadding",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 5,
							["Name"] = "Interrupt Texture",
							["Value"] = "Can't Interrupt Texture:",
							["Key"] = "option5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Name"] = "Show Texture",
							["Value"] = true,
							["Key"] = "showTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled show a texture to tell the cast can't be interrupted",
						}, -- [9]
						{
							["Type"] = 3,
							["Name"] = "Texture Path",
							["Value"] = "Interface\\GROUPFRAME\\UI-GROUP-MAINTANKICON",
							["Key"] = "iconTexturePath",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_text",
							["Desc"] = "Insert the path for the texture",
						}, -- [10]
						{
							["Type"] = 4,
							["Name"] = "Texture Desaturated",
							["Value"] = true,
							["Key"] = "desaturatedTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enbaled, texture is shown in black & white",
						}, -- [11]
						{
							["Type"] = 1,
							["Name"] = "Texture Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.3056715726852417, -- [4]
							},
							["Key"] = "textureColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Select the color of the texture",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Adjust the texture width",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 10,
							["Name"] = "Texture Width",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureWidth",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 16,
							["Desc"] = "The texture is set to be the same size as the cast bar, fine tune the height as wanted",
							["Min"] = -16,
							["Name"] = "Texture Height Mod",
							["Value"] = 0,
							["Key"] = "textureHeightMod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Adjust the texture position",
							["Min"] = -32,
							["Fraction"] = false,
							["Value"] = 0,
							["Name"] = "Texture Position",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "texturePosition",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Adjust the texture transparency",
							["Min"] = 0,
							["Key"] = "textureAlpha",
							["Value"] = 1,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Texture Alpha",
						}, -- [16]
					},
					["Author"] = "Ditador-Azralon",
					["Time"] = 1597097268,
					["Desc"] = "Move the icon of the spell cast to the left or right side of the nameplate.",
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    unitFrame.castBar.BorderShield:SetDrawLayer(\"artwork\")\n    envTable.UpdateIconPosition (unitFrame)\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIconPosition (unitFrame)\n    self.ThrottleUpdate = -1\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable, modTable)\n    \n    --private:\n    function envTable.UpdateIconPosition (unitFrame)\n        local castBar = unitFrame.castBar\n        local icon = castBar.Icon\n        local noInterruptTexture = castBar.BorderShield\n        \n        if (modTable.config.showIcon) then\n            icon:ClearAllPoints()\n            \n            if (modTable.config.iconOnLeftSide) then\n                if (modTable.config.useFullSize) then\n                    icon:SetPoint (\"topright\", unitFrame.healthBar, \"topleft\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                    \n                else\n                    \n                    icon:SetPoint (\"topright\", unitFrame.castBar, \"topleft\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                end\n                \n            else\n                if (modTable.config.useFullSize) then\n                    icon:SetPoint (\"topleft\", unitFrame.healthBar, \"topright\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                    \n                else\n                    \n                    icon:SetPoint (\"topleft\", unitFrame.castBar, \"topright\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                end\n            end\n            \n            icon:SetWidth (icon:GetHeight())\n            icon:Show()\n        else\n            icon:Hide()\n        end\n        \n        if (modTable.config.showTexture and not castBar.canInterrupt) then\n            noInterruptTexture:Show()\n            \n            local texturePath = modTable.config.iconTexturePath\n            texturePath = texturePath:gsub(\"//\", \"/\")\n            texturePath = texturePath:gsub(\"\\\\\", \"/\")\n            \n            noInterruptTexture:SetTexture (texturePath)\n            noInterruptTexture:SetTexCoord (0, 1, 0, 1)\n            \n            if (modTable.config.desaturatedTexture) then\n                noInterruptTexture:SetDesaturated (modTable.config.desaturatedTexture)\n            else\n                noInterruptTexture:SetVertexColor (DetailsFramework:ParseColors (modTable.config.textureColor))\n            end\n            \n            noInterruptTexture:SetSize (modTable.config.textureWidth, castBar:GetHeight() + modTable.config.textureHeightMod)\n            noInterruptTexture:ClearAllPoints()\n            noInterruptTexture:SetPoint (\"center\", castBar, \"left\", modTable.config.texturePosition, 0)\n            noInterruptTexture:SetAlpha (modTable.config.textureAlpha)\n        else\n            noInterruptTexture:Hide()\n        end\n    end\nend",
					},
					["version"] = -1,
					["Name"] = "Cast Bar Icon Settings [P]",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["race"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["PlaterCore"] = 1,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\castbar_icon",
					["HooksTemp"] = {
					},
				}, -- [7]
				{
					["Enabled"] = false,
					["Revision"] = 84,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Ahwa-Azralon",
					["Time"] = 1547406548,
					["Desc"] = "Add extra effects to execute range. See the constructor script for options.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --execute detection, if true the script will handle the execute percent\n    --while false Plater will automatically trigger the execute range\n    --you only want to set this to true in case of Plater not detecting the execute range correctly\n    envTable.UseCustomExecutePercent = false\n    --execute percent, if not detecting automatic, this is the percent to active the execute range\n    --use from zero to one, 0.20 is equal to 20% of the unit life\n    envTable.ExecutePercent = 0.20\n    \n    --allow this script to change the nameplate color when the unit is in execute range\n    envTable.CanChangeColor = true\n    --change the health bar color to this color when the unit is in execute range\n    --color can be set as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}\n    envTable.ExecuteColor = \"green\"\n    \n    --border color\n    envTable.CanChangeBorderColor = false\n    envTable.BorderColor = \"red\"\n    \n    --hide the default health divisor and the health execute indicator\n    envTable.HideHealthDivisor = false\n    --if not hidden, adjust the health divisor settings and the health execute indicator\n    envTable.HealthDivisorAlpha = 0.5\n    envTable.HealthDivisorColor = \"white\"\n    envTable.HealthExecuteIndicatorAlpha = 0.15\n    envTable.HealthExecuteIndicatorColor = \"darkred\"\n    \n    \n    --private (internal functions)\n    do\n        function envTable.UnitInExecuteRange (unitFrame)\n            --check if can change the execute color\n            if (envTable.CanChangeColor) then\n                Plater.SetNameplateColor (unitFrame, envTable.ExecuteColor)\n            end\n            \n            if (envTable.CanChangeBorderColor) then\n                Plater.SetBorderColor (unitFrame, envTable.BorderColor)\n            end\n            \n            if (envTable.HideHealthDivisor) then\n                unitFrame.healthBar.healthCutOff:Hide() \n                unitFrame.healthBar.executeRange:Hide()\n                \n            else\n                envTable.UpdateHealthDivisor (unitFrame)\n                \n            end\n        end\n        \n        function envTable.UpdateHealthDivisor (unitFrame)\n            local healthBar = unitFrame.healthBar\n            \n            healthBar.healthCutOff:Show()\n            healthBar.healthCutOff:SetVertexColor (DetailsFramework:ParseColors (envTable.HealthDivisorColor))\n            healthBar.healthCutOff:SetAlpha (envTable.HealthDivisorAlpha)\n            \n            healthBar.executeRange:Show()\n            healthBar.executeRange:SetVertexColor (DetailsFramework:ParseColors (envTable.HealthExecuteIndicatorColor))\n            healthBar.executeRange:SetAlpha (envTable.HealthExecuteIndicatorAlpha)\n            \n            if (envTable.UseCustomExecutePercent) then\n                healthBar.healthCutOff:ClearAllPoints()\n                healthBar.executeRange:ClearAllPoints()\n                \n                healthBar.healthCutOff:SetSize (healthBar:GetHeight(), healthBar:GetHeight())\n                healthBar.healthCutOff:SetPoint (\"center\", healthBar, \"left\", healthBar:GetWidth() * envTable.ExecutePercent, 0)\n                \n                healthBar.executeRange:SetTexCoord (0, envTable.ExecutePercent, 0, 1)\n                healthBar.executeRange:SetHeight (healthBar:GetHeight())\n                healthBar.executeRange:SetPoint (\"left\", healthBar, \"left\", 0, 0)\n                healthBar.executeRange:SetPoint (\"right\", healthBar.healthCutOff, \"center\")\n            end\n            \n        end\n    end\n    \nend",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (envTable.UseCustomExecutePercent) then\n        \n        --manual detection\n        local healthBar = unitFrame.healthBar\n        if (healthBar.CurrentHealth / healthBar.CurrentHealthMax <= envTable.ExecutePercent) then\n            envTable.UnitInExecuteRange (unitFrame)\n        end        \n        \n    else\n        \n        --auto detection\n        if (unitFrame.InExecuteRange) then\n            envTable.UnitInExecuteRange (unitFrame)\n        end\n        \n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Execute Range [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["role"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 135358,
					["HooksTemp"] = {
					},
				}, -- [8]
				{
					["Enabled"] = false,
					["Revision"] = 363,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Options"] = {
						{
							["Type"] = 1,
							["Key"] = "color",
							["Value"] = {
								0.5019607843137255, -- [1]
								0.5019607843137255, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 4,
							["Key"] = "changeBarColor",
							["Value"] = true,
							["Name"] = "Change Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "changeBorderColor",
							["Value"] = false,
							["Name"] = "Change Border Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "resetColors",
							["Value"] = true,
							["Name"] = "Reset Colors",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
					},
					["Author"] = "Kastfall-Azralon",
					["Time"] = 1620377377,
					["Desc"] = "Change the nameplate color if the unit is attacking a specific unit like Monk's Ox Statue or Druid's Treants. You may edit which units it track in the constructor script.",
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    --list of npcs and their colors, can be inserted:\n    --name of the unit\n    --name of the unit in lower case\n    --npcID of the unit\n    \n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    \n    modTable.changeBarColor = modTable.config.changeBarColor\n    modTable.changeBorderColor = modTable.config.changeBorderColor\n    modTable.resetColors = modTable.config.resetColors\n    \n    modTable.ListOfNpcs = {\n        [61146] = modTable.config.color, --\"olive\", --monk statue npcID\n        [103822] = modTable.config.color, --\"olive\", --druid treant npcID\n        [15352] = modTable.config.color, --\"olive\", --shaman elemental\n        [95072] = modTable.config.color, --\"olive\", --shaman greater earth elemental npcID\n        [61056] = modTable.config.color, --\"olive\", --shaman primal earth elemental npcID\n        \n    }\nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable, modTable)\n    if not unitId then\n        return\n    end\n    --get the GUID of the target of the unit\n    local targetGUID = UnitGUID (unitId .. \"target\")\n    \n    if (targetGUID) then\n        \n        --get the npcID of the target\n        local npcID = Plater.GetNpcIDFromGUID (targetGUID)\n        local unitName = UnitName (unitId .. \"target\")\n        local unitNameLower = string.lower (unitName)\n        \n        --check if the npcID of this unit is in the npc list \n        local color = modTable.ListOfNpcs [npcID] or modTable.ListOfNpcs [unitName] or modTable.ListOfNpcs [unitNameLower]\n        \n        if color then\n            if modTable.changeBarColor then\n                Plater.SetNameplateColor (unitFrame, color)\n            end\n            if modTable.changeBorderColor then\n                Plater.SetBorderColor (unitFrame, color)\n            end\n            unitFrame.attackingSpecificUnitFromMod = true\n        elseif unitFrame.attackingSpecificUnitFromMod and modTable.resetColors then\n            if modTable.changeBorderColor then\n                Plater.SetBorderColor (unitFrame)\n            end\n            if modTable.changeBarColor then\n                Plater.RefreshNameplateColor (unitFrame)\n            end\n            unitFrame.attackingSpecificUnitFromMod = false\n        end\n    end\nend",
					},
					["version"] = -1,
					["Name"] = "Attacking Specific Unit [Plater]",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["PlaterCore"] = 1,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_attacking_unit",
					["HooksTemp"] = {
					},
				}, -- [9]
				{
					["Enabled"] = false,
					["Revision"] = 284,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Options"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Time"] = 1621935143,
					["Desc"] = "Show combo points above the nameplate for Druid Feral and Rogues.",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --run constructor!\n    --constructor is executed only once when any script of the hook runs.\n    \nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if need update the amount of combo points shown\n    if (envTable.LastPlayerTalentUpdate > envTable.LastUpdate) then\n        envTable.UpdateComboPointAmount()\n    end    \n    \n    if (unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.ComboPointFrame:Show()\n        envTable.UpdateComboPoints()\n        \n    else\n        envTable.ComboPointFrame:Hide()\n    end    \n    \nend\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if this nameplate is the current target\n    if (unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.ComboPointFrame:Show()\n        envTable.UpdateComboPoints()\n    else\n        envTable.ComboPointFrame:Hide()\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Player Power Update"] = "function (self, unitId, unitFrame, envTable, modTable, ...)\n    local powerType = ...\n    \n    if (powerType and powerType == \"COMBO_POINTS\" and unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.UpdateComboPoints()\n    end\n    \n    \nend",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.ComboPointFrame:Hide()\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.ComboPointFrame:Hide()\n    \nend\n\n\n\n\n",
						["Player Talent Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    --update the amount of comboo points shown when the player changes talents or specialization\n    envTable.UpdateComboPointAmount()\n    \n    --save the time of the last talent change\n    envTable.LastPlayerTalentUpdate = GetTime()\n    \n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    --settings\n    local anchors = {\n        {\"bottom\", unitFrame.healthBar, \"top\", 0, 24},\n    }\n    \n    local sizes = {\n        width = 12,\n        height = 12,\n        scale = 1,\n    }\n    \n    local textures = {\n        backgroundTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n        backgroundTexCoords = {0/128, 21/128, 101/128, 122/128},\n        \n        comboPointTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n        comboPointTexCoords = {3/128, 18/128, 81/128, 96/128},\n    }\n    if WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE then\n        textures = {\n            backgroundTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n            backgroundTexCoords = {78/128, 98/128, 21/64, 41/64},\n            \n            comboPointTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n            comboPointTexCoords = {100/128, 120/128, 21/64, 41/64},\n        }\n    end\n    \n    local frameLevel = 1000\n    local frameStrata = \"high\"    \n    \n    --private\n    do\n        --store combo points frames on this table\n        envTable.ComboPoints = {}\n        --save when the player changed talents or spec\n        envTable.LastPlayerTalentUpdate = GetTime()\n        --save when this nameplate got a combo point amount and alignment update        \n        \n        --build combo points frame anchor (combo point are anchored to this)\n        if (not unitFrame.PlaterComboPointFrame) then\n            local hostFrame = CreateFrame (\"frame\", nil, unitFrame)\n            hostFrame.ComboPointFramesPool = {}\n            unitFrame.PlaterComboPointFrame = hostFrame\n            envTable.ComboPointFrame = hostFrame\n            envTable.ComboPointFrame:SetScale (sizes.scale)\n            \n            --DetailsFramework:ApplyStandardBackdrop (envTable.ComboPointFrame) --debug anchor size\n            \n            --animations\n            local onPlayShowAnimation = function (animation)\n                --stop the hide animation if it's playing\n                if (animation:GetParent():GetParent().HideAnimation:IsPlaying()) then\n                    animation:GetParent():GetParent().HideAnimation:Stop()\n                end\n                \n                animation:GetParent():Show()\n            end\n            \n            local onPlayHideAnimation = function (animation)\n                --stop the show animation if it's playing\n                if (animation:GetParent():GetParent().ShowAnimation:IsPlaying()) then\n                    animation:GetParent():GetParent().ShowAnimation:Stop()\n                end\n            end        \n            local onStopHideAnimation = function (animation)\n                animation:GetParent():Hide()       \n            end\n            \n            local createAnimations = function (comboPoint)\n                --on show\n                comboPoint.ShowAnimation = Plater:CreateAnimationHub (comboPoint.comboPointTexture, onPlayShowAnimation, nil)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"scale\", 1, 0.1, 0, 0, 1, 1)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"alpha\", 1, 0.1, .5, 1)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"scale\", 2, 0.1, 1.2, 1.2, 1, 1)\n                \n                --on hide\n                comboPoint.HideAnimation = Plater:CreateAnimationHub (comboPoint.comboPointTexture, onPlayHideAnimation, onStopHideAnimation)\n                Plater:CreateAnimation (comboPoint.HideAnimation, \"scale\", 1, 0.1, 1, 1, 0, 0)\n                Plater:CreateAnimation (comboPoint.HideAnimation, \"alpha\", 1, 0.1, 1, 0)\n            end\n            \n            --build combo point frame        \n            for i =1, 10 do \n                local f = CreateFrame (\"frame\", nil, envTable.ComboPointFrame)\n                f:SetSize (sizes.width, sizes.height)\n                tinsert (envTable.ComboPoints, f)\n                tinsert (unitFrame.PlaterComboPointFrame.ComboPointFramesPool, f)\n                \n                local backgroundTexture = f:CreateTexture (nil, \"background\")\n                backgroundTexture:SetTexture (textures.backgroundTexture)\n                backgroundTexture:SetTexCoord (unpack (textures.backgroundTexCoords))\n                backgroundTexture:SetSize (sizes.width, sizes.height)\n                backgroundTexture:SetPoint (\"center\")\n                \n                local comboPointTexture = f:CreateTexture (nil, \"artwork\")\n                comboPointTexture:SetTexture (textures.comboPointTexture)\n                comboPointTexture:SetTexCoord (unpack (textures.comboPointTexCoords))\n                \n                comboPointTexture:SetSize (sizes.width, sizes.height)\n                comboPointTexture:SetPoint (\"center\")\n                comboPointTexture:Hide()            \n                \n                f.IsActive = false\n                \n                f.backgroundTexture = backgroundTexture\n                f.comboPointTexture = comboPointTexture\n                \n                createAnimations (f)\n            end\n            \n        else\n            envTable.ComboPointFrame = unitFrame.PlaterComboPointFrame\n            envTable.ComboPointFrame:SetScale (sizes.scale)\n            envTable.ComboPoints = unitFrame.PlaterComboPointFrame.ComboPointFramesPool\n            \n        end            \n        \n        envTable.ComboPointFrame:SetFrameLevel (frameLevel)\n        envTable.ComboPointFrame:SetFrameStrata (frameStrata)\n        \n        function envTable.UpdateComboPoints()\n            local comboPoints = GetComboPoints(\"player\", \"target\")\n            --UnitPower (\"player\", Enum.PowerType.ComboPoints)\n            \n            for i = 1, envTable.TotalComboPoints do\n                local thisComboPoint = envTable.ComboPoints [i]\n                \n                if (i <= comboPoints ) then\n                    --combo point enabled\n                    if (not thisComboPoint.IsActive) then\n                        thisComboPoint.ShowAnimation:Play()\n                        thisComboPoint.IsActive = true\n                        \n                    end\n                    \n                else\n                    --combo point disabled\n                    if (thisComboPoint.IsActive) then\n                        thisComboPoint.HideAnimation:Play()\n                        thisComboPoint.IsActive = false\n                        \n                    end\n                end\n            end\n            \n            \n        end\n        \n        function envTable.UpdateComboPointAmount()\n            local namePlateWidth = Plater.db.profile.plate_config.enemynpc.health_incombat[1]\n            local comboPoints = UnitPowerMax (\"player\", Enum.PowerType.ComboPoints)\n            local reservedSpace = (namePlateWidth - sizes.width * comboPoints)  / comboPoints \n            \n            --store the total amount of combo points\n            envTable.TotalComboPoints = comboPoints\n            \n            --update anchor frame\n            envTable.ComboPointFrame:SetWidth (namePlateWidth)\n            envTable.ComboPointFrame:SetHeight (20)\n            envTable.ComboPointFrame:ClearAllPoints()\n            for i = 1, #anchors do\n                local anchor = anchors[i]\n                envTable.ComboPointFrame:SetPoint (unpack (anchor))\n            end        \n            \n            --\n            for i = 1, #envTable.ComboPoints do\n                envTable.ComboPoints[i]:Hide()\n                envTable.ComboPoints[i]:ClearAllPoints()\n            end\n            \n            for i = 1, comboPoints do\n                local comboPoint = envTable.ComboPoints[i]\n                if i == 1 then\n                    comboPoint:SetPoint (\"left\", envTable.ComboPointFrame, \"left\", reservedSpace/2, 0)\n                else\n                    comboPoint:SetPoint (\"left\", envTable.ComboPoints[i-1], \"right\", reservedSpace, 0)\n                end\n                \n                comboPoint:Show()\n            end\n            \n            envTable.LastUpdate = GetTime()\n            \n            envTable.UpdateComboPoints()\n        end\n        \n        --initialize\n        envTable.UpdateComboPointAmount()\n        envTable.ComboPointFrame:Hide()\n    end\n    \n    \nend",
					},
					["version"] = -1,
					["Name"] = "Combo Points [Plater]",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
							["Enabled"] = true,
							["DRUID"] = true,
							["ROGUE"] = true,
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
							["103"] = true,
							["Enabled"] = true,
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["affix"] = {
						},
					},
					["PlaterCore"] = 1,
					["url"] = "",
					["Icon"] = 135426,
					["HooksTemp"] = {
					},
				}, -- [10]
				{
					["Enabled"] = false,
					["Revision"] = 182,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["Time"] = 1548278227,
					["Desc"] = "Show how many raid members are targeting the unit",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    envTable.CanShow = false;\n    envTable.TargetAmount:SetText (\"\")\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when a nameplate is added to the screen check if the player is in combat\n    if (InCombatLockdown()) then\n        --player is in combat, check if can check amount of targets\n        envTable.CanShow = envTable.CanShowTargetAmount();\n        \n    else\n        envTable.CanShow = false; \n    end\n    \n    envTable.TargetAmount:SetText (\"\");\n    \nend",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.TargetAmount:SetText (\"\");\n    envTable.CanShow = false;\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --if the script is allowed to show the amount of targets\n    --also check if the unit is in combat\n    if (envTable.CanShow and UnitAffectingCombat (unitId)) then\n        \n        --check if can update the amount of targets following the cooldown set in the constructor script\n        --by default Plater updates the nameplate every 250ms, by default the cooldown is 2, so it'll update the amuont of target every 1/2 of a second\n        envTable.UpdateCooldown = envTable.UpdateCooldown + 1\n        if (envTable.UpdateCooldown < envTable.UpdateInterval) then\n            return\n        else\n            \n            --reset the cooldown interval to check the amount of target again\n            envTable.UpdateCooldown = 0\n            \n            --get the amount of targets\n            local amount;\n            if (envTable.InRaid) then\n                amount = envTable.NumTargetsInRaid (unitFrame)      \n                \n            elseif (envTable.InParty) then\n                amount = envTable.NumTargetsInParty (unitFrame)   \n                \n            else\n                envTable.TargetAmount:SetText (\"\")\n                return\n            end\n            \n            --update the amount text\n            if (amount == 0) then\n                envTable.TargetAmount:SetText (\"\")\n            else\n                envTable.TargetAmount:SetText (amount)\n            end\n            \n        end\n    end\nend\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if can show the amount of targets\n    envTable.CanShow = envTable.CanShowTargetAmount();\n    \n    if (not envTable.CanShow) then\n        envTable.TargetAmount:SetText (\"\") \n    end\nend\n\n\n\n\n",
						["Constructor"] = "--all gray text like this are comments and do not run as code\n--build the settings and basic functions for the hook\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --declare setting variables:\n    local textColor = \"orange\";\n    local textSize = 12;\n    \n    local showInRaid = true;\n    local showInDungeon = true;\n    local showInArena = false;\n    local showInBattleground = false;\n    local showInOpenWorld = true;\n    \n    envTable.UpdateInterval = 2; --each 2 updates in the nameplate it'll update the amount of targets\n    \n    local anchor = {\n        side = 6, --1 = topleft 2 = left 3 = bottomleft 4 = bottom 5 = bottom right 6 = right 7 = topright 8 = top\n        x = 4, --x offset\n        y = 0, --y offset\n    };\n    \n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------\n    \n    \n    --frames:\n    \n    --create the text that will show the amount of people targeting the unit\n    if (not  unitFrame.healthBar.TargetAmount) then\n        envTable.TargetAmount = Plater:CreateLabel (unitFrame.healthBar, \"\", textSize, textColor);\n        Plater.SetAnchor (envTable.TargetAmount, anchor);\n        unitFrame.healthBar.TargetAmount = envTable.TargetAmount\n    end\n    \n    --in case Plater wipes the envTable\n    envTable.TargetAmount = unitFrame.healthBar.TargetAmount\n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------           \n    --private variables (they will be used in the other scripts within this hook)\n    envTable.CanShow = false;\n    envTable.UpdateCooldown = 0;\n    envTable.InRaid = false;\n    envTable.InParty = false;\n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------           \n    --functions\n    \n    --update the InRaid or InParty proprieties\n    function envTable.UpdateGroupType()\n        if (IsInRaid()) then\n            envTable.InRaid = true;\n            envTable.InParty = false;     \n            \n        elseif (IsInGroup()) then\n            envTable.InRaid = false;\n            envTable.InParty = true;   \n            \n        else\n            envTable.InRaid = false;            \n            envTable.InParty = false;\n        end\n    end\n    \n    --this function controls if the amount of targets can show following the settings in the top of this script\n    function envTable.CanShowTargetAmount()\n        \n        local _, instanceType, difficultyID, _, _, _, _, instanceMapID, instanceGroupSize = GetInstanceInfo()\n        \n        if (showInRaid and instanceType == \"raid\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInDungeon and instanceType == \"party\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInArena and instanceType == \"arena\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInBattleground and instanceType == \"pvp\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInOpenWorld and instanceType == \"none\") then\n            envTable.UpdateGroupType()\n            if (envTable.InRaid or envTable.InParty) then\n                return true\n            end\n        end\n        \n        return false\n    end\n    \n    --get the amount of player targetting the unit in raid or party\n    function envTable.NumTargetsInRaid (unitFrame)\n        local amount = 0\n        for i = 1, GetNumGroupMembers() do\n            local unit = \"raid\" .. i .. \"target\"\n            if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n                amount = amount + 1\n            end\n        end\n        \n        return amount\n    end\n    \n    function envTable.NumTargetsInParty()\n        local amount = 0\n        for i = 1, GetNumGroupMembers() - 1 do\n            local unit = \"party\" .. i .. \"target\"\n            if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n                amount = amount + 1\n            end\n        end\n        \n        local unit = \"playertarget\"\n        if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n            amount = amount + 1\n        end        \n        \n        return amount\n    end\n    \nend",
					},
					["Name"] = "Players Targeting a Target [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["race"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["affix"] = {
						},
						["encounter_ids"] = {
						},
						["role"] = {
						},
					},
					["url"] = "",
					["Icon"] = 1966587,
					["HooksTemp"] = {
					},
				}, -- [11]
				{
					["Enabled"] = false,
					["Revision"] = 356,
					["semver"] = "",
					["LastHookEdited"] = "",
					["Options"] = {
					},
					["Author"] = "Ditador-Azralon",
					["Time"] = 1608663128,
					["Desc"] = "Reorder buffs and debuffs following the settings set in the constructor.",
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    \n    --ATTENTION: after enabling this mod, you may have to adjust the anchor point at the Buff Settings tab\n    \n    local sortByTime = false\n    local invertSort = false\n    \n    --which auras goes first, assign a value (any number), bigger value goes first\n    local priority = {\n        [\"Vampiric Touch\"] = 50,\n        [\"Shadow Word: Pain\"] = 22,\n        [\"Mind Flay\"] = 5,\n        [\"Pistol Shot\"] = 50,\n        [\"Marked for Death\"] = 99,\n    }\n    \n    -- Sort function - do not touch\n    Plater.db.profile.aura_sort = true\n    \n    \n    function Plater.AuraIconsSortFunction (aura1, aura2)\n        local p1 = priority[aura1.SpellId] or priority[aura1.SpellName] or 1\n        local p2 = priority[aura2.SpellId] or priority[aura2.SpellName] or 1\n        \n        if sortByTime and p1 == p2 then\n            if invertSort then\n                return (aura1.Duration == 0 and 99999999 or aura1.RemainingTime or 0) > (aura2.Duration == 0 and 99999999 or aura2.RemainingTime or 0)\n            else\n                return (aura1.Duration == 0 and 99999999 or aura1.RemainingTime or 0) < (aura2.Duration == 0 and 99999999 or aura2.RemainingTime or 0)\n            end\n        else\n            if invertSort then\n                 return p1 < p2\n            else\n                return p1 > p2\n            end\n        end\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["version"] = -1,
					["Name"] = "Aura Reorder [Plater]",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["affix"] = {
						},
					},
					["PlaterCore"] = 1,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura_reorder",
					["HooksTemp"] = {
					},
				}, -- [12]
			},
			["aura_x_offset"] = 0,
			["first_run3"] = true,
			["resources_settings"] = {
				["chr"] = {
					["Player-580-0916F7F1"] = "HolyPower",
				},
			},
			["OptionsPanelDB"] = {
				["PlaterOptionsPanelFrame"] = {
					["scale"] = 1,
				},
			},
			["ui_parent_scale_tune"] = 1.111111140545504,
			["number_region_first_run"] = true,
			["saved_cvars"] = {
			},
			["hook_auto_imported"] = {
				["Reorder Nameplate"] = 4,
				["Dont Have Aura"] = 1,
				["Players Targetting Amount"] = 4,
				["Color Automation"] = 1,
				["Combo Points"] = 6,
				["Cast Bar Icon Config"] = 2,
				["Execute Range"] = 1,
				["Extra Border"] = 2,
				["Attacking Specific Unit"] = 2,
				["Target Color"] = 3,
				["Aura Reorder"] = 3,
				["Hide Neutral Units"] = 1,
			},
			["aura2_y_offset"] = 5,
			["login_counter"] = 6,
			["script_data_trash"] = {
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \n    --check if there's a timer for this spell\n    local timer = scriptTable.config.timerList[tostring(envTable._SpellID)]\n    \n    if (timer) then\n        --insert code here\n        \n        --set the castbar config\n        local config = {\n            iconTexture = \"\",\n            iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n            iconAlpha = 1,\n            iconSize = 14,\n            \n            text = \"Spikes Incoming!\",\n            textSize = 8,\n            \n            texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n            color = {.6, .6, .6, 0.8},\n            \n            isChanneling = false,\n            canInterrupt = false,\n            \n            height = 5,\n            width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n            \n            spellNameAnchor = {side = 3, x = 0, y = -2},\n            timerAnchor = {side = 5, x = 0, y = -2},\n        }\n        \n        Plater.SetAltCastBar(unitFrame.PlateFrame, config, timer, nil, nil)\n        local castBar2 = unitFrame.castBar2\n        castBar2.Text:ClearAllPoints()\n        castBar2.Text:SetPoint (\"topleft\", castBar2, \"bottomleft\", 0, 0)\n        castBar2.percentText:ClearAllPoints()\n        castBar2.percentText:SetPoint (\"topright\", castBar2, \"bottomright\", 0, 0)\n        Plater:SetFontSize(castBar2.percentText, 8)\n    end\n    \nend\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1625793282,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["Enabled"] = true,
					["Revision"] = 1154,
					["semver"] = "",
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Player an animation when the cast start. Start a timer when the cast finishes. Set the time in the options.",
					["NpcNames"] = {
					},
					["Name"] = "Cast - Alert + Timer [P]",
					["SpellIds"] = {
						350421, -- [1]
						355787, -- [2]
						348513, -- [3]
					},
					["PlaterCore"] = 1,
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Blank Line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Cast start animation settings",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Cast Bar Color Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "castbarColor",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Blank Line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Key"] = "flashDuration",
							["Value"] = 0.4,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Key"] = "shakeDuration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Key"] = "shakeAmplitude",
							["Value"] = 8,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 40,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 7,
							["Name"] = "Timer (Key is SpellId and Value is Time)",
							["Value"] = {
								{
									"350421", -- [1]
									"5", -- [2]
								}, -- [1]
								{
									"355787", -- [1]
									"15", -- [2]
								}, -- [2]
								{
									"348513", -- [1]
									"14", -- [2]
								}, -- [3]
								{
									"348513", -- [1]
									"14", -- [2]
								}, -- [4]
							},
							["Key"] = "timerList",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the spellId and value is the amount of time of the Timer",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    --set the color of the cast bar to dark orange (only if can be interrupted)\n    --Plater auto set this color to default when a new cast starts, no need to reset this value at OnHide.    \n    if (envTable._CanInterrupt) then\n        if (scriptTable.config.useCastbarColor) then\n            self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n        end\n    end\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["__TrashAt"] = 1673538083,
				}, -- [1]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.castBar, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1670202618,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_darkorange",
					["Enabled"] = true,
					["Revision"] = 798,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Highlight a very important cast applying several effects into the Cast Bar. Add spell in the Add Trigger field.",
					["__TrashAt"] = 1676235944,
					["NpcNames"] = {
					},
					["SpellIds"] = {
						373046, -- [1]
						372863, -- [2]
						164686, -- [3]
						153072, -- [4]
						153680, -- [5]
						196497, -- [6]
						388886, -- [7]
						387145, -- [8]
						384365, -- [9]
						152964, -- [10]
						398150, -- [11]
						152801, -- [12]
						397878, -- [13]
						397914, -- [14]
						183263, -- [15]
						3636, -- [16]
						376171, -- [17]
						350687, -- [18]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Very Important [Plater]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Plays a big animation when the cast start.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 4",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Name"] = "Flash",
							["Value"] = "Flash:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.8,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [6]
						{
							["Type"] = 1,
							["Name"] = "Flash Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "flashColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Shake:",
							["Name"] = "Shake",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Name"] = "Shake Amplitude",
							["Value"] = 5,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 40,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
						{
							["Type"] = 6,
							["Name"] = "Option 13",
							["Value"] = 0,
							["Key"] = "option13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Name"] = "Dot Animation",
							["Value"] = "Dot Animation:",
							["Key"] = "option14",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Name"] = "Dot Color",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Key"] = "dotColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot X Offset",
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot Y Offset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "yOffset",
						}, -- [17]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Name"] = "Option 19",
							["Value"] = "Cast Bar",
							["Key"] = "option19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Name"] = "Use Cast Bar Color",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.castBar, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\nend",
				}, -- [2]
			},
			["aura_tracker"] = {
				["buff_tracked"] = {
					[209859] = true,
				},
			},
			["ghost_auras"] = {
				["auras"] = {
					["WARLOCK"] = {
						{
							[172] = true,
							[980] = true,
						}, -- [1]
					},
					["PRIEST"] = {
						[3] = {
							[589] = true,
							[34914] = true,
						},
					},
				},
			},
			["plate_config"] = {
				["global_health_height"] = 12,
				["global_health_width"] = 112,
			},
			["patch_version"] = 24,
			["aura_y_offset"] = 5,
		},
		["Quazii Plater"] = {
			["aura_sort"] = true,
			["saved_cvars_last_change"] = {
				["nameplateShowOnlyNames"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateOverlapV"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateLargeTopInset"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowEnemyMinus"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["NamePlateClassificationScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowFriendlyTotems"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplatePersonalHideDelaySeconds"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowFriendlyPets"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplatePersonalShowInCombat"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplatePersonalShowWithTarget"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateMinAlpha"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateResourceOnTarget"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowAll"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateMaxDistance"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowFriendlyMinions"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateSelfScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateTargetBehindMaxDistance"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowEnemies"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["NamePlateVerticalScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateSelectedAlpha"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowSelf"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateSelfTopInset"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateMotionSpeed"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateGlobalScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowEnemyMinions"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowFriendlyNPCs"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateSelectedScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateMinAlphaDistance"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateMotion"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateMinScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplatePersonalShowAlways"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateOtherTopInset"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateOccludedAlphaMult"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateSelfBottomInset"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateSelfAlpha"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowFriendlyGuardians"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["NamePlateHorizontalScale"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["ShowNamePlateLoseAggroFlash"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateTargetRadialPosition"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["nameplateShowFriends"] = "Interface/AddOns/Plater/Plater.lua:2204",
				["ShowClassColorInNameplate"] = "Interface/AddOns/Plater/Plater.lua:2204",
			},
			["url"] = "https://wago.io/kvgdjO6_L/3",
			["cast_statusbar_fadein_time"] = 0.02081192471087,
			["target_shady_enabled"] = false,
			["aura2_y_offset"] = 0,
			["buffs_on_aura2"] = true,
			["expansion_triggerwipe"] = {
				[9] = true,
			},
			["cast_statusbar_color_nointerrupt"] = {
				0.49411764705882, -- [1]
				0.49803921568628, -- [2]
				0.50196078431373, -- [3]
				0.96000000089407, -- [4]
			},
			["npc_cache"] = {
				[75829] = {
					"Nhallish", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[198716] = {
					"Unstable Storm", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[196798] = {
					"Corrupted Manafiend", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[189893] = {
					"Infused Whelp", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[96609] = {
					"Gildedfur Stag", -- [1]
					"Halls of Valor", -- [2]
				},
				[134012] = {
					"Taskmaster Askari", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[136186] = {
					"Tidesage Spiritualist", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[196671] = {
					"Arcane Ravager", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[104218] = {
					"Advisor Melandrus", -- [1]
					"Court of Stars", -- [2]
				},
				[195265] = {
					"Stormcaller Arynga", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[187593] = {
					"Primal Flame", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[195138] = {
					"Detonating Crystal", -- [1]
					"The Azure Vault", -- [2]
				},
				[173016] = {
					"Corpse Collector", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[129602] = {
					"Irontide Enforcer", -- [1]
					"Freehold", -- [2]
				},
				[200126] = {
					"Fallen Waterspeaker", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[120651] = {
					"Explosives", -- [1]
					"Halls of Valor", -- [2]
				},
				[197697] = {
					"Flamegullet", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[198081] = {
					"Quarry Earthshaper", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[96611] = {
					"Angerhoof Bull", -- [1]
					"Halls of Valor", -- [2]
				},
				[135167] = {
					"Spectral Berserker", -- [1]
					"Kings' Rest", -- [2]
				},
				[76407] = {
					"Ner'zhul", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[131587] = {
					"Bewitched Captain", -- [1]
					"Waycrest Manor", -- [2]
				},
				[126918] = {
					"Irontide Crackshot", -- [1]
					"Freehold", -- [2]
				},
				[196548] = {
					"Ancient Branch", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[130435] = {
					"Addled Thug", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[192329] = {
					"Territorial Eagle", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[190923] = {
					"Zephyrling", -- [1]
					"Halls of Infusion", -- [2]
				},
				[195399] = {
					"Curious Swoglet", -- [1]
					"Halls of Infusion", -- [2]
				},
				[127111] = {
					"Irontide Oarsman", -- [1]
					"Freehold", -- [2]
				},
				[168418] = {
					"Forsworn Inquisitor", -- [1]
					"Spires of Ascension", -- [2]
				},
				[200387] = {
					"Shambling Infester", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[196679] = {
					"Frozen Shroud", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[165222] = {
					"Zolramus Bonemender", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[201155] = {
					"Nascent Proto-Dragon", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[198214] = {
					"Broodguardian Ziruss", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[200388] = {
					"Malformed Sha", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[197831] = {
					"Quarry Stonebreaker", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[168420] = {
					"Forsworn Champion", -- [1]
					"Spires of Ascension", -- [2]
				},
				[192333] = {
					"Alpha Eagle", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[168932] = {
					"Doomguard", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[75451] = {
					"Defiled Spirit", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[128967] = {
					"Ashvane Sniper", -- [1]
					"Siege of Boralus", -- [2]
				},
				[75899] = {
					"Possessed Soul", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[199368] = {
					"Hardened Crystal", -- [1]
					"The Azure Vault", -- [2]
				},
				[189266] = {
					"Qalashi Trainee", -- [1]
					"Neltharus", -- [2]
				},
				[75452] = {
					"Bonemaw", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[196044] = {
					"Unruly Textbook", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[190034] = {
					"Blazebound Destroyer", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[160495] = {
					"Maniacal Soulbinder", -- [1]
					"Theater of Pain", -- [2]
				},
				[188244] = {
					"Primal Juggernaut", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[192464] = {
					"Raging Ember", -- [1]
					"Neltharus", -- [2]
				},
				[137478] = {
					"Queen Wasi", -- [1]
					"Kings' Rest", -- [2]
				},
				[132491] = {
					"Kul Tiran Marksman", -- [1]
					"Siege of Boralus", -- [2]
				},
				[200137] = {
					"Depraved Mistweaver", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[194895] = {
					"Unstable Squall", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[128969] = {
					"Ashvane Commander", -- [1]
					"Siege of Boralus", -- [2]
				},
				[194896] = {
					"Primal Stormshield", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[196559] = {
					"Volatile Sapling", -- [1]
					"The Azure Vault", -- [2]
				},
				[134284] = {
					"Fallen Deathspeaker", -- [1]
					"The Underrot", -- [2]
				},
				[194897] = {
					"Stormsurge Totem", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[190294] = {
					"Nokhud Stormcaster", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[134157] = {
					"Shadow-Borne Warrior", -- [1]
					"Kings' Rest", -- [2]
				},
				[75966] = {
					"Defiled Spirit", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[194898] = {
					"Primalist Arcblade", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[136076] = {
					"Agitated Nimbus", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[134158] = {
					"Shadow-Borne Champion", -- [1]
					"Kings' Rest", -- [2]
				},
				[172265] = {
					"Remnant of Fury", -- [1]
					"Sanguine Depths", -- [2]
				},
				[165872] = {
					"Flesh Crafter", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[137484] = {
					"King A'akul", -- [1]
					"Kings' Rest", -- [2]
				},
				[129227] = {
					"Azerokk", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[59051] = {
					"Strife", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[131858] = {
					"Thornguard", -- [1]
					"Waycrest Manor", -- [2]
				},
				[194389] = {
					"Lava Spawn", -- [1]
					"Neltharus", -- [2]
				},
				[129547] = {
					"Blacktooth Knuckleduster", -- [1]
					"Freehold", -- [2]
				},
				[127757] = {
					"Reanimated Honor Guard", -- [1]
					"Atal'Dazar", -- [2]
				},
				[186206] = {
					"Cruel Bonecrusher", -- [1]
					"Brackenhide Hollow", -- [2]
				},
				[112668] = {
					"Infernal Imp", -- [1]
					"Court of Stars", -- [2]
				},
				[137486] = {
					"Queen Patlaa", -- [1]
					"Kings' Rest", -- [2]
				},
				[105699] = {
					"Mana Saber", -- [1]
					"Court of Stars", -- [2]
				},
				[137103] = {
					"Blood Visage", -- [1]
					"The Underrot", -- [2]
				},
				[194647] = {
					"Thunder Caller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[134418] = {
					"Drowned Depthbringer", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[97068] = {
					"Storm Drake", -- [1]
					"Halls of Valor", -- [2]
				},
				[75713] = {
					"Shadowmoon Bone-Mender", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[138255] = {
					"Ashvane Spotter", -- [1]
					"Siege of Boralus", -- [2]
				},
				[196694] = {
					"Arcane Forager", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[198868] = {
					"Primalist Voltweaver", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[195927] = {
					"Soulharvester Galtmaa", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[199124] = {
					"Primalist Chillblaster", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[181861] = {
					"Magmatusk", -- [1]
					"Neltharus", -- [2]
				},
				[195928] = {
					"Soulharvester Duuren", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[97197] = {
					"Valarjar Purifier", -- [1]
					"Halls of Valor", -- [2]
				},
				[126928] = {
					"Irontide Corsair", -- [1]
					"Freehold", -- [2]
				},
				[186338] = {
					"Maruuk", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[190686] = {
					"Frozen Destroyer", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[195929] = {
					"Soulharvester Tumen", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[186339] = {
					"Teera", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[75459] = {
					"Plagued Bat", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[195930] = {
					"Soulharvester Mandakh", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[104295] = {
					"Blazing Imp", -- [1]
					"Court of Stars", -- [2]
				},
				[75715] = {
					"Reanimated Ritual Bones", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[193373] = {
					"Nokhud Thunderfist", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[190688] = {
					"Blazing Fiend", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[133912] = {
					"Bloodsworn Defiler", -- [1]
					"The Underrot", -- [2]
				},
				[136214] = {
					"Windspeaker Heldis", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[136470] = {
					"Refreshment Vendor", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[75652] = {
					"Void Spawn", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[190690] = {
					"Thundering Ravager", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[105703] = {
					"Mana Wyrm", -- [1]
					"Court of Stars", -- [2]
				},
				[201560] = {
					"Primalist Flamecaller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[193760] = {
					"Surging Ruiner", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[168058] = {
					"Infused Quill-feather", -- [1]
					"Sanguine Depths", -- [2]
				},
				[189669] = {
					"Binding Spear", -- [1]
					"Neltharus", -- [2]
				},
				[105704] = {
					"Arcane Manifestation", -- [1]
					"Court of Stars", -- [2]
				},
				[127315] = {
					"Reanimation Totem", -- [1]
					"Atal'Dazar", -- [2]
				},
				[187240] = {
					"Drakonid Breaker", -- [1]
					"The Azure Vault", -- [2]
				},
				[132126] = {
					"Gilded Priestess", -- [1]
					"Atal'Dazar", -- [2]
				},
				[174197] = {
					"Battlefield Ritualist", -- [1]
					"Theater of Pain", -- [2]
				},
				[197982] = {
					"Storm Warrior", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[168443] = {
					"Zolramus Necromancer", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[58319] = {
					"Lesser Sha", -- [1]
					"Pandaria", -- [2]
				},
				[196576] = {
					"Spellbound Scepter", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[198878] = {
					"Primalist Tempestmaker", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[105705] = {
					"Bound Energy", -- [1]
					"Court of Stars", -- [2]
				},
				[170490] = {
					"Atal'ai High Priest", -- [1]
					"De Other Side", -- [2]
				},
				[194147] = {
					"Volcanius", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[191206] = {
					"Primalist Mage", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[187242] = {
					"Tarasek Looter", -- [1]
					"The Azure Vault", -- [2]
				},
				[134174] = {
					"Shadow-Borne Witch Doctor", -- [1]
					"Kings' Rest", -- [2]
				},
				[59726] = {
					"Peril", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[163458] = {
					"Forsworn Castigator", -- [1]
					"Spires of Ascension", -- [2]
				},
				[97202] = {
					"Olmyr the Enlightened", -- [1]
					"Halls of Valor", -- [2]
				},
				[122969] = {
					"Zanchuli Witch-Doctor", -- [1]
					"Atal'Dazar", -- [2]
				},
				[197985] = {
					"Flame Channeler", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[163459] = {
					"Forsworn Mender", -- [1]
					"Spires of Ascension", -- [2]
				},
				[104300] = {
					"Shadow Mistress", -- [1]
					"Court of Stars", -- [2]
				},
				[131492] = {
					"Devout Blood Priest", -- [1]
					"The Underrot", -- [2]
				},
				[76104] = {
					"Monstrous Corpse Spider", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[190187] = {
					"Draconic Image", -- [1]
					"The Azure Vault", -- [2]
				},
				[187246] = {
					"Nullmagic Hornswog", -- [1]
					"The Azure Vault", -- [2]
				},
				[135329] = {
					"Matron Bryndle", -- [1]
					"Waycrest Manor", -- [2]
				},
				[166275] = {
					"Mistveil Shaper", -- [1]
					"Mists of Tirna Scithe", -- [2]
				},
				[198500] = {
					"Council Earthcaller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[136353] = {
					"Colossal Tentacle", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[200035] = {
					"Carrion Worm", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[168578] = {
					"Fungalmancer", -- [1]
					"Plaguefall", -- [2]
				},
				[198501] = {
					"Council Icecaller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[162057] = {
					"Chamber Sentinel", -- [1]
					"Sanguine Depths", -- [2]
				},
				[186737] = {
					"Telash Greywing", -- [1]
					"The Azure Vault", -- [2]
				},
				[196200] = {
					"Algeth'ar Echoknight", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[107435] = {
					"Suspicious Noble", -- [1]
					"Court of Stars", -- [2]
				},
				[198502] = {
					"Council Stormcaller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[135204] = {
					"Spectral Hex Priest", -- [1]
					"Kings' Rest", -- [2]
				},
				[122972] = {
					"Dazar'ai Augur", -- [1]
					"Atal'Dazar", -- [2]
				},
				[186738] = {
					"Umbrelskul", -- [1]
					"The Azure Vault", -- [2]
				},
				[129366] = {
					"Bilge Rat Buccaneer", -- [1]
					"Siege of Boralus", -- [2]
				},
				[198503] = {
					"Council Flamecaller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[99891] = {
					"Storm Drake", -- [1]
					"Halls of Valor", -- [2]
				},
				[139425] = {
					"Crazed Incubator", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[184693] = {
					"Living Flame", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[196202] = {
					"Spectral Invoker", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[191215] = {
					"Tarasek Legionnaire", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[122973] = {
					"Dazar'ai Confessor", -- [1]
					"Atal'Dazar", -- [2]
				},
				[75979] = {
					"Exhumed Spirit", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[186740] = {
					"Arcane Construct", -- [1]
					"The Azure Vault", -- [2]
				},
				[196203] = {
					"Ethereal Restorer", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[129559] = {
					"Cutwater Duelist", -- [1]
					"Freehold", -- [2]
				},
				[195820] = {
					"Nokhud Saboteur", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[186741] = {
					"Arcane Elemental", -- [1]
					"The Azure Vault", -- [2]
				},
				[174210] = {
					"Blighted Sludge-Spewer", -- [1]
					"Theater of Pain", -- [2]
				},
				[200936] = {
					"Living Flame", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[137511] = {
					"Bilge Rat Cutthroat", -- [1]
					"Siege of Boralus", -- [2]
				},
				[187894] = {
					"Infused Whelp", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[186616] = {
					"Granyth", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[189813] = {
					"Dathea, Ascended", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[129369] = {
					"Irontide Raider", -- [1]
					"Siege of Boralus", -- [2]
				},
				[95674] = {
					"Fenryr", -- [1]
					"Halls of Valor", -- [2]
				},
				[195696] = {
					"Primalist Thunderbeast", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[187768] = {
					"Dathea Stormlash", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[97081] = {
					"King Bjorn", -- [1]
					"Halls of Valor", -- [2]
				},
				[171656] = {
					"Venomous Sniper Captain", -- [1]
					"Plaguefall", -- [2]
				},
				[195697] = {
					"Thunderbeast Rider", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[134701] = {
					"Blood Effigy", -- [1]
					"The Underrot", -- [2]
				},
				[129370] = {
					"Irontide Waveshaper", -- [1]
					"Siege of Boralus", -- [2]
				},
				[191222] = {
					"Juvenile Frost Proto-Dragon", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[189816] = {
					"Dathea Stormlash", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[188026] = {
					"Frost Tomb", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[77006] = {
					"Corpse Skitterling", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[187771] = {
					"Kadros Icewrath", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[95676] = {
					"Odyn", -- [1]
					"Halls of Valor", -- [2]
				},
				[57109] = {
					"Minion of Doubt", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[191736] = {
					"Crawth", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[187772] = {
					"Opalfang", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[97083] = {
					"King Ranulf", -- [1]
					"Halls of Valor", -- [2]
				},
				[191225] = {
					"Tarasek Earthreaver", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190586] = {
					"Earth Breaker", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[200944] = {
					"Nokhud Fighter", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[105715] = {
					"Watchful Inquisitor", -- [1]
					"Court of Stars", -- [2]
				},
				[192761] = {
					"Iskakx", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[132532] = {
					"Kul Tiran Marksman", -- [1]
					"Siege of Boralus", -- [2]
				},
				[97084] = {
					"King Tor", -- [1]
					"Halls of Valor", -- [2]
				},
				[139949] = {
					"Plague Doctor", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[190588] = {
					"Tectonic Crusher", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[135474] = {
					"Thistle Acolyte", -- [1]
					"Waycrest Manor", -- [2]
				},
				[199028] = {
					"Glacias", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[168594] = {
					"Chamber Sentinel", -- [1]
					"Sanguine Depths", -- [2]
				},
				[190205] = {
					"Scorchling", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[97788] = {
					"Storm Drake", -- [1]
					"Halls of Valor", -- [2]
				},
				[196855] = {
					"Braekkas", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[199029] = {
					"Cyclas", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[133685] = {
					"Befouled Spirit", -- [1]
					"The Underrot", -- [2]
				},
				[190206] = {
					"Primalist Flamedancer", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[167956] = {
					"Dark Acolyte", -- [1]
					"Sanguine Depths", -- [2]
				},
				[196856] = {
					"Primal Stormsentry", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[199030] = {
					"Loamas", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[96574] = {
					"Stormforged Sentinel", -- [1]
					"Halls of Valor", -- [2]
				},
				[198263] = {
					"Stalwart Broodwarden", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[191230] = {
					"Dragonspawn Flamebender", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[169875] = {
					"Shackled Soul", -- [1]
					"Theater of Pain", -- [2]
				},
				[188673] = {
					"Smoldering Colossus", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[104247] = {
					"Duskwatch Arcanist", -- [1]
					"Court of Stars", -- [2]
				},
				[187139] = {
					"Crystal Thrasher", -- [1]
					"The Azure Vault", -- [2]
				},
				[195579] = {
					"Primal Gust", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[133432] = {
					"Venture Co. Alchemist", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[165529] = {
					"Depraved Collector", -- [1]
					"Halls of Atonement", -- [2]
				},
				[191232] = {
					"Drakonid Stormbringer", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[195580] = {
					"Nokhud Saboteur", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[192767] = {
					"Primal Icebulk", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[97087] = {
					"Valarjar Champion", -- [1]
					"Halls of Valor", -- [2]
				},
				[198266] = {
					"Pouncing Broodswarmer", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[96640] = {
					"Valarjar Marksman", -- [1]
					"Halls of Valor", -- [2]
				},
				[192769] = {
					"Thondrozus", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[166299] = {
					"Mistveil Tender", -- [1]
					"Mists of Tirna Scithe", -- [2]
				},
				[56792] = {
					"Figment of Doubt", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[190340] = {
					"Refti Defender", -- [1]
					"Halls of Infusion", -- [2]
				},
				[136249] = {
					"Guardian Elemental", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[134331] = {
					"King Rahu'ai", -- [1]
					"Kings' Rest", -- [2]
				},
				[133436] = {
					"Venture Co. Skyscorcher", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[171799] = {
					"Depths Warden", -- [1]
					"Sanguine Depths", -- [2]
				},
				[167963] = {
					"Headless Client", -- [1]
					"De Other Side", -- [2]
				},
				[199037] = {
					"Primalist Shocktrooper", -- [1]
					"Halls of Infusion", -- [2]
				},
				[190342] = {
					"Containment Apparatus", -- [1]
					"10.0 Dragon Isles", -- [2]
				},
				[122984] = {
					"Dazar'ai Colossus", -- [1]
					"Atal'Dazar", -- [2]
				},
				[166302] = {
					"Corpse Harvester", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[184972] = {
					"Eranog", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[165919] = {
					"Skeletal Marauder", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[195842] = {
					"Ukhel Corruptor", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[104251] = {
					"Duskwatch Sentry", -- [1]
					"Court of Stars", -- [2]
				},
				[163618] = {
					"Zolramus Necromancer", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[196482] = {
					"Overgrown Ancient", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[194181] = {
					"Vexamus", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[190345] = {
					"Primalist Geomancer", -- [1]
					"Halls of Infusion", -- [2]
				},
				[167967] = {
					"Sentient Oil", -- [1]
					"De Other Side", -- [2]
				},
				[97219] = {
					"Solsten", -- [1]
					"Halls of Valor", -- [2]
				},
				[168992] = {
					"Risen Cultist", -- [1]
					"De Other Side", -- [2]
				},
				[134338] = {
					"Tidesage Enforcer", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[196102] = {
					"Conjured Lasher", -- [1]
					"The Azure Vault", -- [2]
				},
				[190348] = {
					"Primalist Ravager", -- [1]
					"Halls of Infusion", -- [2]
				},
				[76057] = {
					"Carrion Worm", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[130404] = {
					"Vermin Trapper", -- [1]
					"Freehold", -- [2]
				},
				[135235] = {
					"Spectral Beastmaster", -- [1]
					"Kings' Rest", -- [2]
				},
				[165414] = {
					"Depraved Obliterator", -- [1]
					"Halls of Atonement", -- [2]
				},
				[193291] = {
					"Apex Blazewing", -- [1]
					"Neltharus", -- [2]
				},
				[59544] = {
					"The Nodding Tiger", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[194315] = {
					"Stormcaller Solongo", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[130661] = {
					"Venture Co. Earthshaper", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[192781] = {
					"Ore Elemental", -- [1]
					"Neltharus", -- [2]
				},
				[168357] = {
					"Zolramus Sorcerer", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[193293] = {
					"Qalashi Warden", -- [1]
					"Neltharus", -- [2]
				},
				[163882] = {
					"Decaying Flesh Giant", -- [1]
					"Plaguefall", -- [2]
				},
				[195851] = {
					"Ukhel Deathspeaker", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[134599] = {
					"Imbued Stormcaller", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[136006] = {
					"Rowdy Reveler", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[169893] = {
					"Nefarious Darkspeaker", -- [1]
					"Theater of Pain", -- [2]
				},
				[135239] = {
					"Spectral Witch Doctor", -- [1]
					"Kings' Rest", -- [2]
				},
				[190609] = {
					"Echo of Doragosa", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[134600] = {
					"Sandswept Marksman", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[59545] = {
					"The Golden Beetle", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[135241] = {
					"Bilge Rat Pillager", -- [1]
					"Siege of Boralus", -- [2]
				},
				[76444] = {
					"Subjugated Soul", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[56732] = {
					"Liu Flameheart", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[133835] = {
					"Feral Bloodswarmer", -- [1]
					"The Underrot", -- [2]
				},
				[187159] = {
					"Shrieking Whelp", -- [1]
					"The Azure Vault", -- [2]
				},
				[193553] = {
					"Nokhud Warhound", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[195855] = {
					"Risen Warrior", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[163503] = {
					"Etherdiver", -- [1]
					"Spires of Ascension", -- [2]
				},
				[187160] = {
					"Crystal Fury", -- [1]
					"The Azure Vault", -- [2]
				},
				[190485] = {
					"Erkhart Stormvein", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[192787] = {
					"Qalashi Spinecrusher", -- [1]
					"Neltharus", -- [2]
				},
				[136139] = {
					"Mechanized Peacekeeper", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[193555] = {
					"Nokhud Villager", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[163121] = {
					"Stitched Vanguard", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[101637] = {
					"Valarjar Aspirant", -- [1]
					"Halls of Valor", -- [2]
				},
				[199182] = {
					"Jumping Spiderling", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190359] = {
					"Skulking Zealot", -- [1]
					"Halls of Infusion", -- [2]
				},
				[189464] = {
					"Qalashi Irontorch", -- [1]
					"Neltharus", -- [2]
				},
				[76446] = {
					"Shadowmoon Dominator", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[192789] = {
					"Nokhud Longbow", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[134990] = {
					"Charged Dust Devil", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[138187] = {
					"Grotesque Horror", -- [1]
					"The Underrot", -- [2]
				},
				[197905] = {
					"Spellbound Scepter", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[131666] = {
					"Coven Thornshaper", -- [1]
					"Waycrest Manor", -- [2]
				},
				[193558] = {
					"Primalist Flamecaller", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[192791] = {
					"Nokhud Warspear", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[196116] = {
					"Crystal Fury", -- [1]
					"The Azure Vault", -- [2]
				},
				[144071] = {
					"Irontide Waveshaper", -- [1]
					"Siege of Boralus", -- [2]
				},
				[138061] = {
					"Venture Co. Longshoreman", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[190362] = {
					"Dazzling Dragonfly", -- [1]
					"Halls of Infusion", -- [2]
				},
				[189467] = {
					"Qalashi Bonesplitter", -- [1]
					"Neltharus", -- [2]
				},
				[101639] = {
					"Valarjar Shieldmaiden", -- [1]
					"Halls of Valor", -- [2]
				},
				[196117] = {
					"Crystal Thrasher", -- [1]
					"The Azure Vault", -- [2]
				},
				[189340] = {
					"Chargath, Bane of Scales", -- [1]
					"Neltharus", -- [2]
				},
				[163126] = {
					"Brittlebone Mage", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[193944] = {
					"Qalashi Lavamancer", -- [1]
					"Neltharus", -- [2]
				},
				[138063] = {
					"Posh Vacationer", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[192794] = {
					"Nokhud Beastmaster", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[131670] = {
					"Heartsbane Vinetwister", -- [1]
					"Waycrest Manor", -- [2]
				},
				[138064] = {
					"Posh Vacationer", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[189470] = {
					"Lava Flare", -- [1]
					"Neltharus", -- [2]
				},
				[163128] = {
					"Zolramus Sorcerer", -- [1]
					"The Necrotic Wake", -- [2]
				},
				[168627] = {
					"Plaguebinder", -- [1]
					"Plaguefall", -- [2]
				},
				[190366] = {
					"Curious Swoglet", -- [1]
					"Halls of Infusion", -- [2]
				},
				[189471] = {
					"Qalashi Blacksmith", -- [1]
					"Neltharus", -- [2]
				},
				[189727] = {
					"Khajin the Unyielding", -- [1]
					"Halls of Infusion", -- [2]
				},
				[189472] = {
					"Qalashi Lavabearer", -- [1]
					"Neltharus", -- [2]
				},
				[185508] = {
					"Claw Fighter", -- [1]
					"Brackenhide Hollow", -- [2]
				},
				[197145] = {
					"Colossal Stormfiend", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[198424] = {
					"Primalist Frostsculptor", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190368] = {
					"Flamecaller Aymi", -- [1]
					"Halls of Infusion", -- [2]
				},
				[190496] = {
					"Terros", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[189729] = {
					"Primal Tsunami", -- [1]
					"Halls of Infusion", -- [2]
				},
				[197146] = {
					"Qalashi Emissary", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[188067] = {
					"Flashfrost Chillweaver", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[168886] = {
					"Virulax Blightweaver", -- [1]
					"Plaguefall", -- [2]
				},
				[134232] = {
					"Hired Assassin", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[133593] = {
					"Expert Technician", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[197147] = {
					"Qalashi Honor Guard", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190370] = {
					"Squallbringer Cyraz", -- [1]
					"Halls of Infusion", -- [2]
				},
				[192800] = {
					"Nokhud Lancemaster", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[197148] = {
					"Qalashi Lavabearer", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[186151] = {
					"Balakar Khan", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[190371] = {
					"Primalist Earthshaker", -- [1]
					"Halls of Infusion", -- [2]
				},
				[131677] = {
					"Heartsbane Runeweaver", -- [1]
					"Waycrest Manor", -- [2]
				},
				[135258] = {
					"Irontide Marauder", -- [1]
					"Siege of Boralus", -- [2]
				},
				[133852] = {
					"Living Rot", -- [1]
					"The Underrot", -- [2]
				},
				[197406] = {
					"Aggravated Skitterfly", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[190373] = {
					"Primalist Galesinger", -- [1]
					"Halls of Infusion", -- [2]
				},
				[189478] = {
					"Forgemaster Gorek", -- [1]
					"Neltharus", -- [2]
				},
				[134364] = {
					"Faithless Tender", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[192803] = {
					"War Ohuna", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[174773] = {
					"Spiteful Shade", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[197535] = {
					"High Channeler Ryvati", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[198047] = {
					"Tempest Channeler", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[128435] = {
					"Toxic Saurid", -- [1]
					"Atal'Dazar", -- [2]
				},
				[193572] = {
					"Nokhud Warsmith", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[76518] = {
					"Ritual of Bones", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[153292] = {
					"Training Dummy", -- [1]
					"Eastern Kingdoms", -- [2]
				},
				[101326] = {
					"Honored Ancestor", -- [1]
					"Halls of Valor", -- [2]
				},
				[196642] = {
					"Hungry Lasher", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[197793] = {
					"Awakened Juggernaut", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[195875] = {
					"Desecrated Bakar", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[192934] = {
					"Volatile Infuser", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[135007] = {
					"Orb Guardian", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[190377] = {
					"Primalist Icecaller", -- [1]
					"Halls of Infusion", -- [2]
				},
				[135263] = {
					"Ashvane Spotter", -- [1]
					"Siege of Boralus", -- [2]
				},
				[133345] = {
					"Feckless Assistant", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[195876] = {
					"Desecrated Ohuna", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[200945] = {
					"Nokhud Warmonger", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[189227] = {
					"Qalashi Hunter", -- [1]
					"Neltharus", -- [2]
				},
				[102019] = {
					"Stormforged Obliterator", -- [1]
					"Halls of Valor", -- [2]
				},
				[104822] = {
					"Flame of Woe", -- [1]
					"Halls of Valor", -- [2]
				},
				[192680] = {
					"Guardian Sentry", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[195877] = {
					"Risen Mystic", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[95675] = {
					"God-King Skovald", -- [1]
					"Halls of Valor", -- [2]
				},
				[95843] = {
					"King Haldor", -- [1]
					"Halls of Valor", -- [2]
				},
				[200131] = {
					"Sha-Touched Guardian", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[200761] = {
					"Wild Ohuna", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[96934] = {
					"Valarjar Trapper", -- [1]
					"Halls of Valor", -- [2]
				},
				[196645] = {
					"Desecrated Bakar", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[191739] = {
					"Scalebane Lieutenant", -- [1]
					"The Azure Vault", -- [2]
				},
				[195878] = {
					"Ukhel Beastcaller", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[186739] = {
					"Azureblade", -- [1]
					"The Azure Vault", -- [2]
				},
				[131685] = {
					"Runic Disciple", -- [1]
					"Waycrest Manor", -- [2]
				},
				[189555] = {
					"Astral Attendant", -- [1]
					"The Azure Vault", -- [2]
				},
				[187154] = {
					"Unstable Curator", -- [1]
					"The Azure Vault", -- [2]
				},
				[186644] = {
					"Leymor", -- [1]
					"The Azure Vault", -- [2]
				},
				[191510] = {
					"Smoldering Hellion", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190407] = {
					"Aqua Rager", -- [1]
					"Halls of Infusion", -- [2]
				},
				[164921] = {
					"Drust Harvester", -- [1]
					"Mists of Tirna Scithe", -- [2]
				},
				[184986] = {
					"Kurog Grimtotem", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[188100] = {
					"Shrieking Whelp", -- [1]
					"The Azure Vault", -- [2]
				},
				[196263] = {
					"Nokhud Neophyte", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[190484] = {
					"Kyrakka", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[186615] = {
					"The Raging Tempest", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[99922] = {
					"Ebonclaw Packmate", -- [1]
					"Halls of Valor", -- [2]
				},
				[190207] = {
					"Primalist Cinderweaver", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[190510] = {
					"Vault Guard", -- [1]
					"The Azure Vault", -- [2]
				},
				[189232] = {
					"Kokia Blazehoof", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[104270] = {
					"Guardian Construct", -- [1]
					"Court of Stars", -- [2]
				},
				[198310] = {
					"Flame Tarasek", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[99868] = {
					"Fenryr", -- [1]
					"Halls of Valor", -- [2]
				},
				[167876] = {
					"Inquisitor Sigar", -- [1]
					"Halls of Atonement", -- [2]
				},
				[197671] = {
					"Volatile Infuser", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[138465] = {
					"Ashvane Cannoneer", -- [1]
					"Siege of Boralus", -- [2]
				},
				[95842] = {
					"Valarjar Thundercaller", -- [1]
					"Halls of Valor", -- [2]
				},
				[134629] = {
					"Scaled Krolusk Rider", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[167493] = {
					"Venomous Sniper", -- [1]
					"Plaguefall", -- [2]
				},
				[170690] = {
					"Diseased Horror", -- [1]
					"Theater of Pain", -- [2]
				},
				[130485] = {
					"Mechanized Peacekeeper", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[168942] = {
					"Death Speaker", -- [1]
					"De Other Side", -- [2]
				},
				[199718] = {
					"Nokhud Huntmaster", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[187602] = {
					"Qalashi Scaleripper", -- [1]
					"10.0 Dragon Isles", -- [2]
				},
				[137716] = {
					"Bottom Feeder", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[59546] = {
					"The Talking Fish", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[195821] = {
					"Nokhud Saboteur", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[131817] = {
					"Cragmaw the Infested", -- [1]
					"The Underrot", -- [2]
				},
				[189233] = {
					"Caustic Spiderling", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190405] = {
					"Infuser Sariya", -- [1]
					"Halls of Infusion", -- [2]
				},
				[199719] = {
					"Nokhud Wardog", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[197801] = {
					"Awakened Terrasentry", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[136549] = {
					"Ashvane Cannoneer", -- [1]
					"Siege of Boralus", -- [2]
				},
				[136005] = {
					"Rowdy Reveler", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[137517] = {
					"Ashvane Destroyer", -- [1]
					"Siege of Boralus", -- [2]
				},
				[131818] = {
					"Marked Sister", -- [1]
					"Waycrest Manor", -- [2]
				},
				[189234] = {
					"Frostbreath Arachnid", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[129367] = {
					"Bilge Rat Tempest", -- [1]
					"Siege of Boralus", -- [2]
				},
				[95832] = {
					"Valarjar Shieldmaiden", -- [1]
					"Halls of Valor", -- [2]
				},
				[197799] = {
					"Quarry Infuser", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[104215] = {
					"Patrol Captain Gerdo", -- [1]
					"Court of Stars", -- [2]
				},
				[167965] = {
					"Lubricator", -- [1]
					"De Other Side", -- [2]
				},
				[197219] = {
					"Vile Lasher", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[136934] = {
					"Weapons Tester", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[189235] = {
					"Overseer Lahar", -- [1]
					"Neltharus", -- [2]
				},
				[133482] = {
					"Crawler Mine", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[136295] = {
					"Sunken Denizen", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[56762] = {
					"Yu'lon", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[131436] = {
					"Chosen Blood Matron", -- [1]
					"The Underrot", -- [2]
				},
				[194990] = {
					"Stormseeker Acolyte", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[137830] = {
					"Pallid Gorger", -- [1]
					"Waycrest Manor", -- [2]
				},
				[96664] = {
					"Valarjar Runecarver", -- [1]
					"Halls of Valor", -- [2]
				},
				[195119] = {
					"Primalist Shockcaster", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[141283] = {
					"Kul Tiran Halberd", -- [1]
					"Siege of Boralus", -- [2]
				},
				[95833] = {
					"Hyrja", -- [1]
					"Halls of Valor", -- [2]
				},
				[185528] = {
					"Trickclaw Mystic", -- [1]
					"Brackenhide Hollow", -- [2]
				},
				[141284] = {
					"Kul Tiran Wavetender", -- [1]
					"Siege of Boralus", -- [2]
				},
				[194991] = {
					"Oathsworn Vanguard", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[104273] = {
					"Jazshariu", -- [1]
					"Court of Stars", -- [2]
				},
				[59873] = {
					"Corrupt Living Water", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[162039] = {
					"Wicked Oppressor", -- [1]
					"Sanguine Depths", -- [2]
				},
				[193457] = {
					"Balara", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[134251] = {
					"Seneschal M'bara", -- [1]
					"Kings' Rest", -- [2]
				},
				[185529] = {
					"Bracken Warscourge", -- [1]
					"Brackenhide Hollow", -- [2]
				},
				[190404] = {
					"Subterranean Proto-Dragon", -- [1]
					"Halls of Infusion", -- [2]
				},
				[194816] = {
					"Forgewrought Monstrosity", -- [1]
					"Neltharus", -- [2]
				},
				[56448] = {
					"Wise Mari", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[137521] = {
					"Irontide Powdershot", -- [1]
					"Siege of Boralus", -- [2]
				},
				[130488] = {
					"Mech Jockey", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[129529] = {
					"Blacktooth Scrapper", -- [1]
					"Freehold", -- [2]
				},
				[95834] = {
					"Valarjar Mystic", -- [1]
					"Halls of Valor", -- [2]
				},
				[163891] = {
					"Rotmarrow Slime", -- [1]
					"Plaguefall", -- [2]
				},
				[59547] = {
					"Jiang", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[133430] = {
					"Venture Co. Mastermind", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[104274] = {
					"Baalgar the Watchful", -- [1]
					"Court of Stars", -- [2]
				},
				[65317] = {
					"Xiang", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[111563] = {
					"Duskwatch Guard", -- [1]
					"Court of Stars", -- [2]
				},
				[192955] = {
					"Draconic Illusion", -- [1]
					"The Azure Vault", -- [2]
				},
				[198702] = {
					"Unstable Frost", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[57080] = {
					"Corrupted Scroll", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[189492] = {
					"Raszageth", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[187767] = {
					"Embar Firepath", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[126919] = {
					"Irontide Stormcaller", -- [1]
					"Freehold", -- [2]
				},
				[133870] = {
					"Diseased Lasher", -- [1]
					"The Underrot", -- [2]
				},
				[62358] = {
					"Corrupt Droplet", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[131585] = {
					"Enthralled Guard", -- [1]
					"Waycrest Manor", -- [2]
				},
				[59552] = {
					"The Crybaby Hozen", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[192786] = {
					"Qalashi Plunderer", -- [1]
					"Neltharus", -- [2]
				},
				[107073] = {
					"Duskwatch Reinforcement", -- [1]
					"Court of Stars", -- [2]
				},
				[192796] = {
					"Nokhud Hornsounder", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[104275] = {
					"Imacu'tya", -- [1]
					"Court of Stars", -- [2]
				},
				[131586] = {
					"Banquet Steward", -- [1]
					"Waycrest Manor", -- [2]
				},
				[104246] = {
					"Duskwatch Guard", -- [1]
					"Court of Stars", -- [2]
				},
				[197698] = {
					"Thunderhead", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[189901] = {
					"Warlord Sargha", -- [1]
					"Neltharus", -- [2]
				},
				[168572] = {
					"Fungi Stormer", -- [1]
					"Plaguefall", -- [2]
				},
				[129788] = {
					"Irontide Bonesaw", -- [1]
					"Freehold", -- [2]
				},
				[169421] = {
					"Felguard", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[170572] = {
					"Atal'ai Hoodoo Hexxer", -- [1]
					"De Other Side", -- [2]
				},
				[197298] = {
					"Nascent Proto-Dragon", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[198577] = {
					"Unstable Flame", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[193462] = {
					"Batak", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[185691] = {
					"Vicious Hyena", -- [1]
					"Brackenhide Hollow", -- [2]
				},
				[185534] = {
					"Bonebolt Hunter", -- [1]
					"Brackenhide Hollow", -- [2]
				},
				[189886] = {
					"Blazebound Firestorm", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[189466] = {
					"Irontorch Commander", -- [1]
					"Neltharus", -- [2]
				},
				[134144] = {
					"Living Current", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[137713] = {
					"Big Money Crab", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[194316] = {
					"Stormcaller Zarii", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[170882] = {
					"Bone Magus", -- [1]
					"Theater of Pain", -- [2]
				},
				[134139] = {
					"Shrine Templar", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[194317] = {
					"Stormcaller Boroo", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[167111] = {
					"Spinemaw Staghorn", -- [1]
					"Mists of Tirna Scithe", -- [2]
				},
				[59555] = {
					"Haunting Sha", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[166276] = {
					"Mistveil Guardian", -- [1]
					"Mists of Tirna Scithe", -- [2]
				},
				[59598] = {
					"Lesser Sha", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[164552] = {
					"Rotmarrow Slime", -- [1]
					"Plaguefall", -- [2]
				},
				[194894] = {
					"Primalist Stormspeaker", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[130436] = {
					"Off-Duty Laborer", -- [1]
					"The MOTHERLODE!!", -- [2]
				},
				[165076] = {
					"Gluttonous Tick", -- [1]
					"Sanguine Depths", -- [2]
				},
				[134514] = {
					"Abyssal Cultist", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[194999] = {
					"Volatile Spark", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[104277] = {
					"Legion Hound", -- [1]
					"Court of Stars", -- [2]
				},
				[196045] = {
					"Corrupted Manafiend", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[199717] = {
					"Nokhud Defender", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[189719] = {
					"Watcher Irideus", -- [1]
					"Halls of Infusion", -- [2]
				},
				[189722] = {
					"Gulping Goliath", -- [1]
					"Halls of Infusion", -- [2]
				},
				[135365] = {
					"Matron Alma", -- [1]
					"Waycrest Manor", -- [2]
				},
				[192788] = {
					"Qalashi Thaumaturge", -- [1]
					"Neltharus", -- [2]
				},
				[169425] = {
					"Felhound", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[187967] = {
					"Sennarth", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[191164] = {
					"Arcane Tender", -- [1]
					"The Azure Vault", -- [2]
				},
				[197835] = {
					"Kaurdyth", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[137516] = {
					"Ashvane Invader", -- [1]
					"Siege of Boralus", -- [2]
				},
				[198709] = {
					"Unstable Earth", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[168318] = {
					"Forsworn Goliath", -- [1]
					"Spires of Ascension", -- [2]
				},
				[75506] = {
					"Shadowmoon Loyalist", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[169426] = {
					"Infernal", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[104278] = {
					"Felbound Enforcer", -- [1]
					"Court of Stars", -- [2]
				},
				[139422] = {
					"Scaled Krolusk Tamer", -- [1]
					"Temple of Sethraliss", -- [2]
				},
				[189247] = {
					"Tamed Phoenix", -- [1]
					"Neltharus", -- [2]
				},
				[162040] = {
					"Grand Overseer", -- [1]
					"Sanguine Depths", -- [2]
				},
				[190174] = {
					"Hypnosis Bat", -- [1]
					"Court of Stars", -- [2]
				},
				[141285] = {
					"Kul Tiran Marksman", -- [1]
					"Siege of Boralus", -- [2]
				},
				[196115] = {
					"Arcane Tender", -- [1]
					"The Azure Vault", -- [2]
				},
				[94960] = {
					"Hymdall", -- [1]
					"Halls of Valor", -- [2]
				},
				[187969] = {
					"Flashfrost Earthshaper", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[196577] = {
					"Spellbound Battleaxe", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[104918] = {
					"Vigilant Duskwatch", -- [1]
					"Court of Stars", -- [2]
				},
				[59553] = {
					"The Songbird Queen", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[56439] = {
					"Sha of Doubt", -- [1]
					"Temple of the Jade Serpent", -- [2]
				},
				[122971] = {
					"Dazar'ai Juggernaut", -- [1]
					"Atal'Dazar", -- [2]
				},
				[134150] = {
					"Runecarver Sorn", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[169428] = {
					"Wrathguard", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[134417] = {
					"Deepsea Ritualist", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[197398] = {
					"Hungry Lasher", -- [1]
					"Algeth'ar Academy", -- [2]
				},
				[191714] = {
					"Seeking Stormling", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[190245] = {
					"Broodkeeper Diurna", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[128434] = {
					"Feasting Skyscreamer", -- [1]
					"Atal'Dazar", -- [2]
				},
				[193709] = {
					"Primalist Earthwarden", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[188011] = {
					"Primal Terrasentry", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[169429] = {
					"Shivarra", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[125977] = {
					"Reanimation Totem", -- [1]
					"Atal'Dazar", -- [2]
				},
				[191847] = {
					"Nokhud Plainstomper", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[187155] = {
					"Rune Seal Keeper", -- [1]
					"The Azure Vault", -- [2]
				},
				[190401] = {
					"Gusting Proto-Dragon", -- [1]
					"Halls of Infusion", -- [2]
				},
				[197149] = {
					"Qalashi Lavamancer", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[199333] = {
					"Frostbreath Arachnid", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[187638] = {
					"Flamescale Tarasek", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[169430] = {
					"Ur'zul", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[199716] = {
					"Nokhud Brute", -- [1]
					"The Nokhud Offensive", -- [2]
				},
				[199353] = {
					"Frost Tomb", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[197509] = {
					"Primal Thundercloud", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[134137] = {
					"Temple Attendant", -- [1]
					"Shrine of the Storm", -- [2]
				},
				[194622] = {
					"Scorchling", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[127106] = {
					"Irontide Officer", -- [1]
					"Freehold", -- [2]
				},
				[191313] = {
					"Bubbling Sapling", -- [1]
					"The Azure Vault", -- [2]
				},
				[187897] = {
					"Defier Draghar", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[96608] = {
					"Ebonclaw Worg", -- [1]
					"Halls of Valor", -- [2]
				},
				[174802] = {
					"Venomous Sniper", -- [1]
					"Plaguefall", -- [2]
				},
				[188252] = {
					"Melidrussa Chillworn", -- [1]
					"Ruby Life Pools", -- [2]
				},
				[190403] = {
					"Glacial Proto-Dragon", -- [1]
					"Halls of Infusion", -- [2]
				},
				[129600] = {
					"Bilge Rat Brinescale", -- [1]
					"Freehold", -- [2]
				},
				[77700] = {
					"Shadowmoon Exhumer", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[75509] = {
					"Sadana Bloodfury", -- [1]
					"Shadowmoon Burial Grounds", -- [2]
				},
				[104217] = {
					"Talixae Flamewreath", -- [1]
					"Court of Stars", -- [2]
				},
				[192764] = {
					"Flame Guardian", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[199027] = {
					"Magmas", -- [1]
					"Vault of the Incarnates", -- [2]
				},
				[189265] = {
					"Qalashi Bonetender", -- [1]
					"Neltharus", -- [2]
				},
			},
			["aura_grow_direction"] = 3,
			["health_selection_overlay_alpha"] = 0.2999999821186066,
			["aura_stack_shadow_color"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				0, -- [4]
			},
			["minor_height_scale"] = 0.9999999403953552,
			["aura_padding"] = 2,
			["indicator_worldboss"] = false,
			["last_news_time"] = 1551553489,
			["aura_width2"] = 16,
			["plater_resources_align"] = "horizontal",
			["aura_height2"] = 10,
			["cast_colors"] = {
				[372223] = {
					true, -- [1]
					"darkorange", -- [2]
					"", -- [3]
				},
				[388392] = {
					true, -- [1]
					"darkorange", -- [2]
				},
				[384597] = {
					false, -- [1]
					"white", -- [2]
				},
			},
			["castbar_target_anchor"] = {
				["side"] = 11,
			},
			["class_colors"] = {
				["DEATHKNIGHT"] = {
					["colorStr"] = "ffc31d3a",
				},
				["WARRIOR"] = {
					["colorStr"] = "ffc69a6d",
				},
				["PALADIN"] = {
					["colorStr"] = "fff48bb9",
				},
				["WARLOCK"] = {
					["colorStr"] = "ff8687ed",
				},
				["DEMONHUNTER"] = {
					["colorStr"] = "ffa22fc8",
				},
				["ROGUE"] = {
					["colorStr"] = "fffff467",
				},
				["DRUID"] = {
					["colorStr"] = "ffff7c09",
				},
				["EVOKER"] = {
					["colorStr"] = "ff33937e",
				},
				["SHAMAN"] = {
					["colorStr"] = "ff006fdd",
				},
			},
			["extra_icon_anchor"] = {
				["x"] = 4,
			},
			["range_check_alpha"] = 1,
			["semver"] = "1.0.2",
			["plater_resources_padding"] = 2,
			["aura_frame2_anchor"] = {
				["y"] = 0,
				["x"] = 2.099990844726563,
				["side"] = 6,
			},
			["cast_statusbar_texture"] = "ElvUI Blank",
			["auto_toggle_friendly"] = {
				["world"] = false,
			},
			["aura_cooldown_edge_texture"] = "Interface\\GLUES\\loadingOld",
			["plater_resources_show_number"] = false,
			["aura_consolidate"] = true,
			["extra_icon_width"] = 22,
			["health_statusbar_texture"] = "ElvUI Blank",
			["hook_auto_imported"] = {
				["Color Automation"] = 1,
				["Blockade Encounter"] = 1,
				["Cast Bar Icon Config"] = 2,
				["Hide Neutral Units"] = 1,
				["Aura Reorder"] = 3,
				["Reorder Nameplate"] = 4,
				["Dont Have Aura"] = 1,
				["Players Targetting Amount"] = 4,
				["Bwonsamdi Reaping"] = 1,
				["Jaina Encounter"] = 6,
				["Execute Range"] = 1,
				["Attacking Specific Unit"] = 2,
				["Extra Border"] = 2,
				["Targetting Alpha"] = 3,
				["Target Color"] = 3,
				["Combo Points"] = 6,
				["Monk Statue"] = 2,
			},
			["minor_width_scale"] = 0.9999999403953552,
			["indicator_pet"] = false,
			["aura_frame1_anchor"] = {
				["y"] = 24.75,
				["side"] = 3,
			},
			["aura_timer_text_font"] = "Accidental Presidency",
			["extra_icon_stack_font"] = "Accidental Presidency",
			["aura_height"] = 10,
			["cast_statusbar_bgtexture"] = "PlaterBackground",
			["aura2_x_offset"] = 2.099990844726563,
			["target_indicator"] = "NONE",
			["saved_cvars"] = {
				["nameplateShowOnlyNames"] = "1",
				["nameplateOverlapV"] = "1.1",
				["ShowNamePlateLoseAggroFlash"] = "1",
				["nameplateShowEnemyMinus"] = "1",
				["NamePlateClassificationScale"] = "1.25",
				["nameplateShowFriendlyTotems"] = "0",
				["nameplatePersonalHideDelaySeconds"] = "0.2",
				["nameplateShowFriendlyPets"] = "0",
				["nameplatePersonalShowInCombat"] = "1",
				["nameplateTargetRadialPosition"] = "1",
				["nameplateMinAlpha"] = "0.90135484",
				["nameplateResourceOnTarget"] = "0",
				["nameplateShowAll"] = "1",
				["nameplateMaxDistance"] = "100",
				["nameplateShowFriendlyMinions"] = "0",
				["nameplateSelfScale"] = "1.0",
				["nameplateTargetBehindMaxDistance"] = "30",
				["nameplateShowEnemies"] = "1",
				["NamePlateVerticalScale"] = "0.1",
				["nameplateSelectedAlpha"] = "1",
				["nameplateShowSelf"] = "0",
				["nameplatePersonalShowAlways"] = "0",
				["nameplateMotionSpeed"] = "0.05",
				["nameplateGlobalScale"] = "1.0",
				["nameplateShowEnemyMinions"] = "1",
				["nameplateShowFriendlyNPCs"] = "0",
				["nameplateSelectedScale"] = "1.15",
				["nameplateShowFriends"] = "1",
				["nameplateMotion"] = "1",
				["nameplateMinScale"] = "1",
				["nameplatePersonalShowWithTarget"] = "0",
				["nameplateOtherTopInset"] = "0.085",
				["nameplateOccludedAlphaMult"] = "1",
				["nameplateSelfBottomInset"] = "0.2",
				["nameplateSelfAlpha"] = "0.75",
				["nameplateShowFriendlyGuardians"] = "0",
				["NamePlateHorizontalScale"] = "1.4",
				["nameplateSelfTopInset"] = "0.5",
				["ShowClassColorInNameplate"] = "1",
				["nameplateLargeTopInset"] = "0.085",
				["nameplateMinAlphaDistance"] = "-158489.31924611",
			},
			["login_counter"] = 12509,
			["extra_icon_caster_name"] = false,
			["aura_cooldown_show_swipe"] = false,
			["plater_resources_show"] = false,
			["OptionsPanelDB"] = {
				["PlaterOptionsPanelFrame"] = {
					["scale"] = 1,
				},
			},
			["aura_timer_text_shadow_color"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				0, -- [4]
			},
			["plater_resources_show_depleted"] = false,
			["plate_config"] = {
				["player"] = {
					["spellpercent_text_font"] = "Accidental Presidency",
					["power_percent_text_enabled"] = false,
					["level_text_font"] = "Accidental Presidency",
					["actorname_text_font"] = "Accidental Presidency",
					["big_actortitle_text_font"] = "Accidental Presidency",
					["spellname_text_font"] = "Accidental Presidency",
					["click_through"] = true,
					["big_actorname_text_font"] = "Accidental Presidency",
					["power_percent_text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["percent_text_font"] = "Accidental Presidency",
					["power_percent_text_font"] = "Accidental Presidency",
				},
				["friendlyplayer"] = {
					["spellpercent_text_font"] = "Accidental Presidency",
					["level_text_size"] = 8,
					["actorname_use_class_color"] = true,
					["cast"] = {
						120, -- [1]
					},
					["spellpercent_text_anchor"] = {
						["x"] = 1,
						["side"] = 5,
					},
					["big_actorname_text_shadow_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["spellpercent_text_outline"] = "NONE",
					["level_text_font"] = "Accidental Presidency",
					["actorname_text_font"] = "Accidental Presidency",
					["big_actorname_text_shadow_color_offset"] = {
						1, -- [1]
						-1, -- [2]
					},
					["mana_incombat"] = {
						nil, -- [1]
						4, -- [2]
					},
					["actorname_use_guild_color"] = false,
					["all_names"] = true,
					["big_actortitle_text_outline"] = "OUTLINE",
					["actorname_text_spacing"] = 11,
					["only_damaged"] = false,
					["quest_color_enemy"] = {
						1, -- [1]
						0.369, -- [2]
						0, -- [3]
					},
					["only_thename"] = true,
					["big_actortitle_text_font"] = "Accidental Presidency",
					["percent_text_ooc"] = true,
					["level_text_anchor"] = {
						["x"] = 1,
						["side"] = 5,
					},
					["big_actortitle_text_shadow_color_offset"] = {
						1, -- [1]
						-1, -- [2]
					},
					["cast_incombat"] = {
						120, -- [1]
					},
					["percent_show_health"] = true,
					["spellname_text_anchor"] = {
						["y"] = 1,
						["side"] = 3,
					},
					["big_actortitle_text_shadow_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["percent_text_anchor"] = {
						["y"] = 1,
						["side"] = 3,
					},
					["spellpercent_text_enabled"] = true,
					["big_actortitle_text_size"] = 10,
					["spellname_text_font"] = "Accidental Presidency",
					["big_actorname_text_outline"] = "OUTLINE",
					["quest_color_neutral"] = {
						1, -- [1]
						0.65, -- [2]
						0, -- [3]
					},
					["mana"] = {
						nil, -- [1]
						4, -- [2]
					},
					["big_actorname_text_font"] = "Accidental Presidency",
					["big_actorname_text_size"] = 10,
					["actorname_use_friends_color"] = false,
					["spellpercent_text_size"] = 9,
					["level_text_alpha"] = 0.29999998211861,
					["percent_text_size"] = 8,
					["actorname_text_anchor"] = {
						["y"] = -3,
						["x"] = -1,
						["side"] = 1,
					},
					["percent_text_font"] = "Accidental Presidency",
					["buff_frame_y_offset"] = 0,
					["percent_text_outline"] = "NONE",
					["spellname_text_color"] = {
						0.95294117647059, -- [1]
						[3] = 0.9921568627451,
					},
					["actorname_text_size"] = 12,
					["spellname_text_size"] = 9,
					["health"] = {
						120, -- [1]
						10, -- [2]
					},
					["percent_text_enabled"] = true,
					["power_percent_text_font"] = "Accidental Presidency",
					["health_incombat"] = {
						120, -- [1]
						10, -- [2]
					},
					["quest_enabled"] = true,
					["level_text_enabled"] = true,
				},
				["friendlynpc"] = {
					["spellpercent_text_font"] = "Accidental Presidency",
					["level_text_size"] = 8,
					["cast"] = {
						120, -- [1]
						8, -- [2]
					},
					["spellpercent_text_anchor"] = {
						["x"] = 1,
						["side"] = 5,
					},
					["enabled"] = false,
					["spellpercent_text_outline"] = "NONE",
					["level_text_font"] = "Accidental Presidency",
					["spellname_text_color"] = {
						0.95294117647059, -- [1]
						[3] = 0.9921568627451,
					},
					["actorname_text_outline"] = "OUTLINE",
					["quest_color_enemy"] = {
						1, -- [1]
						0.369, -- [2]
						0, -- [3]
					},
					["big_actortitle_text_font"] = "Accidental Presidency",
					["spellpercent_text_size"] = 9,
					["level_text_anchor"] = {
						["x"] = 1,
						["side"] = 5,
					},
					["spellname_text_anchor"] = {
						["y"] = 1,
						["side"] = 3,
					},
					["percent_text_anchor"] = {
						["y"] = 1,
						["side"] = 3,
					},
					["power_percent_text_font"] = "Accidental Presidency",
					["spellname_text_font"] = "Accidental Presidency",
					["only_names"] = false,
					["percent_text_ooc"] = true,
					["quest_color_neutral"] = {
						1, -- [1]
						0.65, -- [2]
						0, -- [3]
					},
					["actorname_text_size"] = 11,
					["percent_text_enabled"] = true,
					["big_actorname_text_size"] = 10,
					["health_incombat"] = {
						nil, -- [1]
						18, -- [2]
					},
					["level_text_alpha"] = 0.29999998211861,
					["spellpercent_text_enabled"] = true,
					["big_actortitle_text_size"] = 10,
					["percent_text_font"] = "Accidental Presidency",
					["percent_text_outline"] = "NONE",
					["actorname_text_font"] = "Accidental Presidency",
					["spellname_text_size"] = 9,
					["health"] = {
						120, -- [1]
						18, -- [2]
					},
					["big_actorname_text_font"] = "Accidental Presidency",
					["percent_show_health"] = true,
					["percent_text_size"] = 8,
					["actorname_text_anchor"] = {
						["y"] = -3,
						["x"] = -1,
						["side"] = 1,
					},
					["level_text_enabled"] = true,
				},
				["enemynpc"] = {
					["spellpercent_text_font"] = "ViklunD's SexFont",
					["cast"] = {
						120, -- [1]
						8, -- [2]
					},
					["spellpercent_text_anchor"] = {
						["y"] = -0.8000030517578125,
						["x"] = 3.899993896484375,
						["side"] = 5,
					},
					["level_text_font"] = "Accidental Presidency",
					["actorname_text_font"] = "Accidental Presidency",
					["actorname_text_outline"] = "OUTLINE",
					["actorname_text_spacing"] = 8,
					["big_actortitle_text_font"] = "Accidental Presidency",
					["spellpercent_text_size"] = 9,
					["level_text_anchor"] = {
						["y"] = 100,
						["x"] = 1,
						["side"] = 5,
					},
					["cast_incombat"] = {
						nil, -- [1]
						8, -- [2]
					},
					["actorname_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["spellname_text_anchor"] = {
						["y"] = 0.09999847412109375,
						["x"] = -0.8000030517578125,
						["side"] = 3,
					},
					["percent_text_anchor"] = {
						["y"] = -9.930000305175781,
						["x"] = 1.099998474121094,
						["side"] = 7,
					},
					["spellname_text_font"] = "Accidental Presidency",
					["actorname_text_size"] = 9,
					["big_actorname_text_font"] = "Accidental Presidency",
					["percent_text_show_decimals"] = false,
					["percent_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["level_text_alpha"] = 0.29999998211861,
					["percent_text_font"] = "Accidental Presidency",
					["spellpercent_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["power_percent_text_font"] = "Accidental Presidency",
					["spellname_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["health_incombat"] = {
						nil, -- [1]
						11, -- [2]
					},
					["health"] = {
						120, -- [1]
						11, -- [2]
					},
					["percent_show_health"] = false,
					["spellname_text_color"] = {
						0.95294117647059, -- [1]
						[3] = 0.9921568627451,
					},
					["spellname_text_size"] = 9,
					["actorname_text_anchor"] = {
						["y"] = -9.930000305175781,
						["x"] = 0.9000015258789062,
						["side"] = 1,
					},
					["level_text_enabled"] = false,
				},
				["global_health_height"] = 10,
				["enemyplayer"] = {
					["spellpercent_text_font"] = "ViklunD's SexFont",
					["level_text_size"] = 8,
					["cast"] = {
						120, -- [1]
						8, -- [2]
					},
					["percent_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["spellpercent_text_anchor"] = {
						["x"] = 1,
						["side"] = 5,
					},
					["percent_text_show_decimals"] = false,
					["spellpercent_text_outline"] = "NONE",
					["level_text_font"] = "Accidental Presidency",
					["spellname_text_color"] = {
						0.95294117647059, -- [1]
						[3] = 0.9921568627451,
					},
					["mana_incombat"] = {
						120, -- [1]
						1, -- [2]
					},
					["all_names"] = true,
					["actorname_text_outline"] = "OUTLINE",
					["actorname_text_spacing"] = 9,
					["quest_color_enemy"] = {
						1, -- [1]
						0.369, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["big_actortitle_text_font"] = "Accidental Presidency",
					["spellpercent_text_size"] = 9,
					["level_text_anchor"] = {
						["y"] = 100,
						["x"] = 1,
						["side"] = 5,
					},
					["cast_incombat"] = {
						nil, -- [1]
						8, -- [2]
					},
					["actorname_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["spellname_text_anchor"] = {
						["y"] = 1,
						["side"] = 3,
					},
					["percent_text_anchor"] = {
						["y"] = 4.649993896484375,
						["side"] = 5,
					},
					["spellname_text_font"] = "Accidental Presidency",
					["quest_color_neutral"] = {
						1, -- [1]
						0.65, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["mana"] = {
						120, -- [1]
						1, -- [2]
					},
					["big_actorname_text_font"] = "Accidental Presidency",
					["big_actortitle_text_size"] = 10,
					["big_actorname_text_size"] = 10,
					["level_text_alpha"] = 0.29999998211861,
					["percent_text_size"] = 10,
					["percent_text_font"] = "Accidental Presidency",
					["actorname_text_font"] = "Accidental Presidency",
					["quest_enabled"] = true,
					["power_percent_text_font"] = "Accidental Presidency",
					["spellname_text_shadow_color"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						0, -- [4]
					},
					["quest_color_enabled"] = true,
					["health_incombat"] = {
						nil, -- [1]
						10, -- [2]
					},
					["health"] = {
						120, -- [1]
						10, -- [2]
					},
					["actorname_text_anchor"] = {
						["y"] = -0.4000015258789063,
						["x"] = -1,
						["side"] = 1,
					},
					["percent_show_percent"] = false,
					["percent_show_health"] = false,
					["actorname_text_size"] = 10,
					["level_text_enabled"] = false,
				},
				["global_health_width"] = 120,
			},
			["aura_y_offset"] = 24.75,
			["use_ui_parent"] = true,
			["cast_statusbar_bgcolor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.79781, -- [4]
			},
			["plater_resources_grow_direction"] = "center",
			["resources_settings"] = {
				["chr"] = {
					["Player-4184-003D46E0"] = "Chi",
					["Player-3725-0C16E871"] = "HolyPower",
					["Player-3725-0AA8E1EF"] = "Runes",
					["Player-3725-0C1533F1"] = "ComboPoints",
					["Player-3725-0C1632F3"] = "HolyPower",
					["Player-3725-0A9FE377"] = "Chi",
				},
			},
			["cast_statusbar_spark_offset"] = -13,
			["npc_colors"] = {
				[200137] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[136005] = {
					false, -- [1]
					false, -- [2]
					"blue", -- [3]
				},
				[129602] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[134284] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[133870] = {
					false, -- [1]
					false, -- [2]
					"lightcoral", -- [3]
				},
				[134157] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[136006] = {
					false, -- [1]
					false, -- [2]
					"blue", -- [3]
				},
				[132532] = {
					false, -- [1]
					false, -- [2]
					"palegreen", -- [3]
				},
				[144071] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[134158] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[122972] = {
					false, -- [1]
					false, -- [2]
					"lightsalmon", -- [3]
				},
				[165872] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[122973] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[136549] = {
					false, -- [1]
					false, -- [2]
					"lightcoral", -- [3]
				},
				[169893] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[135239] = {
					false, -- [1]
					false, -- [2]
					"paleturquoise", -- [3]
				},
				[170690] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[128967] = {
					false, -- [1]
					false, -- [2]
					"palegreen", -- [3]
				},
				[134701] = {
					false, -- [1]
					false, -- [2]
					"maroon", -- [3]
				},
				[133835] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[136295] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[104247] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134418] = {
					false, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[133430] = {
					false, -- [1]
					false, -- [2]
					"cornflowerblue", -- [3]
				},
				[104295] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134514] = {
					false, -- [1]
					false, -- [2]
					"lightgreen", -- [3]
				},
				[168420] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[195842] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[173016] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[59552] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[195265] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[76104] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[136934] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[130435] = {
					false, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[192333] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134990] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[174802] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[135365] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[164921] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[136353] = {
					false, -- [1]
					false, -- [2]
					"royalblue", -- [3]
				},
				[138465] = {
					false, -- [1]
					false, -- [2]
					"lightcoral", -- [3]
				},
				[174197] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[196102] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[96664] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[191847] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[129366] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[139422] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[136139] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[188067] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[137478] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[133685] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[131677] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[126928] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[95834] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[196798] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[131858] = {
					false, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[127757] = {
					false, -- [1]
					false, -- [2]
					"lightcoral", -- [3]
				},
				[165529] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[137511] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[194315] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[137830] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[129367] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[131586] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[196576] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[163458] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[167956] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[133432] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[194317] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[128969] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[163618] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[139425] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[168418] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[163459] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[129559] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[131666] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[160495] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[168942] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[137484] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[130404] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[133593] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[131585] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[153292] = {
					false, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[135474] = {
					false, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[131587] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[168594] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[197535] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[75979] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[163126] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[59545] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[195878] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[170572] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134232] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[137103] = {
					false, -- [1]
					false, -- [2]
					"lightsalmon", -- [3]
				},
				[129369] = {
					false, -- [1]
					false, -- [2]
					"lightsalmon", -- [3]
				},
				[196548] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[127106] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[134137] = {
					false, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[166299] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[137516] = {
					false, -- [1]
					false, -- [2]
					"lightsalmon", -- [3]
				},
				[130485] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[138187] = {
					false, -- [1]
					false, -- [2]
					"paleturquoise", -- [3]
				},
				[131492] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[133852] = {
					false, -- [1]
					false, -- [2]
					"olivedrab", -- [3]
				},
				[129529] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[104300] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[137486] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[168627] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[165919] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[136470] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[129370] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[130661] = {
					false, -- [1]
					false, -- [2]
					"lightgreen", -- [3]
				},
				[190207] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134139] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[171656] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[169875] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[131685] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[129227] = {
					false, -- [1]
					false, -- [2]
					"maroon", -- [3]
				},
				[191164] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134331] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[125977] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[59546] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[166302] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[194894] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[138061] = {
					false, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[127315] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[136214] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[193462] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134364] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[105704] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[126918] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[194895] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134150] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[168058] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[138255] = {
					false, -- [1]
					false, -- [2]
					"maroon", -- [3]
				},
				[104270] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[133345] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[129547] = {
					false, -- [1]
					false, -- [2]
					"olivedrab", -- [3]
				},
				[134174] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[137521] = {
					false, -- [1]
					false, -- [2]
					"cornflowerblue", -- [3]
				},
				[138063] = {
					false, -- [1]
					false, -- [2]
					"blue", -- [3]
				},
				[172265] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[163882] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[196044] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[130488] = {
					false, -- [1]
					false, -- [2]
					"lightsalmon", -- [3]
				},
				[137713] = {
					false, -- [1]
					false, -- [2]
					"paleturquoise", -- [3]
				},
				[174210] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[164552] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[138064] = {
					false, -- [1]
					false, -- [2]
					"blue", -- [3]
				},
				[165222] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[167963] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[196045] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[131817] = {
					false, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[134144] = {
					false, -- [1]
					false, -- [2]
					"lightgreen", -- [3]
				},
				[59555] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[165076] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[195696] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[126919] = {
					false, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[165414] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[200126] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[131818] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[141285] = {
					false, -- [1]
					false, -- [2]
					"lightgreen", -- [3]
				},
				[192796] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[136249] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[131436] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[168443] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[167965] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[137716] = {
					false, -- [1]
					false, -- [2]
					"blue", -- [3]
				},
				[129788] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[166276] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[163503] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[168572] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[135007] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[187602] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[163121] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134338] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[187155] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[135167] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[132491] = {
					false, -- [1]
					false, -- [2]
					"palegreen", -- [3]
				},
				[128434] = {
					false, -- [1]
					false, -- [2]
					"palegreen", -- [3]
				},
				[135263] = {
					false, -- [1]
					false, -- [2]
					"maroon", -- [3]
				},
				[76446] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[167967] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[75713] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[166275] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[168318] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134417] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[97197] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[162039] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[122984] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[139949] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[95842] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[186741] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[127111] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[136186] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[128435] = {
					false, -- [1]
					false, -- [2]
					"aqua", -- [3]
				},
				[162040] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[141284] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[135329] = {
					false, -- [1]
					false, -- [2]
					"plum", -- [3]
				},
				[75459] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[141283] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[192800] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[135258] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[168886] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[122969] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[196115] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[195851] = {
					false, -- [1]
					false, -- [2]
					"white", -- [3]
				},
				[194896] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134629] = {
					false, -- [1]
					false, -- [2]
					"navajowhite", -- [3]
				},
				[134012] = {
					false, -- [1]
					false, -- [2]
					"lightsalmon", -- [3]
				},
				[197985] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[135235] = {
					false, -- [1]
					false, -- [2]
					"goldenrod", -- [3]
				},
				[133482] = {
					false, -- [1]
					false, -- [2]
					"maroon", -- [3]
				},
				[137517] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[163891] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[167493] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[198047] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[133436] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[135204] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[167111] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[129600] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[170490] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[168992] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134599] = {
					false, -- [1]
					false, -- [2]
					"lightskyblue", -- [3]
				},
				[133912] = {
					false, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[168578] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[130436] = {
					false, -- [1]
					false, -- [2]
					"aqua", -- [3]
				},
				[195927] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[162057] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[167876] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[163128] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[134600] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[132126] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[194316] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[193293] = {
					false, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[195928] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[122971] = {
					false, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[136076] = {
					false, -- [1]
					false, -- [2]
					"lightcoral", -- [3]
				},
				[171799] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[105715] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[170882] = {
					true, -- [1]
					false, -- [2]
					"magenta", -- [3]
				},
				[197905] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[168357] = {
					true, -- [1]
					false, -- [2]
					"fuchsia", -- [3]
				},
				[195929] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[134251] = {
					false, -- [1]
					false, -- [2]
					"honeydew", -- [3]
				},
				[135241] = {
					false, -- [1]
					false, -- [2]
					"peru", -- [3]
				},
				[195930] = {
					true, -- [1]
					false, -- [2]
					"dodgerblue", -- [3]
				},
				[131670] = {
					false, -- [1]
					false, -- [2]
					"palegreen", -- [3]
				},
			},
			["cast_statusbar_spark_half"] = true,
			["hook_data"] = {
				{
					["OptionsValues"] = {
					},
					["LastHookEdited"] = "",
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    --list of npcs and their colors, can be inserted:\n    --name of the unit\n    --name of the unit in lower case\n    --npcID of the unit\n    \n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    \n    modTable.changeBarColor = modTable.config.changeBarColor\n    modTable.changeBorderColor = modTable.config.changeBorderColor\n    modTable.resetColors = modTable.config.resetColors\n    \n    modTable.ListOfNpcs = {\n        [61146] = modTable.config.color, --\"olive\", --monk statue npcID\n        [103822] = modTable.config.color, --\"olive\", --druid treant npcID\n        [15352] = modTable.config.color, --\"olive\", --shaman elemental\n        [95072] = modTable.config.color, --\"olive\", --shaman greater earth elemental npcID\n        [61056] = modTable.config.color, --\"olive\", --shaman primal earth elemental npcID\n        \n    }\nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable, modTable)\n    if not unitId then\n        return\n    end\n    --get the GUID of the target of the unit\n    local targetGUID = UnitGUID (unitId .. \"target\")\n    \n    if (targetGUID) then\n        \n        --get the npcID of the target\n        local npcID = Plater.GetNpcIDFromGUID (targetGUID)\n        local unitName = UnitName (unitId .. \"target\")\n        local unitNameLower = string.lower (unitName)\n        \n        --check if the npcID of this unit is in the npc list \n        local color = modTable.ListOfNpcs [npcID] or modTable.ListOfNpcs [unitName] or modTable.ListOfNpcs [unitNameLower]\n        \n        if color then\n            if modTable.changeBarColor then\n                Plater.SetNameplateColor (unitFrame, color)\n            end\n            if modTable.changeBorderColor then\n                Plater.SetBorderColor (unitFrame, color)\n            end\n            unitFrame.attackingSpecificUnitFromMod = true\n        elseif unitFrame.attackingSpecificUnitFromMod and modTable.resetColors then\n            if modTable.changeBorderColor then\n                Plater.SetBorderColor (unitFrame)\n            end\n            if modTable.changeBarColor then\n                Plater.RefreshNameplateColor (unitFrame)\n            end\n            unitFrame.attackingSpecificUnitFromMod = false\n        end\n    end\nend",
					},
					["Time"] = 1620377377,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_attacking_unit",
					["Enabled"] = false,
					["Revision"] = 363,
					["semver"] = "",
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Change the nameplate color if the unit is attacking a specific unit like Monk's Ox Statue or Druid's Treants. You may edit which units it track in the constructor script.",
					["Name"] = "Attacking Specific Unit [Plater]",
					["PlaterCore"] = 1,
					["version"] = -1,
					["HooksTemp"] = {
					},
					["Options"] = {
						{
							["Type"] = 1,
							["Key"] = "color",
							["Value"] = {
								0.5019607843137255, -- [1]
								0.5019607843137255, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 4,
							["Key"] = "changeBarColor",
							["Value"] = true,
							["Name"] = "Change Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "changeBorderColor",
							["Value"] = false,
							["Name"] = "Change Border Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "resetColors",
							["Value"] = true,
							["Name"] = "Reset Colors",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
					},
				}, -- [1]
				{
					["Enabled"] = false,
					["Revision"] = 95,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Options"] = {
					},
					["Desc"] = "Hide neutral units, show when selected, see the constructor script for options.",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat) then\n            envTable.HideNameplate (unitFrame)\n        end\n    end\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end\n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat and InCombatLockdown()) then\n            return\n        end\n        \n        envTable.HideNameplate (unitFrame)\n    end\n    \nend\n\n\n\n\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat and InCombatLockdown()) then\n            return\n        end\n        \n        --check the unit reaction\n        if (unitFrame.namePlateIsTarget) then\n            envTable.ShowNameplate (unitFrame)\n            \n        else\n            envTable.HideNameplate (unitFrame)\n            \n        end    \n    end\n    \nend\n\n\n\n\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        envTable.ShowNameplate (unitFrame)\n    end\n    \nend\n\n\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when plater finishes an update on the nameplate\n    --check within the envTable if the healthBar of this nameplate should be hidden\n    if (envTable.IsHidden) then\n        if (unitFrame.healthBar:IsShown()) then\n            envTable.HideNameplate (unitFrame)\n        end\n    end\n    \nend\n\n\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateUnitReaction == envTable.REACTION_NEUTRAL) then\n        \n        --plater already handle this\n        if (unitFrame.PlayerCannotAttack) then\n            return\n        end    \n        \n        --check if is only open world\n        if (envTable.OnlyInOpenWorld and Plater.ZoneInstanceType ~= \"none\") then\n            return \n        end\n        \n        --check for only in combat\n        if (envTable.ShowInCombat) then\n            envTable.ShowNameplate (unitFrame)\n        end\n    end\nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.OnlyInOpenWorld = true;\n    envTable.ShowInCombat = true;\n    \n    --consts\n    envTable.REACTION_NEUTRAL = 4;\n    \n    --functions to hide and show the healthBar\n    function envTable.HideNameplate (unitFrame)\n        Plater.HideHealthBar (unitFrame)\n        Plater.DisableHighlight (unitFrame)\n        envTable.IsHidden = true\n    end\n    \n    function envTable.ShowNameplate (unitFrame)\n        Plater.ShowHealthBar (unitFrame)\n        Plater.EnableHighlight (unitFrame)\n        envTable.IsHidden = false\n    end\n    \nend\n\n\n\n\n",
					},
					["Name"] = "Hide Neutral Units [Plater]",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1553450458,
					["Icon"] = 1990989,
					["LastHookEdited"] = "Constructor",
				}, -- [2]
				{
					["Enabled"] = false,
					["Revision"] = 185,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Options"] = {
					},
					["Desc"] = "Show how many raid members are targeting the unit",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    envTable.CanShow = false;\n    envTable.TargetAmount:SetText (\"\")\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when a nameplate is added to the screen check if the player is in combat\n    if (InCombatLockdown()) then\n        --player is in combat, check if can check amount of targets\n        envTable.CanShow = envTable.CanShowTargetAmount();\n        \n    else\n        envTable.CanShow = false; \n    end\n    \n    envTable.TargetAmount:SetText (\"\");\n    \nend",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.TargetAmount:SetText (\"\");\n    envTable.CanShow = false;\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --if the script is allowed to show the amount of targets\n    --also check if the unit is in combat\n    if (envTable.CanShow and UnitAffectingCombat (unitId)) then\n        \n        --check if can update the amount of targets following the cooldown set in the constructor script\n        --by default Plater updates the nameplate every 250ms, by default the cooldown is 2, so it'll update the amuont of target every 1/2 of a second\n        envTable.UpdateCooldown = envTable.UpdateCooldown + 1\n        if (envTable.UpdateCooldown < envTable.UpdateInterval) then\n            return\n        else\n            \n            --reset the cooldown interval to check the amount of target again\n            envTable.UpdateCooldown = 0\n            \n            --get the amount of targets\n            local amount;\n            if (envTable.InRaid) then\n                amount = envTable.NumTargetsInRaid (unitFrame)      \n                \n            elseif (envTable.InParty) then\n                amount = envTable.NumTargetsInParty (unitFrame)   \n                \n            else\n                envTable.TargetAmount:SetText (\"\")\n                return\n            end\n            \n            --update the amount text\n            if (amount == 0) then\n                envTable.TargetAmount:SetText (\"\")\n            else\n                envTable.TargetAmount:SetText (amount)\n            end\n            \n        end\n    end\nend\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if can show the amount of targets\n    envTable.CanShow = envTable.CanShowTargetAmount();\n    \n    if (not envTable.CanShow) then\n        envTable.TargetAmount:SetText (\"\") \n    end\nend\n\n\n\n\n",
						["Constructor"] = "--all gray text like this are comments and do not run as code\n--build the settings and basic functions for the hook\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --declare setting variables:\n    local textColor = \"orange\";\n    local textSize = 12;\n    \n    local showInRaid = true;\n    local showInDungeon = true;\n    local showInArena = false;\n    local showInBattleground = false;\n    local showInOpenWorld = true;\n    \n    envTable.UpdateInterval = 2; --each 2 updates in the nameplate it'll update the amount of targets\n    \n    local anchor = {\n        side = 6, --1 = topleft 2 = left 3 = bottomleft 4 = bottom 5 = bottom right 6 = right 7 = topright 8 = top\n        x = 4, --x offset\n        y = 0, --y offset\n    };\n    \n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------\n    \n    \n    --frames:\n    \n    --create the text that will show the amount of people targeting the unit\n    if (not  unitFrame.healthBar.TargetAmount) then\n        envTable.TargetAmount = Plater:CreateLabel (unitFrame.healthBar, \"\", textSize, textColor);\n        Plater.SetAnchor (envTable.TargetAmount, anchor);\n        unitFrame.healthBar.TargetAmount = envTable.TargetAmount\n    end\n    \n    --in case Plater wipes the envTable\n    envTable.TargetAmount = unitFrame.healthBar.TargetAmount\n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------           \n    --private variables (they will be used in the other scripts within this hook)\n    envTable.CanShow = false;\n    envTable.UpdateCooldown = 0;\n    envTable.InRaid = false;\n    envTable.InParty = false;\n    \n    ---------------------------------------------------------------------------------------------------------------------------------------------           \n    --functions\n    \n    --update the InRaid or InParty proprieties\n    function envTable.UpdateGroupType()\n        if (IsInRaid()) then\n            envTable.InRaid = true;\n            envTable.InParty = false;     \n            \n        elseif (IsInGroup()) then\n            envTable.InRaid = false;\n            envTable.InParty = true;   \n            \n        else\n            envTable.InRaid = false;            \n            envTable.InParty = false;\n        end\n    end\n    \n    --this function controls if the amount of targets can show following the settings in the top of this script\n    function envTable.CanShowTargetAmount()\n        \n        local _, instanceType, difficultyID, _, _, _, _, instanceMapID, instanceGroupSize = GetInstanceInfo()\n        \n        if (showInRaid and instanceType == \"raid\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInDungeon and instanceType == \"party\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInArena and instanceType == \"arena\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInBattleground and instanceType == \"pvp\") then\n            envTable.UpdateGroupType()\n            return true\n        end\n        \n        if (showInOpenWorld and instanceType == \"none\") then\n            envTable.UpdateGroupType()\n            if (envTable.InRaid or envTable.InParty) then\n                return true\n            end\n        end\n        \n        return false\n    end\n    \n    --get the amount of player targetting the unit in raid or party\n    function envTable.NumTargetsInRaid (unitFrame)\n        local amount = 0\n        for i = 1, GetNumGroupMembers() do\n            local unit = \"raid\" .. i .. \"target\"\n            if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n                amount = amount + 1\n            end\n        end\n        \n        return amount\n    end\n    \n    function envTable.NumTargetsInParty()\n        local amount = 0\n        for i = 1, GetNumGroupMembers() - 1 do\n            local unit = \"party\" .. i .. \"target\"\n            if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n                amount = amount + 1\n            end\n        end\n        \n        local unit = \"playertarget\"\n        if (UnitGUID (unit) == unitFrame.namePlateUnitGUID) then\n            amount = amount + 1\n        end        \n        \n        return amount\n    end\n    \nend",
					},
					["Name"] = "Players Targeting a Target [Plater]",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551825362,
					["Icon"] = 1966587,
					["LastHookEdited"] = "Constructor",
				}, -- [3]
				{
					["Enabled"] = false,
					["Revision"] = 94,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Options"] = {
					},
					["Desc"] = "Changes the target color to the color set in the constructor script.",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateColor (unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --usage: color name e.g \"red\" \"yellow\"; color table e.g {1, 0, 0} {1, 1, 0}; hex string e.g. \"#FF0000\" \"FFFF00\"\n    \n    envTable.TargetColor = \"purple\"\n    --envTable.TargetColor = \"#FF00FF\"\n    --envTable.TargetColor = {252/255, 0/255, 254/255}\n    \n    function envTable.UpdateColor (unitFrame)\n        --do not change the color of the personal bar\n        if (not unitFrame.IsSelf) then\n            \n            --if this nameplate the current target of the player?\n            if (unitFrame.namePlateIsTarget) then\n                Plater.SetNameplateColor (unitFrame, envTable.TargetColor)  --rgb\n            else\n                --refresh the nameplate color\n                Plater.RefreshNameplateColor (unitFrame)\n            end\n        end\n    end\n    \nend\n\n\n\n\n",
					},
					["Prio"] = 99,
					["Time"] = 1613211428,
					["PlaterCore"] = 1,
					["LastHookEdited"] = "",
					["Name"] = "Current Target Color [Plater]",
					["Icon"] = 878211,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [4]
				{
					["OptionsValues"] = {
					},
					["LastHookEdited"] = "",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --run constructor!\n    --constructor is executed only once when any script of the hook runs.\n    \nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if need update the amount of combo points shown\n    if (envTable.LastPlayerTalentUpdate > envTable.LastUpdate) then\n        envTable.UpdateComboPointAmount()\n    end    \n    \n    if (unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.ComboPointFrame:Show()\n        envTable.UpdateComboPoints()\n        \n    else\n        envTable.ComboPointFrame:Hide()\n    end    \n    \nend\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if this nameplate is the current target\n    if (unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.ComboPointFrame:Show()\n        envTable.UpdateComboPoints()\n    else\n        envTable.ComboPointFrame:Hide()\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Player Power Update"] = "function (self, unitId, unitFrame, envTable, modTable, ...)\n    local powerType = ...\n    \n    if (powerType and powerType == \"COMBO_POINTS\" and unitFrame.namePlateIsTarget and not unitFrame.IsSelf) then\n        envTable.UpdateComboPoints()\n    end\n    \n    \nend",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.ComboPointFrame:Hide()\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.ComboPointFrame:Hide()\n    \nend\n\n\n\n\n",
						["Player Talent Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    --update the amount of comboo points shown when the player changes talents or specialization\n    envTable.UpdateComboPointAmount()\n    \n    --save the time of the last talent change\n    envTable.LastPlayerTalentUpdate = GetTime()\n    \n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    --settings\n    local anchors = {\n        {\"bottom\", unitFrame.healthBar, \"top\", 0, 24},\n    }\n    \n    local sizes = {\n        width = 12,\n        height = 12,\n        scale = 1,\n    }\n    \n    local textures = {\n        backgroundTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n        backgroundTexCoords = {0/128, 21/128, 101/128, 122/128},\n        \n        comboPointTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n        comboPointTexCoords = {3/128, 18/128, 81/128, 96/128},\n    }\n    if WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE then\n        textures = {\n            backgroundTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n            backgroundTexCoords = {78/128, 98/128, 21/64, 41/64},\n            \n            comboPointTexture = [[Interface\\PLAYERFRAME\\ClassOverlayComboPoints]],\n            comboPointTexCoords = {100/128, 120/128, 21/64, 41/64},\n        }\n    end\n    \n    local frameLevel = 1000\n    local frameStrata = \"high\"    \n    \n    --private\n    do\n        --store combo points frames on this table\n        envTable.ComboPoints = {}\n        --save when the player changed talents or spec\n        envTable.LastPlayerTalentUpdate = GetTime()\n        --save when this nameplate got a combo point amount and alignment update        \n        \n        --build combo points frame anchor (combo point are anchored to this)\n        if (not unitFrame.PlaterComboPointFrame) then\n            local hostFrame = CreateFrame (\"frame\", nil, unitFrame)\n            hostFrame.ComboPointFramesPool = {}\n            unitFrame.PlaterComboPointFrame = hostFrame\n            envTable.ComboPointFrame = hostFrame\n            envTable.ComboPointFrame:SetScale (sizes.scale)\n            \n            --DetailsFramework:ApplyStandardBackdrop (envTable.ComboPointFrame) --debug anchor size\n            \n            --animations\n            local onPlayShowAnimation = function (animation)\n                --stop the hide animation if it's playing\n                if (animation:GetParent():GetParent().HideAnimation:IsPlaying()) then\n                    animation:GetParent():GetParent().HideAnimation:Stop()\n                end\n                \n                animation:GetParent():Show()\n            end\n            \n            local onPlayHideAnimation = function (animation)\n                --stop the show animation if it's playing\n                if (animation:GetParent():GetParent().ShowAnimation:IsPlaying()) then\n                    animation:GetParent():GetParent().ShowAnimation:Stop()\n                end\n            end        \n            local onStopHideAnimation = function (animation)\n                animation:GetParent():Hide()       \n            end\n            \n            local createAnimations = function (comboPoint)\n                --on show\n                comboPoint.ShowAnimation = Plater:CreateAnimationHub (comboPoint.comboPointTexture, onPlayShowAnimation, nil)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"scale\", 1, 0.1, 0, 0, 1, 1)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"alpha\", 1, 0.1, .5, 1)\n                Plater:CreateAnimation (comboPoint.ShowAnimation, \"scale\", 2, 0.1, 1.2, 1.2, 1, 1)\n                \n                --on hide\n                comboPoint.HideAnimation = Plater:CreateAnimationHub (comboPoint.comboPointTexture, onPlayHideAnimation, onStopHideAnimation)\n                Plater:CreateAnimation (comboPoint.HideAnimation, \"scale\", 1, 0.1, 1, 1, 0, 0)\n                Plater:CreateAnimation (comboPoint.HideAnimation, \"alpha\", 1, 0.1, 1, 0)\n            end\n            \n            --build combo point frame        \n            for i =1, 10 do \n                local f = CreateFrame (\"frame\", nil, envTable.ComboPointFrame)\n                f:SetSize (sizes.width, sizes.height)\n                tinsert (envTable.ComboPoints, f)\n                tinsert (unitFrame.PlaterComboPointFrame.ComboPointFramesPool, f)\n                \n                local backgroundTexture = f:CreateTexture (nil, \"background\")\n                backgroundTexture:SetTexture (textures.backgroundTexture)\n                backgroundTexture:SetTexCoord (unpack (textures.backgroundTexCoords))\n                backgroundTexture:SetSize (sizes.width, sizes.height)\n                backgroundTexture:SetPoint (\"center\")\n                \n                local comboPointTexture = f:CreateTexture (nil, \"artwork\")\n                comboPointTexture:SetTexture (textures.comboPointTexture)\n                comboPointTexture:SetTexCoord (unpack (textures.comboPointTexCoords))\n                \n                comboPointTexture:SetSize (sizes.width, sizes.height)\n                comboPointTexture:SetPoint (\"center\")\n                comboPointTexture:Hide()            \n                \n                f.IsActive = false\n                \n                f.backgroundTexture = backgroundTexture\n                f.comboPointTexture = comboPointTexture\n                \n                createAnimations (f)\n            end\n            \n        else\n            envTable.ComboPointFrame = unitFrame.PlaterComboPointFrame\n            envTable.ComboPointFrame:SetScale (sizes.scale)\n            envTable.ComboPoints = unitFrame.PlaterComboPointFrame.ComboPointFramesPool\n            \n        end            \n        \n        envTable.ComboPointFrame:SetFrameLevel (frameLevel)\n        envTable.ComboPointFrame:SetFrameStrata (frameStrata)\n        \n        function envTable.UpdateComboPoints()\n            local comboPoints = GetComboPoints(\"player\", \"target\")\n            --UnitPower (\"player\", Enum.PowerType.ComboPoints)\n            \n            for i = 1, envTable.TotalComboPoints do\n                local thisComboPoint = envTable.ComboPoints [i]\n                \n                if (i <= comboPoints ) then\n                    --combo point enabled\n                    if (not thisComboPoint.IsActive) then\n                        thisComboPoint.ShowAnimation:Play()\n                        thisComboPoint.IsActive = true\n                        \n                    end\n                    \n                else\n                    --combo point disabled\n                    if (thisComboPoint.IsActive) then\n                        thisComboPoint.HideAnimation:Play()\n                        thisComboPoint.IsActive = false\n                        \n                    end\n                end\n            end\n            \n            \n        end\n        \n        function envTable.UpdateComboPointAmount()\n            local namePlateWidth = Plater.db.profile.plate_config.enemynpc.health_incombat[1]\n            local comboPoints = UnitPowerMax (\"player\", Enum.PowerType.ComboPoints)\n            local reservedSpace = (namePlateWidth - sizes.width * comboPoints)  / comboPoints \n            \n            --store the total amount of combo points\n            envTable.TotalComboPoints = comboPoints\n            \n            --update anchor frame\n            envTable.ComboPointFrame:SetWidth (namePlateWidth)\n            envTable.ComboPointFrame:SetHeight (20)\n            envTable.ComboPointFrame:ClearAllPoints()\n            for i = 1, #anchors do\n                local anchor = anchors[i]\n                envTable.ComboPointFrame:SetPoint (unpack (anchor))\n            end        \n            \n            --\n            for i = 1, #envTable.ComboPoints do\n                envTable.ComboPoints[i]:Hide()\n                envTable.ComboPoints[i]:ClearAllPoints()\n            end\n            \n            for i = 1, comboPoints do\n                local comboPoint = envTable.ComboPoints[i]\n                if i == 1 then\n                    comboPoint:SetPoint (\"left\", envTable.ComboPointFrame, \"left\", reservedSpace/2, 0)\n                else\n                    comboPoint:SetPoint (\"left\", envTable.ComboPoints[i-1], \"right\", reservedSpace, 0)\n                end\n                \n                comboPoint:Show()\n            end\n            \n            envTable.LastUpdate = GetTime()\n            \n            envTable.UpdateComboPoints()\n        end\n        \n        --initialize\n        envTable.UpdateComboPointAmount()\n        envTable.ComboPointFrame:Hide()\n    end\n    \n    \nend",
					},
					["Time"] = 1621935143,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
							["Enabled"] = true,
							["DRUID"] = true,
							["ROGUE"] = true,
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
							["103"] = true,
							["Enabled"] = true,
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["affix"] = {
						},
					},
					["url"] = "",
					["Icon"] = 135426,
					["Enabled"] = false,
					["Revision"] = 284,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Show combo points above the nameplate for Druid Feral and Rogues.",
					["Name"] = "Combo Points [Plater]",
					["PlaterCore"] = 1,
					["version"] = -1,
					["HooksTemp"] = {
					},
					["Options"] = {
					},
				}, -- [5]
				{
					["Enabled"] = false,
					["Revision"] = 197,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Tecno-Azralon",
					["Options"] = {
					},
					["Desc"] = "Add another border with more customizations. This border can also be manipulated by other scripts.",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --run constructor!\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    if (envTable.IsEnabled and unitFrame.ActorType == \"enemyplayer\") then\n        \n        if (unitFrame.IsSelf) then\n            if (envTable.ShowOnPersonalBar) then\n                envTable.BorderFrame:Show()\n            else\n                envTable.BorderFrame:Hide() \n            end\n        else\n            envTable.BorderFrame:Show()\n        end   \n        \n    else\n        envTable.BorderFrame:Hide() \n    end\n    \nend   \n\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BorderFrame:Hide()\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BorderFrame:Hide()\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --border color\n    local borderColor = \"yellow\"\n    \n    --size of the border\n    local borderSize = 1\n    \n    --transparency\n    local borderAlpha = 1\n    \n    --enabled (set to false it you only want to use the extra border in other scripts)\n    local isEnabled = true\n    \n    --export border (allow the border to be used by other scripts)\n    --other scripts can use:\n    --unitFrame.healthBar.extraBorder:Show()\n    --unitFrame.healthBar.extraBorder:SetVertexColor (r, g, b)\n    --unitFrame.healthBar.extraBorder:SetBorderSizes (borderSize)\n    local canExportBorder = true\n    \n    --do not add the border to personal bar\n    local noPersonalBar = true\n    \n    --private\n    do\n        \n        local newBorder = CreateFrame (\"frame\", nil, unitFrame.healthBar, \"NamePlateFullBorderTemplate\")\n        envTable.BorderFrame = newBorder\n        \n        newBorder:SetBorderSizes (borderSize, borderSize, borderSize, borderSize)\n        newBorder:UpdateSizes()\n        \n        local r, g, b = DetailsFramework:ParseColors (borderColor)\n        newBorder:SetVertexColor (r, g, b, borderAlpha)\n        \n        envTable.ShowOnPersonalBar = not noPersonalBar\n        \n        if (canExportBorder) then\n            unitFrame.healthBar.extraBorder = newBorder\n        end\n        \n        if (not isEnabled) then\n            envTable.IsEnabled = false\n        else\n            envTable.IsEnabled = true\n        end\n    end\n    \nend\n\n\n",
					},
					["Prio"] = 99,
					["Time"] = 1613211728,
					["PlaterCore"] = 1,
					["LastHookEdited"] = "",
					["Name"] = "Extra Border [Plater]",
					["Icon"] = 133689,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [6]
				{
					["OptionsValues"] = {
					},
					["LastHookEdited"] = "",
					["Hooks"] = {
						["Nameplate Added"] = "\n\n-- exported function Plater.UpdatePlateSize() from Plater.lua\n--this is for advanced users which wants to reorder the nameplate frame at their desire\n\n\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --check if there's a type of unit on this nameplate\n    local plateFrame = unitFrame:GetParent()\n    if (not plateFrame.actorType) then\n        return\n    end\n    \n    --get all the frames and cache some variables\n    local ACTORTYPE_ENEMY_PLAYER = \"enemyplayer\"\n    local profile = Plater.db.profile\n    local DB_PLATE_CONFIG = profile.plate_config\n    local isInCombat = Plater.IsInCombat()\n    local actorType = plateFrame.actorType\n    \n    local unitFrame = plateFrame.unitFrame\n    local healthBar = unitFrame.healthBar\n    local castBar = unitFrame.castBar\n    local powerBar = unitFrame.powerBar\n    local buffFrame1 = unitFrame.BuffFrame\n    local buffFrame2 = unitFrame.BuffFrame2\n    \n    --use in combat bars when in pvp\n    if (plateFrame.actorType == ACTORTYPE_ENEMY_PLAYER) then\n        if ((Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"arena\") and DB_PLATE_CONFIG.player.pvp_always_incombat) then\n            isInCombat = true\n        end\n    end\n    \n    --get the config for this actor type\n    local plateConfigs = DB_PLATE_CONFIG [actorType]\n    --get the config key based if the player is in combat\n    local castBarConfigKey, healthBarConfigKey, manaConfigKey = Plater.GetHashKey (isInCombat)\n    \n    --get the width and height from what the user set in the options panel\n    local healthBarWidth, healthBarHeight = unitFrame.customHealthBarWidth or plateConfigs [healthBarConfigKey][1], unitFrame.customHealthBarHeight or plateConfigs [healthBarConfigKey][2]\n    local castBarWidth, castBarHeight = unitFrame.customCastBarWidth or plateConfigs [castBarConfigKey][1], unitFrame.customCastBarHeight or plateConfigs [castBarConfigKey][2]\n    local powerBarWidth, powerBarHeight = unitFrame.customPowerBarHeight or plateConfigs [manaConfigKey][1], unitFrame.customPowerBarHeight or plateConfigs [manaConfigKey][2]\n    \n    --calculate the offset for the cast bar, this is done due to the cast bar be anchored to topleft and topright\n    local castBarOffSetX = (healthBarWidth - castBarWidth) / 2\n    local castBarOffSetY = plateConfigs.castbar_offset\n    \n    --calculate offsets for the power bar\n    local powerBarOffSetX = (healthBarWidth - powerBarWidth) / 2\n    local powerBarOffSetY = 0\n    \n    --calculate the size deviation for pets\n    local unitType = Plater.GetUnitType (plateFrame)\n    if (unitType == \"pet\") then\n        healthBarHeight = healthBarHeight * Plater.db.profile.pet_height_scale\n        healthBarWidth = healthBarWidth * Plater.db.profile.pet_width_scale\n        \n    elseif (unitType == \"minus\") then\n        healthBarHeight = healthBarHeight * Plater.db.profile.minor_height_scale\n        healthBarWidth = healthBarWidth * Plater.db.profile.minor_width_scale\n    end\n    \n    --unit frame - is set to be the same size as the plateFrame\n    unitFrame:ClearAllPoints()\n    unitFrame:SetAllPoints()\n    \n    --calculates the health bar anchor points\n    --it will always be placed in the center of the nameplate area (where it accepts mouse clicks) \n    local xOffSet = (plateFrame:GetWidth() - healthBarWidth) / 2\n    local yOffSet = (plateFrame:GetHeight() - healthBarHeight) / 2\n    \n    --set the health bar point\n    healthBar:ClearAllPoints()\n    PixelUtil.SetPoint (healthBar, \"topleft\", unitFrame, \"topleft\", xOffSet + profile.global_offset_x, -yOffSet + profile.global_offset_y)\n    PixelUtil.SetPoint (healthBar, \"bottomright\", unitFrame, \"bottomright\", -xOffSet + profile.global_offset_x, yOffSet + profile.global_offset_y)\n    \n    --set the cast bar point and size\n    castBar:ClearAllPoints()\n    PixelUtil.SetPoint (castBar, \"topleft\", healthBar, \"bottomleft\", castBarOffSetX, castBarOffSetY)\n    PixelUtil.SetPoint (castBar, \"topright\", healthBar, \"bottomright\", -castBarOffSetX, castBarOffSetY)\n    PixelUtil.SetHeight (castBar, castBarHeight)\n    PixelUtil.SetSize (castBar.Icon, castBarHeight, castBarHeight)\n    PixelUtil.SetSize (castBar.BorderShield, castBarHeight * 1.4, castBarHeight * 1.4)\n    \n    --set the power bar point and size\n    powerBar:ClearAllPoints()\n    PixelUtil.SetPoint (powerBar, \"topleft\", healthBar, \"bottomleft\", powerBarOffSetX, powerBarOffSetY)\n    PixelUtil.SetPoint (powerBar, \"topright\", healthBar, \"bottomright\", -powerBarOffSetX, powerBarOffSetY)\n    PixelUtil.SetHeight (powerBar, powerBarHeight)\n    \n    --power bar are hidden by default, show it if there's a custom size for it\n    if (unitFrame.customPowerBarWidth and unitFrame.customPowerBarHeight) then\n        powerBar:SetUnit (unitFrame.unit)\n    end\n    \n    --aura frames\n    local bf1Anchor = Plater.db.profile.aura_frame1_anchor\n    Plater.SetAnchor (buffFrame1, {side = bf1Anchor.side, x = bf1Anchor.x, y = bf1Anchor.y + plateConfigs.buff_frame_y_offset}, unitFrame.healthBar, (Plater.db.profile.aura_grow_direction or 2) == 2)\n    \n    local bf2Anchor = Plater.db.profile.aura_frame2_anchor\n    Plater.SetAnchor (buffFrame2, {side = bf2Anchor.side, x = bf2Anchor.x, y = bf2Anchor.y + plateConfigs.buff_frame_y_offset}, unitFrame.healthBar, (Plater.db.profile.aura2_grow_direction or 2) == 2)\n    \nend\n\n\n",
					},
					["Time"] = 1596791840,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = 574574,
					["Enabled"] = false,
					["Revision"] = 93,
					["semver"] = "",
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Function Plater.UpdatePlateSize from Plater.lua exported to scritps.",
					["version"] = -1,
					["PlaterCore"] = 1,
					["Name"] = "Reorder Nameplate [Plater]",
					["HooksTemp"] = {
					},
					["Options"] = {
					},
				}, -- [7]
				{
					["Enabled"] = false,
					["Revision"] = 107,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Kastfall-Azralon",
					["Options"] = {
					},
					["Desc"] = "Easy way to change the color of an unit. Open the constructor script and follow the examples.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --list of npcs and their colors, can be inserted:\n    --name of the unit\n    --name of the unit in lower case\n    --npcID of the unit\n    \n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    \n    envTable.NpcColors = {\n        \n        --examples, using the unit name in lower case, regular unit name and the unitID:\n        \n        [\"Thunderlord Windreader\"] = \"red\", --using regular mob name and color it as red\n        [\"thunderlord crag-leaper\"] = {1, 1, 0}, --using lower case and coloring it yellow\n        [75790] = \"#00FF00\", --using the ID of the unit and using green as color\n        \n        --insert the new mobs here:\n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n        \n    } --close custom color bracket\n    \nend\n\n\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --attempt to get the color from the unit color list\n    local color = envTable.NpcColors [unitFrame.namePlateUnitNameLower] or envTable.NpcColors [unitFrame.namePlateUnitName] or envTable.NpcColors [unitFrame.namePlateNpcId]\n    \n    --if the color exists, set the health bar color\n    if (color) then\n        Plater.SetNameplateColor (unitFrame, color)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Color Automation [Plater]",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551825317,
					["Icon"] = "Interface\\AddOns\\Plater\\images\\color_bar",
					["LastHookEdited"] = "Constructor",
				}, -- [8]
				{
					["Enabled"] = false,
					["Revision"] = 139,
					["HooksTemp"] = {
					},
					["Author"] = "Ahwa-Azralon",
					["Desc"] = "Adds extra effects to execute range and allow to setup two execute ranges for classes with execute when the unit has almost full healh. See the constructor script for options.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --execute detection, if true the script will handle the execute percent\n    --while false Plater will automatically trigger the execute range\n    --you only want to set this to true in case of Plater not detecting the execute range correctly\n    envTable.UseCustomExecutePercent = true\n    --execute percent, if not detecting automatic, this is the percent to active the execute range\n    --use from zero to one, 0.20 is equal to 20% of the unit life\n    envTable.ExecutePercent = 0.20\n    \n    --second execute range (UseCustomExecutePercent must be enabled)\n    envTable.SecondRangeStart = 0.999\n    envTable.SecondRangeEnd = 0.8\n    \n    --allow this script to change the nameplate color when the unit is in execute range\n    envTable.CanChangeColor = true\n    --change the health bar color to this color when the unit is in execute range\n    --color can be set as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}\n    envTable.ExecuteColor = \"green\"\n    \n    --border color\n    envTable.CanChangeBorderColor = false\n    envTable.BorderColor = \"red\"\n    \n    --hide the default health divisor and the health execute indicator\n    envTable.HideHealthDivisor = false\n    --if not hidden, adjust the health divisor settings and the health execute indicator\n    envTable.HealthDivisorAlpha = 0.5\n    envTable.HealthDivisorColor = \"white\"\n    envTable.HealthExecuteIndicatorAlpha = 0.15\n    envTable.HealthExecuteIndicatorColor = \"darkred\"\n    \n    \n    --private (internal functions)\n    do\n        function envTable.UnitInExecuteRange (unitFrame, divisorPercent)\n            --check if can change the execute color\n            if (envTable.CanChangeColor) then\n                Plater.SetNameplateColor (unitFrame, envTable.ExecuteColor)\n            end\n            \n            if (envTable.CanChangeBorderColor) then\n                Plater.SetBorderColor (unitFrame, envTable.BorderColor)\n            end\n            \n            if (envTable.HideHealthDivisor) then\n                unitFrame.healthBar.healthCutOff:Hide() \n                unitFrame.healthBar.executeRange:Hide()\n                \n            else\n                envTable.UpdateHealthDivisor (unitFrame, divisorPercent)\n                \n            end\n        end\n        \n        function envTable.UpdateHealthDivisor (unitFrame, divisorPercent)\n            local healthBar = unitFrame.healthBar\n            \n            healthBar.healthCutOff:Show()\n            healthBar.healthCutOff:SetVertexColor (DetailsFramework:ParseColors (envTable.HealthDivisorColor))\n            healthBar.healthCutOff:SetAlpha (envTable.HealthDivisorAlpha)\n            \n            healthBar.executeRange:Show()\n            healthBar.executeRange:SetVertexColor (DetailsFramework:ParseColors (envTable.HealthExecuteIndicatorColor))\n            healthBar.executeRange:SetAlpha (envTable.HealthExecuteIndicatorAlpha)\n            \n            if (envTable.UseCustomExecutePercent) then\n                healthBar.healthCutOff:ClearAllPoints()\n                healthBar.executeRange:ClearAllPoints()\n                \n                healthBar.healthCutOff:SetSize (healthBar:GetHeight(), healthBar:GetHeight())\n                healthBar.healthCutOff:SetPoint (\"center\", healthBar, \"left\", healthBar:GetWidth() * divisorPercent, 0)\n                \n                healthBar.executeRange:SetTexCoord (0, envTable.ExecutePercent, 0, 1)\n                healthBar.executeRange:SetHeight (healthBar:GetHeight())\n                healthBar.executeRange:SetPoint (\"left\", healthBar, \"left\", 0, 0)\n                healthBar.executeRange:SetPoint (\"right\", healthBar.healthCutOff, \"center\")\n            end\n            \n        end\n    end\n    \nend",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (envTable.UseCustomExecutePercent) then\n        \n        --manual detection\n        local healthBar = unitFrame.healthBar\n        local percent = healthBar.CurrentHealth / healthBar.CurrentHealthMax\n        \n        if (percent <= envTable.ExecutePercent) then\n            envTable.UnitInExecuteRange (unitFrame, envTable.ExecutePercent)\n            envTable.InExecuteRange = true\n            \n        elseif (percent < envTable.SecondRangeStart and percent >= envTable.SecondRangeEnd) then\n            envTable.UnitInExecuteRange (unitFrame, envTable.SecondRangeEnd)\n            envTable.InExecuteRange = true\n            \n        else\n            if (envTable.InExecuteRange) then\n                unitFrame.healthBar.healthCutOff:Hide() \n                unitFrame.healthBar.executeRange:Hide()\n                Plater.RefreshNameplateColor (unitFrame)\n                Plater.SetBorderColor (unitFrame)\n                envTable.InExecuteRange = false\n            end\n        end\n        \n    else\n        \n        --auto detection\n        if (unitFrame.InExecuteRange) then\n            envTable.UnitInExecuteRange (unitFrame, 0)\n        end\n        \n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Advanced Execute Range",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551825289,
					["Icon"] = 135358,
					["LastHookEdited"] = "Constructor",
				}, -- [9]
				{
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    \n    --ATTENTION: after enabling this mod, you may have to adjust the anchor point at the Buff Settings tab\n    \n    local sortByTime = false\n    local invertSort = false\n    \n    --which auras goes first, assign a value (any number), bigger value goes first\n    local priority = {\n        [\"Vampiric Touch\"] = 50,\n        [\"Shadow Word: Pain\"] = 22,\n        [\"Mind Flay\"] = 5,\n        [\"Pistol Shot\"] = 50,\n        [\"Marked for Death\"] = 99,\n    }\n    \n    -- Sort function - do not touch\n    Plater.db.profile.aura_sort = true\n    \n    \n    function Plater.AuraIconsSortFunction (aura1, aura2)\n        local p1 = priority[aura1.SpellId] or priority[aura1.SpellName] or 1\n        local p2 = priority[aura2.SpellId] or priority[aura2.SpellName] or 1\n        \n        if sortByTime and p1 == p2 then\n            if invertSort then\n                return (aura1.Duration == 0 and 99999999 or aura1.RemainingTime or 0) > (aura2.Duration == 0 and 99999999 or aura2.RemainingTime or 0)\n            else\n                return (aura1.Duration == 0 and 99999999 or aura1.RemainingTime or 0) < (aura2.Duration == 0 and 99999999 or aura2.RemainingTime or 0)\n            end\n        else\n            if invertSort then\n                 return p1 < p2\n            else\n                return p1 > p2\n            end\n        end\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Time"] = 1620348415,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura_reorder",
					["Enabled"] = true,
					["Revision"] = 359,
					["semver"] = "",
					["Author"] = "Ditador-Azralon",
					["Desc"] = "Reorder buffs and debuffs following the settings set in the constructor.",
					["Prio"] = 99,
					["version"] = -1,
					["PlaterCore"] = 1,
					["Name"] = "Aura Reorder [Plater]",
					["LastHookEdited"] = "",
					["Options"] = {
					},
				}, -- [10]
				{
					["Enabled"] = false,
					["Revision"] = 236,
					["HooksTemp"] = {
					},
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Script for the Jaina encounter on Battle for Dazzar'alor",
					["Hooks"] = {
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --Unexploded Ordinance\n    if (unitFrame.namePlateNpcId == envTable.NpcIDs.UnexplodedOrdinance) then\n        \n        --make the life percent be bigger than the regular size\n        --so it's better to see the health percent of the barrel\n        local currentSize = Plater.db.profile.plate_config.enemynpc.percent_text_size\n        Plater:SetFontSize (unitFrame.healthBar.lifePercent, currentSize + envTable.UnexplodedOrdinanceTextSizeIncrease)\n    end\n    \n    if (envTable.IncreaseSize [unitFrame.namePlateNpcId]) then\n        local currentHeight = unitFrame.healthBar:GetHeight()\n        Plater.SetNameplateSize (unitFrame, nil, currentHeight + envTable.IncreaseSize [unitFrame.namePlateNpcId])\n    end\n    \nend\n\n\n\n\n\n\n",
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    if (envTable.UnexplodedOrdinanceCast and envTable._SpellID == envTable.UnexplodedOrdinanceSpellID) then\n        Plater.SetCastBarSize (unitFrame, nil, envTable.UnexplodedOrdinanceCastBarHeight)\n        Plater:SetFontSize (unitFrame.castBar.percentText, envTable.UnexplodedOrdinanceTimerSize)\n    end\nend\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    \n    --reset the health percent text size\n    local currentSize = Plater.db.profile.plate_config.enemynpc.percent_text_size\n    Plater:SetFontSize (unitFrame.healthBar.lifePercent, currentSize)    \n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --Override the color\n    if (envTable.Colors [unitFrame.namePlateNpcId]) then\n        Plater.SetNameplateColor (unitFrame, envTable.Colors [unitFrame.namePlateNpcId])\n    end    \n    \n    --Show the name of the unit in the Ice Block nameplate\n    if (unitFrame.namePlateNpcId == envTable.NpcIDs.IceBlock) then\n        --find which player this block are holding\n        for i = 1, GetNumGroupMembers() do\n            local unit = \"raid\" .. i\n            if (UnitExists (unit)) then\n                for debuffId = 1, 40 do\n                    local name, texture, count, debuffType, duration, expirationTime, caster = UnitDebuff (unit, debuffId)\n                    \n                    --cancel the loop if there's no more debuffs on the player\n                    if (not name) then \n                        break \n                    end                    \n                    \n                    --check if who casted this debuff is the unit shown on this nameplate\n                    if (UnitIsUnit (caster or \"\", unitId)) then\n                        local unitName = UnitName (unit)\n                        \n                        --color the text by the class\n                        unitName = Plater.SetTextColorByClass (unit, unitName)\n                        \n                        --add the role icon\n                        if (Details) then\n                            local role = UnitGroupRolesAssigned (unit)\n                            unitName = Details:AddRoleIcon (unitName, role, 12)\n                        end\n                        \n                        unitFrame.unitName:SetText (unitName)\n                        unitFrame.castBar.Text:SetText (unitName)\n                        break\n                    end\n                    \n                end\n            else\n                break\n            end\n        end\n    end\nend",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --nameplate colors for unit\n    envTable.Colors = {}\n    envTable.Colors [148631] = \"orange\" --Unexploded Ordinance\n    envTable.Colors [148522] = \"white\" --Ice Block\n    \n    --increase the nameplate height for these units\n    envTable.IncreaseSize = {}\n    envTable.IncreaseSize [148522] = 4 --Ice Block (increase in 4 pixels)\n    \n    --increase the size of the life percent for the nameplate of the barrel\n    envTable.UnexplodedOrdinanceTextSizeIncrease = 3\n    \n    --increase the castbar size for the unexploded ordinance explosion cast\n    envTable.UnexplodedOrdinanceCast = true\n    envTable.UnexplodedOrdinanceSpellID = 288221 --12058 --(debug)\n    envTable.UnexplodedOrdinanceCastBarHeight = 18\n    envTable.UnexplodedOrdinanceTimerSize = 18\n    \n    --npcIDs\n    envTable.NpcIDs = {}\n    envTable.NpcIDs.UnexplodedOrdinance = 148631\n    envTable.NpcIDs.IceBlock = 148522\nend\n\n--tests 126023 --harbor saurid - dazar'alor harbor\n--tests 3127 venomtail scorpid - durotar\n--tests 12058 dustwind storm witch - durotar\n--Load Condition: EncounterID 2281\n\n\n",
						["Cast Stop"] = "function (self, unitId, unitFrame, envTable)\n    if (envTable.UnexplodedOrdinanceCast and envTable._SpellID == envTable.UnexplodedOrdinanceSpellID) then\n        Plater.SetCastBarSize (unitFrame)\n        Plater:SetFontSize (unitFrame.castBar.percentText, Plater.db.profile.plate_config.enemynpc.spellpercent_text_size)\n    end\nend\n\n\n",
					},
					["Name"] = "Jaina Encounter [Plater]",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
							["1"] = 2281,
							["Enabled"] = true,
						},
						["spec"] = {
						},
					},
					["Time"] = 1551894760,
					["Icon"] = "Interface\\AddOns\\Plater\\images\\encounter_jaina",
					["LastHookEdited"] = "Constructor",
				}, -- [11]
				{
					["Enabled"] = false,
					["Revision"] = 81,
					["HooksTemp"] = {
					},
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Script for Stormwall Blockade encounter on Battle for Dazzar'alor",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateNpcId == envTable.NpcIDs.TemptingSiren) then\n        \n        if (envTable.Colors.TemptingSiren) then\n            Plater.SetNameplateColor (unitFrame, envTable.Colors.TemptingSiren)\n        end\n        \n    end\n    \n    \nend\n\n\n\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.namePlateNpcId == envTable.NpcIDs.TemptingSiren) then\n        \n        if (envTable.NameplateHeight.TemptingSiren) then\n            \n            Plater.SetNameplateSize (unitFrame, nil, envTable.NameplateHeight.TemptingSiren)\n            \n        end\n        \n    end    \n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --nameplate colors for unit\n    envTable.Colors = {}\n    envTable.Colors.TemptingSiren = \"orange\"\n    \n    --npcID\n    envTable.NpcIDs = {}\n    envTable.NpcIDs.TemptingSiren = 146436\n    \n    --nameplate height for each unit\n    envTable.NameplateHeight = {}\n    envTable.NameplateHeight.TemptingSiren = 18\n    \n    \n    \nend\n\n\n",
					},
					["Name"] = "Stormwall Encounter [Plater]",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
							["1"] = 2280,
							["Enabled"] = true,
						},
						["spec"] = {
						},
					},
					["Time"] = 1551887545,
					["Icon"] = "Interface\\AddOns\\Plater\\images\\encounter_stormwall_blockade",
					["LastHookEdited"] = "Constructor",
				}, -- [12]
				{
					["Enabled"] = false,
					["Revision"] = 58,
					["HooksTemp"] = {
					},
					["Author"] = "Herith�gue-Proudmoore",
					["Desc"] = "Change the border of the focus target.",
					["Hooks"] = {
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateBorder (unitFrame, unitId)\nend\n\n\n",
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    envTable.UpdateBorder (unitFrame, unitId)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.BorderThickness = 3\n    envTable.BorderColor = \"black\"\n    \n    --private\n    function envTable.UpdateBorder (unitFrame, unit)\n        local plateFrame = unitFrame:GetParent()\n        \n        if (UnitIsUnit (\"focus\", unit)) then\n            Plater.SetBorderColor (unitFrame, envTable.BorderColor)\n            local borderSize = envTable.BorderThickness\n            unitFrame.healthBar.border:SetBorderSizes (borderSize, borderSize, borderSize, borderSize)\n            unitFrame.healthBar.border:UpdateSizes()        \n            \n        else\n            Plater.SetBorderColor (unitFrame)\n            Plater.UpdatePlateBorderThickness (unitFrame.PlateFrame)\n            unitFrame.healthBar.border:UpdateSizes()\n        end\n    end\nend\n\n\n\n",
					},
					["Name"] = "Focus Target Border",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1552962607,
					["Icon"] = 133006,
					["LastHookEdited"] = "Constructor",
				}, -- [13]
				{
					["Enabled"] = false,
					["Revision"] = 48,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["OptionsValues"] = {
					},
					["Desc"] = "Change the nameplate color when a nameplate does not have the auras set in the constructor script.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    --Important: lines starting with double dashes are comments and are not part of the script\n    \n    --if the unit does not have any of the following auras, it will be painted with the color listed below\n    --list of spells to track, can be the spell name (case-sensitive) or the spellID\n    envTable.TrackingAuras = {\n        --[\"Nightblade\"] = true, --this is an example using the spell name\n        --[195452] = true, --this is an example using the spellID\n        \n    }\n    \n    --which color the nameplate wil be changed\n    --color can be added as:\n    --color names: \"red\", \"yellow\"\n    --color hex: \"#FF0000\", \"#FFFF00\"\n    --color table: {1, 0, 0}, {1, 1, 0}    \n    --you may also use /plater colors\n    envTable.NameplateColor = \"pink\"\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --do nothing if the player isn't in combat\n    if (not Plater.IsInCombat()) then\n        return \n    end\n    \n    --do nothing if the unit isn't in combat\n    if (not unitFrame.InCombat) then\n        return\n    end\n    \n    --check the auras\n    local hasAura = false\n    \n    for auraName, _ in pairs (envTable.TrackingAuras) do\n        if (Plater.NameplateHasAura (unitFrame, auraName)) then\n            hasAura = true\n            break\n        end\n    end\n    \n    if (not hasAura) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    end    \n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Prio"] = 99,
					["Time"] = 1613211434,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Don't Have Aura [Plater]",
					["Icon"] = 136207,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [14]
				{
					["Enabled"] = false,
					["Revision"] = 55,
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Tint nameplates of Reaping Soul units (Mythic Dungeon Affix) depending on its target and role of the player",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --can detect the reaping souls aggro?\n    if (envTable.detectAggro and Plater.IsInCombat()) then\n        \n        --is this npc a reaping soul?\n        if (envTable.npcIDs [unitFrame.namePlateNpcId]) then\n            \n            --check if the mob is attacking the player\n            if (UnitIsUnit (unitFrame.targetUnitID, \"player\")) then\n                Plater.SetNameplateColor (unitFrame, envTable.NameplateAggroColor)\n                \n            else\n                Plater.SetNameplateColor (unitFrame, envTable.NameplateNoAggroColor)\n            end\n            \n        end\n        \n    end\n    \nend",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    --when the nameplate is added and the npcID matches, cache the color for the nameplate\n    if (envTable.detectAggro) then\n        if (envTable.npcIDs [unitFrame.namePlateNpcId]) then\n            local profile = Plater.db.profile\n            local role = Plater:GetPlayerRole()\n            \n            if (role == \"TANK\") then\n                envTable.NameplateAggroColor = profile.tank.colors.aggro\n                envTable.NameplateNoAggroColor = profile.tank.colors.noaggro\n            else\n                envTable.NameplateAggroColor = profile.dps.colors.aggro\n                envTable.NameplateNoAggroColor = profile.dps.colors.noaggro\n            end\n            \n        end\n    end\n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --npcs affected by this script\n    \n    envTable.npcIDs = {\n        [148716] = true, --risen soul\n        [148893] = true, --tormented soul\n        [148894] = true, --lost soul\n        \n        [127278] = true, --skittering feeder (tests and debug, also need to disable the load conditions)\n    }\n    \n    --detect aggro, if true it will see which group member the soul is attacking and override the color\n    envTable.detectAggro = true\n    \n    \nend\n\n\n",
					},
					["Prio"] = 99,
					["Name"] = "M+ Bwonsamdi Reaping",
					["PlaterCore"] = 1,
					["LastHookEdited"] = "Constructor",
					["Time"] = 1579030189,
					["Icon"] = 2446016,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
							["Enabled"] = true,
							["party"] = true,
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
							["Enabled"] = true,
							["117"] = true,
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [15]
				{
					["Enabled"] = false,
					["Revision"] = 36,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "Kastfall-Azralon",
					["OptionsValues"] = {
					},
					["Desc"] = "Show the name of the unit current target ",
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateSpellNameText (unitFrame)\n    \nend\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateSpellNameText (unitFrame)\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --max length of the text\n    envTable.TextMaxLength = 100\n    \n    --update the spell name text\n    function envTable.UpdateSpellNameText (unitFrame)\n        \n        local castBar = unitFrame.castBar\n        local textString = castBar.Text\n        local spellName = castBar.SpellName\n        \n        if (unitFrame.targetUnitID) then\n            local targetName = UnitName (unitFrame.targetUnitID)\n            \n            if (targetName) then\n                textString:SetText (spellName .. \" > \" .. targetName) \n                \n                if (envTable.TextMaxLength) then\n                    Plater.LimitTextSize (textString, envTable.TextMaxLength)\n                end\n                \n            else\n                textString:SetText (spellName)\n            end\n        else\n            textString:SetText (spellName)\n        end\n    end\nend",
					},
					["Prio"] = 99,
					["Time"] = 1620347099,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Cast Target",
					["Icon"] = 413580,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [16]
				{
					["Enabled"] = false,
					["Revision"] = 43,
					["HooksTemp"] = {
					},
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Only show nameplates while in combat, see the constructor for more options.",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.CheckIfCanShowNameplate (unitFrame)\n    \nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.CheckIfCanShowNameplate (unitFrame)\n    \nend\n\n\n",
						["Zone Changed"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.CheckIfCanShowNameplate (unitFrame)\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    function envTable.CheckIfCanShowNameplate (unitFrame)\n        if (Plater.IsInCombat()) then\n            \n            if (not unitFrame.healthBar:IsShown()) then\n                Plater.ShowHealthBar (unitFrame)\n                Plater.EnableHighlight (unitFrame)\n            end\n            \n        else\n            \n            if (unitFrame.healthBar:IsShown()) then\n                Plater.HideHealthBar (unitFrame)\n                Plater.DisableHighlight (unitFrame)\n            end\n            \n        end        \n    end\n    \nend\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Only in Combat",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551825361,
					["Icon"] = 135473,
					["LastHookEdited"] = "Constructor",
				}, -- [17]
				{
					["Enabled"] = false,
					["Revision"] = 35,
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Add an exclamation icon on units with color set in the Npc Colors tab with the \"Only Script\" box selected.",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    local npcColor = Plater.GetNpcColor (unitFrame)\n    if (npcColor) then\n        unitFrame.NpcColorCodeTexture:SetVertexColor (DetailsFramework:ParseColors (npcColor))\n        unitFrame.NpcColorCodeTexture:SetAlpha (envTable.Alpha)        \n        unitFrame.NpcColorCodeTexture:Show()\n        \n    else\n        unitFrame.NpcColorCodeTexture:Hide()\n        \n    end\n    \nend\n\n\n\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    unitFrame.NpcColorCodeTexture:SetSize (unitFrame.healthBar:GetHeight(), unitFrame.healthBar:GetHeight())\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.IconTexture = [[Interface\\AddOns\\Plater\\media\\exclamation_64]]\n    envTable.Alpha = 0.8\n    \n    --private\n    if (not unitFrame.NpcColorCodeTexture) then\n        unitFrame.NpcColorCodeTexture = unitFrame.healthBar:CreateTexture (nil, \"overlay\")\n        unitFrame.NpcColorCodeTexture:SetTexture (envTable.IconTexture)\n        \n        --texture side | anchor to which frame | frame side | x offset | y offset\n        unitFrame.NpcColorCodeTexture:SetPoint (\"right\", unitFrame.healthBar, \"right\", -2, 0)\n        \n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Npc Colors Icon",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1553450716,
					["Icon"] = "Interface\\AddOns\\Plater\\media\\exclamation_64",
					["LastHookEdited"] = "Constructor",
				}, -- [18]
				{
					["Enabled"] = false,
					["Revision"] = 68,
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Add a color tag on units with color set in the Npc Colors tab with the \"Only Script\" box selected.",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateColorTag (unitFrame)   \n    \nend\n\n\n\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateTexture (unitFrame)\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.Alpha = 0.75\n    \n    envTable.Anchor = {\n        side = 11, --right side inside the nameplate\n        x = -3,\n        y = 0\n    }\n    \n    --private\n    if (not unitFrame.NpcColorCodeTexture) then\n        unitFrame.NpcColorCodeTexture = unitFrame.healthBar:CreateTexture (nil, \"overlay\")\n        unitFrame.NpcColorCodeTexture:SetColorTexture (1, 1, 1, 1)\n        \n    end\n    \n    function  envTable.UpdateColorTag (unitFrame)\n        local npcColor = Plater.GetNpcColor (unitFrame)\n        if (npcColor) then\n            unitFrame.NpcColorCodeTexture:SetVertexColor (DetailsFramework:ParseColors (npcColor))\n            unitFrame.NpcColorCodeTexture:SetAlpha (envTable.Alpha)           \n            unitFrame.NpcColorCodeTexture:Show()        \n        end\n    end\n    \n    function  envTable.UpdateTexture (unitFrame)\n        Plater.SetAnchor (unitFrame.NpcColorCodeTexture, envTable.Anchor)\n        unitFrame.NpcColorCodeTexture:SetSize (unitFrame.healthBar:GetHeight() - 4, unitFrame.healthBar:GetHeight() - 4)\n        unitFrame.NpcColorCodeTexture:Hide()\n        \n        envTable.UpdateColorTag (unitFrame)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Npc Colors Tag",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1553450705,
					["Icon"] = "Interface\\AddOns\\Plater\\media\\radio_64",
					["LastHookEdited"] = "Constructor",
				}, -- [19]
				{
					["Enabled"] = false,
					["Revision"] = 44,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "Ditador-Azralon",
					["OptionsValues"] = {
					},
					["Desc"] = "Change the color of the aura timer by it's time left",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --colors for each time bracket\n    envTable.Colors = {\n        critical = \"red\",\n        warning = \"yellow\",\n        okay = \"white\",\n    }\n    \n    --time amount to enter in warning or critical state\n    envTable.Timers = {\n        critical = 4.9,\n        warning = 8,\n    }\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    local auras = unitFrame.BuffFrame.PlaterBuffList\n    \n    for _, auraIcon in ipairs (auras) do\n        if (auraIcon:IsVisible()) then\n            if (auraIcon.RemainingTime < envTable.Timers.critical) then\n                Plater:SetFontColor (auraIcon.TimerText, envTable.Colors.critical)\n                \n            elseif (auraIcon.RemainingTime < envTable.Timers.warning) then\n                Plater:SetFontColor (auraIcon.TimerText, envTable.Colors.warning)\n                \n            else\n                Plater:SetFontColor (auraIcon.TimerText, envTable.Colors.okay)\n            end \n        end\n        \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Prio"] = 99,
					["Time"] = 1613211753,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Paint Aura Timers",
					["Icon"] = "Interface\\Timer\\Challenges-Logo",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [20]
				{
					["Enabled"] = true,
					["Revision"] = 129,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "????????-Illidan",
					["OptionsValues"] = {
					},
					["Desc"] = "Config aura borders",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --border thickness\n    local size = 1 \n    \n    for index, auraIcon in ipairs (unitFrame.BuffFrame.PlaterBuffList) do\n        if (auraIcon:IsShown()) then\n            \n            if (not auraIcon.PixelPerfectBorder) then\n                auraIcon.PixelPerfectBorder = CreateFrame (\"frame\", nil, auraIcon, \"NamePlateFullBorderTemplate\")\n            end\n            \n            local r, g, b = auraIcon:GetBackdropBorderColor()\n            auraIcon:SetBackdropBorderColor (0, 0, 0, 0)\n            \n            auraIcon.PixelPerfectBorder:SetVertexColor (r, g, b)\n            auraIcon.PixelPerfectBorder:SetBorderSizes (size, size, size, size)\n            auraIcon.PixelPerfectBorder:UpdateSizes()\n            \n            auraIcon.Icon:ClearAllPoints()\n            auraIcon.Icon:SetAllPoints()\n            \n            auraIcon.Border:Hide() --hide plater default border\n        end\n    end\n    \n    for index, auraIcon in ipairs (unitFrame.BuffFrame2.PlaterBuffList) do\n        if (auraIcon:IsShown()) then\n            \n            if (not auraIcon.PixelPerfectBorder) then\n                auraIcon.PixelPerfectBorder = CreateFrame (\"frame\", nil, auraIcon, \"NamePlateFullBorderTemplate\")\n            end\n            \n            local r, g, b = auraIcon:GetBackdropBorderColor()\n            auraIcon:SetBackdropBorderColor (0, 0, 0, 0)\n            \n            auraIcon.PixelPerfectBorder:SetVertexColor (r, g, b)\n            auraIcon.PixelPerfectBorder:SetBorderSizes (size, size, size, size)\n            auraIcon.PixelPerfectBorder:UpdateSizes()            \n            \n            auraIcon.Icon:ClearAllPoints()\n            auraIcon.Icon:SetAllPoints()\n            \n            auraIcon.Border:Hide() --hide plater default border\n        end\n    end    \nend",
					},
					["Prio"] = 99,
					["Time"] = 1620348411,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Advanced Debuff Border",
					["Icon"] = 133006,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [21]
				{
					["Enabled"] = false,
					["Revision"] = 35,
					["HooksTemp"] = {
					},
					["Author"] = "�r��ne-Kel'thuzad",
					["Desc"] = "Show yellow star for elite; Silver star for rares",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIndicator (unitFrame, unitId)\n    \nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIndicator (unitFrame, unitId)\n    \nend\n\n\n\n\n\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    function envTable.UpdateIndicator (unitFrame, unitId)\n        local unitClassification = UnitClassification (unitId)\n        local unitName = UnitName (unitId)\n        unitName = unitName or UNKNOWN\n        \n        if (unitClassification == \"rareelite\") then\n            unitFrame.unitName:SetText (\"|TInterface\\\\AddOns\\\\Plater\\\\media\\\\star_full_64:12:12:0:0:64:64:0:64:0:64|t\" .. \"|TInterface\\\\GLUES\\\\CharacterSelect\\\\Glues-AddOn-Icons:12:12:0:0:64:16:48:64:0:16|t \" .. unitName)\n            \n        elseif (unitClassification == \"rare\") then\n            unitFrame.unitName:SetText (\"|TInterface\\\\AddOns\\\\Plater\\\\media\\\\star_full_64:12:12:0:0:64:64:0:64:0:64|t\" .. unitName)\n            \n        elseif (unitClassification == \"elite\") then\n            unitFrame.unitName:SetText (\"|TInterface\\\\GLUES\\\\CharacterSelect\\\\Glues-AddOn-Icons:12:12:0:0:64:16:48:64:0:16|t\" .. unitName)\n            \n        end\n    end\n    \nend\n\n\n\n\n",
					},
					["Name"] = "Rarity in the Name",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551825364,
					["Icon"] = "Interface\\AddOns\\Plater\\media\\star_full_64",
					["LastHookEdited"] = "Constructor",
				}, -- [22]
				{
					["Enabled"] = true,
					["Revision"] = 75,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Cyclopes-Turalyon",
					["Options"] = {
					},
					["Desc"] = "Add an icon to indicate an unit has Aggro on you. By default only show for units using a custom color from Npc Colors.",
					["Hooks"] = {
						["Leave Combat"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.ThreatIcon) then\n        unitFrame.ThreatIcon:Hide()\n    end\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIndicator (unitFrame)\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.ThreatIcon) then\n        unitFrame.ThreatIcon:Hide()\n    end    \nend\n\n\n",
						["Nameplate Removed"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.ThreatIcon) then\n        unitFrame.ThreatIcon:Hide()\n    end\nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateThreatState (unitFrame, unitId)\n    \nend\n\n\n",
						["Enter Combat"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdatePlayerRole (unitFrame)\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.Anchor = {side = 11, x = -2, y = 0}\n    envTable.Texture = \"Interface\\\\AddOns\\\\Plater\\\\media\\\\exclamation2_64\"\n    \n    --it'll only use the icon if the nameplate has a color from the Npc Colors tab and \"Only Scripts\" disabled.\n    envTable.OnlyWhenUsingNpcColor = true --if false, it'll always use the icon\n    \n    --private\n    envTable.PlayerRole = \"NONE\" --automatically changed by the script\n    \n    function envTable.CreateIndicator (unitFrame)\n        if (not unitFrame.ThreatIcon) then\n            unitFrame.ThreatIcon = unitFrame.healthBar:CreateTexture (nil, \"overlay\")\n        end\n    end\n    \n    function envTable.UpdateIndicator (unitFrame)\n        envTable.CreateIndicator (unitFrame)\n        \n        unitFrame.ThreatIcon:SetTexture (envTable.Texture)\n        Plater.SetAnchor (unitFrame.ThreatIcon, envTable.Anchor)\n        unitFrame.ThreatIcon:SetSize (unitFrame.healthBar:GetHeight(), unitFrame.healthBar:GetHeight())\n    end\n    \n    function envTable.UpdateThreatState (unitFrame, unitId)\n        if (not unitFrame.ThreatIcon) then --if there's no icon created yet\n            return\n            \n        elseif (not Plater.IsInCombat()) then --not in combat\n            unitFrame.ThreatIcon:Hide()\n            return\n            \n        elseif (unitFrame.IsSelf) then --personal bar\n            unitFrame.ThreatIcon:Hide()\n            return\n            \n        elseif (envTable.OnlyWhenUsingNpcColor) then --must be using a npc color?\n            if (not unitFrame.UsingCustomColor) then\n                unitFrame.ThreatIcon:Hide()\n                return\n            end\n        end\n        \n        local isTanking, threatStatus, threatpct = UnitDetailedThreatSituation (\"player\", unitId)\n        \n        if (isTanking) then\n            if (envTable.PlayerRole == \"TANK\") then\n                unitFrame.ThreatIcon:Hide()\n            else\n                unitFrame.ThreatIcon:Show()\n                unitFrame.ThreatIcon:SetVertexColor (unpack (envTable.NameplateAggroColor))\n            end\n        else\n            if (envTable.PlayerRole == \"TANK\") then\n                unitFrame.ThreatIcon:Show()\n                unitFrame.ThreatIcon:SetVertexColor (unpack (envTable.NameplateNoAggroColor))                \n            else\n                unitFrame.ThreatIcon:Hide()                \n            end\n        end\n    end\n    \n    function envTable.UpdatePlayerRole (unitFrame)\n        local profile = Plater.db.profile\n        local role = Plater:GetPlayerRole()\n        \n        if (role == \"TANK\") then\n            envTable.PlayerRole = \"TANK\"\n            envTable.NameplateAggroColor = profile.tank.colors.aggro\n            envTable.NameplateNoAggroColor = profile.tank.colors.noaggro\n            \n        else\n            envTable.PlayerRole = \"DAMAGER\"\n            envTable.NameplateAggroColor = profile.dps.colors.aggro\n            envTable.NameplateNoAggroColor = profile.dps.colors.noaggro\n            \n        end        \n    end\n    \n    envTable.UpdatePlayerRole (unitFrame)\n    \nend",
					},
					["Prio"] = 99,
					["Name"] = "Aggro Indicator",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["LastHookEdited"] = "",
					["Time"] = 1672515283,
					["Icon"] = 132344,
					["PlaterCore"] = 1,
				}, -- [23]
				{
					["Enabled"] = false,
					["Revision"] = 20,
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Edit the Constructor script setting the font you want in the FONT = \"\", then /reload.",
					["Hooks"] = {
						["Nameplate Created"] = "function (self, unitId, unitFrame, envTable)\n    \n    --added this event just to run the constructor script\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --insert here the font you want to change then /reeload\n    --after the reload, check if the font has changed and disable this script\n    \n    local FONT = \"Accidental Presidency\"\n    \n    local profile = Plater.db.profile\n    local actorTables = profile.plate_config\n    \n    for plateType, plateTable in pairs (actorTables) do\n        \n        plateTable.actorname_text_font = FONT\n        plateTable.spellname_text_font = FONT\n        plateTable.spellpercent_text_font = FONT\n        plateTable.level_text_font = FONT\n        plateTable.percent_text_font = FONT\n        plateTable.big_actortitle_text_font = FONT\n        plateTable.big_actorname_text_font = FONT\n        plateTable.power_percent_text_font = FONT\n        \n    end\n    \n    profile.castbar_target_font = FONT\n    profile.aura_timer_text_font = FONT    \n    profile.aura_stack_font = FONT    \n    \nend\n\n\n",
					},
					["Name"] = "Change All Fonts",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551825316,
					["Icon"] = 134331,
					["LastHookEdited"] = "Constructor",
				}, -- [24]
				{
					["Enabled"] = false,
					["Revision"] = 50,
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Show the power bar for specific units",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.PowerBarAnchor = {side = 4, x = 0, y = -10}\n    \n    function envTable.UpdatePowerBar (unitFrame)\n        unitFrame.powerBar:SetUnit (unitFrame.unit)\n        Plater.SetAnchor (unitFrame.powerBar, envTable.PowerBarAnchor)\n        \n    end\n    \nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (Plater.ZoneInstanceType == \"arena\") then\n        \n        local arenaEnemies = GetNumArenaOpponentSpecs()\n        local found = false\n        for i = 1, arenaEnemies do\n            local guid = UnitGUID (\"arena\" .. i)\n            print (guid)\n            if (guid == unitFrame.namePlateUnitGUID) then\n                \n                local spec = GetArenaOpponentSpec (i)\n                print (spec)\n                if (spec) then\n                    local id, name, description, icon, role, class = GetSpecializationInfoByID (spec)\n                    print (name)\n                    if (role == \"HEALER\") then\n                        envTable.UpdatePowerBar (unitFrame)\n                    end\n                    print (role)\n                end\n                \n                break\n            end\n        end\n        \n        return\n    end\n    \n    --show for enemy players\n    if (unitFrame.ActorType == \"enemyplayer\") then\n        envTable.UpdatePowerBar (unitFrame)\n        return\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
					["Name"] = "Power Bar",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1553450521,
					["Icon"] = 1375677,
					["LastHookEdited"] = "Constructor",
				}, -- [25]
				{
					["Enabled"] = false,
					["Revision"] = 140,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "Ditador-Azralon",
					["OptionsValues"] = {
					},
					["Desc"] = "Move the icon of the spell cast to the left or right side of the nameplate.",
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIconPosition (unitFrame)\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIconPosition (unitFrame)\n    self.ThrottleUpdate = -1\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings:\n    --show cast icon\n    envTable.ShowIcon = true\n    --anchor icon on what side\n    envTable.IconAnchor = \"left\" --accep 'left' 'right'\n    --fine tune the size of the icon\n    envTable.IconSizeOffset = 1\n    \n    --shield for non interruptible casts\n    envTable.ShowShield = false\n    envTable.ShieldTexture = [[Interface\\GROUPFRAME\\UI-GROUP-MAINTANKICON]]\n    envTable.ShieldDesaturated = true\n    envTable.ShieldColor = {1, 1, 1 ,1}\n    envTable.ShieldSize = {10, 12}\n    \n    --private:\n    function envTable.UpdateIconPosition (unitFrame)\n        local castBar = unitFrame.castBar\n        local icon = castBar.Icon\n        local shield = castBar.BorderShield\n        \n        if (envTable.ShowIcon) then\n            icon:ClearAllPoints()\n            \n            if (envTable.IconAnchor == \"left\") then\n                icon:SetPoint (\"topright\", unitFrame.healthBar, \"topleft\", -1, envTable.IconSizeOffset)\n                icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", -1, 0)    \n                \n            elseif (envTable.IconAnchor == \"right\") then\n                icon:SetPoint (\"topleft\", unitFrame.healthBar, \"topright\", 1, envTable.IconSizeOffset)\n                icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", 1, 0)\n                \n            end\n            \n            icon:SetWidth (icon:GetHeight())\n            icon:Show()\n            \n        else\n            icon:Hide()\n            \n        end\n        \n        if (envTable.ShowShield and not castBar.canInterrupt) then\n            shield:Show()\n            shield:SetAlpha (1)\n            shield:SetTexCoord (0, 1, 0, 1)\n            shield:SetVertexColor (1, 1, 1, 1)\n            \n            shield:SetTexture (envTable.ShieldTexture)\n            shield:SetDesaturated (envTable.ShieldDesaturated)\n            \n            if (not envTable.ShieldDesaturated) then\n                shield:SetVertexColor (DetailsFramework:ParseColors (envTable.ShieldColor))\n            end\n            \n            shield:SetSize (unpack (envTable.ShieldSize))\n            \n            shield:ClearAllPoints()\n            shield:SetPoint (\"center\", castBar, \"left\", 0, 0)\n            \n        else\n            shield:Hide()\n            \n        end\n        \n    end\nend",
					},
					["Prio"] = 99,
					["Time"] = 1620346604,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Cast Icon Anchor",
					["Icon"] = "Interface\\Buttons\\UI-Quickslot2",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [26]
				{
					["Enabled"] = false,
					["Revision"] = 65,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["OptionsValues"] = {
					},
					["Desc"] = "Adds a pixels perfect border around the cast bar spell icon.",
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BuildFrames (unitFrame)\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (unitFrame.castBar.IconOverlayFrame) then\n        unitFrame.castBar.IconOverlayFrame:Hide()\n    end\n    \nend\n\n\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.BuildFrames (unitFrame)\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.AnchorSide = \"left\"\n    envTable.BorderThickness = 1\n    envTable.BorderColor = \"black\"\n    \n    --private\n    function envTable.BuildFrames (unitFrame)\n        local castBar = unitFrame.castBar\n        \n        local r, g, b, a = DetailsFramework:ParseColors (envTable.BorderColor)\n        castBar.IconBorder:SetVertexColor (r, g, b, a)\n        \n        local size = envTable.BorderThickness\n        castBar.IconBorder:SetBorderSizes (size, size, size, size)\n        castBar.IconBorder:UpdateSizes()\n        \n        local icon = castBar.Icon\n        if (envTable.AnchorSide == \"left\") then\n            icon:ClearAllPoints()\n            icon:SetPoint (\"topright\", unitFrame.healthBar, \"topleft\", -1, 0)\n            icon:SetPoint (\"bottomright\", castBar, \"bottomleft\", -1, 0)\n            icon:SetWidth (icon:GetHeight())\n            \n        elseif (envTable.AnchorSide == \"right\") then\n            icon:ClearAllPoints()\n            icon:SetPoint (\"topleft\", unitFrame.healthBar, \"topright\", 1, 0)\n            icon:SetPoint (\"bottomleft\", castBar, \"bottomright\", 1, 0)\n            icon:SetWidth (icon:GetHeight())\n            \n        end\n        \n        icon:Show()\n        castBar.IconOverlayFrame:Show()\n    end\n    \n    if (not unitFrame.castBar.IconOverlayFrame) then\n        --icon support frame\n        unitFrame.castBar.IconOverlayFrame = CreateFrame (\"frame\", nil, unitFrame.castBar)\n        unitFrame.castBar.IconOverlayFrame:SetPoint (\"topleft\", unitFrame.castBar.Icon, \"topleft\")\n        unitFrame.castBar.IconOverlayFrame:SetPoint (\"bottomright\", unitFrame.castBar.Icon, \"bottomright\")\n        \n        unitFrame.castBar.IconBorder = CreateFrame (\"frame\", nil,  unitFrame.castBar.IconOverlayFrame, \"NamePlateFullBorderTemplate\")\n    end    \n    \nend\n\n\n\n\n",
					},
					["Prio"] = 99,
					["Time"] = 1620346604,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Cast Icon Border",
					["Icon"] = 133004,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [27]
				{
					["Enabled"] = true,
					["Revision"] = 93,
					["Options"] = {
					},
					["LastHookEdited"] = "",
					["Author"] = "Izimode-Azralon",
					["OptionsValues"] = {
					},
					["Desc"] = "Adds a pixels perfect border around the cast bar.",
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateBorder (unitFrame)\n    \nend\n\n\n",
						["Destructor"] = "function (self, unitId, unitFrame, envTable)\n    if (unitFrame.castBar.CastBarBorder) then\n        unitFrame.castBar.CastBarBorder:Hide()\n    end    \nend",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateBorder (unitFrame)\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings\n    \n    --hide the icon of the spell, may require /reload after changing\n    envTable.HideIcon = false\n    \n    --border settings\n    envTable.BorderThickness = 1\n    envTable.BorderColor = \"black\"\n    \n    --private\n    --create the border\n    if (not unitFrame.castBar.CastBarBorder) then\n        unitFrame.castBar.CastBarBorder = CreateFrame (\"frame\", nil, unitFrame.castBar, \"NamePlateFullBorderTemplate\")\n    end    \n    \n    --update the border\n    function envTable.UpdateBorder (unitFrame)\n        local castBar = unitFrame.castBar\n        \n        local r, g, b, a = DetailsFramework:ParseColors (envTable.BorderColor)\n        castBar.CastBarBorder:SetVertexColor (r, g, b, a)\n        \n        local size = envTable.BorderThickness\n        castBar.CastBarBorder:SetBorderSizes (size, size, size, size)\n        castBar.CastBarBorder:UpdateSizes()        \n        \n        if (envTable.HideIcon) then\n            castBar.Icon:Hide()\n        end\n        \n        castBar.CastBarBorder:Show()\n    end\n    \nend\n\n\n\n\n",
					},
					["Prio"] = 99,
					["Time"] = 1672052507,
					["PlaterCore"] = 1,
					["HooksTemp"] = {
					},
					["Name"] = "Cast Bar Border",
					["Icon"] = 133004,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
				}, -- [28]
				{
					["Enabled"] = false,
					["Revision"] = 46,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "????????-Illidan",
					["Options"] = {
					},
					["Desc"] = "Debuff timer show decimal values",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --minimum time left to take effect\n    envTable.MinTime = 9.999\n    \nend",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    for index, auraIcon in ipairs (unitFrame.BuffFrame.PlaterBuffList) do\n        if (auraIcon:IsShown()) then\n            if (auraIcon.RemainingTime < envTable.MinTime) then\n                auraIcon.TimerText:SetText (format (\"%.1f\", auraIcon.RemainingTime))\n            end\n        end\n    end\n    \n    for index, auraIcon in ipairs (unitFrame.BuffFrame2.PlaterBuffList) do\n        if (auraIcon:IsShown()) then\n            if (auraIcon.RemainingTime < envTable.MinTime) then            \n                auraIcon.TimerText:SetText (format (\"%.1f\", auraIcon.RemainingTime))\n            end\n        end        \n    end    \nend",
					},
					["Prio"] = 99,
					["Name"] = "Decimal Debuff Timer",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["LastHookEdited"] = "",
					["Time"] = 1613211431,
					["Icon"] = 609811,
					["PlaterCore"] = 1,
				}, -- [29]
				{
					["Enabled"] = true,
					["Revision"] = 85,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "?????-Illidan",
					["Options"] = {
					},
					["Desc"] = "Format Buff Special icons like the regular aura icons.",
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    \n    --    if false then return end\n    \n    for _, iconFrame in ipairs (unitFrame.ExtraIconFrame.IconPool) do\n        \n        unitFrame.ExtraIconFrame.options.show_text = true\n        \n        local profile = Plater.db.profile\n        \n        Plater.SetAnchor (iconFrame.CountdownText, profile.aura_timer_text_anchor)\n        Plater:SetFontSize (iconFrame.CountdownText, profile.aura_timer_text_size)\n        Plater:SetFontFace (iconFrame.CountdownText, profile.aura_timer_text_font)\n        \n        Plater.SetFontOutlineAndShadow (iconFrame.CountdownText, profile.aura_timer_text_outline, profile.aura_timer_text_shadow_color, profile.aura_timer_text_shadow_color_offset[1], profile.aura_timer_text_shadow_color_offset[2])\n        \n        iconFrame.Cooldown:SetEdgeTexture (profile.aura_cooldown_edge_texture)\n        iconFrame.Cooldown:SetReverse (profile.aura_cooldown_reverse)\n        iconFrame.Cooldown:SetDrawSwipe (profile.aura_cooldown_show_swipe)        \n        \n    end\n    \nend",
					},
					["Prio"] = 99,
					["Name"] = "Buff Special Mod",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["LastHookEdited"] = "",
					["Time"] = 1620348416,
					["Icon"] = 136139,
					["PlaterCore"] = 1,
				}, -- [30]
				{
					["Enabled"] = false,
					["Revision"] = 29,
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Adds two arrows into the target indicators options.",
					["Hooks"] = {
						["Player Talent Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    --after editing this script, save it and /reload\n    \n    --adds two target indicators in arrow format\n    --to change the texture you may replace the path with another texture path\n    --or you can copy and paste more options here\n    \n    Plater.TargetIndicators    [\"SmallArrow\"] = {\n        path = [[Interface\\MONEYFRAME\\Arrow-Right-Up]],\n        coords = {\n            {0, 1, 0, 1}, \n            {1, 0, 0, 1}\n        },\n        desaturated = false,\n        width = 12,\n        height = 12,\n        x = 8,\n        y = 0,\n        blend = \"ADD\",\n    }\n    \n    Plater.TargetIndicators    [\"BigArrow\"] = {\n        path = [[Interface\\AddOns\\Plater\\media\\arrow_right_64]],\n        coords = {\n            {0, 1, 0, 1}, \n            {1, 0, 0, 1}\n        },\n        desaturated = false,\n        width = 18,\n        height = 16,\n        x = 24,\n        y = 0,\n        blend = \"ADD\",\n        color = \"yellow\",\n    }\n    \n    \n    \nend\n\n\n",
					},
					["Name"] = "Arrow Target Indicators",
					["PlaterCore"] = 1,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["Time"] = 1551887544,
					["Icon"] = "Interface\\AddOns\\Plater\\media\\arrow_right_64",
					["LastHookEdited"] = "Player Talent Update",
				}, -- [31]
				{
					["Enabled"] = true,
					["Revision"] = 12,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Ditador-Azralon",
					["Options"] = {
					},
					["Desc"] = "Set the unit name to be above the target shading texture.",
					["Hooks"] = {
						["Target Changed"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.unitName:SetDrawLayer (\"overlay\", 7)\nend\n\n\n\n\n\n\n\n\n",
					},
					["Prio"] = 99,
					["Name"] = "Unit Name Over Target Shading",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["LastHookEdited"] = "",
					["Time"] = 1620348420,
					["Icon"] = 237377,
					["PlaterCore"] = 1,
				}, -- [32]
				{
					["Enabled"] = false,
					["Revision"] = 25,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Ditador-Azralon",
					["Options"] = {
					},
					["Desc"] = "Set the spark height to the same size of the cast bar.",
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    self.Spark:SetHeight (self:GetHeight())\n    \nend\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    self.Spark:SetHeight (self:GetHeight())\n    \nend\n\n\n",
					},
					["Prio"] = 99,
					["Name"] = "Adjust Spark Size",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["LastHookEdited"] = "",
					["Time"] = 1620348421,
					["Icon"] = "Interface\\AddOns\\Plater\\images\\spark6",
					["PlaterCore"] = 1,
				}, -- [33]
				{
					["Enabled"] = false,
					["Revision"] = 71,
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Options"] = {
					},
					["Desc"] = "Show power bar for some units.",
					["Hooks"] = {
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    --power bar options:\n    \n    --for which units it should\n    envTable.ShowForEnemyPlayers = true\n    envTable.ShowForEnemyNpcs = false\n    \n    --specific npcs, can be the npc name or npcId\n    --this list work even if the ShowForEnemyNpcs is false\n    envTable.SpecificNpcs = {\n        [\"the rock\"] = true, --npc name\n        [225] = true, --npcId\n    }\n    \n    --anchor the power bar to\n    envTable.Anchor = {\n        side = 13, --inside the healthbar, bottom side\n        x = 0, \n        y = 0,\n    }\n    \n    --power bar height\n    envTable.Height = 1\n    \n    --power bar percent text\n    envTable.PercentTextEnabled = false\n    envTable.PercentTextAnchor = {\n        side = 7, --top right\n        x = 2, \n        y = 0,\n    }\n    \n    \n    --private\n    function envTable.ShowPowerbar (unitFrame)\n        unitFrame.powerBar:SetUnit (unitFrame.unit)\n        envTable.UpdatePowerbar (unitFrame)\n    end\n    \n    function envTable.UpdatePowerbar (unitFrame)\n        local powerBar = unitFrame.powerBar\n        Plater.SetAnchor (powerBar, envTable.Anchor, unitFrame.healthBar)\n        powerBar:SetSize (unitFrame.healthBar:GetWidth(), envTable.Height)\n        \n        envTable.SavePowerBarSize (unitFrame, envTable.Height)\n        \n        if (envTable.PercentTextEnabled) then\n            powerBar.percentText:Show()\n            --copy the font from the health percent\n            Plater:SetFontFace (powerBar.percentText, Plater.GetConfig (unitFrame).percent_text_font)\n            Plater:SetFontSize (powerBar.percentText, Plater.GetConfig (unitFrame).percent_text_size)\n            Plater.SetAnchor (powerBar.percentText, envTable.PercentTextAnchor)\n        else\n            powerBar.percentText:Hide()\n        end\n    end\n    \n    function envTable.CanShowPowerBarForUnit (unitFrame)\n        --check if the is in the special list to force show\n        local forceShowPowerBar = envTable.SpecificNpcs [unitFrame.namePlateNpcId] or envTable.SpecificNpcs [unitFrame.namePlateUnitName] or envTable.SpecificNpcs [unitFrame.namePlateUnitNameLower]\n        if (forceShowPowerBar) then\n            envTable.ShowPowerbar (unitFrame)\n            \n            --check if the unit is a enemy player\n        elseif (unitFrame.ActorType == \"enemyplayer\") then\n            if (envTable.ShowForEnemyPlayers) then\n                envTable.ShowPowerbar (unitFrame)\n            end\n            \n            --check if the unit is a enemy npc\n        elseif (unitFrame.ActorType == \"enemynpc\") then\n            if (envTable.ShowForEnemyNpcs) then\n                envTable.ShowPowerbar (unitFrame)\n            end\n        end\n    end\n    \n    function envTable.SavePowerBarSize (unitFrame, height)\n        local plateConfigs = Plater.db.profile.plate_config [unitFrame.ActorType]\n        plateConfigs.mana[1] = plateConfigs.health[1]\n        plateConfigs.mana[2] = height\n        plateConfigs.mana_incombat[1] = plateConfigs.health_incombat[1]\n        plateConfigs.mana_incombat[2] = height\n    end\nend\n\n\n\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    envTable.CanShowPowerBarForUnit (unitFrame)    \nend",
					},
					["Prio"] = 99,
					["Name"] = "Power Bar",
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["LastHookEdited"] = "",
					["Time"] = 1620346758,
					["Icon"] = "Interface/Addons/Plater/Media/fire_64",
					["PlaterCore"] = 1,
				}, -- [34]
				{
					["OptionsValues"] = {
						["useFullSize"] = false,
						["iconOnLeftSide"] = false,
						["showIcon"] = false,
					},
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Cast Start"] = "function (self, unitId, unitFrame, envTable)\n    \n    unitFrame.castBar.BorderShield:SetDrawLayer(\"artwork\")\n    envTable.UpdateIconPosition (unitFrame)\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["Cast Update"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.UpdateIconPosition (unitFrame)\n    self.ThrottleUpdate = -1\n    \nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable, modTable)\n    \n    --private:\n    function envTable.UpdateIconPosition (unitFrame)\n        local castBar = unitFrame.castBar\n        local icon = castBar.Icon\n        local noInterruptTexture = castBar.BorderShield\n        \n        if (modTable.config.showIcon) then\n            icon:ClearAllPoints()\n            \n            if (modTable.config.iconOnLeftSide) then\n                if (modTable.config.useFullSize) then\n                    icon:SetPoint (\"topright\", unitFrame.healthBar, \"topleft\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                    \n                else\n                    \n                    icon:SetPoint (\"topright\", unitFrame.castBar, \"topleft\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomright\", unitFrame.castBar, \"bottomleft\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                end\n                \n            else\n                if (modTable.config.useFullSize) then\n                    icon:SetPoint (\"topleft\", unitFrame.healthBar, \"topright\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                    \n                else\n                    \n                    icon:SetPoint (\"topleft\", unitFrame.castBar, \"topright\", modTable.config.iconPadding, modTable.config.iconSizeOffset)\n                    icon:SetPoint (\"bottomleft\", unitFrame.castBar, \"bottomright\", modTable.config.iconPadding, -modTable.config.iconSizeOffset)\n                end\n            end\n            \n            icon:SetWidth (icon:GetHeight())\n            icon:Show()\n        else\n            icon:Hide()\n        end\n        \n        if (modTable.config.showTexture and not castBar.canInterrupt) then\n            noInterruptTexture:Show()\n            \n            local texturePath = modTable.config.iconTexturePath\n            texturePath = texturePath:gsub(\"//\", \"/\")\n            texturePath = texturePath:gsub(\"\\\\\", \"/\")\n            \n            noInterruptTexture:SetTexture (texturePath)\n            noInterruptTexture:SetTexCoord (0, 1, 0, 1)\n            \n            if (modTable.config.desaturatedTexture) then\n                noInterruptTexture:SetDesaturated (modTable.config.desaturatedTexture)\n            else\n                noInterruptTexture:SetVertexColor (DetailsFramework:ParseColors (modTable.config.textureColor))\n            end\n            \n            noInterruptTexture:SetSize (modTable.config.textureWidth, castBar:GetHeight() + modTable.config.textureHeightMod)\n            noInterruptTexture:ClearAllPoints()\n            noInterruptTexture:SetPoint (\"center\", castBar, \"left\", modTable.config.texturePosition, 0)\n            noInterruptTexture:SetAlpha (modTable.config.textureAlpha)\n        else\n            noInterruptTexture:Hide()\n        end\n    end\nend",
					},
					["Time"] = 1620347016,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\castbar_icon",
					["Enabled"] = false,
					["Revision"] = 352,
					["semver"] = "",
					["Author"] = "Ditador-Azralon",
					["Desc"] = "Move the icon of the spell cast to the left or right side of the nameplate.",
					["Prio"] = 99,
					["version"] = -1,
					["PlaterCore"] = 1,
					["Name"] = "Cast Bar Icon Settings [P]",
					["LastHookEdited"] = "",
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option4",
							["Value"] = "Icon Settings:",
							["Name"] = "Icon Settings",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 4,
							["Key"] = "showIcon",
							["Value"] = true,
							["Name"] = "Show Icon",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show the castbar icon when enabled",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "iconOnLeftSide",
							["Value"] = true,
							["Name"] = "Icon on Left Side",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled it anchor the icon on the left side, right otherwise",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "useFullSize",
							["Value"] = false,
							["Name"] = "Use Big Icon",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled the icon has the size of the cast bar plus the healthbar",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 5,
							["Desc"] = "Fine tune the icon size",
							["Min"] = 0,
							["Key"] = "iconSizeOffset",
							["Value"] = 0,
							["Name"] = "Icon Size Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 5,
							["Desc"] = "Space between the icon and the cast bar",
							["Min"] = -5,
							["Key"] = "iconPadding",
							["Value"] = 0,
							["Name"] = "Icon Padding",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [6]
						{
							["Type"] = 6,
							["Key"] = "option6",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 5,
							["Key"] = "option5",
							["Value"] = "Can't Interrupt Texture:",
							["Name"] = "Interrupt Texture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Key"] = "showTexture",
							["Value"] = true,
							["Name"] = "Show Texture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled show a texture to tell the cast can't be interrupted",
						}, -- [9]
						{
							["Type"] = 3,
							["Key"] = "iconTexturePath",
							["Value"] = "Interface\\GROUPFRAME\\UI-GROUP-MAINTANKICON",
							["Name"] = "Texture Path",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_text",
							["Desc"] = "Insert the path for the texture",
						}, -- [10]
						{
							["Type"] = 4,
							["Key"] = "desaturatedTexture",
							["Value"] = true,
							["Name"] = "Texture Desaturated",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enbaled, texture is shown in black & white",
						}, -- [11]
						{
							["Type"] = 1,
							["Key"] = "textureColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								0.30567157268524, -- [4]
							},
							["Name"] = "Texture Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Select the color of the texture",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Adjust the texture width",
							["Min"] = 1,
							["Key"] = "textureWidth",
							["Value"] = 10,
							["Name"] = "Texture Width",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 16,
							["Desc"] = "The texture is set to be the same size as the cast bar, fine tune the height as wanted",
							["Min"] = -16,
							["Key"] = "textureHeightMod",
							["Value"] = 0,
							["Name"] = "Texture Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Adjust the texture position",
							["Min"] = -32,
							["Key"] = "texturePosition",
							["Value"] = 0,
							["Name"] = "Texture Position",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Adjust the texture transparency",
							["Min"] = 0,
							["Key"] = "textureAlpha",
							["Value"] = 1,
							["Name"] = "Texture Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [16]
					},
				}, -- [35]
				{
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    local name = unitFrame.healthBar.unitName:GetText()\n    \n    if (name) then\n        unitFrame.healthBar.unitName:SetText(name:gsub('(%S+) ',function(t) return t:sub(0,0)..'' end))\n    end\nend\n\n\n\n\n\n\n\n",
					},
					["Time"] = 1620348405,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "https://wago.io/Rcm39UnZV/2",
					["Icon"] = "INTERFACE\\ICONS\\Ability_Spy",
					["Enabled"] = true,
					["Revision"] = 445,
					["semver"] = "1.0.1",
					["Author"] = "Zenshoes-Area 52",
					["Desc"] = "Abbreviates names on nameplates",
					["Prio"] = 99,
					["version"] = 2,
					["PlaterCore"] = 1,
					["Name"] = "Abbreviated Names",
					["LastHookEdited"] = "",
					["Options"] = {
					},
				}, -- [36]
				{
					["OptionsValues"] = {
					},
					["HooksTemp"] = {
					},
					["Hooks"] = {
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable)\n    envTable.CheckAggro (unitFrame)\nend\n\n\n",
						["Nameplate Added"] = "function (self, unitId, unitFrame, envTable)\n    envTable.CheckAggro (unitFrame)\nend\n\n\n",
						["Constructor"] = "function (self, unitId, unitFrame, envTable)\n    \n    function envTable.CheckAggro (unitFrame)\n        --if the player isn't in combat, ignore this check\n        if (not Plater.IsInCombat()) then\n            return\n        end\n        \n        --if this unit isn't in combat, ignore\n        if (not unitFrame.InCombat) then\n            return \n        end\n        \n        --player is a tank?\n        if (Plater.PlayerIsTank) then\n            --player isn't tanking this unit?\n            if (not unitFrame.namePlateThreatIsTanking) then\n                --check if a second tank is tanking it\n                if (Plater.ZoneInstanceType == \"raid\") then\n                    --return a list with the name of tanks in the raid\n                    local tankPlayersInTheRaid = Plater.GetTanks()\n                    \n                    --get the target name of this unit\n                    local unitTargetName = UnitName (unitFrame.targetUnitID)\n                    \n                    --check if the unit isn't targeting another tank in the raid and paint the color\n                    if (not tankPlayersInTheRaid [unitTargetName]) then\n                        Plater.SetNameplateColor (unitFrame, Plater.db.profile.tank.colors.noaggro)\n                    else\n                        --another tank is tanking this unit\n                        --do nothing\n                    end\n                    \n                else\n                    Plater.SetNameplateColor (unitFrame, Plater.db.profile.tank.colors.noaggro)\n                end\n            end\n            \n        else\n            --player is a dps or healer\n            if (unitFrame.namePlateThreatIsTanking) then\n                Plater.SetNameplateColor (unitFrame, Plater.db.profile.dps.colors.aggro)\n            end\n            \n        end        \n    end\nend\n\n\n\n\n\n\n",
					},
					["Time"] = 1672515632,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["affix"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["spec"] = {
						},
					},
					["url"] = "https://wago.io/id_wRWfKp/2",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\checked_64",
					["Enabled"] = true,
					["Revision"] = 35,
					["semver"] = "1.0.1",
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "When a mob is attacking you, force show the threat color. For tanks, force threat color if the mob is not attacking you.",
					["Prio"] = 99,
					["version"] = 2,
					["PlaterCore"] = 1,
					["Name"] = "Force Threat Color",
					["LastHookEdited"] = "",
					["Options"] = {
					},
				}, -- [37]
				{
					["LastHookEdited"] = "Initialization",
					["Hooks"] = {
						["Initialization"] = "function (modTable)\n    -- settings:\n    \n    -- for the LibCustomGlow implementation:\n    modTable.options = {\n        glowType = \"pixel\",\n        color = modTable.config.glowColor,--\"red\", -- all plater color types accepted, from lib: {r,g,b,a}, color of lines and opacity, from 0 to 1. Defaul value is {0.95, 0.95, 0.32, 1}\n        N = modTable.config.antsAmount, --8, -- number of lines. Defaul value is 8;\n        frequency = modTable.config.frequency, -- frequency, set to negative to inverse direction of rotation. Default value is 0.25;\n        length = modTable.config.antsLength, -- length of lines. Default value depends on region size and number of lines;\n        th = modTable.config.antsThickness, -- thickness of lines. Default value is 2;\n        xOffset = 0,\n        yOffset = 0, -- offset of glow relative to region border;\n        border = modTable.config.antsBorder, -- set to true to create border under lines;\n        key = \"StealPurgeAuraGlow\", -- key of glow, allows for multiple glows on one frame;\n    }\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable, modTable)\n    \n    local buffSpecialGlow = true\n    \n    \n    -- functions --\n    local auraContainers = {unitFrame.BuffFrame.PlaterBuffList}\n    \n    if (Plater.db.profile.buffs_on_aura2) then\n        auraContainers [2] = unitFrame.BuffFrame2.PlaterBuffList\n    end\n    \n    for containerID = 1, #auraContainers do\n        local auraContainer = auraContainers [containerID]\n        for index, auraIcon in ipairs (auraContainer) do\n            if (auraIcon:IsShown() and auraIcon.CanStealOrPurge) then\n                Plater.StartGlow(auraIcon, nil, modTable.options)\n                if modTable.config.outerGlow and auraIcon.__PlaterGlowFrame then\n                    auraIcon.__PlaterGlowFrame:ClearAllPoints()\n                    local offset = modTable.config.antsThickness\n                    auraIcon.__PlaterGlowFrame:SetPoint(\"topleft\", auraIcon, \"topleft\", -offset, offset)\n                    auraIcon.__PlaterGlowFrame:SetPoint(\"bottomright\", auraIcon, \"bottomright\", offset, -offset)\n                end\n            else\n                Plater.StopGlow(auraIcon, modTable.options.glowType, modTable.options.key)\n            end\n        end\n    end\n    \n    if buffSpecialGlow then\n        for _, auraIcon in ipairs (unitFrame.ExtraIconFrame.IconPool) do\n            if auraIcon:IsShown() then\n                if (auraIcon:IsShown() and auraIcon.canStealOrPurge) then\n                    Plater.StartGlow(auraIcon, nil, modTable.options)\n                    if modTable.config.outerGlow and auraIcon.__PlaterGlowFrame then\n                        auraIcon.__PlaterGlowFrame:ClearAllPoints()\n                        local offset = modTable.config.antsThickness\n                        auraIcon.__PlaterGlowFrame:SetPoint(\"topleft\", auraIcon, \"topleft\", -offset, offset)\n                        auraIcon.__PlaterGlowFrame:SetPoint(\"bottomright\", auraIcon, \"bottomright\", offset, -offset)\n                    end\n                else\n                    Plater.StopGlow(auraIcon, modTable.options.glowType, modTable.options.key)\n                end                \n            end\n        end\n    end\n    \nend",
					},
					["Time"] = 1673538498,
					["LoadConditions"] = {
						["talent"] = {
						},
						["group"] = {
						},
						["class"] = {
						},
						["map_ids"] = {
						},
						["role"] = {
						},
						["pvptalent"] = {
						},
						["spec"] = {
						},
						["race"] = {
						},
						["encounter_ids"] = {
						},
						["affix"] = {
						},
					},
					["url"] = "https://wago.io/turHC0a5k/7",
					["Icon"] = "INTERFACE\\ICONS\\Ability_Creature_Cursed_04",
					["Enabled"] = true,
					["Revision"] = 283,
					["semver"] = "1.0.6",
					["Author"] = "Viashi-Antonidas",
					["Desc"] = "Adds a glow to the aura if you can steal or purge the buff.",
					["Prio"] = 99,
					["Name"] = "Steal/Purge Aura Glow",
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "@scriptname Options:",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Name"] = "Option 4",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "The color of the glow ants.",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 16,
							["Desc"] = "Amount of ants in the glow effect.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 6,
							["Key"] = "antsAmount",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Ants Amount",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Ants move speed",
							["Min"] = -1,
							["Fraction"] = true,
							["Value"] = 0.25,
							["Key"] = "frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Speed",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 4,
							["Key"] = "antsLength",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Ants length",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 4,
							["Desc"] = "",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 2,
							["Key"] = "antsThickness",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Ants Thickness",
						}, -- [7]
						{
							["Type"] = 4,
							["Name"] = "Ants Border",
							["Value"] = false,
							["Key"] = "antsBorder",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Name"] = "Outer Glow",
							["Value"] = false,
							["Key"] = "outerGlow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [9]
					},
					["HooksTemp"] = {
						["Initialization"] = "function (modTable)\n    -- settings:\n    \n    -- for the LibCustomGlow implementation:\n    modTable.options = {\n        glowType = \"pixel\",\n        color = modTable.config.glowColor,--\"red\", -- all plater color types accepted, from lib: {r,g,b,a}, color of lines and opacity, from 0 to 1. Defaul value is {0.95, 0.95, 0.32, 1}\n        N = modTable.config.antsAmount, --8, -- number of lines. Defaul value is 8;\n        frequency = modTable.config.frequency, -- frequency, set to negative to inverse direction of rotation. Default value is 0.25;\n        length = modTable.config.antsLength, -- length of lines. Default value depends on region size and number of lines;\n        th = modTable.config.antsThickness, -- thickness of lines. Default value is 2;\n        xOffset = 0,\n        yOffset = 0, -- offset of glow relative to region border;\n        border = modTable.config.antsBorder, -- set to true to create border under lines;\n        key = \"StealPurgeAuraGlow\", -- key of glow, allows for multiple glows on one frame;\n    }\n    \nend\n\n\n",
						["Nameplate Updated"] = "function (self, unitId, unitFrame, envTable, modTable)\n    \n    local buffSpecialGlow = true\n    \n    \n    -- functions --\n    local auraContainers = {unitFrame.BuffFrame.PlaterBuffList}\n    \n    if (Plater.db.profile.buffs_on_aura2) then\n        auraContainers [2] = unitFrame.BuffFrame2.PlaterBuffList\n    end\n    \n    for containerID = 1, #auraContainers do\n        local auraContainer = auraContainers [containerID]\n        for index, auraIcon in ipairs (auraContainer) do\n            if (auraIcon:IsShown() and auraIcon.CanStealOrPurge) then\n                Plater.StartGlow(auraIcon, nil, modTable.options)\n                if modTable.config.outerGlow and auraIcon.__PlaterGlowFrame then\n                    auraIcon.__PlaterGlowFrame:ClearAllPoints()\n                    local offset = modTable.config.antsThickness\n                    auraIcon.__PlaterGlowFrame:SetPoint(\"topleft\", auraIcon, \"topleft\", -offset, offset)\n                    auraIcon.__PlaterGlowFrame:SetPoint(\"bottomright\", auraIcon, \"bottomright\", offset, -offset)\n                end\n            else\n                Plater.StopGlow(auraIcon, modTable.options.glowType, modTable.options.key)\n            end\n        end\n    end\n    \n    if buffSpecialGlow then\n        for _, auraIcon in ipairs (unitFrame.ExtraIconFrame.IconPool) do\n            if auraIcon:IsShown() then\n                if (auraIcon:IsShown() and auraIcon.canStealOrPurge) then\n                    Plater.StartGlow(auraIcon, nil, modTable.options)\n                    if modTable.config.outerGlow and auraIcon.__PlaterGlowFrame then\n                        auraIcon.__PlaterGlowFrame:ClearAllPoints()\n                        local offset = modTable.config.antsThickness\n                        auraIcon.__PlaterGlowFrame:SetPoint(\"topleft\", auraIcon, \"topleft\", -offset, offset)\n                        auraIcon.__PlaterGlowFrame:SetPoint(\"bottomright\", auraIcon, \"bottomright\", offset, -offset)\n                    end\n                else\n                    Plater.StopGlow(auraIcon, modTable.options.glowType, modTable.options.key)\n                end                \n            end\n        end\n    end\n    \nend",
					},
					["version"] = 7,
				}, -- [38]
			},
			["aura_width"] = 16,
			["health_statusbar_bgcolor"] = {
				0.0431372, -- [1]
				0.0431372, -- [2]
				0.0431372, -- [3]
				1, -- [4]
			},
			["buff_frame_anchor_and_size_migrated"] = true,
			["pet_width_scale"] = 0.9999999403953552,
			["quick_hide"] = true,
			["target_highlight_color"] = {
				nil, -- [1]
				0.52156862745098, -- [2]
			},
			["target_shady_alpha"] = 0.59999996423721,
			["resources"] = {
				["y_offset"] = 1,
				["y_offset_target"] = 9,
				["scale"] = 0.79999995231628,
			},
			["click_space"] = {
				115, -- [1]
			},
			["extra_icon_auras"] = {
				277242, -- [1]
			},
			["aura2_grow_direction"] = 3,
			["castbar_target_outline"] = "NONE",
			["extra_icon_show_enrage"] = true,
			["cast_statusbar_spark_color"] = {
				0.98823529411765, -- [1]
				[3] = 0.94117647058823,
			},
			["aura_cooldown_reverse"] = false,
			["aura_show_tooltip"] = true,
			["castbar_framelevel"] = 0,
			["pet_height_scale"] = 0.9999999403953552,
			["aura_x_offset"] = 0,
			["first_run3"] = true,
			["hover_highlight_alpha"] = 0.29999998211861,
			["ui_parent_scale_tune"] = 1.111111140545504,
			["ui_parent_buff_strata"] = "LOW",
			["healthbar_framelevel"] = 0,
			["health_statusbar_bgtexture"] = "PlaterBackground",
			["indicator_raidmark_anchor"] = {
				["x"] = 15.97000122070313,
			},
			["tank"] = {
				["colors"] = {
					["noaggro"] = {
						[3] = 0.19607843137255,
					},
					["pulling"] = {
						nil, -- [1]
						0, -- [2]
						0.77647058823529, -- [3]
					},
				},
			},
			["aura_tracker"] = {
				["buff_banned"] = {
					["333553"] = true,
					["281242"] = true,
					["61573"] = true,
					["206150"] = true,
					["61574"] = true,
				},
				["debuff_banned"] = {
					["331653"] = true,
					["330911"] = true,
					["299151"] = true,
					["327980"] = true,
					["284678"] = true,
					["281242"] = true,
					["342938"] = true,
					["340007"] = true,
				},
				["debuff"] = {
					224991, -- [1]
					277950, -- [2]
				},
				["debuff_tracked"] = {
					["341408"] = true,
					["324652"] = false,
					["342938"] = true,
					["281242"] = true,
				},
				["buff_tracked"] = {
					["280001"] = true,
					["328501"] = false,
					[233210] = true,
					[297133] = true,
					["329181"] = false,
					[163689] = true,
					[227931] = true,
				},
			},
			["castbar_target_show"] = true,
			["cast_statusbar_color"] = {
				nil, -- [1]
				0.85882352941176, -- [2]
				nil, -- [3]
				0.96000000089407, -- [4]
			},
			["update_throttle"] = 0.09999999403953552,
			["color_override"] = false,
			["plater_resources_personal_bar"] = false,
			["castbar_icon_show"] = false,
			["not_affecting_combat_alpha"] = 0.7999999523162842,
			["use_health_animation"] = true,
			["target_highlight_alpha"] = 1,
			["news_frame"] = {
				["PlaterNewsFrame"] = {
					["scale"] = 1,
				},
			},
			["target_shady_combat_only"] = false,
			["plater_resources_anchor"] = {
				["y"] = 40,
				["x"] = 0,
				["side"] = 8,
			},
			["script_data"] = {
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --flash duration\n    local CONFIG_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --manually create a new texture for the flash animation\n    if (not envTable.SmallFlashTexture) then\n        envTable.SmallFlashTexture = envTable.SmallFlashTexture or Plater:CreateImage (unitFrame.castBar)\n        envTable.SmallFlashTexture:SetColorTexture (1, 1, 1)\n        envTable.SmallFlashTexture:SetAllPoints()\n    end\n    \n    --manually create a flash animation using the framework\n    if (not envTable.SmallFlashAnimationHub) then \n        \n        local onPlay = function()\n            envTable.SmallFlashTexture:Show()\n        end\n        \n        local onFinished = function()\n            envTable.SmallFlashTexture:Hide()\n        end\n        \n        local animationHub = Plater:CreateAnimationHub (envTable.SmallFlashTexture, onPlay, onFinished)\n        envTable.flashIn = Plater:CreateAnimation (animationHub, \"Alpha\", 1, CONFIG_FLASH_DURATION/2, 0, .6)\n        envTable.flashOut = Plater:CreateAnimation (animationHub, \"Alpha\", 2, CONFIG_FLASH_DURATION/2, 1, 0)\n        \n        envTable.SmallFlashAnimationHub = animationHub\n    end\n    \n    envTable.flashIn:SetDuration(scriptTable.config.flashDuration / 2)\n    envTable.flashOut:SetDuration(scriptTable.config.flashDuration / 2)\n    envTable.SmallFlashTexture:SetColorTexture (Plater:ParseColors(scriptTable.config.flashColor))\n    \nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.SmallFlashAnimationHub:Stop()\n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    \n    \nend\n\n\n",
					["Time"] = 1669325410,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 662,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Plays a small animation when the cast start.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 3",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.6,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Flash Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "flashColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [6]
					},
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.SmallFlashAnimationHub:Play()\n    \nend\n\n\n",
					["Name"] = "Cast - Small Alert [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						376851, -- [1]
						396044, -- [2]
						373932, -- [3]
						397801, -- [4]
						208165, -- [5]
						392576, -- [6]
						198750, -- [7]
						387843, -- [8]
						387411, -- [9]
						211299, -- [10]
						198595, -- [11]
						198934, -- [12]
						198962, -- [13]
						156722, -- [14]
						377991, -- [15]
					},
					["Desc"] = "Flashes the Cast Bar when a spell in the trigger list is Cast. Add spell in the Add Trigger field.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar",
				}, -- [1]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --color to set the nameplate\n    envTable.NameplateColor = \"gray\"\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --only change the nameplate color in combat\n    if (InCombatLockdown()) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n\n\n",
					["Time"] = 1620346873,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --color to set the nameplate\n    envTable.NameplateColor = \"gray\"\n    \nend\n\n\n",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 110,
					["Options"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "When an aura makes the unit invulnarable and you don't want to attack it. Add spell in the Add Trigger field.",
					["SpellIds"] = {
						261265, -- [1]
						261266, -- [2]
						271590, -- [3]
					},
					["Prio"] = 99,
					["Name"] = "Aura - Invalidate Unit [Plater]",
					["PlaterCore"] = 1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --only change the nameplate color in combat\n    if (InCombatLockdown()) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_invalid",
				}, -- [2]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --creates a glow around the icon\n    envTable.buffIconGlow = envTable.buffIconGlow or Plater.CreateIconGlow (self, scriptTable.config.glowColor)\n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Hide()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        Plater.StopDotAnimation(self, envTable.dotAnimation)\n    end\n    \n    \nend",
					["OptionsValues"] = {
					},
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    \n    \n    \nend",
					["Time"] = 1669327144,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 632,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Buff in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Glow Enabled",
							["Value"] = false,
							["Key"] = "glowEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.403921568627451, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Dots Enabled",
							["Value"] = true,
							["Key"] = "dotsEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.3215686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dots Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [8]
					},
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Show()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        envTable.dotAnimation = Plater.PlayDotAnimation(self, 6, scriptTable.config.dotsColor, 6, 3) \n    end\n    \nend\n\n\n\n\n",
					["Name"] = "Aura - Buff Alert [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						398151, -- [1]
						375596, -- [2]
					},
					["Desc"] = "Add the buff name in the trigger box.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura",
				}, -- [3]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.castBar, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1673994690,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_darkorange",
					["Enabled"] = true,
					["Revision"] = 828,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Highlight a very important cast applying several effects into the Cast Bar. Add spell in the Add Trigger field.",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.castBar, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\n    \n    --Dominator on Shadowmoon Burial Grounds\n    if (envTable._SpellID == 154327) then\n        if (UnitHealth(unitId) == UnitHealthMax(unitId)) then\n            if (envTable._Duration == 604800) then\n                Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, {1, 0, 0, 1}, envTable)\n            end\n        end\n    end\nend",
					["SpellIds"] = {
						373046, -- [1]
						372863, -- [2]
						164686, -- [3]
						153072, -- [4]
						153680, -- [5]
						196497, -- [6]
						388886, -- [7]
						387145, -- [8]
						384365, -- [9]
						152964, -- [10]
						398150, -- [11]
						152801, -- [12]
						397878, -- [13]
						397914, -- [14]
						183263, -- [15]
						3636, -- [16]
						376171, -- [17]
						350687, -- [18]
						372735, -- [19]
						373017, -- [20]
						392488, -- [21]
					},
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Plays a big animation when the cast start.",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Flash:",
							["Name"] = "Flash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.8,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [6]
						{
							["Type"] = 1,
							["Key"] = "flashColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Flash Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Name"] = "Shake",
							["Value"] = "Shake:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 5,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Amplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 40,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Frequency",
						}, -- [12]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Key"] = "option14",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 8,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot Y Offset",
						}, -- [17]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Key"] = "option19",
							["Value"] = "Cast Bar",
							["Name"] = "Option 19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Use Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Key"] = "castBarColor",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
					},
					["version"] = -1,
					["Name"] = "Cast - Very Important [Plater]",
					["NpcNames"] = {
					},
				}, -- [4]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --creates a glow around the icon\n    envTable.buffIconGlow = envTable.buffIconGlow or Plater.CreateIconGlow (self, scriptTable.config.glowColor)\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Hide()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        Plater.StopDotAnimation(self, envTable.dotAnimation)\n    end\n    \n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Time"] = 1669327144,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 368,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Buff in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Glow Enabled",
							["Value"] = false,
							["Key"] = "glowEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.403921568627451, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Dots Enabled",
							["Value"] = true,
							["Key"] = "dotsEnabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.3215686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dots Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [8]
					},
					["Author"] = "Tercioo-Sylvanas",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (scriptTable.config.glowEnabled) then\n        envTable.buffIconGlow:Show()\n    end\n    \n    if (scriptTable.config.dotsEnabled) then\n        envTable.dotAnimation = Plater.PlayDotAnimation(self, 6, scriptTable.config.dotsColor, 6, 3) \n    end\nend\n\n\n",
					["Name"] = "Aura - Debuff Alert [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "Add the debuff name in the trigger box.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura",
				}, -- [5]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local movingArrowTexture = unitFrame._movingArrowTexture\n    if (not movingArrowTexture) then\n        movingArrowTexture = self:CreateTexture(nil, \"artwork\", nil, 6)\n        unitFrame._movingArrowTexture = movingArrowTexture\n    end\n    \n    envTable.movingAnimation = envTable.movingAnimation or Plater:CreateAnimationHub (unitFrame._movingArrowTexture, \n        function() \n            unitFrame._movingArrowTexture:Show() \n            unitFrame._movingArrowTexture:SetPoint(\"left\", 0, 0)\n        end, \n        function() unitFrame._movingArrowTexture:Hide() end)\n    \n    envTable.movingAnimation:SetLooping (\"REPEAT\")\n    \n    envTable.arrowAnimation = envTable.arrowAnimation or Plater:CreateAnimation (envTable.movingAnimation, \"translation\", 1, 0.20, self:GetWidth()-16, 0)\n    \n    envTable.arrowAnimation:SetDuration(scriptTable.config.animSpeed)\nend\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.movingAnimation:Stop()\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    unitFrame._movingArrowTexture:SetAlpha(scriptTable.config.arrowAlpha)\n    \n    local percent = envTable.movingAnimation:GetProgress()\n    \n    if (percent < 0.4) then\n        local value = Lerp(0.01, scriptTable.config.arrowAlpha, percent) or 0\n        unitFrame._movingArrowTexture:SetAlpha(Saturate(value))\n        \n    elseif (percent > 0.6) then\n        local value = Lerp(scriptTable.config.arrowAlpha, 0.01, percent) or 0\n        unitFrame._movingArrowTexture:SetAlpha(Saturate(value))\n    end\n    \n    --unitFrame._movingArrowTexture:SetAlpha(1)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1670202265,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 620,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces an effect to indicate the spell will hit players in front of the enemy.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 4",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 3",
							["Value"] = 0,
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Set the alpha of the moving arrow",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.73,
							["Key"] = "arrowAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Alpha",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Time that takes for an arrow to travel from the to right.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "animSpeed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Animation Speed",
						}, -- [6]
						{
							["Type"] = 4,
							["Name"] = "Use White Arrow",
							["Value"] = false,
							["Key"] = "desaturateArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the arrow color will be desaturated.",
						}, -- [7]
					},
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame._movingArrowTexture:SetTexture([[Interface\\PETBATTLES\\PetBattle-StatIcons]])\n    unitFrame._movingArrowTexture:SetSize(16, self:GetHeight() - 2)\n    unitFrame._movingArrowTexture:SetTexCoord(unpack({0, 15/32, 18/32, 30/32}))\n    unitFrame._movingArrowTexture:SetAlpha(scriptTable.config.arrowAlpha)\n    unitFrame._movingArrowTexture:SetDesaturated(scriptTable.config.desaturateArrow)    \n    \n    unitFrame._movingArrowTexture:SetParent(self.FrameOverlay)\n    unitFrame._movingArrowTexture:SetDrawLayer(\"overlay\",  7)\n    \n    envTable.arrowAnimation:SetDuration(scriptTable.config.animSpeed)\n    envTable.movingAnimation:Play()\nend\n\n\n",
					["Name"] = "Cast - Frontal Cone [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						375943, -- [1]
						385958, -- [2]
						388623, -- [3]
						377034, -- [4]
						374361, -- [5]
						381525, -- [6]
						386660, -- [7]
						384699, -- [8]
						153501, -- [9]
						153686, -- [10]
						154442, -- [11]
						192018, -- [12]
						219488, -- [13]
						372087, -- [14]
						391726, -- [15]
						391723, -- [16]
						377383, -- [17]
						388976, -- [18]
						370764, -- [19]
						387067, -- [20]
						391118, -- [21]
						391136, -- [22]
						382233, -- [23]
						209027, -- [24]
						212031, -- [25]
						207261, -- [26]
						207979, -- [27]
						198888, -- [28]
						199805, -- [29]
						199050, -- [30]
						191508, -- [31]
						152792, -- [32]
						153395, -- [33]
					},
					["Desc"] = "Does an animation for casts that affect the frontal area of the enemy. Add spell in the Add Trigger field.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_frontal",
				}, -- [6]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.BuffFrame, \"top\", 0, 10);    \n    \n    envTable.FixateIcon = Plater:CreateImage (unitFrame, 236188, 16, 16, \"overlay\");\n    envTable.FixateIcon:SetPoint (\"bottom\", envTable.FixateTarget, \"top\", 0, 4);    \n    \n    envTable.FixateTarget:Hide()\n    envTable.FixateIcon:Hide()\nend\n\n--165560 = Gormling Larva - MTS\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:Hide()\n    envTable.FixateIcon:Hide()\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    local targetName = UnitName (unitId .. \"target\");\n    if (targetName) then\n        local _, class = UnitClass (unitId .. \"target\");\n        targetName = Plater.SetTextColorByClass (unitId .. \"target\", targetName);\n        envTable.FixateTarget.text = targetName;\n        \n        envTable.FixateTarget:Show();\n        envTable.FixateIcon:Show();\n    end    \nend\n\n\n",
					["Time"] = 1604239880,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 269,
					["Options"] = {
					},
					["Author"] = "Celian-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n\n\n\n\n",
					["Desc"] = "Show above the nameplate who is the player fixated",
					["Name"] = "Fixate [Plater]",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["version"] = -1,
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["semver"] = "",
					["Icon"] = 1029718,
				}, -- [7]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount = Plater:CreateLabel (unitFrame, \"\", 16, \"silver\");\n    envTable.EnergyAmount:SetPoint (\"bottom\", unitFrame, \"top\", 0, 18);\nend\n\n--[=[\n\n\n--]=]",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount:Hide()\nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount:Show()\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount.text = \"\" .. UnitPower (unitId);\nend\n\n\n",
					["Time"] = 1609154874,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount = Plater:CreateLabel (unitFrame, \"\", 16, \"silver\");\n    envTable.EnergyAmount:SetPoint (\"bottom\", unitFrame, \"top\", 0, 18);\nend\n\n--[=[\n\n\n--]=]",
					["NpcNames"] = {
						"Guardian of Yogg-Saron", -- [1]
					},
					["Enabled"] = true,
					["Revision"] = 136,
					["Options"] = {
					},
					["Author"] = "Celian-Sylvanas",
					["Desc"] = "Show the energy amount above the nameplate",
					["SpellIds"] = {
					},
					["Prio"] = 99,
					["Name"] = "UnitPower [Plater]",
					["PlaterCore"] = 1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount.text = \"\" .. UnitPower (unitId);\nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount:Show()\nend\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.EnergyAmount:Hide()\nend\n\n\n",
					["Icon"] = 136048,
				}, -- [8]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not Plater.IsShowingCastBarTest) then\n        --don't execute on battlegrounds and arenas\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end    \n    end\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
						["castbarColor"] = {
							1, -- [1]
							0.4313725829124451, -- [2]
							0, -- [3]
							1, -- [4]
						},
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (not Plater.IsShowingCastBarTest) then\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    --set the color of the cast bar to dark orange (only if can be interrupted)\n    --Plater auto set this color to default when a new cast starts, no need to reset this value at OnHide.    \n    if (envTable._CanInterrupt) then\n        if (scriptTable.config.useCastbarColor) then\n            self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n        end\n    end\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["Temp_Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Time"] = 1670748227,
					["Enabled"] = true,
					["url"] = "",
					["NpcNames"] = {
					},
					["semver"] = "",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not Plater.IsShowingCastBarTest) then\n        --don't execute on battlegrounds and arenas\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end    \n    end\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n",
					["Revision"] = 1225,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces a notable effect in the cast bar when a spell from the 'Triggers' starts to cast.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Name"] = "Flash Duration",
							["Value"] = 0.4,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Name"] = "Cast Bar Height Mod",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "castBarHeight",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Fraction"] = false,
							["Value"] = 40,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (not Plater.IsShowingCastBarTest) then\n        if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\" or Plater.ZoneInstanceType == \"none\") then\n            return\n        end\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    --set the color of the cast bar to dark orange (only if can be interrupted)\n    --Plater auto set this color to default when a new cast starts, no need to reset this value at OnHide.    \n    if (envTable._CanInterrupt) then\n        if (scriptTable.config.useCastbarColor) then\n            self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n        end\n    end\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["SpellIds"] = {
						396640, -- [1]
						372743, -- [2]
						377389, -- [3]
						396812, -- [4]
						387955, -- [5]
						386546, -- [6]
						384808, -- [7]
						386024, -- [8]
						387615, -- [9]
						387606, -- [10]
						225100, -- [11]
						211401, -- [12]
						211470, -- [13]
						215433, -- [14]
						192563, -- [15]
						198959, -- [16]
						152818, -- [17]
						156776, -- [18]
						398206, -- [19]
						153524, -- [20]
						396073, -- [21]
						396018, -- [22]
						345202, -- [23]
						377950, -- [24]
						372223, -- [25]
						385578, -- [26]
						377488, -- [27]
						375596, -- [28]
						263365, -- [29]
						388392, -- [30]
						395859, -- [31]
						395872, -- [32]
						397914, -- [33]
						209410, -- [34]
						215433, -- [35]
						384194, -- [36]
						392451, -- [37]
						392924, -- [38]
						397889, -- [39]
					},
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Flash, Bounce and Red Color the CastBar border when when an important cast is happening. Add spell in the Add Trigger field.",
					["version"] = -1,
					["Prio"] = 99,
					["Name"] = "Cast - Big Alert [Plater]",
					["PlaterCore"] = 1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
				}, -- [9]
				{
					["ConstructorCode"] = "--todo: add npc ids for multilanguage support\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.TextAboveNameplate = \"** On You **\"\n    envTable.NameplateColor = \"green\"\n    \n    --label to show the text above the nameplate\n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.healthBar, \"top\", 0, 30);\n    \n    --the spell casted by the npc in the trigger list needs to be in the list below as well\n    local spellList = {\n        [321891] = \"Freeze Tag Fixation\", --Illusionary Vulpin - MTS\n        \n    }\n    \n    --build the list with localized spell names\n    envTable.FixateDebuffs = {}\n    for spellID, enUSSpellName in pairs (spellList) do\n        local localizedSpellName = GetSpellInfo (spellID)\n        envTable.FixateDebuffs [localizedSpellName or enUSSpellName] = true\n    end\n    \n    --debug - smuggled crawg\n    envTable.FixateDebuffs [\"Jagged Maw\"] = true\n    \nend\n\n--[=[\nNpcIDs:\n136461: Spawn of G'huun (mythic uldir G'huun)\n\n--]=]\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:SetText (\"\")\n    envTable.FixateTarget:Hide()\n    \n    envTable.IsFixated = false\n    \n    Plater.RefreshNameplateColor (unitFrame)\nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --swap this to true when it is fixated\n    local isFixated = false\n    \n    --check the debuffs the player has and see if any of these debuffs has been placed by this unit\n    for debuffId = 1, 40 do\n        local name, texture, count, debuffType, duration, expirationTime, caster = UnitDebuff (\"player\", debuffId)\n        \n        --cancel the loop if there's no more debuffs on the player\n        if (not name) then \n            break \n        end\n        \n        --check if the owner of the debuff is this unit\n        if (envTable.FixateDebuffs [name] and caster and UnitIsUnit (caster, unitId)) then\n            --the debuff the player has, has been placed by this unit, set the name above the unit name\n            envTable.FixateTarget:SetText (envTable.TextAboveNameplate)\n            envTable.FixateTarget:Show()\n            Plater.SetNameplateColor (unitFrame,  envTable.NameplateColor)\n            isFixated = true\n            \n            if (not envTable.IsFixated) then\n                envTable.IsFixated = true\n                Plater.FlashNameplateBody (unitFrame, \"fixate\", .2)\n            end\n        end\n        \n    end\n    \n    --check if the nameplate color is changed but isn't fixated any more\n    if (not isFixated and envTable.IsFixated) then\n        --refresh the nameplate color\n        Plater.RefreshNameplateColor (unitFrame)\n        --reset the text\n        envTable.FixateTarget:SetText (\"\")\n        \n        envTable.IsFixated = false\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1610463138,
					["url"] = "",
					["Icon"] = 841383,
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    envTable.FixateTarget:SetText (\"\")\n    envTable.FixateTarget:Hide()\n    \n    envTable.IsFixated = false\n    \n    Plater.RefreshNameplateColor (unitFrame)\nend\n\n\n",
					["Revision"] = 267,
					["semver"] = "",
					["Desc"] = "When an enemy places a debuff and starts to chase you. This script changes the nameplate color and place your name above the nameplate as well.",
					["Name"] = "Fixate On You [Plater]",
					["Author"] = "Tecno-Azralon",
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --swap this to true when it is fixated\n    local isFixated = false\n    \n    --check the debuffs the player has and see if any of these debuffs has been placed by this unit\n    for debuffId = 1, 40 do\n        local name, texture, count, debuffType, duration, expirationTime, caster = UnitDebuff (\"player\", debuffId)\n        \n        --cancel the loop if there's no more debuffs on the player\n        if (not name) then \n            break \n        end\n        \n        --check if the owner of the debuff is this unit\n        if (envTable.FixateDebuffs [name] and caster and UnitIsUnit (caster, unitId)) then\n            --the debuff the player has, has been placed by this unit, set the name above the unit name\n            envTable.FixateTarget:SetText (envTable.TextAboveNameplate)\n            envTable.FixateTarget:Show()\n            Plater.SetNameplateColor (unitFrame,  envTable.NameplateColor)\n            isFixated = true\n            \n            if (not envTable.IsFixated) then\n                envTable.IsFixated = true\n                Plater.FlashNameplateBody (unitFrame, \"fixate\", .2)\n            end\n        end\n        \n    end\n    \n    --check if the nameplate color is changed but isn't fixated any more\n    if (not isFixated and envTable.IsFixated) then\n        --refresh the nameplate color\n        Plater.RefreshNameplateColor (unitFrame)\n        --reset the text\n        envTable.FixateTarget:SetText (\"\")\n        \n        envTable.IsFixated = false\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["version"] = -1,
					["Prio"] = 99,
					["SpellIds"] = {
						"spawn of g'huun", -- [1]
						"smuggled crawg", -- [2]
						"sergeant bainbridge", -- [3]
						"blacktooth scrapper", -- [4]
						"irontide grenadier", -- [5]
						"feral bloodswarmer", -- [6]
						"earthrager", -- [7]
						"crawler mine", -- [8]
						"rezan", -- [9]
					},
					["PlaterCore"] = 1,
					["Options"] = {
					},
					["Enabled"] = true,
					["NpcNames"] = {
					},
					["Temp_ConstructorCode"] = "--todo: add npc ids for multilanguage support\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --settings\n    envTable.TextAboveNameplate = \"** On You **\"\n    envTable.NameplateColor = \"green\"\n    \n    --label to show the text above the nameplate\n    envTable.FixateTarget = Plater:CreateLabel (unitFrame);\n    envTable.FixateTarget:SetPoint (\"bottom\", unitFrame.healthBar, \"top\", 0, 30);\n    \n    --the spell casted by the npc in the trigger list needs to be in the list below as well\n    local spellList = {\n        [321891] = \"Freeze Tag Fixation\", --Illusionary Vulpin - MTS\n        \n    }\n    \n    --build the list with localized spell names\n    envTable.FixateDebuffs = {}\n    for spellID, enUSSpellName in pairs (spellList) do\n        local localizedSpellName = GetSpellInfo (spellID)\n        envTable.FixateDebuffs [localizedSpellName or enUSSpellName] = true\n    end\n    \n    --debug - smuggled crawg\n    envTable.FixateDebuffs [\"Jagged Maw\"] = true\n    \nend\n\n--[=[\nNpcIDs:\n136461: Spawn of G'huun (mythic uldir G'huun)\n\n--]=]\n\n\n\n\n",
				}, -- [10]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --color to set the nameplate\n    envTable.NameplateColor = \"pink\" \n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    \nend\n\n\n",
					["Time"] = 1541606626,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --color to set the nameplate\n    envTable.NameplateColor = \"pink\" \n    \nend\n\n\n",
					["NpcNames"] = {
					},
					["Enabled"] = false,
					["Revision"] = 45,
					["Author"] = "抹了油的大叔-白银之手",
					["Desc"] = "NameplaterColor with Special Buff ID",
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    \nend\n\n\n",
					["SpellIds"] = {
						277242, -- [1]
					},
					["PlaterCore"] = 1,
					["Name"] = "NameplaterColor with Special Buff ID",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Icon"] = "INTERFACE\\ICONS\\Achievement_PVP_P_01",
				}, -- [11]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings\n    envTable.NameplateSizeOffset = scriptTable.config.castBarHeight\n    envTable.ShowArrow = scriptTable.config.showArrow\n    envTable.ArrowAlpha = scriptTable.config.arrowAlpha\n    \n    --creates the spark to show the cast progress inside the health bar\n    envTable.overlaySpark = envTable.overlaySpark or Plater:CreateImage (unitFrame.healthBar)\n    envTable.overlaySpark:SetBlendMode (\"ADD\")\n    envTable.overlaySpark.width = 16\n    envTable.overlaySpark.height = 36\n    envTable.overlaySpark.alpha = .9\n    envTable.overlaySpark.texture = [[Interface\\AddOns\\Plater\\images\\spark3]]\n    \n    envTable.topArrow = envTable.topArrow or Plater:CreateImage (unitFrame.healthBar)\n    envTable.topArrow:SetBlendMode (\"ADD\")\n    envTable.topArrow.width = scriptTable.config.arrowWidth\n    envTable.topArrow.height = scriptTable.config.arrowHeight\n    envTable.topArrow.alpha = envTable.ArrowAlpha\n    envTable.topArrow.texture = [[Interface\\BUTTONS\\Arrow-Down-Up]]\n    \n    --scale animation\n    envTable.smallScaleAnimation = envTable.smallScaleAnimation or Plater:CreateAnimationHub (unitFrame.healthBar)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 1, 0.075, 1, 1, 1.08, 1.08)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 2, 0.075, 1, 1, 0.95, 0.95)    \n    --envTable.smallScaleAnimation:Play() --envTable.smallScaleAnimation:Stop()\n    \nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    \n    envTable.overlaySpark:Hide()\n    envTable.topArrow:Hide()\n    \n    Plater.RefreshNameplateColor (unitFrame)\n    \n    envTable.smallScaleAnimation:Stop()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)\n    \n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --update the percent\n    envTable.overlaySpark:SetPoint (\"left\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100)-9, 0)\n    \n    envTable.topArrow:SetPoint (\"bottomleft\", unitFrame.healthBar, \"topleft\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100) - 4, 2 )\n    \n    --forces the script to run the update as fast as the game framerate\n    self.ThrottleUpdate = 0\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \n    local dotSpeed = abs(envTable._Duration - envTable._RemainingTime) + 1.5\n    envTable.dotAnimation.textureInfo.speedMultiplier = dotSpeed\nend\n\n\n\n\n",
					["Time"] = 1670201853,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 533,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 3,
							["Key"] = "castBarHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Changes the cast bar color to this one.",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 5,
							["Name"] = "Arrow:",
							["Value"] = "Arrow:",
							["Key"] = "option6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Show Arrow",
							["Value"] = true,
							["Key"] = "showArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above the nameplate showing the cast bar progress.",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Arrow alpha.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 1,
							["Key"] = "arrowAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Alpha",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Width.",
							["Min"] = 4,
							["Name"] = "Arrow Width",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "arrowWidth",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Height.",
							["Min"] = 4,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "arrowHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Arrow Height",
						}, -- [8]
						{
							["Type"] = 6,
							["Name"] = "Option 13",
							["Value"] = 0,
							["Key"] = "option13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 5,
							["Name"] = "Dot Animation:",
							["Value"] = "Dot Animation:",
							["Key"] = "option12",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 1,
							["Name"] = "Dot Color",
							["Value"] = {
								1, -- [1]
								0.615686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "dotColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dot animation.",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot X Offset",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 4,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot Y Offset",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot Y Offset",
						}, -- [13]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "Option 18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 5,
							["Key"] = "option17",
							["Value"] = "Nameplate Color",
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [15]
						{
							["Type"] = 4,
							["Name"] = "Change Nameplate Color",
							["Value"] = false,
							["Key"] = "useNameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [16]
						{
							["Type"] = 1,
							["Key"] = "healthBarColor",
							["Value"] = {
								1, -- [1]
								0.1843137294054031, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Health Bar Color",
						}, -- [17]
					},
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.overlaySpark:Show()\n    \n    if (envTable.ShowArrow) then\n        envTable.topArrow:Show()\n    end\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    envTable.smallScaleAnimation:Play()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    envTable.overlaySpark.height = nameplateHeight + 5\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    Plater.SetCastBarColorForScript(self, true, scriptTable.config.castBarColor, envTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.healthBarColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end       \nend\n\n\n\n\n\n\n",
					["Name"] = "Explosion Affix M+ [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						240446, -- [1]
						385339, -- [2]
						198077, -- [3]
						210261, -- [4]
						360857, -- [5]
						273577, -- [6]
					},
					["Desc"] = "Apply several animations when the explosion orb cast starts on a Mythic Dungeon with Explosion Affix",
					["semver"] = "",
					["Icon"] = 2175503,
				}, -- [12]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings:\n    do\n        \n        --change the nameplate color to this color\n        --can use color names: \"red\", \"yellow\"\n        --can use color hex: \"#FF0000\", \"#FFFF00\"\n        --con use color table: {1, 0, 0}, {1, 1, 0}\n        \n        envTable.Color = \"green\"\n        \n        --if true, it'll replace the health info with the unit name\n        envTable.ReplaceHealthWithName = false\n        \n        --use flash when the unit is shown in the screen\n        envTable.FlashNameplate = true\n        \n    end\n    \n    --private:\n    do\n        --create a flash for when the unit if shown\n        envTable.smallFlash = envTable.smallFlash or Plater.CreateFlash (unitFrame.healthBar, 0.15, 1, envTable.Color)\n        \n    end\n    \nend\n\n--[=[\n\nNpc IDS:\n\n141851: Spawn of G'Huun on Mythic Dungeons\n\n\n--]=]\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --make plater refresh the nameplate color\n    Plater.RefreshNameplateColor (unitFrame)\n    \n        envTable.smallFlash:Stop()\n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if can flash the nameplate\n    if (envTable.FlashNameplate) then\n        envTable.smallFlash:Play()\n    end\n    \nend\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --adjust the nameplate color\n    Plater.SetNameplateColor (unitFrame, envTable.Color)\n    \n    --check if can replace the health amount with the unit name\n    if (envTable.ReplaceHealthWithName) then\n        \n        local healthPercent = format (\"%.1f\", unitFrame.healthBar.CurrentHealth / unitFrame.healthBar.CurrentHealthMax *100)\n        \n        unitFrame.healthBar.lifePercent:SetText (unitFrame.namePlateUnitName .. \"  (\" .. healthPercent  .. \"%)\")\n        \n    end\n    \nend\n\n\n",
					["Time"] = 1613211631,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --settings:\n    do\n        \n        --change the nameplate color to this color\n        --can use color names: \"red\", \"yellow\"\n        --can use color hex: \"#FF0000\", \"#FFFF00\"\n        --con use color table: {1, 0, 0}, {1, 1, 0}\n        \n        envTable.Color = \"green\"\n        \n        --if true, it'll replace the health info with the unit name\n        envTable.ReplaceHealthWithName = false\n        \n        --use flash when the unit is shown in the screen\n        envTable.FlashNameplate = true\n        \n    end\n    \n    --private:\n    do\n        --create a flash for when the unit if shown\n        envTable.smallFlash = envTable.smallFlash or Plater.CreateFlash (unitFrame.healthBar, 0.15, 1, envTable.Color)\n        \n    end\n    \nend\n\n--[=[\n\nNpc IDS:\n\n141851: Spawn of G'Huun on Mythic Dungeons\n\n\n--]=]\n\n\n\n\n",
					["NpcNames"] = {
						"141851", -- [1]
					},
					["Enabled"] = true,
					["Revision"] = 70,
					["Options"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Add a unitID or unit name in 'Add Trigger' entry. See the constructor script for options.",
					["SpellIds"] = {
					},
					["Prio"] = 99,
					["Name"] = "Color Change [Plater]",
					["PlaterCore"] = 1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --adjust the nameplate color\n    Plater.SetNameplateColor (unitFrame, envTable.Color)\n    \n    --check if can replace the health amount with the unit name\n    if (envTable.ReplaceHealthWithName) then\n        \n        local healthPercent = format (\"%.1f\", unitFrame.healthBar.CurrentHealth / unitFrame.healthBar.CurrentHealthMax *100)\n        \n        unitFrame.healthBar.lifePercent:SetText (unitFrame.namePlateUnitName .. \"  (\" .. healthPercent  .. \"%)\")\n        \n    end\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --check if can flash the nameplate\n    if (envTable.FlashNameplate) then\n        envTable.smallFlash:Play()\n    end\n    \nend\n\n\n\n\n\n\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --make plater refresh the nameplate color\n    Plater.RefreshNameplateColor (unitFrame)\n    \n        envTable.smallFlash:Stop()\n    \nend\n\n\n",
					["Icon"] = 135024,
				}, -- [13]
				{
					["ConstructorCode"] = "--gray lines are comments and doesn't affect the code\n\n--1) add the aura you want by typing its name or spellID into the \"Add Trigger\" and click the \"Add\" button.\n--2) the border will use the default color set below, to a custom color type aura name and the color you want in the BorderColorByAura table.\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --default color if the aura name isn't found in the Color By Aura table below\n    envTable.DefaultBorderColor = \"orange\"\n    \n    --transparency, affect all borders\n    envTable.BorderAlpha = 1.0\n    \n    --add the aura name and the color, \n    envTable.BorderColorByAura = {\n        \n        --examples:\n        --[\"Aura Name\"] = \"yellow\", --using regular aura name | using the name of the color\n        --[\"aura name\"] = \"#FFFF00\", --using lower case in the aura name |using html #hex for the color\n        --[54214] = {1, 1, 0}, --using the spellID instead of the name | using rgb table (0 to 1) for the color\n        --color table uses zero to one values: 255 = 1.0, 127 = 0.5, orange color = {1, 0.7, 0}\n        \n        --add your custom border colors below:\n        \n        [\"Aura Name\"] = {1, .5, 0}, --example to copy/paste\n        \n    }\n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --reset the border color\n    self:SetBackdropBorderColor (0, 0, 0, 0)\n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --get the aura name in lower case\n    local auraLowerName = string.lower (envTable._SpellName)\n    \n    --attempt to get a custom color added by the user in the constructor script\n    local hasCustomBorderColor = envTable.BorderColorByAura [auraLowerName] or envTable.BorderColorByAura [envTable._SpellName] or envTable.BorderColorByAura [envTable._SpellID]\n    \n    --save the custom color\n    envTable.CustomBorderColor = hasCustomBorderColor\n    \nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --get the custom color added by the user or the default color\n    local color = envTable.CustomBorderColor or envTable.DefaultBorderColor\n    --parse the color since it can be a color name, hex or color table\n    local r, g, b = DetailsFramework:ParseColors (color)\n    \n    --set the border color\n    self:SetBackdropBorderColor (r, g, b, envTable.BorderAlpha)\n    \nend\n\n\n\n\n",
					["Time"] = 1620152446,
					["Temp_ConstructorCode"] = "--gray lines are comments and doesn't affect the code\n\n--1) add the aura you want by typing its name or spellID into the \"Add Trigger\" and click the \"Add\" button.\n--2) the border will use the default color set below, to a custom color type aura name and the color you want in the BorderColorByAura table.\n\nfunction (self, unitId, unitFrame, envTable)\n    \n    --default color if the aura name isn't found in the Color By Aura table below\n    envTable.DefaultBorderColor = \"orange\"\n    \n    --transparency, affect all borders\n    envTable.BorderAlpha = 1.0\n    \n    --add the aura name and the color, \n    envTable.BorderColorByAura = {\n        \n        --examples:\n        --[\"Aura Name\"] = \"yellow\", --using regular aura name | using the name of the color\n        --[\"aura name\"] = \"#FFFF00\", --using lower case in the aura name |using html #hex for the color\n        --[54214] = {1, 1, 0}, --using the spellID instead of the name | using rgb table (0 to 1) for the color\n        --color table uses zero to one values: 255 = 1.0, 127 = 0.5, orange color = {1, 0.7, 0}\n        \n        --add your custom border colors below:\n        \n        [\"Aura Name\"] = {1, .5, 0}, --example to copy/paste\n        \n    }\n    \n    \nend\n\n\n\n\n",
					["NpcNames"] = {
					},
					["Enabled"] = false,
					["Revision"] = 48,
					["Options"] = {
					},
					["Author"] = "Izimode-Azralon",
					["Desc"] = "Add a border to an aura icon. Add the aura into the Add Trigger entry. You can customize the icon color at the constructor script.",
					["SpellIds"] = {
					},
					["Prio"] = 99,
					["Name"] = "Aura - Border Color [Plater]",
					["PlaterCore"] = 1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --get the custom color added by the user or the default color\n    local color = envTable.CustomBorderColor or envTable.DefaultBorderColor\n    --parse the color since it can be a color name, hex or color table\n    local r, g, b = DetailsFramework:ParseColors (color)\n    \n    --set the border color\n    self:SetBackdropBorderColor (r, g, b, envTable.BorderAlpha)\n    \nend\n\n\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --get the aura name in lower case\n    local auraLowerName = string.lower (envTable._SpellName)\n    \n    --attempt to get a custom color added by the user in the constructor script\n    local hasCustomBorderColor = envTable.BorderColorByAura [auraLowerName] or envTable.BorderColorByAura [envTable._SpellName] or envTable.BorderColorByAura [envTable._SpellID]\n    \n    --save the custom color\n    envTable.CustomBorderColor = hasCustomBorderColor\n    \nend\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --reset the border color\n    self:SetBackdropBorderColor (0, 0, 0, 0)\n    \nend\n\n\n",
					["Icon"] = 133006,
				}, -- [14]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings (require a /reload after editing any setting)\n    do\n        --blink and glow\n        envTable.BlinkEnabled = scriptTable.config.blinkEnabled\n        envTable.GlowEnabled = scriptTable.config.glowEnabled \n        envTable.ChangeNameplateColor = scriptTable.config.changeNameplateColor;\n        envTable.TimeLeftToBlink = scriptTable.config.timeleftToBlink;\n        envTable.BlinkSpeed = scriptTable.config.blinkSpeed; \n        envTable.BlinkColor = scriptTable.config.blinkColor; \n        envTable.BlinkMaxAlpha = scriptTable.config.blinkMaxAlpha; \n        envTable.NameplateColor = scriptTable.config.nameplateColor; \n        \n        --text color\n        envTable.TimerColorEnabled = scriptTable.config.timerColorEnabled \n        envTable.TimeLeftWarning = scriptTable.config.timeLeftWarning;\n        envTable.TimeLeftCritical = scriptTable.config.timeLeftCritical;\n        envTable.TextColor_Warning = scriptTable.config.warningColor; \n        envTable.TextColor_Critical = scriptTable.config.criticalColor; \n        \n        --list of spellIDs to ignore\n        envTable.IgnoredSpellID = {\n            [12] = true, --use a simple comma here\n            [13] = true,\n        }\n    end\n    \n    \n    --private\n    do\n        --if not envTable.blinkTexture then\n        envTable.blinkTexture = Plater:CreateImage (self, \"\", 1, 1, \"overlay\")\n        envTable.blinkTexture:SetPoint ('center', 0, 0)\n        envTable.blinkTexture:Hide()\n        \n        local onPlay = function()\n            envTable.blinkTexture:Show() \n            envTable.blinkTexture.color = envTable.BlinkColor\n        end\n        local onStop = function()\n            envTable.blinkTexture:Hide()  \n        end\n        envTable.blinkAnimation = Plater:CreateAnimationHub (envTable.blinkTexture, onPlay, onStop)\n        Plater:CreateAnimation (envTable.blinkAnimation, \"ALPHA\", 1, envTable.BlinkSpeed / 2, 0, envTable.BlinkMaxAlpha)\n        Plater:CreateAnimation (envTable.blinkAnimation, \"ALPHA\", 2, envTable.BlinkSpeed / 2, envTable.BlinkMaxAlpha, 0)\n        --end\n        \n        envTable.glowEffect = envTable.glowEffect or self.overlay or Plater.CreateIconGlow (self)\n        --envTable.glowEffect = envTable.glowEffect or Plater.CreateIconGlow (self)\n        --envTable.glowEffect:Show() --envTable.glowEffect:Hide()\n        \n    end\n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.blinkAnimation:Stop()\n    envTable.blinkTexture:Hide()\n    envTable.blinkAnimation:Stop()\n    envTable.glowEffect:Stop()\n    Plater:SetFontColor (self.Cooldown.Timer, Plater.db.profile.aura_timer_text_color)\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local timeLeft = envTable._RemainingTime\n    \n    --check if the spellID isn't being ignored\n    if (envTable.IgnoredSpellID [envTable._SpellID]) then\n        return\n    end\n    \n    --check the time left and start or stop the blink animation and also check if the time left is > zero\n    if ((envTable.BlinkEnabled or envTable.GlowEnabled) and timeLeft > 0) then\n        if (timeLeft < envTable.TimeLeftToBlink) then\n            --blink effect\n            if (envTable.BlinkEnabled) then\n                if (not envTable.blinkAnimation:IsPlaying()) then\n                    envTable.blinkAnimation:Play()\n                end\n            end\n            --glow effect\n            if (envTable.GlowEnabled) then\n                envTable.glowEffect:Show()\n            end\n            --nameplate color\n            if (envTable.ChangeNameplateColor) then\n                Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n            end\n        else\n            --blink effect\n            if (envTable.blinkAnimation:IsPlaying()) then\n                envTable.blinkAnimation:Stop()\n            end\n            --glow effect\n            if (envTable.GlowEnabled and envTable.glowEffect:IsShown()) then\n                envTable.glowEffect:Hide()\n            end\n        end\n    end\n    \n    --timer color\n    if (envTable.TimerColorEnabled and timeLeft > 0) then\n        if (timeLeft < envTable.TimeLeftCritical) then\n            Plater:SetFontColor (self.Cooldown.Timer, envTable.TextColor_Critical)\n        elseif (timeLeft < envTable.TimeLeftWarning) then\n            Plater:SetFontColor (self.Cooldown.Timer, envTable.TextColor_Warning)        \n        else\n            Plater:SetFontColor (self.Cooldown.Timer, Plater.db.profile.aura_timer_text_color)\n        end\n    end\n    \nend",
					["Time"] = 1626382829,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = false,
					["Revision"] = 375,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option10",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option17",
							["Value"] = "Enter the spell name or spellID in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 17",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option10",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "blinkEnabled",
							["Value"] = true,
							["Name"] = "Blink Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable blink",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "glowEnabled",
							["Value"] = true,
							["Name"] = "Glow Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable glows",
						}, -- [5]
						{
							["Type"] = 4,
							["Key"] = "changeNameplateColor",
							["Value"] = false,
							["Name"] = "Change NamePlate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'true' to enable nameplate color change",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "in seconds, affects the blink effect only",
							["Min"] = 1,
							["Fraction"] = true,
							["Value"] = 3,
							["Key"] = "timeleftToBlink",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Timeleft to Blink",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 3,
							["Desc"] = "time to complete a blink loop",
							["Min"] = 0.5,
							["Fraction"] = true,
							["Value"] = 1,
							["Key"] = "blinkSpeed",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Speed",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "max transparency in the animation loop (1.0 is full opaque)",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.6,
							["Key"] = "blinkMaxAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Blink Max Alpha",
						}, -- [9]
						{
							["Type"] = 1,
							["Key"] = "blinkColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Blink Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color of the blink",
						}, -- [10]
						{
							["Type"] = 1,
							["Key"] = "nameplateColor",
							["Value"] = {
								0.2862745098039216, -- [1]
								0.00392156862745098, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "nameplate color if ChangeNameplateColor is true",
						}, -- [11]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option10",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [12]
						{
							["Type"] = 4,
							["Key"] = "timerColorEnabled",
							["Value"] = true,
							["Name"] = "Timer Color Enabled",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "set to 'false' to disable changes in the color of the time left text",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "in seconds, affects the color of the text",
							["Min"] = 1,
							["Name"] = "Time Left Warning",
							["Value"] = 8,
							["Key"] = "timeLeftWarning",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "in seconds, affects the color of the text",
							["Min"] = 1,
							["Name"] = "Time Left Critical",
							["Value"] = 3,
							["Key"] = "timeLeftCritical",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [15]
						{
							["Type"] = 1,
							["Key"] = "warningColor",
							["Value"] = {
								1, -- [1]
								0.8705882352941177, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Warning Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color when the time left entered in a warning zone",
						}, -- [16]
						{
							["Type"] = 1,
							["Key"] = "criticalColor",
							["Value"] = {
								1, -- [1]
								0.07450980392156863, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Critical Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "color when the time left is critical",
						}, -- [17]
					},
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.blinkTexture:SetSize (self:GetSize())\n    \nend\n\n\n",
					["Name"] = "Aura - Blink by Time Left [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "Blink, change the number and nameplate color. Add the debuffs int he trigger box. Set settings on constructor script.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\icon_aura_blink",
				}, -- [15]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["OnHideCode"] = "		function (self, unitId, unitFrame, envTable)\n			\n		end\n	",
					["Temp_OnShowCode"] = "		function (self, unitId, unitFrame, envTable)\n			\n		end\n	",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    local isTanking = UnitDetailedThreatSituation (\"player\", unitId)\n    if (not isTanking) then \n        Plater.SetNameplateColor (unitFrame, \"pink\") \n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1550589160,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["NpcNames"] = {
						"surf darter", -- [1]
					},
					["Temp_OnHideCode"] = "		function (self, unitId, unitFrame, envTable)\n			\n		end\n	",
					["Revision"] = 5,
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "",
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    local isTanking = UnitDetailedThreatSituation (\"player\", unitId)\n    if (not isTanking) then \n        Plater.SetNameplateColor (unitFrame, \"pink\") \n    end\n    \nend\n\n\n\n\n",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "New Script",
					["OnShowCode"] = "		function (self, unitId, unitFrame, envTable)\n			\n		end\n	",
					["Enabled"] = false,
				}, -- [16]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.CastbarColor = \"orangered\"\n    \n    --settings (you may need /reload if some configs isn't applied immediately)\n    local CONFIG_BACKGROUND_FLASH_DURATION = 0.8 --0.8\n    local CONFIG_BORDER_GLOW_ALPHA = 0 --0.3\n    local CONFIG_SHAKE_DURATION = 0.2 --0.2\n    local CONFIG_SHAKE_AMPLITUDE = 5 --5\n    \n    envTable.CastBarHeightAdd = 1.5\n    \n    --create a glow effect in the border of the cast bar\n    envTable.glowEffect = envTable.glowEffect or Plater.CreateNameplateGlow (self)\n    envTable.glowEffect:SetOffset (-22, 20, 8, -11)\n    envTable.glowEffect:SetAlpha (CONFIG_BORDER_GLOW_ALPHA)\n    --envTable.glowEffect:Show() --envTable.glowEffect:Hide() \n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+20, self:GetHeight()+30, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (self, CONFIG_SHAKE_DURATION, CONFIG_SHAKE_AMPLITUDE, 35, false, false, 0, 1, 0.05, 0.1, true)    \n    \n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (CONFIG_BACKGROUND_FLASH_DURATION/2)\n    fadeOut:SetDuration (CONFIG_BACKGROUND_FLASH_DURATION/2)    \n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = CONFIG_SHAKE_AMPLITUDE\n    envTable.FrameShake.OriginalDuration = CONFIG_SHAKE_DURATION  \n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end    \n    \n    envTable.glowEffect:Hide()\n    \n    envTable.BackgroundFlash:Stop()\n    \n    self:StopFrameShake (envTable.FrameShake)    \n    \n    --restore the cast bar to its original height\n    if (envTable.OriginalHeight) then\n        self:SetWidth (envTable.OriginalWidth)\n        self:SetHeight (envTable.OriginalHeight)\n        envTable.OriginalHeight = nil\n        envTable.OriginalWidth = nil\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end\n    \n    envTable.glowEffect:Show()\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    self:PlayFrameShake (envTable.FrameShake)\n    \n    if (envTable._CanInterrupt) then\n        self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n    end\n    \n    Plater.SetCastBarBorderColor (self, 1, 0, 0, 0.4)\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetWidth (envTable.OriginalWidth)\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    \n    --increase the cast bar size\n    envTable.OriginalHeight = self:GetHeight()\n    envTable.OriginalWidth = self:GetWidth()\n    local width = Plater.db.profile.plate_config.enemynpc.cast_incombat[1]\n    local height = Plater.db.profile.plate_config.enemynpc.cast_incombat[2]\n    \n    self:SetWidth (width)\n    self:SetHeight (height * envTable.CastBarHeightAdd)\n    \n    print (envTable.glowEffect:GetAlpha())\n    \nend",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["Time"] = 1610463043,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    envTable.CastbarColor = \"orangered\"\n    \n    --settings (you may need /reload if some configs isn't applied immediately)\n    local CONFIG_BACKGROUND_FLASH_DURATION = 0.8 --0.8\n    local CONFIG_BORDER_GLOW_ALPHA = 0 --0.3\n    local CONFIG_SHAKE_DURATION = 0.2 --0.2\n    local CONFIG_SHAKE_AMPLITUDE = 5 --5\n    \n    envTable.CastBarHeightAdd = 1.5\n    \n    --create a glow effect in the border of the cast bar\n    envTable.glowEffect = envTable.glowEffect or Plater.CreateNameplateGlow (self)\n    envTable.glowEffect:SetOffset (-22, 20, 8, -11)\n    envTable.glowEffect:SetAlpha (CONFIG_BORDER_GLOW_ALPHA)\n    --envTable.glowEffect:Show() --envTable.glowEffect:Hide() \n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+20, self:GetHeight()+30, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (self, CONFIG_SHAKE_DURATION, CONFIG_SHAKE_AMPLITUDE, 35, false, false, 0, 1, 0.05, 0.1, true)    \n    \n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (CONFIG_BACKGROUND_FLASH_DURATION/2)\n    fadeOut:SetDuration (CONFIG_BACKGROUND_FLASH_DURATION/2)    \n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = CONFIG_SHAKE_AMPLITUDE\n    envTable.FrameShake.OriginalDuration = CONFIG_SHAKE_DURATION  \n    \nend",
					["NpcNames"] = {
					},
					["Enabled"] = false,
					["Revision"] = 1384,
					["Options"] = {
					},
					["Author"] = "Tercioo-Sylvanas",
					["Desc"] = "Flash, Bounce and Red Color the CastBar border when when an important cast is happening. Add spell in the Add Trigger field.",
					["SpellIds"] = {
						258153, -- [1]
						258313, -- [2]
						274569, -- [3]
						278020, -- [4]
						261635, -- [5]
						272700, -- [6]
						268030, -- [7]
						265368, -- [8]
						264520, -- [9]
						265407, -- [10]
						278567, -- [11]
						278602, -- [12]
						258128, -- [13]
						257791, -- [14]
						258938, -- [15]
						265089, -- [16]
						272183, -- [17]
						256060, -- [18]
						257397, -- [19]
						269972, -- [20]
						270901, -- [21]
						270492, -- [22]
						263215, -- [23]
						268797, -- [24]
						262554, -- [25]
						253517, -- [26]
						255041, -- [27]
						252781, -- [28]
						250368, -- [29]
						258777, -- [30]
						278504, -- [31]
						266106, -- [32]
						257732, -- [33]
						268309, -- [34]
						269302, -- [35]
						263202, -- [36]
						257784, -- [37]
						278755, -- [38]
						272180, -- [39]
						263066, -- [40]
						267273, -- [41]
						265912, -- [42]
						274438, -- [43]
						268317, -- [44]
						268375, -- [45]
						276767, -- [46]
						264105, -- [47]
						265876, -- [48]
						270464, -- [49]
						278961, -- [50]
						265468, -- [51]
						256897, -- [52]
						280604, -- [53]
						268702, -- [54]
						255824, -- [55]
						253583, -- [56]
						250096, -- [57]
						278456, -- [58]
						262092, -- [59]
						257270, -- [60]
						267818, -- [61]
						265091, -- [62]
						262540, -- [63]
						263318, -- [64]
						263959, -- [65]
						257069, -- [66]
						256849, -- [67]
						267459, -- [68]
						253544, -- [69]
						268008, -- [70]
						267981, -- [71]
						272659, -- [72]
						264396, -- [73]
						257736, -- [74]
						264390, -- [75]
						255952, -- [76]
						257426, -- [77]
						274400, -- [78]
						272609, -- [79]
						269843, -- [80]
						269029, -- [81]
						272827, -- [82]
						269266, -- [83]
						263912, -- [84]
						264923, -- [85]
						258864, -- [86]
						256955, -- [87]
						265540, -- [88]
						260793, -- [89]
						270003, -- [90]
						270507, -- [91]
						257337, -- [92]
						268415, -- [93]
						275907, -- [94]
						268865, -- [95]
						260669, -- [96]
						260280, -- [97]
						253239, -- [98]
						265541, -- [99]
						250258, -- [100]
						256709, -- [101]
						277596, -- [102]
						276268, -- [103]
						265372, -- [104]
						263905, -- [105]
						265781, -- [106]
						257170, -- [107]
						268846, -- [108]
						270514, -- [109]
						258622, -- [110]
						258199, -- [111]
						256627, -- [112]
						257870, -- [113]
						259711, -- [114]
						258917, -- [115]
						263891, -- [116]
						268027, -- [117]
						268348, -- [118]
						269313, -- [119]
						272711, -- [120]
						271174, -- [121]
						268260, -- [122]
						269399, -- [123]
						268239, -- [124]
						264574, -- [125]
						261563, -- [126]
						257288, -- [127]
						257757, -- [128]
						267899, -- [129]
						255741, -- [130]
						264757, -- [131]
						260894, -- [132]
						260292, -- [133]
						263583, -- [134]
						276292, -- [135]
						272874, -- [136]
						264101, -- [137]
						264407, -- [138]
						271456, -- [139]
						262515, -- [140]
						275192, -- [141]
						256405, -- [142]
						270084, -- [143]
						257785, -- [144]
						267237, -- [145]
						266951, -- [146]
						267433, -- [147]
						255577, -- [148]
						255371, -- [149]
						270891, -- [150]
						267357, -- [151]
						258338, -- [152]
						257169, -- [153]
						270927, -- [154]
						273995, -- [155]
						260926, -- [156]
						264027, -- [157]
						267257, -- [158]
						253721, -- [159]
						265019, -- [160]
						260924, -- [161]
						263309, -- [162]
						266206, -- [163]
						268187, -- [164]
						260067, -- [165]
						274507, -- [166]
						276068, -- [167]
						263278, -- [168]
						258317, -- [169]
						256594, -- [170]
						268391, -- [171]
						268230, -- [172]
						260852, -- [173]
						267763, -- [174]
						268706, -- [175]
						264734, -- [176]
						288693, -- [177]
						288694, -- [178]
						270590, -- [179]
						290787, -- [180]
						72286, -- [181]
					},
					["Prio"] = 99,
					["Name"] = "M+ Important Spells [Plater]",
					["PlaterCore"] = 1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end\n    \n    envTable.glowEffect:Show()\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    self:PlayFrameShake (envTable.FrameShake)\n    \n    if (envTable._CanInterrupt) then\n        self:SetStatusBarColor (Plater:ParseColors (envTable.CastbarColor))\n    end\n    \n    Plater.SetCastBarBorderColor (self, 1, 0, 0, 0.4)\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetWidth (envTable.OriginalWidth)\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    \n    --increase the cast bar size\n    envTable.OriginalHeight = self:GetHeight()\n    envTable.OriginalWidth = self:GetWidth()\n    local width = Plater.db.profile.plate_config.enemynpc.cast_incombat[1]\n    local height = Plater.db.profile.plate_config.enemynpc.cast_incombat[2]\n    \n    self:SetWidth (width)\n    self:SetHeight (height * envTable.CastBarHeightAdd)\n    \n    print (envTable.glowEffect:GetAlpha())\n    \nend",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end    \n    \n    envTable.glowEffect:Hide()\n    \n    envTable.BackgroundFlash:Stop()\n    \n    self:StopFrameShake (envTable.FrameShake)    \n    \n    --restore the cast bar to its original height\n    if (envTable.OriginalHeight) then\n        self:SetWidth (envTable.OriginalWidth)\n        self:SetHeight (envTable.OriginalHeight)\n        envTable.OriginalHeight = nil\n        envTable.OriginalWidth = nil\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n",
					["Icon"] = "INTERFACE\\ICONS\\Spell_Fire_FelFlameStrike",
				}, -- [17]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --custom frames\n    unitFrame.JadeFireGlowEffect = unitFrame.JadeFireGlowEffect or Plater.CreateNameplateGlow (unitFrame.healthBar)\n    unitFrame.JadeFireGlowEffect:SetOffset (-27, 25, 6, -8)\n    unitFrame.JadeFireGlowEffect:Hide()\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.JadeFireGlowEffect:Hide() \nend\n\n\n",
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.JadeFireGlowEffect:Show() \nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.JadeFireGlowEffect:SetAlpha (.5)\nend\n\n\n",
					["Time"] = 1550596124,
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable)\n    \n    --custom frames\n    unitFrame.JadeFireGlowEffect = unitFrame.JadeFireGlowEffect or Plater.CreateNameplateGlow (unitFrame.healthBar)\n    unitFrame.JadeFireGlowEffect:SetOffset (-27, 25, 6, -8)\n    unitFrame.JadeFireGlowEffect:Hide()\n    \nend\n\n\n",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 33,
					["Author"] = "Kastfall-Azralon",
					["Desc"] = "Alert when the unit has the Fire Shield to be broken.",
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.JadeFireGlowEffect:SetAlpha (.5)\nend\n\n\n",
					["SpellIds"] = {
						286425, -- [1]
					},
					["PlaterCore"] = 1,
					["Name"] = "Jadefire [BOD] - Fire Shield",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.JadeFireGlowEffect:Show() \nend\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    unitFrame.JadeFireGlowEffect:Hide() \nend\n\n\n",
					["Icon"] = 132221,
				}, -- [18]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --settings\n    envTable.NameplateSizeOffset = scriptTable.config.castBarHeight\n    envTable.ShowArrow = scriptTable.config.showArrow\n    envTable.ArrowAlpha = scriptTable.config.arrowAlpha\n    \n    --creates the spark to show the cast progress inside the health bar\n    envTable.overlaySpark = envTable.overlaySpark or Plater:CreateImage (unitFrame.healthBar)\n    envTable.overlaySpark:SetBlendMode (\"ADD\")\n    envTable.overlaySpark.width = 16\n    envTable.overlaySpark.height = 36\n    envTable.overlaySpark.alpha = .9\n    envTable.overlaySpark.texture = [[Interface\\AddOns\\Plater\\images\\spark3]]\n    \n    envTable.topArrow = envTable.topArrow or Plater:CreateImage (unitFrame.healthBar)\n    envTable.topArrow:SetBlendMode (\"ADD\")\n    envTable.topArrow.width = scriptTable.config.arrowWidth\n    envTable.topArrow.height = scriptTable.config.arrowHeight\n    envTable.topArrow.alpha = envTable.ArrowAlpha\n    envTable.topArrow.texture = [[Interface\\BUTTONS\\Arrow-Down-Up]]\n    \n    --scale animation\n    envTable.smallScaleAnimation = envTable.smallScaleAnimation or Plater:CreateAnimationHub (unitFrame.healthBar)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 1, 0.075, 1, 1, 1.08, 1.08)\n    Plater:CreateAnimation (envTable.smallScaleAnimation, \"SCALE\", 2, 0.075, 1, 1, 0.95, 0.95)    \n    --envTable.smallScaleAnimation:Play() --envTable.smallScaleAnimation:Stop()\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))    \n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    \n    envTable.overlaySpark:Hide()\n    envTable.topArrow:Hide()\n    \n    Plater.RefreshNameplateColor (unitFrame)\n    \n    envTable.smallScaleAnimation:Stop()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)\n    \n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --update the percent\n    envTable.overlaySpark:SetPoint (\"left\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100)-9, 0)\n    \n    envTable.topArrow:SetPoint (\"bottomleft\", unitFrame.healthBar, \"topleft\", unitFrame.healthBar:GetWidth() * (envTable._CastPercent / 100) - 4, 2 )\n    \n    --forces the script to update on a 60Hz base\n    self.ThrottleUpdate = 0\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1670790652,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_red",
					["Enabled"] = true,
					["Revision"] = 694,
					["semver"] = "",
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Used on casts that make the mob explode or transform if the cast passes.",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.overlaySpark:Show()\n    \n    if (envTable.ShowArrow) then\n        envTable.topArrow:Show()\n    else\n        envTable.topArrow:Hide()\n    end\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    envTable.smallScaleAnimation:Play()\n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    envTable.overlaySpark.height = nameplateHeight + 5\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, customColor or scriptTable.config.castBarColor, envTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.healthBarColor)        \n        Plater.DenyColorChange(unitFrame, true)            \n    end\n    \nend",
					["SpellIds"] = {
						383823, -- [1]
						382670, -- [2]
						388537, -- [3]
						372851, -- [4]
						200682, -- [5]
						192307, -- [6]
						196838, -- [7]
						193827, -- [8]
						194043, -- [9]
						209410, -- [10]
						211464, -- [11]
						361180, -- [12]
						156718, -- [13]
						395859, -- [14]
						358320, -- [15]
						374045, -- [16]
						386757, -- [17]
						367500, -- [18]
						370225, -- [19]
						376200, -- [20]
						372107, -- [21]
					},
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Plays a special animation showing the explosion time.",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option3",
							["Value"] = 0,
							["Name"] = "Option 3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "Increases the health bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 3,
							["Name"] = "Health Bar Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "castBarHeight",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [5]
						{
							["Type"] = 1,
							["Key"] = "healthBarColor",
							["Value"] = {
								1, -- [1]
								0.5843137254901961, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [6]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 4,
							["Name"] = "Use Cast Bar Color",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above Use Cast Bar Color",
						}, -- [8]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.168627455830574, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast Bar Color",
						}, -- [9]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 5,
							["Key"] = "option6",
							["Value"] = "Arrow:",
							["Name"] = "Arrow:",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [11]
						{
							["Type"] = 4,
							["Name"] = "Show Arrow",
							["Value"] = true,
							["Key"] = "showArrow",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show an arrow above the nameplate showing the cast bar progress.",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Arrow alpha.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.5,
							["Name"] = "Arrow Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "arrowAlpha",
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Width.",
							["Min"] = 4,
							["Name"] = "Arrow Width",
							["Value"] = 8,
							["Key"] = "arrowWidth",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [14]
						{
							["Type"] = 2,
							["Max"] = 12,
							["Desc"] = "Arrow Height.",
							["Min"] = 4,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Arrow Height",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "arrowHeight",
						}, -- [15]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [16]
						{
							["Type"] = 5,
							["Key"] = "option12",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation:",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [17]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								1, -- [1]
								0.615686274509804, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dot animation.",
						}, -- [18]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot X Offset",
							["Min"] = -10,
							["Name"] = "Dot X Offset",
							["Value"] = 4,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "xOffset",
						}, -- [19]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Dot Y Offset",
							["Min"] = -10,
							["Key"] = "yOffset",
							["Value"] = 3,
							["Name"] = "Dot Y Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [20]
						{
							["Type"] = 7,
							["Key"] = "castColor",
							["Value"] = {
								{
									"200682", -- [1]
									"darkslateblue", -- [2]
								}, -- [1]
								{
									"192307", -- [1]
									"goldenrod", -- [2]
								}, -- [2]
								{
									"196838", -- [1]
									"maroon", -- [2]
								}, -- [3]
								{
									"193827", -- [1]
									"darkgreen", -- [2]
								}, -- [4]
								{
									"194043", -- [1]
									"darkgreen", -- [2]
								}, -- [5]
								{
									"156718", -- [1]
									"DRUID", -- [2]
								}, -- [6]
								{
									"395859", -- [1]
									"ROGUE", -- [2]
								}, -- [7]
							},
							["Name"] = "Color List by SpellId",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the spellId in the Key, and the color name in the Value",
						}, -- [21]
					},
					["version"] = -1,
					["Name"] = "Cast - Ultra Important [P]",
					["NpcNames"] = {
					},
				}, -- [19]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    --check for marks\n    function  envTable.CheckMark (unitId, unitFrame)\n        if (not GetRaidTargetIndex(unitId)) then\n            if (scriptTable.config.onlyInCombat) then\n                if (not UnitAffectingCombat(unitId)) then\n                    return\n                end                \n            end\n            \n            SetRaidTarget(unitId, 8)\n        end       \n    end\nend\n\n\n--163520 - forsworn squad-leader\n--163618 - zolramus necromancer - The Necrotic Wake\n--164506 - anciet captain - theater of pain\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n",
					["Time"] = 1620346875,
					["Enabled"] = true,
					["url"] = "",
					["NpcNames"] = {
					},
					["Desc"] = "Auto set skull marker",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Revision"] = 66,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option1",
							["Value"] = "Auto set a raid target Skull on the unit.",
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "onlyInCombat",
							["Value"] = false,
							["Name"] = "Only in Combat",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Set the mark only if the unit is in combat.",
						}, -- [3]
					},
					["Name"] = "Auto Set Skull",
					["Prio"] = 99,
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["version"] = -1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.CheckMark (unitId, unitFrame)\nend\n\n\n",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["semver"] = "",
					["Icon"] = "Interface\\Worldmap\\GlowSkull_64Grey",
					["Temp_Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    --check for marks\n    function  envTable.CheckMark (unitId, unitFrame)\n        if (not GetRaidTargetIndex(unitId)) then\n            if (scriptTable.config.onlyInCombat) then\n                if (not UnitAffectingCombat(unitId)) then\n                    return\n                end                \n            end\n            \n            SetRaidTarget(unitId, 8)\n        end       \n    end\nend\n\n\n--163520 - forsworn squad-leader\n--163618 - zolramus necromancer - The Necrotic Wake\n--164506 - anciet captain - theater of pain\n\n\n",
				}, -- [20]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    envTable.npcInfo = {\n        [164427] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"1\", name = \"Boom!\"}, --reanimated warrior - plaguefall\n        \n        [164414] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"2\", name = \"Boom!\"}, --reanimated mage - plaguefall\n        \n        [164185] = {secondCastBar = true, timer = 20, timerId = 319941, altCastId = \"3\", remaining = 5, name = GetSpellInfo(319941)}, --Echelon - Halls of Atonement\n        \n        [164567] = {secondCastBar = true, altCastId = \"dromanswrath\", debuffTimer = 323059, name = GetSpellInfo(323059), spellIcon = 323059}, --Ingra Maloch -- tirna scythe\n        \n        [165408] = {secondCastBar = true, timer = 20, timerId = 322711, altCastId = \"4\", remaining = 5, name = GetSpellInfo(322711)}, --Halkias - Refracted Sinlight - Halls of Atonement\n        \n        \n        --[154564] = {secondCastBar = true, timerId = \"Test Bar\", altCastId = \"debugcast\", remaining = 5, name = GetSpellInfo(319941), spellIcon = 319941}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n        --[154580] = {secondCastBar = true, altCastId = \"debugcast\", debuffTimer = 204242, name = GetSpellInfo(81297), spellIcon = 81297}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n    }\n    \n    --set the castbar config\n    local config = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end\n        \n        DetailsFramework:TruncateText(unitFrame.castBar2.Text, unitFrame.castBar2:GetWidth() - 16)\n    end\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    Plater.ClearAltCastBar(unitFrame.PlateFrame)\nend",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                \n                envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, expirationTime-duration)\n            else\n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        else\n            envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                if (altCastId ~= npcInfo.altCastId or not unitFrame.castBar2:IsShown()) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n                end\n            end \n            \n        elseif (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                --get the debuff timeleft\n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                local startTime = expirationTime - duration\n                \n                if (not unitFrame.castBar2:IsShown() or unitFrame.castBar2.spellStartTime < startTime) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, startTime)\n                end\n                \n            else \n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1620348068,
					["Enabled"] = true,
					["url"] = "",
					["NpcNames"] = {
					},
					["Desc"] = "Some units has special events without a clear way to show. This script adds a second cast bar to inform the user about it.",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    Plater.ClearAltCastBar(unitFrame.PlateFrame)\nend",
					["Revision"] = 210,
					["Options"] = {
					},
					["Name"] = "Countdown",
					["Prio"] = 99,
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                \n                envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, expirationTime-duration)\n            else\n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        else\n            envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["version"] = -1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local npcInfo = envTable.npcInfo[envTable._NpcID]\n    \n    if (npcInfo and npcInfo.secondCastBar) then\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                if (altCastId ~= npcInfo.altCastId or not unitFrame.castBar2:IsShown()) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId)\n                end\n            end \n            \n        elseif (npcInfo.debuffTimer) then\n            if (Plater.NameplateHasAura (unitFrame, npcInfo.debuffTimer)) then\n                \n                --get the debuff timeleft\n                local name = npcInfo.name\n                local _, _, _, _, duration, expirationTime = AuraUtil.FindAuraByName(name, unitId, \"DEBUFF\")\n                local startTime = expirationTime - duration\n                \n                if (not unitFrame.castBar2:IsShown() or unitFrame.castBar2.spellStartTime < startTime) then\n                    envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, duration, startTime)\n                end\n                \n            else \n                if (unitFrame.castBar2:IsShown()) then\n                    local altCastId = Plater.GetAltCastBarAltId(unitFrame.PlateFrame)\n                    if (altCastId == npcInfo.altCastId) then\n                        Plater.ClearAltCastBar(unitFrame.PlateFrame)\n                    end                   \n                end                              \n            end\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\Images\\countdown_bar_icon",
					["Temp_Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    envTable.npcInfo = {\n        [164427] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"1\", name = \"Boom!\"}, --reanimated warrior - plaguefall\n        \n        [164414] = {secondCastBar = true, timer = 20, timerId = 321247, altCastId = \"2\", name = \"Boom!\"}, --reanimated mage - plaguefall\n        \n        [164185] = {secondCastBar = true, timer = 20, timerId = 319941, altCastId = \"3\", remaining = 5, name = GetSpellInfo(319941)}, --Echelon - Halls of Atonement\n        \n        [164567] = {secondCastBar = true, altCastId = \"dromanswrath\", debuffTimer = 323059, name = GetSpellInfo(323059), spellIcon = 323059}, --Ingra Maloch -- tirna scythe\n        \n        [165408] = {secondCastBar = true, timer = 20, timerId = 322711, altCastId = \"4\", remaining = 5, name = GetSpellInfo(322711)}, --Halkias - Refracted Sinlight - Halls of Atonement\n        \n        \n        --[154564] = {secondCastBar = true, timerId = \"Test Bar\", altCastId = \"debugcast\", remaining = 5, name = GetSpellInfo(319941), spellIcon = 319941}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n        --[154580] = {secondCastBar = true, altCastId = \"debugcast\", debuffTimer = 204242, name = GetSpellInfo(81297), spellIcon = 81297}, --debug \"Test (1)\" BW \"Test Bar\" DBM --DEBUG\n    }\n    \n    --set the castbar config\n    local config = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end\n        \n        DetailsFramework:TruncateText(unitFrame.castBar2.Text, unitFrame.castBar2:GetWidth() - 16)\n    end\nend",
				}, -- [21]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount = Plater:CreateLabel (unitFrame, \"\", 16, \"silver\");\n    envTable.EnergyAmount:SetPoint (\"bottom\", unitFrame, \"top\", 0, 18);    \n    \n    envTable.EnergyAmount.fontsize = scriptTable.config.fontSize\n    envTable.EnergyAmount.fontcolor = scriptTable.config.fontColor\n    envTable.EnergyAmount.outline = scriptTable.config.outline\n    \n    \nend\n\n--[=[\n\n164406 = Shriekwing\n164407 = Sludgefist\n162100 = kryxis the voracious\n162099 = general kaal - sanguine depths\n162329 = Xav the Unfallen - threater of pain\n--]=]",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Hide()\nend\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Show()\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local currentPower = UnitPower(unitId)\n    \n    if (currentPower and currentPower > 0) then\n        local maxPower = UnitPowerMax (unitId)\n        local percent = floor (currentPower / maxPower * 100)\n        \n        envTable.EnergyAmount.text = \"\" .. percent;\n        \n        if (scriptTable.config.showLater) then\n            local alpha = (percent -80) * 5\n            alpha = alpha / 100\n            alpha = max(0, alpha)\n            envTable.EnergyAmount:SetAlpha(alpha)\n            \n        else\n            envTable.EnergyAmount:SetAlpha(1.0)\n        end\n        \n        \n    else\n        envTable.EnergyAmount.text = \"\"\n    end\nend\n\n\n\n\n\n\n\n\n",
					["Time"] = 1609154875,
					["Enabled"] = true,
					["url"] = "",
					["NpcNames"] = {
					},
					["Desc"] = "Show the energy amount above the nameplate.",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Hide()\nend\n\n\n",
					["Revision"] = 234,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option3",
							["Value"] = "Show the power of the unit above the nameplate.",
							["Name"] = "script desc",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Key"] = "option3",
							["Value"] = "Add the unit name or unitId in the \"Add Trigger\" field and press \"Add\".",
							["Name"] = "add trigger",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Key"] = "showLater",
							["Value"] = true,
							["Name"] = "Show at 80% of Energy",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the energy won't start showing until the unit has 80% energy.",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option2",
							["Value"] = 0,
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "Text size.",
							["Min"] = 8,
							["Key"] = "fontSize",
							["Value"] = 16,
							["Name"] = "Text Size",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "fontColor",
							["Value"] = {
								0.80392156862745, -- [1]
								0.80392156862745, -- [2]
								0.80392156862745, -- [3]
								1, -- [4]
							},
							["Name"] = "Font Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the text.",
						}, -- [8]
						{
							["Type"] = 4,
							["Key"] = "outline",
							["Value"] = true,
							["Name"] = "Enable Text Outline",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "If enabled, the text uses outline.",
						}, -- [9]
					},
					["Name"] = "Unit - Show Energy [Plater]",
					["Prio"] = 99,
					["Author"] = "Celian-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount:Show()\nend\n\n\n",
					["version"] = -1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local currentPower = UnitPower(unitId)\n    \n    if (currentPower and currentPower > 0) then\n        local maxPower = UnitPowerMax (unitId)\n        local percent = floor (currentPower / maxPower * 100)\n        \n        envTable.EnergyAmount.text = \"\" .. percent;\n        \n        if (scriptTable.config.showLater) then\n            local alpha = (percent -80) * 5\n            alpha = alpha / 100\n            alpha = max(0, alpha)\n            envTable.EnergyAmount:SetAlpha(alpha)\n            \n        else\n            envTable.EnergyAmount:SetAlpha(1.0)\n        end\n        \n        \n    else\n        envTable.EnergyAmount.text = \"\"\n    end\nend\n\n\n\n\n\n\n\n\n",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["semver"] = "",
					["Icon"] = 136048,
					["Temp_Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.EnergyAmount = Plater:CreateLabel (unitFrame, \"\", 16, \"silver\");\n    envTable.EnergyAmount:SetPoint (\"bottom\", unitFrame, \"top\", 0, 18);    \n    \n    envTable.EnergyAmount.fontsize = scriptTable.config.fontSize\n    envTable.EnergyAmount.fontcolor = scriptTable.config.fontColor\n    envTable.EnergyAmount.outline = scriptTable.config.outline\n    \n    \nend\n\n--[=[\n\n164406 = Shriekwing\n164407 = Sludgefist\n162100 = kryxis the voracious\n162099 = general kaal - sanguine depths\n162329 = Xav the Unfallen - threater of pain\n--]=]",
				}, -- [22]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    if (not unitFrame.spitefulTexture) then\n        unitFrame.spitefulTexture = unitFrame.healthBar:CreateTexture(nil, \"overlay\", nil, 6)\n        unitFrame.spitefulTexture:SetPoint('right', 0, 0)\n        unitFrame.spitefulTexture:SetSize(27, 14)\n        unitFrame.spitefulTexture:SetColorTexture(.3, .3, 1, .7)\n        \n        unitFrame.spitefulText = unitFrame.healthBar:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)\n        DetailsFramework:SetFontFace (unitFrame.spitefulText, \"2002\")\n        unitFrame.spitefulText:SetPoint(\"right\", unitFrame.spitefulTexture, \"right\", -2, 0)\n        unitFrame.spitefulText:SetJustifyH(\"right\")\n        \n        unitFrame.roleIcon = unitFrame:CreateTexture(nil, \"overlay\")\n        unitFrame.roleIcon:SetPoint(\"left\", unitFrame.healthBar, \"left\", 2, 0)\n        unitFrame.targetName = unitFrame:CreateFontString(nil, \"overlay\", \"GameFontNormal\")\n        unitFrame.targetName:SetPoint(\"left\", unitFrame.roleIcon, \"right\", 2, 0)\n        \n        unitFrame.spitefulTexture:Hide()\n        unitFrame.spitefulText:Hide()\n    end\n    \n    function envTable.UpdateSpitefulWidget(unitFrame)\n        \n        local r, g, b, a = Plater:ParseColors(scriptTable.config.bgColor)\n        unitFrame.spitefulTexture:SetColorTexture(r, g, b, a)\n        unitFrame.spitefulTexture:SetSize(scriptTable.config.bgWidth, unitFrame.healthBar:GetHeight())   \n        Plater:SetFontSize(unitFrame.spitefulText, scriptTable.config.textSize)\n        Plater:SetFontColor(unitFrame.spitefulText, scriptTable.config.textColor)\n        \n        local currentHealth = unitFrame.healthBar.CurrentHealth\n        local maxHealth = unitFrame.healthBar.CurrentHealthMax\n        \n        local healthPercent = currentHealth / maxHealth * 100\n        local timeToDie = format(\"%.1fs\", healthPercent / 8)\n        unitFrame.spitefulText:SetText(timeToDie)\n        \n        unitFrame.spitefulText:Show()\n        unitFrame.spitefulTexture:Show()\n        \n        if scriptTable.config.switchTargetName then\n            local plateFrame = unitFrame.PlateFrame\n            \n            local target = UnitName(unitFrame.namePlateUnitToken .. \"target\") or UnitName(unitFrame.namePlateUnitToken)\n            \n            if (target and target ~= \"\") then\n                local _, class = UnitClass(unitFrame.namePlateUnitToken .. \"target\")\n                if (class) then\n                    target = DetailsFramework:AddClassColorToText(target, class)\n                end\n                \n                local role = UnitGroupRolesAssigned(unitFrame.namePlateUnitToken .. \"target\")\n                if (role and role ~= \"NONE\") then\n                    target = DetailsFramework:AddRoleIconToText(target, role)\n                end\n                \n                plateFrame.namePlateUnitName = target\n                Plater.UpdateUnitName(plateFrame)\n            end\n        end\n        \n        if scriptTable.config.useTargetingColor then\n            local targeted = UnitIsUnit(unitFrame.namePlateUnitToken .. \"target\", \"player\")\n            if targeted then\n                Plater.SetNameplateColor (unitFrame, scriptTable.config.targetingColor)\n            else\n                Plater.RefreshNameplateColor(unitFrame)\n            end\n        end\n    end\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    if (unitFrame.spitefulTexture) then\n        unitFrame.spitefulText:Hide()\n        unitFrame.spitefulTexture:Hide()    \n        unitFrame.roleIcon:Hide()\n        unitFrame.targetName:Hide()\n    end\nend\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
					["Time"] = 1620348126,
					["Enabled"] = true,
					["url"] = "",
					["NpcNames"] = {
						"174773", -- [1]
					},
					["Desc"] = "Time to die Spiteful affix",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    if (unitFrame.spitefulTexture) then\n        unitFrame.spitefulText:Hide()\n        unitFrame.spitefulTexture:Hide()    \n        unitFrame.roleIcon:Hide()\n        unitFrame.targetName:Hide()\n    end\nend\n\n\n\n\n\n",
					["Revision"] = 189,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option12",
							["Value"] = "Time to Die",
							["Name"] = "Time to Die",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 2,
							["Max"] = 50,
							["Desc"] = "",
							["Min"] = 10,
							["Key"] = "bgWidth",
							["Value"] = 27,
							["Name"] = "Width",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "bgColor",
							["Value"] = {
								0.50588235294118, -- [1]
								0.070588235294118, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Background Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 24,
							["Desc"] = "",
							["Min"] = 7,
							["Key"] = "textSize",
							["Value"] = 8,
							["Name"] = "Text Size",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "textColor",
							["Value"] = {
								1, -- [1]
								0.5843137254902, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Text Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 5,
							["Key"] = "option11",
							["Value"] = "Targeting",
							["Name"] = "Targeting",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 4,
							["Key"] = "switchTargetName",
							["Value"] = true,
							["Name"] = "Show Target instead of Name",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 4,
							["Key"] = "useTargetingColor",
							["Value"] = true,
							["Name"] = "Change Color if targeting You",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 1,
							["Key"] = "targetingColor",
							["Value"] = {
								0.070588235294118, -- [1]
								0.61960784313725, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Color if targeting You",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [10]
						{
							["Type"] = 6,
							["Key"] = "option11",
							["Value"] = 0,
							["Name"] = "Option 11",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [11]
					},
					["Name"] = "M+ Spiteful",
					["Prio"] = 99,
					["Author"] = "Symantec-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
					["version"] = -1,
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateSpitefulWidget(unitFrame)\nend\n\n\n",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["semver"] = "",
					["Icon"] = 135945,
					["Temp_Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    if (not unitFrame.spitefulTexture) then\n        unitFrame.spitefulTexture = unitFrame.healthBar:CreateTexture(nil, \"overlay\", nil, 6)\n        unitFrame.spitefulTexture:SetPoint('right', 0, 0)\n        unitFrame.spitefulTexture:SetSize(27, 14)\n        unitFrame.spitefulTexture:SetColorTexture(.3, .3, 1, .7)\n        \n        unitFrame.spitefulText = unitFrame.healthBar:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)\n        DetailsFramework:SetFontFace (unitFrame.spitefulText, \"2002\")\n        unitFrame.spitefulText:SetPoint(\"right\", unitFrame.spitefulTexture, \"right\", -2, 0)\n        unitFrame.spitefulText:SetJustifyH(\"right\")\n        \n        unitFrame.roleIcon = unitFrame:CreateTexture(nil, \"overlay\")\n        unitFrame.roleIcon:SetPoint(\"left\", unitFrame.healthBar, \"left\", 2, 0)\n        unitFrame.targetName = unitFrame:CreateFontString(nil, \"overlay\", \"GameFontNormal\")\n        unitFrame.targetName:SetPoint(\"left\", unitFrame.roleIcon, \"right\", 2, 0)\n        \n        unitFrame.spitefulTexture:Hide()\n        unitFrame.spitefulText:Hide()\n    end\n    \n    function envTable.UpdateSpitefulWidget(unitFrame)\n        \n        local r, g, b, a = Plater:ParseColors(scriptTable.config.bgColor)\n        unitFrame.spitefulTexture:SetColorTexture(r, g, b, a)\n        unitFrame.spitefulTexture:SetSize(scriptTable.config.bgWidth, unitFrame.healthBar:GetHeight())   \n        Plater:SetFontSize(unitFrame.spitefulText, scriptTable.config.textSize)\n        Plater:SetFontColor(unitFrame.spitefulText, scriptTable.config.textColor)\n        \n        local currentHealth = unitFrame.healthBar.CurrentHealth\n        local maxHealth = unitFrame.healthBar.CurrentHealthMax\n        \n        local healthPercent = currentHealth / maxHealth * 100\n        local timeToDie = format(\"%.1fs\", healthPercent / 8)\n        unitFrame.spitefulText:SetText(timeToDie)\n        \n        unitFrame.spitefulText:Show()\n        unitFrame.spitefulTexture:Show()\n        \n        if scriptTable.config.switchTargetName then\n            local plateFrame = unitFrame.PlateFrame\n            \n            local target = UnitName(unitFrame.namePlateUnitToken .. \"target\") or UnitName(unitFrame.namePlateUnitToken)\n            \n            if (target and target ~= \"\") then\n                local _, class = UnitClass(unitFrame.namePlateUnitToken .. \"target\")\n                if (class) then\n                    target = DetailsFramework:AddClassColorToText(target, class)\n                end\n                \n                local role = UnitGroupRolesAssigned(unitFrame.namePlateUnitToken .. \"target\")\n                if (role and role ~= \"NONE\") then\n                    target = DetailsFramework:AddRoleIconToText(target, role)\n                end\n                \n                plateFrame.namePlateUnitName = target\n                Plater.UpdateUnitName(plateFrame)\n            end\n        end\n        \n        if scriptTable.config.useTargetingColor then\n            local targeted = UnitIsUnit(unitFrame.namePlateUnitToken .. \"target\", \"player\")\n            if targeted then\n                Plater.SetNameplateColor (unitFrame, scriptTable.config.targetingColor)\n            else\n                Plater.RefreshNameplateColor(unitFrame)\n            end\n        end\n    end\nend",
				}, -- [23]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \n    --check if there's a timer for this spell\n    local timer = scriptTable.config.timerList[tostring(envTable._SpellID)]\n    \n    if (timer) then\n        --insert code here\n        \n        --set the castbar config\n        local config = {\n            iconTexture = \"\",\n            iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n            iconAlpha = 1,\n            iconSize = 14,\n            \n            text = \"Spikes Incoming!\",\n            textSize = 8,\n            \n            texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n            color = {.6, .6, .6, 0.8},\n            \n            isChanneling = false,\n            canInterrupt = false,\n            \n            height = 5,\n            width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n            \n            spellNameAnchor = {side = 3, x = 0, y = -2},\n            timerAnchor = {side = 5, x = 0, y = -2},\n        }\n        \n        Plater.SetAltCastBar(unitFrame.PlateFrame, config, timer, nil, nil)\n        local castBar2 = unitFrame.castBar2\n        castBar2.Text:ClearAllPoints()\n        castBar2.Text:SetPoint (\"topleft\", castBar2, \"bottomleft\", 0, 0)\n        castBar2.percentText:ClearAllPoints()\n        castBar2.percentText:SetPoint (\"topright\", castBar2, \"bottomright\", 0, 0)\n        Plater:SetFontSize(castBar2.percentText, 8)\n    end\n    \nend\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
						["timerList"] = {
						},
					},
					["Temp_OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["Temp_Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Time"] = 1670701360,
					["Enabled"] = true,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_orange",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castbarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["Temp_OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \n    --check if there's a timer for this spell\n    local timer = scriptTable.config.timerList[tostring(envTable._SpellID)]\n    \n    if (timer) then\n        --insert code here\n        \n        --set the castbar config\n        local config = {\n            iconTexture = \"\",\n            iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n            iconAlpha = 1,\n            iconSize = 14,\n            \n            text = \"Spikes Incoming!\",\n            textSize = 8,\n            \n            texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n            color = {.6, .6, .6, 0.8},\n            \n            isChanneling = false,\n            canInterrupt = false,\n            \n            height = 5,\n            width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n            \n            spellNameAnchor = {side = 3, x = 0, y = -2},\n            timerAnchor = {side = 5, x = 0, y = -2},\n        }\n        \n        Plater.SetAltCastBar(unitFrame.PlateFrame, config, timer, nil, nil)\n        local castBar2 = unitFrame.castBar2\n        castBar2.Text:ClearAllPoints()\n        castBar2.Text:SetPoint (\"topleft\", castBar2, \"bottomleft\", 0, 0)\n        castBar2.percentText:ClearAllPoints()\n        castBar2.percentText:SetPoint (\"topright\", castBar2, \"bottomright\", 0, 0)\n        Plater:SetFontSize(castBar2.percentText, 8)\n    end\n    \nend\n\n\n\n\n\n\n\n",
					["Revision"] = 1215,
					["semver"] = "",
					["Name"] = "Cast - Alert + Timer [P]",
					["Prio"] = 99,
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["Desc"] = "Player an animation when the cast start. Start a timer when the cast finishes. Set the time in the options.",
					["SpellIds"] = {
					},
					["Temp_UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["version"] = -1,
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Cast start animation settings",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [4]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [5]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Key"] = "flashDuration",
							["Value"] = 0.4,
							["Name"] = "Flash Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Key"] = "castBarHeight",
							["Value"] = 5,
							["Name"] = "Cast Bar Height Mod",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Key"] = "shakeDuration",
							["Value"] = 0.2,
							["Name"] = "Shake Duration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 100,
							["Desc"] = "How strong is the shake.",
							["Min"] = 2,
							["Key"] = "shakeAmplitude",
							["Value"] = 8,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Amplitude",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 40,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Frequency",
						}, -- [11]
						{
							["Type"] = 7,
							["Key"] = "timerList",
							["Value"] = {
							},
							["Name"] = "Timer (Key is SpellId and Value is Time)",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the spellId and value is the amount of time of the Timer",
						}, -- [12]
					},
					["NpcNames"] = {
					},
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Temp_ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\", 7)\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n\n\n",
				}, -- [24]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --create a texture to use for a flash behind the cast bar\n    \n    if (not unitFrame.backGroundFlashTextureImpTarget) then\n        unitFrame.backGroundFlashTextureImpTarget =  Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    end\n    \n    local backGroundFlashTexture = unitFrame.backGroundFlashTextureImpTarget\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\n    \n    --create the target unit name box\n    if (not unitFrame.targetBox) then\n        unitFrame.targetBox = CreateFrame(\"frame\", unitFrame:GetName() .. \"ScriptImportantTarget\", unitFrame, \"BackdropTemplate\")\n        unitFrame.targetBox:SetSize(80, 20)\n        unitFrame.targetBox:SetFrameStrata(\"TOOLTIP\")\n        unitFrame.targetBox:Hide()\n        unitFrame.targetBox:SetPoint(\"left\", unitFrame, \"right\", 0, 0)\n        \n        unitFrame.targetBox:SetBackdrop({edgeFile = [[Interface\\Buttons\\WHITE8X8]], edgeSize = 1, bgFile = [[Interface\\AddOns\\Details\\images\\background]], tile = true, tileSize = 16})\n        unitFrame.targetBox:SetBackdropColor(.2, .2, .2, .8)\n        unitFrame.targetBox:SetBackdropBorderColor(0, 0, 0, 1)\n        \n        unitFrame.targetBoxName = unitFrame.targetBox:CreateFontString(nil, \"artwork\", \"GameFontNormal\")\n        unitFrame.targetBoxName:SetPoint(\"center\")\n    end\n    \n    function envTable.UpdateTargetBox(unitFrame, unitId)\n        local targetUnitId = unitId .. \"target\"\n        local unitName = UnitName(targetUnitId)\n        \n        if (unitName) then\n            if (scriptTable.config.colorByClass) then\n                Plater:SetFontColor(unitFrame.targetBoxName, \"white\")\n                unitName = Plater.SetTextColorByClass(targetUnitId, unitName)\n            else\n                Plater:SetFontColor(unitFrame.targetBoxName, scriptTable.config.textColor)\n            end\n            \n            unitFrame.targetBoxName:SetText(unitName)\n            Plater:SetFontSize(unitFrame.targetBoxName, scriptTable.config.targetNameSize)\n            unitFrame.targetBox:SetBackdropColor(Plater:ParseColors(scriptTable.config.targetBgColor))\n            unitFrame.targetBox:SetBackdropBorderColor(Plater:ParseColors(scriptTable.config.targetBgBorderColor))\n            unitFrame.targetBox:Show()\n            \n            unitFrame.targetBox:SetWidth(scriptTable.config.targetFrameWidth)\n            unitFrame.targetBox:SetHeight(scriptTable.config.targetFrameHeight)\n            \n            if (not Plater.HasDotAnimationPlaying(unitFrame.targetBox)) then\n                envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.targetBox, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n            end\n            \n            unitFrame.backGroundFlashTextureImpTarget:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n            \n            return true\n            \n        end\n    end\n    \nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.targetBox, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \n    unitFrame.targetBox:Hide()\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.UpdateTargetBox(unitFrame, unitId) \n    \nend\n\n\n",
					["Time"] = 1669339628,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 878,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option1",
							["Value"] = 0,
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Shows the target name in a separate box",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Flash:",
							["Name"] = "Flash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.8,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "flashDuration",
						}, -- [6]
						{
							["Type"] = 1,
							["Key"] = "flashColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Flash Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Name"] = "Shake",
							["Value"] = "Shake:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeDuration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Name"] = "Shake Amplitude",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeAmplitude",
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 40,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "shakeFrequency",
						}, -- [12]
						{
							["Type"] = 6,
							["Key"] = "option13",
							["Value"] = 0,
							["Name"] = "Option 13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Key"] = "option14",
							["Value"] = "Dot Animation:",
							["Name"] = "Dot Animation",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Key"] = "dotColor",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 8,
							["Name"] = "Dot X Offset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "xOffset",
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot Y Offset",
							["Value"] = 3,
							["Key"] = "yOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [17]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Key"] = "option19",
							["Value"] = "Cast Bar",
							["Name"] = "Option 19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Key"] = "useCastbarColor",
							["Value"] = true,
							["Name"] = "Use Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Key"] = "castBarColor",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Cast Bar Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
						{
							["Type"] = 6,
							["Name"] = "Option 27",
							["Value"] = 0,
							["Key"] = "option27",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [27]
						{
							["Type"] = 5,
							["Name"] = "Option 28",
							["Value"] = "Target Options",
							["Key"] = "option28",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [28]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "",
							["Min"] = 8,
							["Name"] = "Text Size",
							["Value"] = 14,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "targetNameSize",
						}, -- [29]
						{
							["Type"] = 4,
							["Name"] = "Use Class Color",
							["Value"] = true,
							["Key"] = "colorByClass",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [30]
						{
							["Type"] = 1,
							["Name"] = "Text Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "textColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [31]
						{
							["Type"] = 1,
							["Name"] = "Background Color",
							["Value"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								0.9846720322966576, -- [4]
							},
							["Key"] = "targetBgColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [32]
						{
							["Type"] = 1,
							["Name"] = "Border Color",
							["Value"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "targetBgBorderColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [33]
						{
							["Type"] = 2,
							["Max"] = 160,
							["Desc"] = "",
							["Min"] = 30,
							["Name"] = "Frame Width",
							["Value"] = 90,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "targetFrameWidth",
						}, -- [34]
						{
							["Type"] = 2,
							["Max"] = 32,
							["Desc"] = "",
							["Min"] = 8,
							["Key"] = "targetFrameHeight",
							["Value"] = 20,
							["Name"] = "Frame Height",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [35]
					},
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (envTable.UpdateTargetBox(unitFrame, unitId)) then\n        \n        envTable.BackgroundFlash:Play()\n        \n        Plater.FlashNameplateBorder (unitFrame, 0.05)   \n        Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n        \n        unitFrame:PlayFrameShake (envTable.FrameShake)\n        \n        if (envTable._CanInterrupt) then\n            if (scriptTable.config.useCastbarColor) then\n                self:SetStatusBarColor (Plater:ParseColors (scriptTable.config.castBarColor))\n            end\n        end\n        \n    end\n    \nend\n\n\n\n\n\n\n",
					["Name"] = "Cast - Important Target [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "Highlight the target name",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_target",
				}, -- [25]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    local unitPowerBar = unitFrame.powerBar\n    unitPowerBar:Hide()\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE) then\n        return \n    end\n    \n    local continuationToken\n    local slots\n    local foundAura = false\n    \n    repeat    \n        slots = { UnitAuraSlots(unitId, \"HELPFUL\", BUFF_MAX_DISPLAY, continuationToken) }\n        continuationToken = slots[1]\n        numSlots = #slots\n        \n        for i = 2, numSlots do\n            local slot = slots[i]\n            local name, texture, count, actualAuraType, duration, expirationTime, caster, canStealOrPurge, nameplateShowPersonal, spellId, canApplyAura, isBossDebuff, isCastByPlayer, nameplateShowAll, timeMod, auraAmount = UnitAuraBySlot(unitId, slot) \n            \n            if (spellId == envTable._SpellID) then --need to get the trigger spellId\n                --Ablative Shield\n                local unitPowerBar = unitFrame.powerBar\n                if (not unitPowerBar:IsShown()) then\n                    unitPowerBar:SetUnit(unitId)\n                end\n                \n                foundAura = true\n                return\n            end\n        end\n        \n    until continuationToken == nil\n    \n    if (not foundAura) then\n        local unitPowerBar = unitFrame.powerBar\n        if (unitPowerBar:IsShown()) then\n            unitPowerBar:Hide()\n        end\n    end\nend",
					["Time"] = 1669327146,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 65,
					["Options"] = {
					},
					["Author"] = "Keyspell-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Name"] = "Aura is Shield [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "Show power bar where its value is the buff value (usualy shown in the buff tooltip)",
					["semver"] = "",
					["Icon"] = 610472,
				}, -- [26]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "		function (self, unitId, unitFrame, envTable, scriptTable)\n			--insert code here\n			\n		end\n	",
					["OptionsValues"] = {
					},
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (UnitIsUnit(unitId .. \"target\", \"player\")) then\n        Plater.SetNameplateColor(unitFrame, scriptTable.config.nameplateColor)\n    else\n        Plater.RefreshNameplateColor(unitFrame)\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1668886509,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 33,
					["Options"] = {
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								0, -- [1]
								0.5568627450980392, -- [2]
								0.03529411764705882, -- [3]
								1, -- [4]
							},
							["Key"] = "nameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Change the enemy nameplate color to this color when fixating you!",
						}, -- [1]
					},
					["Author"] = "Ditador-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Name"] = "Fixate by Unit Buff [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "Alert about a unit fixated on the player by using a buff on the enemy unit.",
					["semver"] = "",
					["Icon"] = "Interface\\ICONS\\Ability_Fixated_State_Red",
				}, -- [27]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do --max amount of segments is 20\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.Textures) then\n        for i = 1, scriptTable.config.segmentsAmount  do\n            local texture = unitFrame.felAnimation.Textures[i]\n            if (texture) then\n                texture:Hide()\n            end\n        end\n    end\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.textureStretched) then\n        local textureStretched = unitFrame.felAnimation.textureStretched\n        if (textureStretched) then\n            textureStretched:Hide()\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    if (not envTable.NextPercent) then\n        return\n    end\n    \n    local castBar = unitFrame.castBar\n    \n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then --eeror here, compare with nil\n        local nextPercent = 100  / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1672514190,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_glow",
					["Enabled"] = true,
					["Revision"] = 547,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Show a different animation for the cast bar.",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        --texture:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.trailColor))\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    Plater.SetCastBarColorForScript(self, true, customColor or scriptTable.config.castBarColor, envTable)\nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["SpellIds"] = {
						376644, -- [1]
						373017, -- [2]
						386781, -- [3]
						384823, -- [4]
						372735, -- [5]
						385536, -- [6]
						392398, -- [7]
						375596, -- [8]
						387135, -- [9]
						209033, -- [10]
						360850, -- [11]
						212784, -- [12]
						207980, -- [13]
						199033, -- [14]
						199034, -- [15]
						200969, -- [16]
						394512, -- [17]
						397881, -- [18]
						396020, -- [19]
						374430, -- [20]
						373201, -- [21]
					},
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Key"] = "segmentsAmount",
							["Value"] = 7,
							["Name"] = "Amount of Segments",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 7,
							["Key"] = "castColor",
							["Value"] = {
								{
									"385536", -- [1]
									"maroon", -- [2]
								}, -- [1]
								{
									"198750", -- [1]
									"midnightblue", -- [2]
								}, -- [2]
								{
									"360850", -- [1]
									"lime", -- [2]
								}, -- [3]
								{
									"212784", -- [1]
									"deepskyblue", -- [2]
								}, -- [4]
								{
									"207980", -- [1]
									"midnightblue", -- [2]
								}, -- [5]
								{
									"199033", -- [1]
									"gold", -- [2]
								}, -- [6]
								{
									"199034", -- [1]
									"gold", -- [2]
								}, -- [7]
								{
									"200969", -- [1]
									"orange", -- [2]
								}, -- [8]
								{
									"394512", -- [1]
									"indigo", -- [2]
								}, -- [9]
								{
									"397881", -- [1]
									"deepskyblue", -- [2]
								}, -- [10]
								{
									"396020", -- [1]
									"khaki", -- [2]
								}, -- [11]
							},
							["Name"] = "Cast Color by SpellID",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the Spell ID in the to Key and a color name into the Value",
						}, -- [4]
					},
					["version"] = -1,
					["Name"] = "Cast - Glowing [P]",
					["NpcNames"] = {
					},
				}, -- [28]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    \n    --set the castbar config\n    envTable.configAltCastBar = {\n        iconTexture = \"\",\n        iconTexcoord = {0.1, 0.9, 0.1, 0.9},\n        iconAlpha = 1,\n        iconSize = 14,\n        \n        text = \"Boom!\",\n        textSize = 9,\n        \n        texture = [[Interface\\AddOns\\Plater\\images\\bar_background]],\n        color = \"silver\",\n        \n        isChanneling = false,\n        canInterrupt = false,\n        \n        height = 2,\n        width = Plater.db.profile.plate_config.enemynpc.health_incombat[1],\n        \n        spellNameAnchor = {side = 3, x = 0, y = -2},\n        timerAnchor = {side = 5, x = 0, y = -2},\n    }    \n    \n    function envTable.ShowAltCastBar(npcInfo, unitFrame, unitId, customTime, customStart)\n        --show the cast bar\n        if (npcInfo.timerId) then\n            local barObject = Plater.GetBossTimer(npcInfo.timerId)\n            if (barObject) then\n                if (npcInfo.remaining) then\n                    local timeLeft = barObject.timer + barObject.start - GetTime()\n                    if (timeLeft > npcInfo.remaining) then\n                        return\n                    end\n                end\n                \n                config.text = npcInfo.name\n                \n                if (npcInfo.spellIcon) then\n                    local _, _, iconTexture = GetSpellInfo(npcInfo.spellIcon)\n                    config.iconTexture = iconTexture\n                else\n                    config.iconTexture = \"\"\n                end\n                \n                Plater.SetAltCastBar(unitFrame.PlateFrame, config, barObject.timer, customStart or barObject.start, npcInfo.altCastId)\n            end\n        else\n            Plater.SetAltCastBar(unitFrame.PlateFrame, config, customTime or npcInfo.timer, customStart, npcInfo.altCastId)            \n        end    \n        \n        \n    end\nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (envTable._SpellID == 191284) then\n        Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 4.70, GetTime(), 191284)\n        \n        C_Timer.After(4.75, function()\n                Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 5.30, GetTime(), 191284)\n        end)\n        \n        C_Timer.After(4.75 + 5.30, function()\n                Plater.SetAltCastBar(unitFrame.PlateFrame, envTable.configAltCastBar, 4.30, GetTime(), 191284)\n                C_Timer.After(4.50, function() unitFrame.castBar2:Hide() end)\n        end)\n    end\n    \nend",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1671066705,
					["url"] = "",
					["Icon"] = 134229,
					["Enabled"] = true,
					["Revision"] = 37,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Start extra cast bars for effects after the cast is done. Setup the effect on On Hide script.",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["SpellIds"] = {
						191284, -- [1]
					},
					["PlaterCore"] = 1,
					["Options"] = {
					},
					["version"] = -1,
					["Name"] = "Cast - Effect After Cast [P]",
					["NpcNames"] = {
					},
				}, -- [29]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    function envTable.PlaySwipeAnimation(unitFrame)\n        unitFrame.CastSwipeTexture:Show()\n        unitFrame.CastSwipeAnimation:Play()\n        unitFrame.StartSwipeAnimation:Play()\n    end\n    \n    function envTable.StopSwipeAnimation(unitFrame)\n        unitFrame.EndSwipeAnimation:Play()\n        C_Timer.After(0.21, function()\n                unitFrame.CastSwipeAnimation:Stop()\n                unitFrame.CastSwipeTexture:Hide()\n        end)\n    end\n    \n    function envTable.CreateSwipeTextureAndAnimations(unitFrame)\n        if (unitFrame.CastSwipeTexture) then\n            return\n        end\n        \n        local swipeTexture = unitFrame:CreateTexture(nil, \"overlay\")\n        swipeTexture:SetTexture([[Interface\\AddOns\\Plater\\images\\circular_swipe]])\n        swipeTexture:SetPoint(\"center\", 0, 0)\n        swipeTexture:SetSize(64, 64)\n        swipeTexture:Hide()\n        \n        unitFrame.CastSwipeTexture = swipeTexture\n        \n        --rotation animation\n        unitFrame.CastSwipeAnimation = Plater:CreateAnimationHub(swipeTexture)\n        unitFrame.CastSwipeAnimation:SetLooping(\"repeat\")\n        unitFrame.CastSwipeAnimation.Rotation = Plater:CreateAnimation(unitFrame.CastSwipeAnimation, \"rotation\", 1, 1, 360)\n        \n        --starting animation\n        unitFrame.StartSwipeAnimation = Plater:CreateAnimationHub(swipeTexture, function()swipeTexture:Show() end)\n        unitFrame.StartSwipeAnimation.Alpha = Plater:CreateAnimation(unitFrame.StartSwipeAnimation, \"alpha\", 1, 0.2, 0, 1)\n        unitFrame.StartSwipeAnimation.Scale = Plater:CreateAnimation(unitFrame.StartSwipeAnimation, \"scale\", 1, 0.2, 1.3, 1.3, 1, 1)        \n        \n        --finished animation\n        unitFrame.EndSwipeAnimation = Plater:CreateAnimationHub(swipeTexture, nil, function()swipeTexture:Hide() end)\n        unitFrame.EndSwipeAnimation.Alpha = Plater:CreateAnimation(unitFrame.EndSwipeAnimation, \"alpha\", 1, 0.2, 1, 0)\n        unitFrame.EndSwipeAnimation.Scale = Plater:CreateAnimation(unitFrame.EndSwipeAnimation, \"scale\", 1, 0.2, 1, 1, 1.3, 1.3)\n    end\n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.StopSwipeAnimation(unitFrame)\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "		function (self, unitId, unitFrame, envTable, scriptTable)\n			--insert code here\n			\n		end\n	",
					["Time"] = 1670428019,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\circular_swipe",
					["Enabled"] = true,
					["Revision"] = 162,
					["semver"] = "",
					["Author"] = "Butazzul-Valdrakken",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Play a animation when the spell effect is an circular AoE around the caster.",
					["NpcNames"] = {
					},
					["SpellIds"] = {
						385916, -- [1]
						386063, -- [2]
						388822, -- [3]
						373087, -- [4]
						397785, -- [5]
						106864, -- [6]
						193660, -- [7]
						198263, -- [8]
						387910, -- [9]
						370766, -- [10]
						375591, -- [11]
						384336, -- [12]
						209404, -- [13]
						209378, -- [14]
						210875, -- [15]
						396001, -- [16]
						397899, -- [17]
						386559, -- [18]
						382555, -- [19]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Circle AoE [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 0.3,
							["Desc"] = "Rotation Duration",
							["Min"] = 0.1,
							["Name"] = "Rotation Duration",
							["Value"] = 0.15,
							["Key"] = "rotationDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [1]
						{
							["Type"] = 6,
							["Name"] = "Option 5",
							["Value"] = 0,
							["Key"] = "option5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 2,
							["Max"] = 1.5,
							["Desc"] = "Animation Start Duration",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.3,
							["Key"] = "animStartDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Animation Start Duration",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Texture Alpha when the animation start playing, this effect in intended to catch the player attention",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 1,
							["Name"] = "Texture Start Alpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "textureStartAlpha",
						}, -- [4]
						{
							["Type"] = 6,
							["Key"] = "option5",
							["Value"] = 0,
							["Name"] = "Option 5",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "Texture Scale",
							["Min"] = 0.6,
							["Name"] = "Texture Scale",
							["Value"] = 0.8,
							["Key"] = "textureScale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Texture Alpha",
							["Min"] = 0,
							["Name"] = "Texture Alpha",
							["Value"] = 1,
							["Key"] = "textureAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [7]
						{
							["Type"] = 1,
							["Name"] = "Texture Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "textureColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Texture Color",
						}, -- [8]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.CreateSwipeTextureAndAnimations(unitFrame)\n    \n    local options = scriptTable.config\n    \n    local targetScale = scriptTable.config.textureScale\n    \n    --swipe rotation duration    \n    unitFrame.CastSwipeAnimation.Rotation:SetDuration(scriptTable.config.rotationDuration)\n    \n    --swipe texture settings\n    unitFrame.CastSwipeTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.textureColor))\n    unitFrame.CastSwipeTexture:SetScale(targetScale)\n    unitFrame.CastSwipeTexture:SetAlpha(scriptTable.config.textureAlpha)  \n    \n    unitFrame.StartSwipeAnimation.Alpha:SetDuration(scriptTable.config.animStartDuration)\n    unitFrame.StartSwipeAnimation.Alpha:SetFromAlpha(scriptTable.config.textureStartAlpha)\n    unitFrame.StartSwipeAnimation.Alpha:SetToAlpha(scriptTable.config.textureAlpha)\n    \n    unitFrame.StartSwipeAnimation.Scale:SetDuration(scriptTable.config.animStartDuration)\n    unitFrame.StartSwipeAnimation.Scale:SetScaleTo(targetScale, targetScale)\n    \n    unitFrame.EndSwipeAnimation.Scale:SetDuration(0.1)\n    unitFrame.EndSwipeAnimation.Alpha:SetDuration(0.1)\n    \n    --start playing\n    envTable.PlaySwipeAnimation(unitFrame)    \n    \nend\n\n\n",
				}, -- [30]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    envTable.lifePercent = { --dragonflight\n        [197697] = {50}, --Flamegullet\n        [59544] = {50}, --The Nodding Tiger\n        \n    }\n    \n    \n    function envTable.CreateMarker(unitFrame)\n        unitFrame.healthMarker = unitFrame.healthBar:CreateTexture(nil, \"overlay\")\n        unitFrame.healthMarker:SetColorTexture(1, 1, 1)\n        unitFrame.healthMarker:SetSize(1, unitFrame.healthBar:GetHeight())\n        \n        unitFrame.healthOverlay = unitFrame.healthBar:CreateTexture(nil, \"overlay\")\n        unitFrame.healthOverlay:SetColorTexture(1, 1, 1)\n        unitFrame.healthOverlay:SetSize(1, unitFrame.healthBar:GetHeight())\n    end\n    \n    function envTable.UpdateMarkers(unitFrame)\n        local markersTable = envTable.lifePercent[envTable._NpcID]\n        if (markersTable) then\n            local unitLifePercent = envTable._HealthPercent / 100\n            for i, percent in ipairs(markersTable) do\n                percent = percent / 100\n                if (unitLifePercent > percent) then\n                    if (not unitFrame.healthMarker) then\n                        envTable.CreateMarker(unitFrame)\n                    end\n                    \n                    unitFrame.healthMarker:Show()\n                    local width = unitFrame.healthBar:GetWidth()\n                    unitFrame.healthMarker:SetPoint(\"left\", unitFrame.healthBar, \"left\", width*percent, 0)\n                    \n                    local overlaySize = width * (unitLifePercent - percent)\n                    unitFrame.healthOverlay:SetWidth(overlaySize)\n                    unitFrame.healthOverlay:SetPoint(\"left\", unitFrame.healthMarker, \"right\", 0, 0)\n                    \n                    unitFrame.healthMarker:SetVertexColor(Plater:ParseColors(scriptTable.config.indicatorColor))\n                    unitFrame.healthMarker:SetAlpha(scriptTable.config.indicatorAlpha)\n                    \n                    unitFrame.healthOverlay:SetVertexColor(Plater:ParseColors(scriptTable.config.fillColor))\n                    unitFrame.healthOverlay:SetAlpha(scriptTable.config.fillAlpha)\n                    \n                    return\n                end\n            end --end for\n            \n            if (unitFrame.healthMarker and unitFrame.healthMarker:IsShown()) then\n                unitFrame.healthMarker:Hide()\n                unitFrame.healthOverlay:Hide()\n            end\n        end\n    end\nend      \n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (unitFrame.healthMarker) then\n        unitFrame.healthMarker:Hide()\n        unitFrame.healthOverlay:Hide()\n    end\nend\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateMarkers(unitFrame)\nend\n\n\n",
					["Time"] = 1669340967,
					["url"] = "",
					["NpcNames"] = {
						"197697", -- [1]
						"59544", -- [2]
					},
					["Enabled"] = true,
					["Revision"] = 137,
					["Options"] = {
						{
							["Type"] = 5,
							["Key"] = "option1",
							["Value"] = "Add markers into the health bar to remind you about boss abilities at life percent.",
							["Name"] = "Option 1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "",
							["Value"] = 0,
							["Name"] = "blank line",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "indicatorColor",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Vertical Line Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Indicator color.",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Indicator alpha.",
							["Min"] = 0.1,
							["Name"] = "Vertical Line Alpha",
							["Value"] = 0.79,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "indicatorAlpha",
						}, -- [4]
						{
							["Type"] = 6,
							["Name"] = "blank line",
							["Value"] = 0,
							["Key"] = "",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Fill Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "fillColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Fill color.",
						}, -- [6]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Fill alpha.",
							["Min"] = 0,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "fillAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Fill Alpha",
						}, -- [7]
					},
					["Author"] = "Aelerolor-Torghast",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.UpdateMarkers(unitFrame)\nend\n\n\n",
					["Name"] = "Add - Health Markers [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "Place a marker into the health bar to indicate when the unit will change phase or cast an important spell.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\health_indicator",
				}, -- [31]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.NameplateColor = scriptTable.config.nameplateColor\n    envTable.NameplateSizeOffset = scriptTable.config.nameplateSizeOffset\n    \n    unitFrame.UnitImportantSkullTexture = unitFrame.UnitImportantSkullTexture or unitFrame:CreateTexture(nil, \"background\")\n    \n    unitFrame.UnitImportantSkullTexture:Hide()\nend\n\n--[=[\n\n154564 - debug\n\nUsing spellIDs for multi-language support\n\n196548 = ancient branch (academy dungeon)\n195580, 195821, 195820 = nokhub saboteur\n189886 = blazebound firestorm\n75966 = Defiled Spirit\n102019 = Stormforged Obliterator\n    187159 = Shrieking Whelp\n194897 = stormsurge totem\n104251 = duskwatch sentry\n101326 = honored ancestor\n189669 = binding speakl netharius\n192464 = raging ember neltharius\n--]=]\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable)\n    Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)   \n    \n    --restore the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight)    \n    \n    unitFrame.UnitImportantSkullTexture:Hide()\n    Plater.DenyColorChange(unitFrame, false)\nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --check if can change the nameplate color\n    if (scriptTable.config.changeNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n\n\n",
					["Time"] = 1670423785,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\skullbones_64",
					["Enabled"] = true,
					["Revision"] = 572,
					["semver"] = "",
					["Author"] = "Izimode-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Change the color and highlight a nameplate of an important Add. Add the unit name or NpcID into the trigger box to add more.",
					["NpcNames"] = {
						"196548", -- [1]
						"195580", -- [2]
						"195820", -- [3]
						"195821", -- [4]
						"189886", -- [5]
						"75966", -- [6]
						"102019", -- [7]
						"187159", -- [8]
						"194897", -- [9]
						"104251", -- [10]
						"101326", -- [11]
						"189669", -- [12]
						"192464", -- [13]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Important [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Key"] = "option6",
							["Value"] = "Enter the npc name or npcId in the \"Add Trigger\" box and hit \"Add\".",
							["Name"] = "Option 6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Key"] = "changeNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "change to true to change the color",
						}, -- [4]
						{
							["Type"] = 1,
							["Key"] = "nameplateColor",
							["Value"] = {
								1, -- [1]
								0, -- [2]
								0.5254901960784314, -- [3]
								1, -- [4]
							},
							["Name"] = "Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 6,
							["Desc"] = "increase the nameplate height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 3,
							["Key"] = "nameplateSizeOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Nameplate Size Offset",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 1,
							["Key"] = "dotsColor",
							["Value"] = {
								1, -- [1]
								0.7137255072593689, -- [2]
								0, -- [3]
								0.5631310641765594, -- [4]
							},
							["Name"] = "Dot Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Dot Color",
						}, -- [8]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 5,
							["Key"] = "option10",
							["Value"] = "Extra Texture",
							["Name"] = "Extra Texture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "Extra Texture",
						}, -- [10]
						{
							["Type"] = 4,
							["Name"] = "Show Extra Texture",
							["Value"] = false,
							["Key"] = "showExtraTexture",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show Extra Texture",
						}, -- [11]
						{
							["Type"] = 1,
							["Key"] = "skullColor",
							["Value"] = {
								1, -- [1]
								0.4627450980392157, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Name"] = "Texture Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Texture Color",
						}, -- [12]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Alpha",
							["Min"] = 0,
							["Name"] = "Alpha",
							["Value"] = 0.2,
							["Key"] = "skullAlpha",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [13]
						{
							["Type"] = 2,
							["Max"] = 2,
							["Desc"] = "Scale",
							["Min"] = 0.4,
							["Key"] = "skullScale",
							["Value"] = 0.6,
							["Fraction"] = true,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Scale",
						}, -- [14]
						{
							["Type"] = 7,
							["Name"] = "Npc Color By NpcID",
							["Value"] = {
								{
									"196548", -- [1]
									"forestgreen", -- [2]
								}, -- [1]
								{
									"195580", -- [1]
									"forestgreen", -- [2]
								}, -- [2]
								{
									"195820", -- [1]
									"forestgreen", -- [2]
								}, -- [3]
								{
									"195821", -- [1]
									"forestgreen", -- [2]
								}, -- [4]
								{
									"189886", -- [1]
									"forestgreen", -- [2]
								}, -- [5]
								{
									"75966", -- [1]
									"forestgreen", -- [2]
								}, -- [6]
								{
									"102019 ", -- [1]
									"forestgreen", -- [2]
								}, -- [7]
								{
									"187159", -- [1]
									"forestgreen", -- [2]
								}, -- [8]
								{
									"194897", -- [1]
									"forestgreen", -- [2]
								}, -- [9]
								{
									"104251", -- [1]
									"forestgreen", -- [2]
								}, -- [10]
							},
							["Key"] = "npcColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Key is the npcID, value is the color name",
						}, -- [15]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (envTable.dotAnimation) then\n        Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation)\n    end\n    \n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.healthBar, 2, scriptTable.config.dotsColor, 3, 4) \n    \n    --increase the nameplate size\n    local nameplateHeight = Plater.db.profile.plate_config.enemynpc.health_incombat [2]\n    unitFrame.healthBar:SetHeight (nameplateHeight + envTable.NameplateSizeOffset)\n    \n    unitFrame.UnitImportantSkullTexture:Show()\n    \n    --color priority:\n    local npcIdString = tostring(envTable._NpcID)\n    envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.nameplateColor)    \n    \n    if (scriptTable.config.showExtraTexture) then\n        unitFrame.UnitImportantSkullTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.skullColor))\n        unitFrame.UnitImportantSkullTexture:SetAlpha(scriptTable.config.skullAlpha)\n        unitFrame.UnitImportantSkullTexture:SetScale(scriptTable.config.skullScale)\n        unitFrame.UnitImportantSkullTexture:SetTexture([[Interface/AddOns/Plater/media/x_64]])\n        unitFrame.UnitImportantSkullTexture:ClearAllPoints()\n        unitFrame.UnitImportantSkullTexture:SetPoint(\"right\", unitFrame.healthBar, \"left\", -2, 0)\n        unitFrame.UnitImportantSkullTexture:SetSize(28, 28)\n        unitFrame.UnitImportantSkullTexture:Show()\n    else\n        unitFrame.UnitImportantSkullTexture:Hide()\n    end\n    \n    --rules for some npcs\n    if (envTable._NpcID == 194895) then --unstable squall (explode at dying\n        unitFrame.UnitImportantSkullTexture:Hide()\n        Plater.StopDotAnimation(unitFrame.healthBar, envTable.dotAnimation) \n    end\n    \n    if (scriptTable.config.changeNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        \n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.nameplateColor)        \n        \n        Plater.DenyColorChange(unitFrame, true)\n    end\n    \nend\n\n\n\n\n",
				}, -- [32]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.AddSpawnIDTexture) then\n        unitFrame.AddSpawnIDTexture:Hide()\n        unitFrame.AddIcon:Hide()\n        unitFrame.AddNumber:Hide()\n    end\n    \nend\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Time"] = 1669340442,
					["url"] = "",
					["Icon"] = "interface/addons/plater/images/add_id_icon",
					["Enabled"] = false,
					["Revision"] = 161,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    \n    scriptTable.allAdds = {} \n    scriptTable.nextAddWave = 0\n    scriptTable.waveTime = 20\n    \n    function scriptTable.ArrangeNpcNumbers(GUID)\n        local spawnId = select(7, strsplit (\"-\", GUID))\n        spawnId = tonumber(spawnId, 16)\n        \n        if (spawnId) then\n            --check if this is a new wave of adds\n            if (GetTime() > scriptTable.nextAddWave) then\n                scriptTable.nextAddWave = GetTime() + scriptTable.waveTime\n                scriptTable.allAdds = {}\n            end\n            \n            local bIsAlreadyOnTheList = false\n            \n            for o = 1, #scriptTable.allAdds do\n                if (scriptTable.allAdds[o][1] == GUID) then\n                    bIsAlreadyOnTheList = true\n                end\n            end\n            \n            if (not bIsAlreadyOnTheList) then\n                scriptTable.allAdds[#scriptTable.allAdds+1] = {GUID, spawnId}\n            end\n        end\n        \n        table.sort(scriptTable.allAdds, function(t1, t2) return t1[2] < t2[2] end)\n        \n        --this is a \"loop\" because this is running each time a nameplate is added!\n        \n        for namePlateIndex, plateFrame in ipairs(Plater.GetAllShownPlates()) do\n            local unitFrame = plateFrame.unitFrame\n            \n            --get the unit GUID\n            local unitGUID = unitFrame.namePlateUnitGUID\n            \n            for addId = 1, #scriptTable.allAdds do\n                local addTable = scriptTable.allAdds[addId]\n                local addGUID = addTable[1]\n                \n                if (unitGUID == addGUID) then\n                    scriptTable.TagNameplate(unitFrame, unitGUID, addId)\n                    break\n                end\n            end\n            \n        end\n    end\n    \n    function scriptTable.TagNameplate(unitFrame, GUID, addId)\n        scriptTable.CreateAddWidgetsForNameplate(unitFrame, GUID, addId)\n        \n        if (addId and addId >= 1 and addId <= 8) then\n            unitFrame.AddSpawnIDTexture:Show()\n            unitFrame.AddIcon:Show()\n            unitFrame.AddNumber:Show()\n            \n            local addTexture = \"Interface\\\\TargetingFrame\\\\UI-RaidTargetingIcon_\" .. addId\n            \n            unitFrame.AddIcon:SetTexture(addTexture)\n            unitFrame.AddNumber:SetText(addId)\n        end\n    end\n    \n    function scriptTable.CreateAddWidgetsForNameplate(unitFrame, GUID, addId)\n        if (not unitFrame.AddSpawnIDTexture) then\n            local healthBar = unitFrame.healthBar\n            \n            local textureBackground = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 5)\n            local addIcon = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 6)\n            local addNumber = healthBar.FrameOverlay:CreateFontString(nil, \"overlay\", \"GameFontNormal\", 6)           \n            \n            unitFrame.AddSpawnIDTexture = textureBackground\n            unitFrame.AddIcon = addIcon\n            unitFrame.AddNumber = addNumber\n        end\n    end    \nend\n\n--Creature-0-2085-1-11042-153285-0002F8DB2B --training dummy for testing\n--195138 Detonating Crystal\n--192955 dracomoc illusion\n--190294 nokhub stormcaster\n--76518 ritual of bones\n\n\n\n\n",
					["Desc"] = "Put a number above multiples adds, numbers follow their respawn id.",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.AddSpawnIDTexture) then\n        unitFrame.AddSpawnIDTexture:Hide()\n        unitFrame.AddIcon:Hide()\n        unitFrame.AddNumber:Hide()\n    end\n    \n    scriptTable.ArrangeNpcNumbers(unitFrame.namePlateUnitGUID)\n    \n    local textureBackground = unitFrame.AddSpawnIDTexture\n    textureBackground:SetSize(22, 10)\n    textureBackground:ClearAllPoints()\n    textureBackground:SetPoint(\"bottomright\", unitFrame.healthBar, \"topright\", 0, 1)\n    \n    textureBackground:SetMask([[Interface\\AddOns\\Plater\\masks\\mask_smallrectangle_rounded1]])\n    textureBackground:SetTexture([[Interface\\AddOns\\Plater\\masks\\mask_smallrectangle_rounded1]])\n    textureBackground:SetVertexColor(0.1215, 0.1176, 0.1294, 1)\n    \n    \n    --textureBackground:SetMask([[Interface/ChatFrame/UI-ChatIcon-HotS]])\n    --    \"Interface/ChatFrame/UI-ChatIcon-HotS\"\n    \n    local addIcon = unitFrame.AddIcon\n    addIcon:ClearAllPoints()\n    addIcon:SetPoint(\"left\", textureBackground, \"left\", 2, 0)\n    addIcon:SetSize(10, 10)\n    \n    local addNumber = unitFrame.AddNumber\n    addNumber:ClearAllPoints()\n    addNumber:SetPoint(\"right\", textureBackground, \"right\", -2, 0)\n    DetailsFramework:SetFontSize(addNumber, 10)\n    \nend\n\n\n",
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Options"] = {
					},
					["version"] = -1,
					["Name"] = "Add - Tag Number [P]",
					["NpcNames"] = {
						"195138", -- [1]
						"192955", -- [2]
						"190294", -- [3]
						"76518", -- [4]
					},
				}, -- [33]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --castbar color (when can be interrupted)\n    envTable.CastbarColor = scriptTable.config.castbarColor\n    \n    --flash duration\n    local CONFIG_BACKGROUND_FLASH_DURATION = scriptTable.config.flashDuration\n    \n    --add this value to the cast bar height\n    envTable.CastBarHeightAdd = scriptTable.config.castBarHeight\n    \n    --create a fast flash above the cast bar\n    envTable.FullBarFlash = envTable.FullBarFlash or Plater.CreateFlash (self, 0.05, 1, \"white\")\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+60, self:GetHeight()+50, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    envTable.BackgroundFlash.fadeIn = envTable.BackgroundFlash.fadeIn or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, CONFIG_BACKGROUND_FLASH_DURATION/2, 0, .75)\n    envTable.BackgroundFlash.fadeIn:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    envTable.BackgroundFlash.fadeOut = envTable.BackgroundFlash.fadeOut or Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, CONFIG_BACKGROUND_FLASH_DURATION/2, 1, 0)    \n    envTable.BackgroundFlash.fadeOut:SetDuration(CONFIG_BACKGROUND_FLASH_DURATION/2)\n    \n    --envTable.BackgroundFlash:Play() --envTable.BackgroundFlash:Stop()    \n    \n    \n    \n    \n    \nend\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end    \n    \n    unitFrame.castBar:SetHeight (envTable._DefaultHeight)\n    \n    --stop the camera shake\n    unitFrame:StopFrameShake (envTable.FrameShake)\n    \n    envTable.FullBarFlash:Stop()\n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1669324381,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 887,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Produces a notable but fast effect in the cast bar when a spell from the 'Triggers' starts to cast.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Name"] = "Option 3",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Key"] = "option3",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Blank Space",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 4,
							["Name"] = "Cast Bar Color Enabled",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "When enabled, changes the cast bar color,",
						}, -- [5]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								1, -- [1]
								0.4313725490196079, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the cast bar.",
						}, -- [6]
						{
							["Type"] = 6,
							["Name"] = "Blank Line",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [7]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts it flash rapidly, adjust how fast it flashes. Value is milliseconds.",
							["Min"] = 0.05,
							["Fraction"] = true,
							["Value"] = 0.2,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Flash Duration",
						}, -- [8]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Increases the cast bar height by this value",
							["Min"] = 0,
							["Fraction"] = false,
							["Value"] = 0,
							["Key"] = "castBarHeight",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Cast Bar Height Mod",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Fraction"] = true,
							["Value"] = 0.1,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Shake Duration",
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 200,
							["Desc"] = "How strong is the shake.",
							["Min"] = 10,
							["Name"] = "Shake Amplitude",
							["Value"] = 25,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 30,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
					},
					["Author"] = "Tercioo-Sylvanas",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --don't execute on battlegrounds and arenas\n    if (Plater.ZoneInstanceType == \"arena\" or Plater.ZoneInstanceType == \"pvp\") then\n        return\n    end\n    \n    --play flash animations\n    envTable.FullBarFlash:Play()\n    \n    --envTable.currentHeight = unitFrame.castBar:GetHeight()\n    \n    --restoring the default size (not required since it already restore in the hide script)\n    if (envTable.OriginalHeight) then\n        self:SetHeight (envTable.OriginalHeight)\n    end\n    \n    --increase the cast bar size\n    local height = self:GetHeight()\n    envTable.OriginalHeight = height\n    \n    self:SetHeight (height + envTable.CastBarHeightAdd)\n    \n    Plater.SetCastBarBorderColor (self, 1, .2, .2, 0.4)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\n    \n    envTable.BackgroundFlash:Play()\n    \n    unitFrame.castBar.Spark:SetHeight(unitFrame.castBar:GetHeight())\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["Name"] = "Cast - Quick Flash [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						392640, -- [1]
						397888, -- [2]
						381517, -- [3]
					},
					["Desc"] = "Play a very fast flash when the cast start",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_quickflash.tga",
				}, -- [34]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n--190187 draconic image\n--189893 infused whelp\n--99922 Ebonclaw Packmate\n--104822 flames of woe",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.DenyColorChange(unitFrame, false)\n    unitFrame.onShowAddToKillFlash:Stop()\n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor(unitFrame, envTable.NameplateColor)\n    end\nend\n\n\n\n\n",
					["Time"] = 1670427654,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/exclamation_64",
					["Enabled"] = true,
					["Revision"] = 162,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Change the color of  add",
					["NpcNames"] = {
						"190187", -- [1]
						"189893", -- [2]
						"99922", -- [3]
						"104822", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Warning [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = true,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								1, -- [1]
								0.4392157196998596, -- [2]
								0.458823561668396, -- [3]
								1, -- [4]
							},
							["Key"] = "healthBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option5",
							["Value"] = 0,
							["Name"] = "Blank Space",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Flash Nameplate",
							["Value"] = true,
							["Key"] = "useFlash",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Flash Nameplate",
						}, -- [4]
						{
							["Type"] = 7,
							["Name"] = "NpcID to Color",
							["Value"] = {
								{
									"189893", -- [1]
									"olivedrab", -- [2]
								}, -- [1]
								{
									"190187", -- [1]
									"olivedrab", -- [2]
								}, -- [2]
								{
									"99922", -- [1]
									"olivedrab", -- [2]
								}, -- [3]
								{
									"153285", -- [1]
									"olivedrab", -- [2]
								}, -- [4]
								{
									"104822", -- [1]
									"olivedrab", -- [2]
								}, -- [5]
							},
							["Key"] = "npcColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "If the npc isn't on this list, use the default color set in the Health Bar Color",
						}, -- [5]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    unitFrame.onShowAddToKillFlash = unitFrame.onShowAddToKillFlash or Plater.CreateFlash (unitFrame.healthBar, 0.25, 1, \"white\")\n    \n    if (scriptTable.config.useFlash) then\n        unitFrame.onShowAddToKillFlash:Play()\n    end\n    \n    if (scriptTable.config.useNameplateColor) then\n        local npcIdString = tostring(envTable._NpcID)\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.npcColor[npcIdString], scriptTable.config.healthBarColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end\nend\n\n\n\n\n\n\n\n\n\n",
				}, -- [35]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n\n--Scorchling 194622\n--Scorchling 190205\n--197398  Hungry Lasher\n--77006 corpse skitterling\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    --restoring and color state and scale even if disabled, maybe the player disabled during the combat\n    Plater.DenyColorChange(unitFrame, false)\n    unitFrame.healthBar:SetScale(unitFrame.healthBar._savedOriginalScale)\n    \nend\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        Plater.SetNameplateColor (unitFrame, envTable.NameplateColor)\n    end\n    \nend\n\n\n",
					["Time"] = 1670427838,
					["url"] = "",
					["Icon"] = "interface/addons/plater/media/duck_64",
					["Enabled"] = true,
					["Revision"] = 111,
					["semver"] = "",
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "",
					["NpcNames"] = {
						"194622", -- [1]
						"190205", -- [2]
						"197398", -- [3]
						"77006", -- [4]
					},
					["SpellIds"] = {
					},
					["PlaterCore"] = 1,
					["Name"] = "Add - Non Elite Trash [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useNameplateColor",
							["Value"] = false,
							["Name"] = "Change Nameplate Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Color",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Nameplate Color",
							["Value"] = {
								0.062745101749897, -- [1]
								0.062745101749897, -- [2]
								0.0941176563501358, -- [3]
								1, -- [4]
							},
							["Key"] = "nameplateColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Nameplate Color",
						}, -- [2]
						{
							["Type"] = 6,
							["Key"] = "option4",
							["Value"] = 0,
							["Name"] = "Option 4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 4,
							["Name"] = "Change Nameplate Scale",
							["Value"] = true,
							["Key"] = "useNameplateScale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Change Nameplate Scale",
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "Nameplate Scale",
							["Min"] = 0,
							["Key"] = "scale",
							["Value"] = 0.8,
							["Name"] = "Nameplate Scale",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [5]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (scriptTable.config.useNameplateColor) then\n        envTable.NameplateColor = Plater.GetColorByPriority(unitFrame, scriptTable.config.nameplateColor)\n        Plater.DenyColorChange(unitFrame, true)\n    end    \n    \n    unitFrame.healthBar._savedOriginalScale = unitFrame.healthBar:GetScale()\n    \n    if (scriptTable.config.useNameplateScale) then\n        unitFrame.healthBar:SetScale(scriptTable.config.scale)\n    end\n    \nend\n\n\n\n\n",
				}, -- [36]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    \n    if (not healthBar.absorbBar) then\n        healthBar.absorbBar = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\")\n        healthBar.absorbBar:SetTexture([[Interface\\RaidFrame\\Shield-Fill]])\n        healthBar.absorbBar:Hide()\n    end\n    \n    if (not healthBar.absorbSpark) then\n        healthBar.absorbSpark = healthBar.FrameOverlay:CreateTexture(nil, \"overlay\")\n        healthBar.absorbSpark:SetTexture([[Interface\\CastingBar\\UI-CastingBar-Spark]])\n        healthBar.absorbSpark:SetBlendMode(\"ADD\")\n        healthBar.absorbSpark:Hide()\n    end\n    \nend\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Hide()    \n    healthBar.absorbSpark:Hide()\n    \nend\n\n\n",
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Show()\n    healthBar.absorbSpark:Show()\n    \n    local maxValue = healthBar.absorbBar.MaxValue\n    local currentValue = UnitGetTotalAbsorbs(unitId) or 0\n    \n    if (currentValue > 0) then\n        local minValue = 0\n        \n        local percent = currentValue / maxValue\n        healthBar.absorbBar:SetTexCoord(0, percent, 0, 1)\n        healthBar.absorbBar:SetWidth(percent * healthBar:GetWidth())\n        \n        healthBar.absorbSpark:SetPoint(\"left\", healthBar, \"left\", percent * healthBar:GetWidth() - 16, 0)\n        \n    else\n        healthBar.absorbBar:Hide()    \n        healthBar.absorbSpark:Hide()\n    end\n    \n    self.ThrottleUpdate = 0\n    \nend\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1669325411,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 101,
					["Options"] = {
					},
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    if (not UnitGetTotalAbsorbs) then\n        return\n    end\n    \n    local healthBar = unitFrame.healthBar\n    \n    healthBar.absorbBar:Show()\n    healthBar.absorbSpark:Show()\n    \n    healthBar.absorbBar:SetTexture([[Interface\\RaidFrame\\Shield-Fill]])\n    \n    healthBar.absorbBar:ClearAllPoints()    \n    healthBar.absorbBar:SetPoint(\"topleft\", healthBar, \"topleft\", 0, 0)\n    healthBar.absorbBar:SetPoint(\"bottomleft\", healthBar, \"bottomleft\", 0, 0)\n    \n    healthBar.absorbBar:SetAlpha(1)\n    \n    healthBar.absorbBar.MaxValue = UnitGetTotalAbsorbs(unitId) or 0\n    healthBar.absorbBar.MinValue = 0\nend\n\n\n",
					["Name"] = "Cast - Shield Interrupt [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						373688, -- [1]
						391050, -- [2]
					},
					["Desc"] = "When the caster has a shield and only when the shield is removed the cast can be interrupted",
					["semver"] = "",
					["Icon"] = "interface/addons/plater/images/cast_bar - absorb",
				}, -- [37]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.stopCastingX) then\n        unitFrame.stopCastingX = castBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 7)\n        unitFrame.stopCastingX:SetPoint(\"center\", unitFrame.castBar.Spark, \"center\", 0, 0)\n        unitFrame.stopCastingX:SetTexture([[Interface\\AddOns\\Plater\\Media\\stop_64]])\n        unitFrame.stopCastingX:SetSize(16, 16)\n        unitFrame.stopCastingX:Hide()\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:Hide()\n    end\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Hide()    \n    unitFrame.stopCastingX:Hide()\n    \n    self.Text:SetDrawLayer(\"overlay\", 0)\n    self.Spark:SetDrawLayer(\"overlay\", 3)\n    self.Spark:Show()\n    \nend\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then\n        local nextPercent = 100 / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        \n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        --print(envTable.NextPercent, envTable.CurrentTexture)\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \n    self.ThrottleUpdate = 0\nend",
					["Time"] = 1672514185,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\stop_64",
					["Enabled"] = true,
					["Revision"] = 506,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Just stop casting",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        --local duration = 0.6 --debug\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    unitFrame.stopCastingX:Show()\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    self.Text:SetDrawLayer(\"artwork\", 7)\n    self.Spark:SetDrawLayer(\"artwork\", 7)\n    self.Spark:Hide()\nend\n\n\n\n\n\n\n\n\n",
					["SpellIds"] = {
						377004, -- [1]
						381516, -- [2]
						196543, -- [3]
						199726, -- [4]
					},
					["PlaterCore"] = 1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Fraction"] = false,
							["Value"] = 20,
							["Key"] = "segmentsAmount",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Amount of Segments",
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
					},
					["version"] = -1,
					["Name"] = "Cast - Stop Casting [P]",
					["NpcNames"] = {
					},
				}, -- [38]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    function envTable.CreateWidgets()\n        --create a camera shake for the nameplate\n        if (not unitFrame.AddExplosionOnDieShake) then\n            unitFrame.AddExplosionOnDieShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n        end\n        \n        if (not unitFrame.AddExplosionOnDieBackground) then\n            unitFrame.AddExplosionOnDieBackground = unitFrame.healthBar:CreateTexture(nil, \"background\")\n            unitFrame.AddExplosionOnDieBackground:SetAllPoints(unitFrame.healthBar)\n            unitFrame.AddExplosionOnDieBackground:SetColorTexture(1, 0, 0, 1)\n        end\n    end\n    \nend\n\n--194895 = unstable squall\n--105703 = mana wyrm\n--59598 = lesser sha\n--58319 = lesser sha\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    healthBar:SetReverseFill(false)\n    \n    if (unitFrame.AddExplosionOnDieShake) then\n        unitFrame:StopFrameShake (unitFrame.AddExplosionOnDieShake)    \n    end\n    \n    if (unitFrame.AddExplosionOnDieBackground) then\n        unitFrame.AddExplosionOnDieBackground:Hide()\n    end\nend\n\n\n\n\n\n\n\n\n",
					["ScriptType"] = 3,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (envTable._HealthPercent < 50) then\n        local alpha = DetailsFramework:MapRangeClamped(0, 50, 0.5, 0, envTable._HealthPercent)\n        \n        unitFrame.AddExplosionOnDieBackground:SetAlpha(alpha)\n    else\n        unitFrame.AddExplosionOnDieBackground:SetAlpha(0)\n    end\n    \n    if (envTable._HealthPercent < 15 and scriptTable.config.useShake) then\n        local shakeAmpliture = DetailsFramework:MapRangeClamped(0.001, 15, 10, 1, envTable._HealthPercent)\n        \n        unitFrame.AddExplosionOnDieShake.OriginalAmplitude = scriptTable.config.shakeAmplitude * shakeAmpliture\n        unitFrame.AddExplosionOnDieShake.OriginalFrequency = scriptTable.config.shakeFrequency\n        \n        unitFrame:PlayFrameShake (unitFrame.AddExplosionOnDieShake)\n    end\n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["Time"] = 1669340350,
					["url"] = "",
					["NpcNames"] = {
						"194895", -- [1]
						"105703", -- [2]
						"59598", -- [3]
						"58319", -- [4]
						200388, -- [5]
					},
					["Enabled"] = true,
					["Revision"] = 106,
					["Options"] = {
						{
							["Type"] = 4,
							["Key"] = "useReverse",
							["Value"] = false,
							["Name"] = "Reverse Health Bar",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 6,
							["Key"] = "option6",
							["Value"] = 0,
							["Name"] = "Option 6",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 4,
							["Key"] = "useShake",
							["Value"] = false,
							["Name"] = "Enable Shake",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 2,
							["Max"] = 1,
							["Desc"] = "How strong is the shake.",
							["Min"] = 0.05,
							["Key"] = "shakeAmplitude",
							["Value"] = 0.2,
							["Name"] = "Shake Amplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [4]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Key"] = "shakeFrequency",
							["Value"] = 70,
							["Name"] = "Shake Frequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [5]
						{
							["Type"] = 6,
							["Key"] = "option7",
							["Value"] = 0,
							["Name"] = "Option 7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [6]
						{
							["Type"] = 4,
							["Key"] = "useBackground",
							["Value"] = true,
							["Name"] = "Show Red Background",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Show Red Background",
						}, -- [7]
					},
					["Author"] = "Huugg-Valdrakken",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local healthBar = unitFrame.healthBar\n    \n    if (scriptTable.config.useReverse) then\n        healthBar:SetReverseFill(true)\n    end\n    \n    --unitFrame.AddExplosionOnDieShake\n    \n    envTable.CreateWidgets()\n    \n    unitFrame.AddExplosionOnDieShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    unitFrame.AddExplosionOnDieShake.OriginalDuration = 0.120\n    unitFrame.AddExplosionOnDieShake.OriginalFrequency = scriptTable.config.shakeFrequency\n    \n    if (scriptTable.config.useBackground) then\n        unitFrame.AddExplosionOnDieBackground:Show()\n        unitFrame.AddExplosionOnDieBackground:SetAlpha(0)\n    else\n        unitFrame.AddExplosionOnDieBackground:Hide()\n    end\nend\n\n\n\n\n\n\n",
					["Name"] = "Add - Explode on Die [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
					},
					["Desc"] = "",
					["semver"] = "",
					["Icon"] = "interface/addons/plater/media/radio_64",
				}, -- [39]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \n    local plateFrame = unitFrame.PlateFrame\n    \n    if (not plateFrame.BWC_RedBackground) then\n        plateFrame.BWC_RedBackground = plateFrame:CreateTexture(nil, \"background\")\n        plateFrame.BWC_RedBackground:SetAllPoints()\n    end\n    \n    plateFrame.BWC_RedBackground:SetTexture([[Interface/AddOns/Plater/masks/mask1]])\n    plateFrame.BWC_RedBackground:Hide()\n    \n    function envTable.ShowBackground(unitFrame)\n        local plateFrame = unitFrame.PlateFrame\n        plateFrame.BWC_RedBackground:SetVertexColor(1, 0, 0, 0.4)\n        plateFrame.BWC_RedBackground:Show()\n    end\n    \n    function envTable.HideBackground(unitFrame)\n        plateFrame.BWC_RedBackground:Hide()\n    end\nend\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    envTable.HideBackground(unitFrame)\nend\n\n\n",
					["ScriptType"] = 1,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (Plater.UnitIsCasting(unitId)) then\n        envTable.ShowBackground(unitFrame)\n    else\n        envTable.HideBackground(unitFrame)\n    end\n    \nend",
					["Time"] = 1673726734,
					["url"] = "",
					["Icon"] = 236209,
					["Enabled"] = true,
					["Revision"] = 18,
					["semver"] = "",
					["Author"] = "Tiranaa-Azralon",
					["Initialization"] = "		function (scriptTable)\n			--insert code here\n			\n		end\n	",
					["Desc"] = "Highlight the nameplate of a unit when has a certain Buff (trigger) and start to cast a spell",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["SpellIds"] = {
						372743, -- [1]
						372749, -- [2]
						384933, -- [3]
					},
					["PlaterCore"] = 1,
					["Options"] = {
					},
					["version"] = -1,
					["Name"] = "Aura While Casting [P]",
					["NpcNames"] = {
					},
				}, -- [40]
			},
			["target_highlight_height"] = 18,
			["indicator_raidmark_scale"] = 0.8962845206260681,
			["version"] = 3,
			["cast_statusbar_spark_alpha"] = 0.7199999690055847,
			["first_run2"] = true,
			["color_override_colors"] = {
				[3] = {
					nil, -- [1]
					0.2784313, -- [2]
					0.2078431, -- [3]
				},
				[4] = {
					1, -- [1]
					0.83921568627451, -- [2]
					0, -- [3]
				},
				[5] = {
					0.29019607843137, -- [1]
					1, -- [2]
					0.19607843137255, -- [3]
				},
			},
			["extra_icon_auras_mine"] = {
				["277242"] = false,
				["224991"] = true,
			},
			["health_animation_time_dilatation"] = 2.869999885559082,
			["patch_version"] = 24,
			["no_spellname_length_limit"] = true,
			["aura_timer_text_size"] = 10,
			["extra_icon_show_timer"] = false,
			["cast_statusbar_fadeout_time"] = 0.4899999797344208,
			["number_region_first_run"] = true,
			["plater_resources_scale"] = 0.8,
			["ghost_auras"] = {
				["auras"] = {
					["PRIEST"] = {
						[3] = {
							[589] = true,
							[34914] = true,
						},
					},
					["WARLOCK"] = {
						{
							[172] = true,
							[980] = true,
						}, -- [1]
					},
				},
			},
			["script_data_trash"] = {
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, 20 do --max amount of segments is 20\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.Textures) then\n        for i = 1, scriptTable.config.segmentsAmount  do\n            local texture = unitFrame.felAnimation.Textures[i]\n            if (texture) then\n                texture:Hide()\n            end\n        end\n    end\n    \n    if (unitFrame.felAnimation and unitFrame.felAnimation.textureStretched) then\n        local textureStretched = unitFrame.felAnimation.textureStretched\n        if (textureStretched) then\n            textureStretched:Hide()\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    if (not envTable.NextPercent) then\n        return\n    end\n    \n    local castBar = unitFrame.castBar\n    \n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then --eeror here, compare with nil\n        local nextPercent = 100  / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \nend",
					["Time"] = 1671311518,
					["url"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_glow",
					["Enabled"] = true,
					["Revision"] = 511,
					["semver"] = "",
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["Desc"] = "Show a different animation for the cast bar.",
					["__TrashAt"] = 1673538263,
					["NpcNames"] = {
					},
					["SpellIds"] = {
						376644, -- [1]
						373017, -- [2]
						386781, -- [3]
						384823, -- [4]
						372735, -- [5]
						385536, -- [6]
						392398, -- [7]
						375596, -- [8]
						387135, -- [9]
						209033, -- [10]
						360850, -- [11]
						212784, -- [12]
						207980, -- [13]
						199033, -- [14]
						199034, -- [15]
						200969, -- [16]
						394512, -- [17]
						397881, -- [18]
						396020, -- [19]
						374430, -- [20]
						373201, -- [21]
					},
					["PlaterCore"] = 1,
					["Name"] = "Cast - Glowing [P]",
					["version"] = -1,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Name"] = "Amount of Segments",
							["Value"] = 7,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "segmentsAmount",
						}, -- [1]
						{
							["Type"] = 1,
							["Name"] = "Spark Color",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Key"] = "sparkColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Name"] = "Glow Color",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "glowColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 7,
							["Name"] = "Cast Color by SpellID",
							["Value"] = {
								{
									"385536", -- [1]
									"maroon", -- [2]
								}, -- [1]
								{
									"198750", -- [1]
									"midnightblue", -- [2]
								}, -- [2]
								{
									"360850", -- [1]
									"lime", -- [2]
								}, -- [3]
								{
									"212784", -- [1]
									"deepskyblue", -- [2]
								}, -- [4]
								{
									"207980", -- [1]
									"midnightblue", -- [2]
								}, -- [5]
								{
									"199033", -- [1]
									"gold", -- [2]
								}, -- [6]
								{
									"199034", -- [1]
									"gold", -- [2]
								}, -- [7]
								{
									"200969", -- [1]
									"orange", -- [2]
								}, -- [8]
								{
									"394512", -- [1]
									"indigo", -- [2]
								}, -- [9]
								{
									"397881", -- [1]
									"deepskyblue", -- [2]
								}, -- [10]
								{
									"396020", -- [1]
									"khaki", -- [2]
								}, -- [11]
							},
							["Key"] = "castColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_list",
							["Desc"] = "Insert the Spell ID in the to Key and a color name into the Value",
						}, -- [4]
					},
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    if (self.channeling) then\n        return \n    end\n    \n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        --texture:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.trailColor))\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    local customColor = scriptTable.config.castColor[tostring(envTable._SpellID)]\n    Plater.SetCastBarColorForScript(self, true, customColor or scriptTable.config.castBarColor, envTable)\nend\n\n\n\n\n\n\n\n\n\n\n",
				}, -- [1]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n    local castBarHeight = castBar:GetHeight()\n    \n    unitFrame.felAnimation = unitFrame.felAnimation or {}\n    \n    if (not unitFrame.felAnimation.textureStretched) then\n        unitFrame.felAnimation.textureStretched = castBar:CreateTexture(nil, \"overlay\", nil, 5)\n    end\n    \n    if (not unitFrame.stopCastingX) then\n        unitFrame.stopCastingX = castBar.FrameOverlay:CreateTexture(nil, \"overlay\", nil, 7)\n        unitFrame.stopCastingX:SetPoint(\"center\", unitFrame.castBar.Spark, \"center\", 0, 0)\n        unitFrame.stopCastingX:SetTexture([[Interface\\AddOns\\Plater\\Media\\stop_64]])\n        unitFrame.stopCastingX:SetSize(16, 16)\n        unitFrame.stopCastingX:Hide()\n    end\n    \n    if (not unitFrame.felAnimation.Textures) then\n        unitFrame.felAnimation.Textures = {}\n        \n        for i = 1, scriptTable.config.segmentsAmount do\n            local texture = castBar:CreateTexture(nil, \"overlay\", nil, 6)\n            unitFrame.felAnimation.Textures[i] = texture            \n            \n            texture.animGroup = texture.animGroup or texture:CreateAnimationGroup()\n            local animationGroup = texture.animGroup\n            animationGroup:SetToFinalAlpha(true)            \n            animationGroup:SetLooping(\"NONE\")\n            \n            texture:SetTexture([[Interface\\COMMON\\XPBarAnim]])\n            texture:SetTexCoord(0.2990, 0.0010, 0.0010, 0.4159)\n            texture:SetBlendMode(\"ADD\")\n            \n            texture.scale = animationGroup:CreateAnimation(\"SCALE\")\n            texture.scale:SetTarget(texture)\n            \n            texture.alpha = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha:SetTarget(texture)\n            \n            texture.alpha2 = animationGroup:CreateAnimation(\"ALPHA\")\n            texture.alpha2:SetTarget(texture)\n        end\n    end\n    \n    \n    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        texture:Hide()\n    end\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Hide()    \n    unitFrame.stopCastingX:Hide()\n    \n    self.Text:SetDrawLayer(\"overlay\", 0)\n    self.Spark:SetDrawLayer(\"overlay\", 3)\n    self.Spark:Show()\n    \nend\n\n\n\n\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    local castBar = unitFrame.castBar\n    \n    local textures = unitFrame.felAnimation.Textures\n    \n    if (envTable._CastPercent > envTable.NextPercent) then\n        local nextPercent = 100  / scriptTable.config.segmentsAmount\n        \n        textures[envTable.CurrentTexture]:Show()\n        textures[envTable.CurrentTexture].animGroup:Play()\n        envTable.NextPercent = envTable.NextPercent + nextPercent \n        envTable.CurrentTexture = envTable.CurrentTexture + 1\n        \n        if (envTable.CurrentTexture == #textures) then\n            envTable.NextPercent = 98\n        elseif (envTable.CurrentTexture > #textures) then\n            envTable.NextPercent = 999\n        end\n    end\n    \n    local normalizedPercent = envTable._CastPercent / 100\n    local textureStretched = unitFrame.felAnimation.textureStretched\n    local point = DetailsFramework:GetBezierPoint(normalizedPercent, 0, 0.001, 1)\n    textureStretched:SetPoint(\"left\", castBar, \"left\", point * envTable.castBarWidth, 0)\n    \nend",
					["Time"] = 1670202019,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 468,
					["Options"] = {
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Need a /reload",
							["Min"] = 5,
							["Name"] = "Amount of Segments",
							["Value"] = 5,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "segmentsAmount",
						}, -- [1]
						{
							["Type"] = 1,
							["Key"] = "sparkColor",
							["Value"] = {
								0.9568627450980391, -- [1]
								1, -- [2]
								0.9882352941176471, -- [3]
								1, -- [4]
							},
							["Name"] = "Spark Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 1,
							["Key"] = "glowColor",
							["Value"] = {
								0.8588235294117647, -- [1]
								0.4313725490196079, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Name"] = "Glow Color",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "",
						}, -- [3]
					},
					["Author"] = "Terciob",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    local castBar = unitFrame.castBar\n    envTable.castBarWidth = castBar:GetWidth()\n    castBar.Spark:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.sparkColor))\n    \n    local textureStretched = unitFrame.felAnimation.textureStretched\n    textureStretched:Show()\n    textureStretched:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.glowColor))\n    textureStretched:SetAtlas(\"XPBarAnim-OrangeTrail\")\n    textureStretched:ClearAllPoints()\n    textureStretched:SetPoint(\"right\", castBar.Spark, \"center\", 0, 0)\n    textureStretched:SetHeight(castBar:GetHeight())\n    textureStretched:SetBlendMode(\"ADD\") \n    textureStretched:SetAlpha(0.5)\n    textureStretched:SetDrawLayer(\"overlay\", 7)\n    \n    for i = 1, scriptTable.config.segmentsAmount  do\n        local texture = unitFrame.felAnimation.Textures[i]\n        --texture:SetVertexColor(DetailsFramework:ParseColors(scriptTable.config.trailColor))\n        texture:SetVertexColor(1, 1, 1, 1)\n        texture:SetDesaturated(true)\n        \n        local castBarPortion = castBar:GetWidth()/scriptTable.config.segmentsAmount\n        \n        texture:SetSize(castBarPortion+5, castBar:GetHeight())\n        texture:SetDrawLayer(\"overlay\", 6)\n        \n        texture:ClearAllPoints()\n        if (i == scriptTable.config.segmentsAmount) then\n            texture:SetPoint(\"right\", castBar, \"right\", 0, 0)\n        else\n            texture:SetPoint(\"left\", castBar, \"left\", (i-1)*castBarPortion, 2)\n        end\n        \n        texture:SetAlpha(0)\n        texture:Hide()\n        \n        texture.scale:SetOrder(1)\n        texture.scale:SetDuration(0.5)\n        texture.scale:SetScaleFrom(0.2, 1)\n        texture.scale:SetScaleTo(1, 1.5)\n        texture.scale:SetOrigin(\"right\", 0, 0)\n        \n        local durationTime = DetailsFramework:GetBezierPoint(i / scriptTable.config.segmentsAmount, 0.2, 0.01, 0.6)\n        local duration = abs(durationTime-0.6)\n        \n        texture.alpha:SetOrder(1)\n        texture.alpha:SetDuration(0.05)\n        texture.alpha:SetFromAlpha(0)\n        texture.alpha:SetToAlpha(0.4)\n        \n        texture.alpha2:SetOrder(1)\n        texture.alpha2:SetDuration(duration) --0.6\n        texture.alpha2:SetStartDelay(duration)\n        texture.alpha2:SetFromAlpha(0.5)\n        texture.alpha2:SetToAlpha(0)\n    end\n    \n    unitFrame.stopCastingX:Show()\n    \n    envTable.CurrentTexture = 1\n    envTable.NextPercent  = 100  / scriptTable.config.segmentsAmount\n    \n    self.Text:SetDrawLayer(\"artwork\", 7)\n    self.Spark:SetDrawLayer(\"artwork\", 7)\n    self.Spark:Hide()\nend\n\n\n\n\n\n\n\n\n",
					["__TrashAt"] = 1673538263,
					["Name"] = "Cast - Stop Casting [P]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						377004, -- [1]
						381516, -- [2]
						196543, -- [3]
						199726, -- [4]
					},
					["Desc"] = "Just stop casting",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\media\\stop_64",
				}, -- [2]
				{
					["ConstructorCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    --create a texture to use for a flash behind the cast bar\n    local backGroundFlashTexture = Plater:CreateImage (self, [[Interface\\ACHIEVEMENTFRAME\\UI-Achievement-Alert-Glow]], self:GetWidth()+40, self:GetHeight()+20, \"background\", {0, 400/512, 0, 170/256})\n    backGroundFlashTexture:SetBlendMode (\"ADD\")\n    backGroundFlashTexture:SetDrawLayer(\"OVERLAY\", 7)\n    backGroundFlashTexture:SetPoint (\"center\", self, \"center\")\n    backGroundFlashTexture:SetVertexColor(Plater:ParseColors(scriptTable.config.flashColor))\n    backGroundFlashTexture:Hide()\n    \n    --create the animation hub to hold the flash animation sequence\n    envTable.BackgroundFlash = envTable.BackgroundFlash or Plater:CreateAnimationHub (backGroundFlashTexture, \n        function()\n            backGroundFlashTexture:Show()\n        end,\n        function()\n            backGroundFlashTexture:Hide()\n        end\n    )\n    \n    --create the flash animation sequence\n    local fadeIn = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 1, scriptTable.config.flashDuration/2, 0, 1)\n    local fadeOut = Plater:CreateAnimation (envTable.BackgroundFlash, \"ALPHA\", 2, scriptTable.config.flashDuration/2, 1, 0)\n    \n    --create a camera shake for the nameplate\n    envTable.FrameShake = Plater:CreateFrameShake (unitFrame, scriptTable.config.shakeDuration, scriptTable.config.shakeAmplitude, scriptTable.config.shakeFrequency, false, false, 0, 1, 0.05, 0.1, Plater.GetPoints (unitFrame))\n    \n    --update the config for the flash here so it wont need a /reload\n    fadeIn:SetDuration (scriptTable.config.flashDuration/2)\n    fadeOut:SetDuration (scriptTable.config.flashDuration/2)\n    \n    --update the config for the skake here so it wont need a /reload\n    envTable.FrameShake.OriginalAmplitude = scriptTable.config.shakeAmplitude\n    envTable.FrameShake.OriginalDuration = scriptTable.config.shakeDuration\n    envTable.FrameShake.OriginalFrequency = scriptTable.config.shakeFrequency\nend",
					["OnHideCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \n    Plater.StopDotAnimation(unitFrame.castBar, envTable.dotAnimation)    \n    \n    envTable.BackgroundFlash:Stop()\n    \n    unitFrame:StopFrameShake (envTable.FrameShake)    \n    \nend\n\n\n",
					["OptionsValues"] = {
					},
					["ScriptType"] = 2,
					["UpdateCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    \nend\n\n\n",
					["Time"] = 1670202618,
					["url"] = "",
					["NpcNames"] = {
					},
					["Enabled"] = true,
					["Revision"] = 798,
					["Options"] = {
						{
							["Type"] = 6,
							["Name"] = "Option 1",
							["Value"] = 0,
							["Key"] = "option1",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [1]
						{
							["Type"] = 5,
							["Name"] = "Option 2",
							["Value"] = "Plays a big animation when the cast start.",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [2]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Enter the spell name or spellID of the Spell in the Add Trigger box and hit \"Add\".",
							["Name"] = "Option 2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [3]
						{
							["Type"] = 6,
							["Name"] = "Option 4",
							["Value"] = 0,
							["Key"] = "option4",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [4]
						{
							["Type"] = 5,
							["Name"] = "Flash",
							["Value"] = "Flash:",
							["Key"] = "option2",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [5]
						{
							["Type"] = 2,
							["Max"] = 1.2,
							["Desc"] = "How long is the flash played when the cast starts.",
							["Min"] = 0.1,
							["Name"] = "Flash Duration",
							["Value"] = 0.8,
							["Key"] = "flashDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [6]
						{
							["Type"] = 1,
							["Name"] = "Flash Color",
							["Value"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["Key"] = "flashColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Color of the Flash",
						}, -- [7]
						{
							["Type"] = 6,
							["Name"] = "Option 7",
							["Value"] = 0,
							["Key"] = "option7",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [8]
						{
							["Type"] = 5,
							["Key"] = "option2",
							["Value"] = "Shake:",
							["Name"] = "Shake",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [9]
						{
							["Type"] = 2,
							["Max"] = 0.5,
							["Desc"] = "When the cast starts, there's a small shake in the nameplate, this settings controls how long it takes.",
							["Min"] = 0.1,
							["Name"] = "Shake Duration",
							["Value"] = 0.2,
							["Key"] = "shakeDuration",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = true,
						}, -- [10]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "How strong is the shake.",
							["Min"] = 1,
							["Name"] = "Shake Amplitude",
							["Value"] = 5,
							["Key"] = "shakeAmplitude",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [11]
						{
							["Type"] = 2,
							["Max"] = 80,
							["Desc"] = "How fast the shake moves.",
							["Min"] = 1,
							["Name"] = "Shake Frequency",
							["Value"] = 40,
							["Key"] = "shakeFrequency",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Fraction"] = false,
						}, -- [12]
						{
							["Type"] = 6,
							["Name"] = "Option 13",
							["Value"] = 0,
							["Key"] = "option13",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [13]
						{
							["Type"] = 5,
							["Name"] = "Dot Animation",
							["Value"] = "Dot Animation:",
							["Key"] = "option14",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [14]
						{
							["Type"] = 1,
							["Name"] = "Dot Color",
							["Value"] = {
								0.5647058823529412, -- [1]
								0.5647058823529412, -- [2]
								0.5647058823529412, -- [3]
								1, -- [4]
							},
							["Key"] = "dotColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Adjust the color of the dots around the nameplate",
						}, -- [15]
						{
							["Type"] = 2,
							["Max"] = 20,
							["Desc"] = "Adjust the width of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Fraction"] = false,
							["Value"] = 8,
							["Key"] = "xOffset",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Name"] = "Dot X Offset",
						}, -- [16]
						{
							["Type"] = 2,
							["Max"] = 10,
							["Desc"] = "Adjust the height of the dots to better fit in your nameplate.",
							["Min"] = -10,
							["Name"] = "Dot Y Offset",
							["Value"] = 3,
							["Fraction"] = false,
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_number",
							["Key"] = "yOffset",
						}, -- [17]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [18]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [19]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [20]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [21]
						{
							["Type"] = 6,
							["Name"] = "blank",
							["Value"] = 0,
							["Key"] = "option18",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [22]
						{
							["Type"] = 6,
							["Key"] = "option18",
							["Value"] = 0,
							["Name"] = "blank",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_blank",
							["Desc"] = "",
						}, -- [23]
						{
							["Type"] = 5,
							["Name"] = "Option 19",
							["Value"] = "Cast Bar",
							["Key"] = "option19",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_label",
							["Desc"] = "",
						}, -- [24]
						{
							["Type"] = 4,
							["Name"] = "Use Cast Bar Color",
							["Value"] = true,
							["Key"] = "useCastbarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_bool",
							["Desc"] = "Use cast bar color.",
						}, -- [25]
						{
							["Type"] = 1,
							["Name"] = "Cast Bar Color",
							["Value"] = {
								0.4117647058823529, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["Key"] = "castBarColor",
							["Icon"] = "Interface\\AddOns\\Plater\\images\\option_color",
							["Desc"] = "Cast bar color.",
						}, -- [26]
					},
					["Author"] = "Bombad�o-Azralon",
					["Initialization"] = "function (scriptTable)\n    --insert code here\n    \nend\n\n\n",
					["OnShowCode"] = "function (self, unitId, unitFrame, envTable, scriptTable)\n    envTable.dotAnimation = Plater.PlayDotAnimation(unitFrame.castBar, 5, scriptTable.config.dotColor, scriptTable.config.xOffset, scriptTable.config.yOffset)\n    \n    envTable.BackgroundFlash:Play()\n    \n    Plater.FlashNameplateBorder (unitFrame, 0.05)   \n    Plater.FlashNameplateBody (unitFrame, \"\", 0.075)\n    \n    unitFrame:PlayFrameShake (envTable.FrameShake)\n    \n    Plater.SetCastBarColorForScript(self, scriptTable.config.useCastbarColor, scriptTable.config.castBarColor, envTable)\nend",
					["__TrashAt"] = 1674753784,
					["Name"] = "Cast - Very Important [Plater]",
					["version"] = -1,
					["PlaterCore"] = 1,
					["SpellIds"] = {
						373046, -- [1]
						372863, -- [2]
						164686, -- [3]
						153072, -- [4]
						153680, -- [5]
						196497, -- [6]
						388886, -- [7]
						387145, -- [8]
						384365, -- [9]
						152964, -- [10]
						398150, -- [11]
						152801, -- [12]
						397878, -- [13]
						183263, -- [14]
						3636, -- [15]
						376171, -- [16]
					},
					["Desc"] = "Highlight a very important cast applying several effects into the Cast Bar. Add spell in the Add Trigger field.",
					["semver"] = "",
					["Icon"] = "Interface\\AddOns\\Plater\\images\\cast_bar_darkorange",
				}, -- [3]
			},
			["ui_parent_cast_strata"] = "DIALOG",
			["script_auto_imported"] = {
				["Relics 9.2 M Dungeons"] = 2,
				["Cast - Effect After Cast [P]"] = 2,
				["Explosion Affix M+"] = 14,
				["Aura - Debuff Alert"] = 12,
				["Cast - Castbar is Timer [P]"] = 2,
				["Blink by Time Left"] = 1,
				["Add - Health Markers [P]"] = 1,
				["Cast - Small Alert"] = 12,
				["Aura - Invalidate Unit"] = 1,
				["Add - Important [P]"] = 4,
				["Unit - Main Target"] = 11,
				["Aura - Blink Time Left"] = 13,
				["Add - Tag Number [P]"] = 2,
				["Unit Power"] = 1,
				["Cast - Tank Interrupt"] = 12,
				["Unit - Important"] = 11,
				["Fixate On You"] = 11,
				["Cast - Shield Interrupt"] = 2,
				["Cast - Alert + Timer [P]"] = 4,
				["Cast - Very Important"] = 15,
				["Cast - Quick Flash"] = 2,
				["Aura is Shield [P]"] = 2,
				["Add - Warning [P]"] = 5,
				["Cast - Ultra Important"] = 14,
				["Aura While Casting [P]"] = 1,
				["Cast - Big Alert"] = 14,
				["Fixate"] = 11,
				["Color Change"] = 1,
				["Auto Set Skull"] = 11,
				["Countdown"] = 11,
				["Spiteful Affix"] = 3,
				["Aura - Buff Alert"] = 15,
				["Add - Non Elite Trash [P]"] = 4,
				["Unit - Health Markers"] = 12,
				["Aura Border Color"] = 1,
				["Cast - Stop Casting"] = 4,
				["Fixate by Unit Buff [P]"] = 2,
				["Cast - Frontal Cone"] = 15,
				["Add - Explode on Die [P]"] = 1,
				["Cast - Important Target [P]"] = 2,
				["Cast - Circular Swipe"] = 4,
				["Cast - Glowing [P]"] = 10,
				["Unit - Show Energy"] = 11,
			},
			["castbar_target_font"] = "Accidental Presidency",
			["aura_alpha"] = 0.84999996423721,
			["indicator_elite"] = false,
			["dps"] = {
				["colors"] = {
					["aggro"] = {
						nil, -- [1]
						0.047058823529412, -- [2]
					},
					["pulling"] = {
						nil, -- [1]
						0.96078431372549, -- [2]
						0.95294117647059, -- [3]
					},
				},
			},
			["extra_icon_height"] = 16,
			["click_space_friendly"] = {
				nil, -- [1]
				1, -- [2]
			},
			["indicator_rare"] = false,
			["castbar_target_text_size"] = 9,
			["cast_statusbar_spark_width"] = 25,
			["aura_stack_font"] = "Accidental Presidency",
		},
	},
}
