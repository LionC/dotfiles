
HandyNotesDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Scahra - Blackmoore",
		["Xyresia - Blackmoore"] = "Xyresia - Blackmoore",
		["Ämelia - Blackmoore"] = "Ämelia - Blackmoore",
		["Zakarum - Blackmoore"] = "Zakarum - Blackmoore",
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
		["Gaeralt - Blackmoore"] = "Gaeralt - Blackmoore",
		["Laeduin - Blackmoore"] = "Laeduin - Blackmoore",
		["Jakuup - Blackmoore"] = "Jakuup - Blackmoore",
		["Nißa - Blackmoore"] = "Nißa - Blackmoore",
		["Crayona - Blackmoore"] = "Crayona - Blackmoore",
		["Lioncilu - Blackmoore"] = "Lioncilu - Blackmoore",
		["Bhrian - Blackmoore"] = "Bhrian - Blackmoore",
		["Amilanoo - Blackmoore"] = "Amilanoo - Blackmoore",
	},
	["profiles"] = {
		["Scahra - Blackmoore"] = {
		},
		["Xyresia - Blackmoore"] = {
		},
		["Ämelia - Blackmoore"] = {
		},
		["Zakarum - Blackmoore"] = {
		},
		["Lionc - Blackmoore"] = {
		},
		["Gaeralt - Blackmoore"] = {
		},
		["Laeduin - Blackmoore"] = {
		},
		["Jakuup - Blackmoore"] = {
		},
		["Nißa - Blackmoore"] = {
		},
		["Crayona - Blackmoore"] = {
		},
		["Lioncilu - Blackmoore"] = {
		},
		["Bhrian - Blackmoore"] = {
		},
		["Amilanoo - Blackmoore"] = {
		},
	},
}
HandyNotes_HandyNotesDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Scahra - Blackmoore",
		["Xyresia - Blackmoore"] = "Xyresia - Blackmoore",
		["Ämelia - Blackmoore"] = "Ämelia - Blackmoore",
		["Zakarum - Blackmoore"] = "Zakarum - Blackmoore",
		["Lionc - Blackmoore"] = "Lionc - Blackmoore",
		["Gaeralt - Blackmoore"] = "Gaeralt - Blackmoore",
		["Laeduin - Blackmoore"] = "Laeduin - Blackmoore",
		["Jakuup - Blackmoore"] = "Jakuup - Blackmoore",
		["Nißa - Blackmoore"] = "Nißa - Blackmoore",
		["Crayona - Blackmoore"] = "Crayona - Blackmoore",
		["Lioncilu - Blackmoore"] = "Lioncilu - Blackmoore",
		["Bhrian - Blackmoore"] = "Bhrian - Blackmoore",
		["Amilanoo - Blackmoore"] = "Amilanoo - Blackmoore",
	},
	["profiles"] = {
		["Scahra - Blackmoore"] = {
		},
		["Xyresia - Blackmoore"] = {
		},
		["Ämelia - Blackmoore"] = {
		},
		["Zakarum - Blackmoore"] = {
		},
		["Lionc - Blackmoore"] = {
		},
		["Gaeralt - Blackmoore"] = {
		},
		["Laeduin - Blackmoore"] = {
		},
		["Jakuup - Blackmoore"] = {
		},
		["Nißa - Blackmoore"] = {
		},
		["Crayona - Blackmoore"] = {
		},
		["Lioncilu - Blackmoore"] = {
		},
		["Bhrian - Blackmoore"] = {
		},
		["Amilanoo - Blackmoore"] = {
		},
	},
}
