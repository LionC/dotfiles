
ClassicFCTCustomPresets = {
	["Classic"] = {
		["petheal"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["pethealcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["filterAverageThreshold"] = 10,
		["mergeEventsBySchool"] = true,
		["pethealtickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["healtickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spelltickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["mergeEventsIntervalMode"] = "last",
		["inheritNameplates"] = false,
		["healtick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petautocrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFF9D00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["petspellcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["mergeEventsInterval"] = 0.1,
		["petautomiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFF9D00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["colorTableDotEnabled"] = false,
		["mergeEventsBySpellID"] = false,
		["mergeEventsMisses"] = false,
		["colorTable"] = {
			"ffff0000", -- [1]
			"ffffffb6", -- [2]
			"ffffffe6", -- [3]
			"ffff432c", -- [4]
			"ffff8879", -- [5]
			"ffffca68", -- [6]
			nil, -- [7]
			"ff3c9742", -- [8]
			"ffa1eaa3", -- [9]
			"ffe9ffa9", -- [10]
			nil, -- [11]
			"ffdfcfb6", -- [12]
			nil, -- [13]
			nil, -- [14]
			nil, -- [15]
			"ff00abff", -- [16]
			"ff7dd5ff", -- [17]
			"ffbffffc", -- [18]
			nil, -- [19]
			"ffff64ab", -- [20]
			nil, -- [21]
			nil, -- [22]
			nil, -- [23]
			"ff5de1de", -- [24]
			nil, -- [25]
			nil, -- [26]
			nil, -- [27]
			"ffffa500", -- [28]
			nil, -- [29]
			nil, -- [30]
			nil, -- [31]
			"ff9500b6", -- [32]
			"ffa89cff", -- [33]
			"ff242d8d", -- [34]
			nil, -- [35]
			"ffb92334", -- [36]
			nil, -- [37]
			nil, -- [38]
			nil, -- [39]
			"ff462b68", -- [40]
			nil, -- [41]
			nil, -- [42]
			nil, -- [43]
			nil, -- [44]
			nil, -- [45]
			nil, -- [46]
			nil, -- [47]
			"ff3a00e5", -- [48]
			nil, -- [49]
			nil, -- [50]
			nil, -- [51]
			nil, -- [52]
			nil, -- [53]
			nil, -- [54]
			nil, -- [55]
			nil, -- [56]
			nil, -- [57]
			nil, -- [58]
			nil, -- [59]
			nil, -- [60]
			nil, -- [61]
			"ffffffff", -- [62]
			nil, -- [63]
			"ffdd4aff", -- [64]
			"ffa8caff", -- [65]
			"fffff9ed", -- [66]
			nil, -- [67]
			"ffff4d5c", -- [68]
			[126] = "ff97f4ff",
			[124] = "ff8000ff",
			[72] = "ff3f45ff",
			[80] = "ff828ffd",
			[96] = "ff0009ff",
		},
		["textStrata"] = "MEDIUM",
		["dontOverlapNameplates"] = false,
		["petspelltickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["animSpeed"] = 1,
		["filterAbsoluteEnabled"] = false,
		["preventOverlapSpacingY"] = 50,
		["attachMode"] = "tn",
		["auto"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFFFFF",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["filterRelativeThreshold"] = 10,
		["areaNX"] = 0,
		["filterAverageEnabled"] = false,
		["sortByDamage"] = false,
		["attachModeFallback"] = true,
		["spelltick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["preventOverlap"] = true,
		["mergeEvents"] = false,
		["abbreviateNumbers"] = false,
		["filterAbsoluteThreshold"] = 100,
		["autocrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFFFFF",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["preventOverlapSpacingX"] = 30,
		["heal"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petauto"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFF9D00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petspelltickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["colorTableDot"] = {
			"ffff0000", -- [1]
			"ffffffb6", -- [2]
			"ffffffe6", -- [3]
			"ffff432c", -- [4]
			"ffff8879", -- [5]
			"ffffca68", -- [6]
			nil, -- [7]
			"ff3c9742", -- [8]
			"ffa1eaa3", -- [9]
			"ffe9ffa9", -- [10]
			nil, -- [11]
			"ffdfcfb6", -- [12]
			nil, -- [13]
			nil, -- [14]
			nil, -- [15]
			"ff00abff", -- [16]
			"ff7dd5ff", -- [17]
			"ffbffffc", -- [18]
			nil, -- [19]
			"ffff64ab", -- [20]
			nil, -- [21]
			nil, -- [22]
			nil, -- [23]
			"ff5de1de", -- [24]
			nil, -- [25]
			nil, -- [26]
			nil, -- [27]
			"ffffa500", -- [28]
			nil, -- [29]
			nil, -- [30]
			nil, -- [31]
			"ff9500b6", -- [32]
			"ffa89cff", -- [33]
			"ff242d8d", -- [34]
			nil, -- [35]
			"ffb92334", -- [36]
			nil, -- [37]
			nil, -- [38]
			nil, -- [39]
			"ff462b68", -- [40]
			nil, -- [41]
			nil, -- [42]
			nil, -- [43]
			nil, -- [44]
			nil, -- [45]
			nil, -- [46]
			nil, -- [47]
			"ff3a00e5", -- [48]
			nil, -- [49]
			nil, -- [50]
			nil, -- [51]
			nil, -- [52]
			nil, -- [53]
			nil, -- [54]
			nil, -- [55]
			nil, -- [56]
			nil, -- [57]
			nil, -- [58]
			nil, -- [59]
			nil, -- [60]
			nil, -- [61]
			"ffffffff", -- [62]
			nil, -- [63]
			"ffdd4aff", -- [64]
			"ffa8caff", -- [65]
			"fffff9ed", -- [66]
			nil, -- [67]
			"ffff4d5c", -- [68]
			[126] = "ff97f4ff",
			[124] = "ff8000ff",
			[72] = "ff3f45ff",
			[80] = "ff828ffd",
			[96] = "ff0009ff",
		},
		["mergeEventsCounter"] = true,
		["spellIconOffsetX"] = 0,
		["filterMissesEnabled"] = false,
		["spellIconOffsetY"] = 0,
		["pethealtickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["pethealmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spell"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["areaNY"] = 0,
		["animDuration"] = 1.5,
		["mergeEventsByGuid"] = false,
		["kiloSeparator"] = false,
		["filterRelativeEnabled"] = false,
		["spellmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["automiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFFFFF",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petspell"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["areaY"] = 150,
		["healcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["spellIconAspectRatio"] = 1,
		["mergeEventsBySpellIcon"] = true,
		["spelltickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["areaX"] = 0,
		["petspellmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spellcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["petspelltick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spellIconZoom"] = 1,
		["sortMissPrio"] = false,
		["healtickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["duration"] = 0.3,
				["inOutRatio"] = 0.7,
			},
			["colorByType"] = false,
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
		},
		["healmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["pethealtick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["showIcons"] = false,
			["colorByType"] = false,
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
	},
	["Mists of Pandaria"] = {
		["petheal"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["pethealcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["filterAverageThreshold"] = 10,
		["mergeEventsBySchool"] = true,
		["pethealtickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["healtickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spelltickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["mergeEventsIntervalMode"] = "last",
		["inheritNameplates"] = false,
		["healtick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petautocrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFF9D00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petspellcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["mergeEventsInterval"] = 0.1,
		["petautomiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFF9D00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["colorTableDotEnabled"] = false,
		["mergeEventsBySpellID"] = false,
		["mergeEventsMisses"] = false,
		["colorTable"] = {
			"ffff0000", -- [1]
			"ffffffb6", -- [2]
			"ffffffe6", -- [3]
			"ffff432c", -- [4]
			"ffff8879", -- [5]
			"ffffca68", -- [6]
			nil, -- [7]
			"ff3c9742", -- [8]
			"ffa1eaa3", -- [9]
			"ffe9ffa9", -- [10]
			nil, -- [11]
			"ffdfcfb6", -- [12]
			nil, -- [13]
			nil, -- [14]
			nil, -- [15]
			"ff00abff", -- [16]
			"ff7dd5ff", -- [17]
			"ffbffffc", -- [18]
			nil, -- [19]
			"ffff64ab", -- [20]
			nil, -- [21]
			nil, -- [22]
			nil, -- [23]
			"ff5de1de", -- [24]
			nil, -- [25]
			nil, -- [26]
			nil, -- [27]
			"ffffa500", -- [28]
			nil, -- [29]
			nil, -- [30]
			nil, -- [31]
			"ff9500b6", -- [32]
			"ffa89cff", -- [33]
			"ff242d8d", -- [34]
			nil, -- [35]
			"ffb92334", -- [36]
			nil, -- [37]
			nil, -- [38]
			nil, -- [39]
			"ff462b68", -- [40]
			nil, -- [41]
			nil, -- [42]
			nil, -- [43]
			nil, -- [44]
			nil, -- [45]
			nil, -- [46]
			nil, -- [47]
			"ff3a00e5", -- [48]
			nil, -- [49]
			nil, -- [50]
			nil, -- [51]
			nil, -- [52]
			nil, -- [53]
			nil, -- [54]
			nil, -- [55]
			nil, -- [56]
			nil, -- [57]
			nil, -- [58]
			nil, -- [59]
			nil, -- [60]
			nil, -- [61]
			"ffffffff", -- [62]
			nil, -- [63]
			"ffdd4aff", -- [64]
			"ffa8caff", -- [65]
			"fffff9ed", -- [66]
			nil, -- [67]
			"ffff4d5c", -- [68]
			[126] = "ff97f4ff",
			[124] = "ff8000ff",
			[72] = "ff3f45ff",
			[80] = "ff828ffd",
			[96] = "ff0009ff",
		},
		["textStrata"] = "MEDIUM",
		["dontOverlapNameplates"] = false,
		["petspelltickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["animSpeed"] = 1,
		["filterAbsoluteEnabled"] = false,
		["preventOverlapSpacingY"] = 50,
		["attachMode"] = "tn",
		["auto"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFFFFF",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["filterRelativeThreshold"] = 10,
		["areaNX"] = 0,
		["filterAverageEnabled"] = false,
		["sortByDamage"] = false,
		["attachModeFallback"] = true,
		["spelltick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["preventOverlap"] = true,
		["mergeEvents"] = false,
		["abbreviateNumbers"] = false,
		["filterAbsoluteThreshold"] = 100,
		["autocrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFFFFF",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["preventOverlapSpacingX"] = 30,
		["heal"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petauto"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFF9D00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petspelltickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["colorTableDot"] = {
			"ffff0000", -- [1]
			"ffffffb6", -- [2]
			"ffffffe6", -- [3]
			"ffff432c", -- [4]
			"ffff8879", -- [5]
			"ffffca68", -- [6]
			nil, -- [7]
			"ff3c9742", -- [8]
			"ffa1eaa3", -- [9]
			"ffe9ffa9", -- [10]
			nil, -- [11]
			"ffdfcfb6", -- [12]
			nil, -- [13]
			nil, -- [14]
			nil, -- [15]
			"ff00abff", -- [16]
			"ff7dd5ff", -- [17]
			"ffbffffc", -- [18]
			nil, -- [19]
			"ffff64ab", -- [20]
			nil, -- [21]
			nil, -- [22]
			nil, -- [23]
			"ff5de1de", -- [24]
			nil, -- [25]
			nil, -- [26]
			nil, -- [27]
			"ffffa500", -- [28]
			nil, -- [29]
			nil, -- [30]
			nil, -- [31]
			"ff9500b6", -- [32]
			"ffa89cff", -- [33]
			"ff242d8d", -- [34]
			nil, -- [35]
			"ffb92334", -- [36]
			nil, -- [37]
			nil, -- [38]
			nil, -- [39]
			"ff462b68", -- [40]
			nil, -- [41]
			nil, -- [42]
			nil, -- [43]
			nil, -- [44]
			nil, -- [45]
			nil, -- [46]
			nil, -- [47]
			"ff3a00e5", -- [48]
			nil, -- [49]
			nil, -- [50]
			nil, -- [51]
			nil, -- [52]
			nil, -- [53]
			nil, -- [54]
			nil, -- [55]
			nil, -- [56]
			nil, -- [57]
			nil, -- [58]
			nil, -- [59]
			nil, -- [60]
			nil, -- [61]
			"ffffffff", -- [62]
			nil, -- [63]
			"ffdd4aff", -- [64]
			"ffa8caff", -- [65]
			"fffff9ed", -- [66]
			nil, -- [67]
			"ffff4d5c", -- [68]
			[126] = "ff97f4ff",
			[124] = "ff8000ff",
			[72] = "ff3f45ff",
			[80] = "ff828ffd",
			[96] = "ff0009ff",
		},
		["mergeEventsCounter"] = true,
		["spellIconOffsetX"] = 0,
		["filterMissesEnabled"] = false,
		["spellIconOffsetY"] = 0,
		["pethealtickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["pethealmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spell"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["areaNY"] = 0,
		["animDuration"] = 1.5,
		["mergeEventsByGuid"] = false,
		["kiloSeparator"] = false,
		["filterRelativeEnabled"] = false,
		["spellmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["automiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFFFFF",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petspell"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["areaY"] = 150,
		["healcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spellIconAspectRatio"] = 1,
		["mergeEventsBySpellIcon"] = true,
		["spelltickmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["areaX"] = 0,
		["petspellmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spellcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["petspelltick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FFFFE800",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["spellIconZoom"] = 1,
		["sortMissPrio"] = false,
		["healtickcrit"] = {
			["enabled"] = true,
			["fontSize"] = 60,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = true,
				["endScale"] = 1,
				["initScale"] = 1.8,
				["midScale"] = 1.6,
				["duration"] = 0.16,
				["inOutRatio"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = false,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["healmiss"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
		["pethealtick"] = {
			["enabled"] = true,
			["fontSize"] = 42,
			["fontColor"] = "FF00FF00",
			["fontPath"] = "Fonts\\FRIZQT__.TTF",
			["fontStyle"] = "",
			["colorByType"] = false,
			["showIcons"] = false,
			["Pow"] = {
				["enabled"] = false,
				["endScale"] = 1,
				["initScale"] = 0.25,
				["midScale"] = 1.55,
				["inOutRatio"] = 0.7,
				["duration"] = 0.3,
			},
			["FadeOut"] = {
				["enabled"] = true,
				["duration"] = 0.3,
			},
			["FadeIn"] = {
				["enabled"] = true,
				["duration"] = 0.07,
			},
			["Scroll"] = {
				["enabled"] = true,
				["direction"] = "UP",
				["distance"] = 32,
			},
		},
	},
}
ClassicFCTConfig = {
	["petheal"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["pethealcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["filterAverageThreshold"] = 10,
	["mergeEventsBySchool"] = true,
	["pethealtickcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["healtickmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["spelltickcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.799999952316284,
			["midScale"] = 1.600000023841858,
			["inOutRatio"] = 0.2999999821186066,
			["duration"] = 0.1599999964237213,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["mergeEventsIntervalMode"] = "last",
	["inheritNameplates"] = false,
	["healtick"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["petautocrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FFFF9D00",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["areaX"] = 0,
	["mergeEventsInterval"] = 0.09999999403953552,
	["petautomiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFF9D00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["colorTableDotEnabled"] = false,
	["mergeEventsBySpellID"] = false,
	["animDuration"] = 1.5,
	["colorTable"] = {
		"ffff0000", -- [1]
		"ffffffb6", -- [2]
		"ffffffe6", -- [3]
		"ffff432c", -- [4]
		"ffff8879", -- [5]
		"ffffca68", -- [6]
		nil, -- [7]
		"ff3c9742", -- [8]
		"ffa1eaa3", -- [9]
		"ffe9ffa9", -- [10]
		nil, -- [11]
		"ffdfcfb6", -- [12]
		nil, -- [13]
		nil, -- [14]
		nil, -- [15]
		"ff00abff", -- [16]
		"ff7dd5ff", -- [17]
		"ffbffffc", -- [18]
		nil, -- [19]
		"ffff64ab", -- [20]
		nil, -- [21]
		nil, -- [22]
		nil, -- [23]
		"ff5de1de", -- [24]
		nil, -- [25]
		nil, -- [26]
		nil, -- [27]
		"ffffa500", -- [28]
		nil, -- [29]
		nil, -- [30]
		nil, -- [31]
		"ff9500b6", -- [32]
		"ffa89cff", -- [33]
		"ff242d8d", -- [34]
		nil, -- [35]
		"ffb92334", -- [36]
		nil, -- [37]
		nil, -- [38]
		nil, -- [39]
		"ff462b68", -- [40]
		nil, -- [41]
		nil, -- [42]
		nil, -- [43]
		nil, -- [44]
		nil, -- [45]
		nil, -- [46]
		nil, -- [47]
		"ff3a00e5", -- [48]
		nil, -- [49]
		nil, -- [50]
		nil, -- [51]
		nil, -- [52]
		nil, -- [53]
		nil, -- [54]
		nil, -- [55]
		nil, -- [56]
		nil, -- [57]
		nil, -- [58]
		nil, -- [59]
		nil, -- [60]
		nil, -- [61]
		"ffffffff", -- [62]
		nil, -- [63]
		"ffdd4aff", -- [64]
		"ffa8caff", -- [65]
		"fffff9ed", -- [66]
		nil, -- [67]
		"ffff4d5c", -- [68]
		nil, -- [69]
		nil, -- [70]
		nil, -- [71]
		"ff3f45ff", -- [72]
		[124] = "ff8000ff",
		[80] = "ff828ffd",
		[96] = "ff0009ff",
		[126] = "ff97f4ff",
	},
	["textStrata"] = "MEDIUM",
	["dontOverlapNameplates"] = false,
	["petspelltickmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["animSpeed"] = 1,
	["filterAbsoluteEnabled"] = false,
	["preventOverlapSpacingY"] = 50,
	["attachMode"] = "tn",
	["spellIconOffsetX"] = 0,
	["filterRelativeThreshold"] = 10,
	["areaNX"] = 0,
	["filterAverageEnabled"] = false,
	["sortByDamage"] = false,
	["attachModeFallback"] = true,
	["spelltick"] = {
		["enabled"] = false,
		["fontSize"] = 26,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.549999952316284,
			["duration"] = 0.2999999821186066,
			["inOutRatio"] = 0.699999988079071,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["preventOverlap"] = true,
	["mergeEvents"] = false,
	["abbreviateNumbers"] = true,
	["petspelltick"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["autocrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FFFFFFFF",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.799999952316284,
			["midScale"] = 1.600000023841858,
			["inOutRatio"] = 0.2999999821186066,
			["duration"] = 0.1599999964237213,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["preventOverlapSpacingX"] = 30,
	["heal"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["petauto"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFF9D00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["petspelltickcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["pethealtick"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["kiloSeparator"] = false,
	["healcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["healtickcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["spellIconOffsetY"] = 0,
	["healmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["petspellcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.8,
			["midScale"] = 1.6,
			["inOutRatio"] = 0.3,
			["duration"] = 0.16,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["filterAbsoluteThreshold"] = 100,
	["areaNY"] = 0,
	["auto"] = {
		["enabled"] = false,
		["fontSize"] = 42,
		["fontColor"] = "FFFFFFFF",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.549999952316284,
			["duration"] = 0.2999999821186066,
			["inOutRatio"] = 0.699999988079071,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["mergeEventsByGuid"] = false,
	["petspellmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["spellIconZoom"] = 1,
	["spellmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.549999952316284,
			["duration"] = 0.2999999821186066,
			["inOutRatio"] = 0.699999988079071,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["spell"] = {
		["enabled"] = true,
		["fontSize"] = 25,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = true,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.549999952316284,
			["duration"] = 0.2999999821186066,
			["inOutRatio"] = 0.699999988079071,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["petspell"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["areaY"] = 150,
	["pethealtickmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["pethealmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FF00FF00",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.55,
			["duration"] = 0.3,
			["inOutRatio"] = 0.7,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["mergeEventsBySpellIcon"] = true,
	["spelltickmiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.549999952316284,
			["duration"] = 0.2999999821186066,
			["inOutRatio"] = 0.699999988079071,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["automiss"] = {
		["enabled"] = true,
		["fontSize"] = 42,
		["fontColor"] = "FFFFFFFF",
		["Scroll"] = {
			["enabled"] = true,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = false,
			["endScale"] = 1,
			["initScale"] = 0.25,
			["midScale"] = 1.549999952316284,
			["duration"] = 0.2999999821186066,
			["inOutRatio"] = 0.699999988079071,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["filterRelativeEnabled"] = false,
	["spellcrit"] = {
		["enabled"] = true,
		["fontSize"] = 60,
		["fontColor"] = "FFFFE800",
		["Scroll"] = {
			["enabled"] = false,
			["direction"] = "UP",
			["distance"] = 32,
		},
		["fontStyle"] = "",
		["fontPath"] = "Fonts\\FRIZQT__.TTF",
		["showIcons"] = false,
		["Pow"] = {
			["enabled"] = true,
			["endScale"] = 1,
			["initScale"] = 1.799999952316284,
			["midScale"] = 1.600000023841858,
			["inOutRatio"] = 0.2999999821186066,
			["duration"] = 0.1599999964237213,
		},
		["FadeOut"] = {
			["enabled"] = true,
			["duration"] = 0.3,
		},
		["FadeIn"] = {
			["enabled"] = true,
			["duration"] = 0.07,
		},
		["colorByType"] = false,
	},
	["mergeEventsMisses"] = false,
	["mergeEventsCounter"] = true,
	["sortMissPrio"] = false,
	["filterMissesEnabled"] = false,
	["spellIconAspectRatio"] = 1,
	["colorTableDot"] = {
		"ffff0000", -- [1]
		"ffffffb6", -- [2]
		"ffffffe6", -- [3]
		"ffff432c", -- [4]
		"ffff8879", -- [5]
		"ffffca68", -- [6]
		nil, -- [7]
		"ff3c9742", -- [8]
		"ffa1eaa3", -- [9]
		"ffe9ffa9", -- [10]
		nil, -- [11]
		"ffdfcfb6", -- [12]
		nil, -- [13]
		nil, -- [14]
		nil, -- [15]
		"ff00abff", -- [16]
		"ff7dd5ff", -- [17]
		"ffbffffc", -- [18]
		nil, -- [19]
		"ffff64ab", -- [20]
		nil, -- [21]
		nil, -- [22]
		nil, -- [23]
		"ff5de1de", -- [24]
		nil, -- [25]
		nil, -- [26]
		nil, -- [27]
		"ffffa500", -- [28]
		nil, -- [29]
		nil, -- [30]
		nil, -- [31]
		"ff9500b6", -- [32]
		"ffa89cff", -- [33]
		"ff242d8d", -- [34]
		nil, -- [35]
		"ffb92334", -- [36]
		nil, -- [37]
		nil, -- [38]
		nil, -- [39]
		"ff462b68", -- [40]
		nil, -- [41]
		nil, -- [42]
		nil, -- [43]
		nil, -- [44]
		nil, -- [45]
		nil, -- [46]
		nil, -- [47]
		"ff3a00e5", -- [48]
		nil, -- [49]
		nil, -- [50]
		nil, -- [51]
		nil, -- [52]
		nil, -- [53]
		nil, -- [54]
		nil, -- [55]
		nil, -- [56]
		nil, -- [57]
		nil, -- [58]
		nil, -- [59]
		nil, -- [60]
		nil, -- [61]
		"ffffffff", -- [62]
		nil, -- [63]
		"ffdd4aff", -- [64]
		"ffa8caff", -- [65]
		"fffff9ed", -- [66]
		nil, -- [67]
		"ffff4d5c", -- [68]
		nil, -- [69]
		nil, -- [70]
		nil, -- [71]
		"ff3f45ff", -- [72]
		[124] = "ff8000ff",
		[80] = "ff828ffd",
		[96] = "ff0009ff",
		[126] = "ff97f4ff",
	},
}
ClassicFCTVars = {
	["enabled"] = true,
	["hideBlizzHeals"] = true,
	["forceCVars"] = true,
	["hideBlizz"] = true,
	["lastVersion"] = "M0.87k",
	["selectedPreset"] = "Classic",
	["characterSpecificConfig"] = false,
}
ClassicFCTTables = {
	["filterSpellBlacklist"] = {
		["HUNTER"] = {
		},
		["WARRIOR"] = {
		},
		["ROGUE"] = {
		},
		["MAGE"] = {
		},
		["PRIEST"] = {
		},
		["DEATHKNIGHT"] = {
		},
		["EVOKER"] = {
		},
		["WARLOCK"] = {
		},
		["DEMONHUNTER"] = {
			[6603] = true,
			[378994] = true,
			[258921] = true,
			[258922] = true,
			[384117] = true,
			[377079] = true,
			[320334] = true,
		},
		["SHAMAN"] = {
		},
		["DRUID"] = {
		},
		["MONK"] = {
		},
		["PALADIN"] = {
		},
	},
	["mergeEventsIntervalOverrides"] = {
		["HUNTER"] = {
		},
		["WARRIOR"] = {
		},
		["ROGUE"] = {
		},
		["MAGE"] = {
		},
		["PRIEST"] = {
		},
		["DEATHKNIGHT"] = {
		},
		["EVOKER"] = {
		},
		["WARLOCK"] = {
		},
		["DEMONHUNTER"] = {
		},
		["SHAMAN"] = {
		},
		["DRUID"] = {
		},
		["MONK"] = {
		},
		["PALADIN"] = {
		},
	},
}
