
OmniCDDB = {
	["profileKeys"] = {
		["Taifunari - Blackmoore"] = "Default",
		["Allegory - Blackmoore"] = "Default",
		["Natinne - Blackmoore"] = "Default",
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
		["BattleRes"] = {
		},
	},
	["cooldowns"] = {
	},
	["version"] = 3,
	["profiles"] = {
		["Default"] = {
			["Party"] = {
				["party"] = {
					["extraBars"] = {
						["raidBar0"] = {
							["manualPos"] = {
								["raidBar0"] = {
									["y"] = 384.4500081260994,
									["x"] = 682.2166811461793,
								},
							},
						},
					},
				},
			},
		},
	},
}
