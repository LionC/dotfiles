
MADB = {
	["noMMMW"] = false,
	["autoShowNext"] = true,
	["characters"] = {
	},
	["alwaysShowNudger"] = false,
	["tooltips"] = true,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
			},
		},
	},
	["frameListRows"] = 18,
	["squareMM"] = false,
	["noBags"] = false,
	["playSound"] = false,
	["closeGUIOnEscape"] = false,
}
