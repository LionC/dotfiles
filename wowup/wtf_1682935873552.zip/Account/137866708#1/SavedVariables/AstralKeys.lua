
AstralKeys = {
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "ROGUE",
		["key_level"] = 20,
		["unit"] = "Happenslol-Blackmoore",
		["dungeon_id"] = 165,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 131451,
	}, -- [1]
	{
		["source"] = "guild",
		["weekly_best"] = 17,
		["class"] = "SHAMAN",
		["key_level"] = 6,
		["unit"] = "Happensbzzt-Blackmoore",
		["dungeon_id"] = 200,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 126304,
		["btag"] = "happens#21255",
	}, -- [2]
	{
		["source"] = "guild",
		["weekly_best"] = 2,
		["class"] = "DEATHKNIGHT",
		["key_level"] = 20,
		["unit"] = "Astranith-Blackmoore",
		["dungeon_id"] = 399,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 137434,
		["btag"] = "HostileFyr#2166",
	}, -- [3]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "PRIEST",
		["key_level"] = 18,
		["unit"] = "Nilandra-Blackmoore",
		["dungeon_id"] = 399,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 144341,
		["btag"] = "HostileFyr#2166",
	}, -- [4]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "PALADIN",
		["key_level"] = 20,
		["unit"] = "Aubry-Blackmoore",
		["dungeon_id"] = 210,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 143465,
	}, -- [5]
	{
		["btag"] = "HostileFyr#2166",
		["weekly_best"] = 17,
		["class"] = "DRUID",
		["key_level"] = 2,
		["unit"] = "Ludian-Blackmoore",
		["dungeon_id"] = 401,
		["week"] = 291,
		["faction"] = "0",
		["time_stamp"] = 51719,
		["source"] = "friend",
	}, -- [6]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "DEMONHUNTER",
		["key_level"] = 19,
		["unit"] = "Scahra-Blackmoore",
		["dungeon_id"] = 210,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 143434,
	}, -- [7]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "MONK",
		["key_level"] = 14,
		["unit"] = "Acumena-Blackmoore",
		["dungeon_id"] = 400,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 144341,
	}, -- [8]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "HUNTER",
		["key_level"] = 18,
		["unit"] = "Soosai-Blackmoore",
		["dungeon_id"] = 200,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 137152,
	}, -- [9]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "WARRIOR",
		["key_level"] = 2,
		["unit"] = "Carêless-Blackmoore",
		["dungeon_id"] = 401,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 3,
	}, -- [10]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "MONK",
		["key_level"] = 17,
		["unit"] = "Dyrell-Blackmoore",
		["dungeon_id"] = 165,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 3,
	}, -- [11]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "DEATHKNIGHT",
		["key_level"] = 15,
		["unit"] = "Selenerah-Blackmoore",
		["dungeon_id"] = 402,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 143446,
	}, -- [12]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "EVOKER",
		["key_level"] = 18,
		["unit"] = "Morrizane-Blackmoore",
		["dungeon_id"] = 2,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 131489,
	}, -- [13]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "SHAMAN",
		["key_level"] = 15,
		["unit"] = "Miotas-Blackmoore",
		["dungeon_id"] = 165,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 1,
	}, -- [14]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "HUNTER",
		["key_level"] = 14,
		["unit"] = "Bahyla-Blackmoore",
		["dungeon_id"] = 399,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 131471,
	}, -- [15]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "PALADIN",
		["key_level"] = 15,
		["unit"] = "Kendrana-Blackmoore",
		["dungeon_id"] = 2,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 8,
	}, -- [16]
	{
		["source"] = "guild",
		["weekly_best"] = 16,
		["class"] = "DRUID",
		["key_level"] = 15,
		["unit"] = "Caxivora-Blackmoore",
		["dungeon_id"] = 399,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 143461,
	}, -- [17]
	{
		["source"] = "guild",
		["weekly_best"] = 20,
		["class"] = "PRIEST",
		["key_level"] = 20,
		["unit"] = "Gorlirn-Blackmoore",
		["dungeon_id"] = 401,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 140201,
	}, -- [18]
	{
		["source"] = "guild",
		["weekly_best"] = 0,
		["class"] = "MAGE",
		["key_level"] = 20,
		["unit"] = "Hakizu-Blackmoore",
		["dungeon_id"] = 200,
		["week"] = 291,
		["faction"] = 0,
		["time_stamp"] = 131557,
	}, -- [19]
}
AstralCharacters = {
	{
		["weekly_best"] = 20,
		["class"] = "DEMONHUNTER",
		["unit"] = "Scahra-Blackmoore",
		["faction"] = 0,
	}, -- [1]
}
AstralKeysSettings = {
	["wipedOldTables"] = true,
	["general"] = {
		["show_minimap_button"] = {
			["isEnabled"] = true,
		},
		["init_time"] = 1677049200,
		["expanded_tooltip"] = {
			["isEnabled"] = true,
		},
		["report_on_message"] = {
			["raid"] = false,
			["party"] = true,
			["no_key"] = false,
			["guild"] = false,
		},
		["show_tooltip_key"] = {
			["isEnabled"] = true,
		},
		["announce_party"] = {
			["isEnabled"] = true,
		},
		["announce_guild"] = {
			["isEnabled"] = false,
		},
	},
	["frame"] = {
		["rank_filter"] = {
			true, -- [1]
			true, -- [2]
			true, -- [3]
			true, -- [4]
			true, -- [5]
			true, -- [6]
			true, -- [7]
			true, -- [8]
			true, -- [9]
			true, -- [10]
		},
		["current_list"] = "GUILD",
		["isCollapsed"] = {
			["isEnabled"] = false,
		},
		["orientation"] = 1,
		["mingle_offline"] = {
			["isEnabled"] = false,
		},
		["sorth_method"] = "character_name",
		["show_offline"] = {
			["isEnabled"] = true,
		},
	},
	["new_settings_config"] = true,
	["friendOptions"] = {
		["friend_sync"] = {
			["isEnabled"] = true,
		},
		["show_other_faction"] = {
			["isEnabled"] = true,
		},
	},
}
AstralMinimap = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Scahra - Blackmoore",
		["Zakarum - Blackmoore"] = "Zakarum - Blackmoore",
	},
	["profiles"] = {
		["Scahra - Blackmoore"] = {
			["minimap"] = {
				["minimapPos"] = 144.7910282153782,
			},
		},
		["Zakarum - Blackmoore"] = {
		},
	},
}
AstralAffixes = {
	["season_affix"] = 132,
	["season_start_week"] = 286,
}
AstralLists = {
	{
		["name"] = "GUILD",
		["units"] = {
			["Scahra-Blackmoore"] = true,
			["Moiyra-Blackmoore"] = "Miotas#2431",
			["Acumena-Blackmoore"] = true,
			["Aubry-Blackmoore"] = true,
			["Bahyla-Blackmoore"] = true,
			["Prîmecut-Blackmoore"] = true,
			["Malomedies-Blackmoore"] = "Miotas#2431",
			["Carêless-Blackmoore"] = true,
			["Dyrell-Blackmoore"] = true,
			["Allegory-Blackmoore"] = "Schneearie#2275",
			["Astrona-Blackmoore"] = "HostileFyr#2166",
			["Miotas-Blackmoore"] = true,
			["Soosai-Blackmoore"] = true,
			["Kalzifer-Blackmoore"] = "Miotas#2431",
			["Selenerah-Blackmoore"] = true,
			["Astranith-Blackmoore"] = "HostileFyr#2166",
			["Happenslol-Blackmoore"] = true,
			["Gorlirn-Blackmoore"] = true,
			["Nascha-Blackmoore"] = "Hakizu#2404",
			["Nilandra-Blackmoore"] = "HostileFyr#2166",
			["Caxivora-Blackmoore"] = true,
			["Kendrana-Blackmoore"] = true,
			["Morrizane-Blackmoore"] = true,
			["Hakizu-Blackmoore"] = true,
			["Akisu-Blackmoore"] = "Hakizu#2404",
			["Selendrenah-Blackmoore"] = true,
			["Happensbzzt-Blackmoore"] = "happens#21255",
		},
	}, -- [1]
	{
		["name"] = "FRIENDS",
		["units"] = {
			["Ludian-Blackmoore"] = "HostileFyr#2166",
			["Moiyra-Blackmoore"] = "Miotas#2431",
			["Acumena-Blackmoore"] = "Noxicon#2337",
			["Aubry-Blackmoore"] = "mhlz#2131",
			["Malomedies-Blackmoore"] = "Miotas#2431",
			["Dyrell-Blackmoore"] = "Hakizu#2404",
			["Astrona-Blackmoore"] = "HostileFyr#2166",
			["Diablerie-Blackmoore"] = "Noxicon#2337",
			["Kalzifer-Blackmoore"] = "Miotas#2431",
			["Akisu-Blackmoore"] = "Hakizu#2404",
			["Happenslol-Blackmoore"] = "happens#21255",
			["Gorlirn-Blackmoore"] = "reckter#2891",
			["Astranith-Blackmoore"] = "HostileFyr#2166",
			["Caxivora-Blackmoore"] = "Noxicon#2337",
			["Nascha-Blackmoore"] = "Hakizu#2404",
			["Morrizane-Blackmoore"] = "Miotas#2431",
			["Nilandra-Blackmoore"] = "HostileFyr#2166",
			["Hakizu-Blackmoore"] = "Hakizu#2404",
			["Miotas-Blackmoore"] = "Miotas#2431",
			["Allegory-Blackmoore"] = "Schneearie#2275",
			["Happensbzzt-Blackmoore"] = "happens#21255",
		},
	}, -- [2]
}
AstralUnits = nil
