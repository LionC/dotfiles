
SimulationCraftDB = {
	["profileKeys"] = {
		["Scahra - Blackmoore"] = "Scahra - Blackmoore",
		["Bhrian - Blackmoore"] = "Bhrian - Blackmoore",
		["Zakarum - Blackmoore"] = "Zakarum - Blackmoore",
	},
	["profiles"] = {
		["Scahra - Blackmoore"] = {
			["minimap"] = {
				["minimapPos"] = 198.5177456548694,
			},
		},
		["Bhrian - Blackmoore"] = {
		},
		["Zakarum - Blackmoore"] = {
		},
	},
}
